# Build and reproduction

## Paper

The PDF `rvm_zeta_pi_mertens_v26.pdf` is included. To rebuild it from source:

```bash
./build_pdf.sh
```

or `make pdf`.  The build runs `pdflatex` three times so that the table of contents, cross-references,
back-references and hover annotations are resolved.  All PNG figures required by the TeX source are in
`figures/`.  After editing the TeX, regenerate the hover tooltips: compile twice, then
`python3 tools/make_tips.py rvm_zeta_pi_mertens_v26.tex rvm_zeta_pi_mertens_v26.aux tips.tex && python3 tools/replace_tips.py rvm_zeta_pi_mertens_v26.tex tips.tex`,
then compile three times.

## Numerical programs

```bash
python3 -m pip install -r code/requirements.txt
```

`code/requirements.txt` pins the versions used for every distributed output (Python 3.13.16, NumPy 2.5.3,
SciPy 1.18.1, mpmath 1.4.1, Matplotlib 3.11.2, finufft 2.5.1, Linux x86_64).

The raw ordinate data used by `s01`--`s13` and `s15`--`s17` are NOT included in this package, nor is the large
output `output/s05_walks.csv`:

- `data/zeross.bin`
- `data/zLamb.bin`

(format and checks in `data/README.md`).  With the two files in `data/`, run all main programs in the required
order with

```bash
./run_all_python.sh
```

Tables are written to `output/` and figures to `figures/`.  `s14_varpi_bound.py` needs no data file.

## Route B programs

Run from `output/routeB/` (they need no data file; `zeros.py` computes 400 zeta ordinates with mpmath for the
diagnostic columns only):

```bash
cd output/routeB
python3 ../../code/routeB/zeros.py 400
python3 ../../code/routeB/gonek_fast.py 8 1400
python3 ../../code/routeB/horizonG.py 16 2.4 4 > out_horizonG.txt
python3 ../../code/routeB/cert7.py > out_cert7.txt
python3 ../../code/routeB/diag_cert7_gamma.py > out_cert7_gamma.txt
python3 ../../code/routeB/entry.py > out_entry.txt
python3 ../../code/routeB/laplace_check.py > out_laplace_check.txt
python3 ../../code/routeB/figs.py
python3 ../../code/routeB/results_summary.py
```

## MATLAB

`matlab/s15_tables_1000.m` and `matlab/s16_walks_3d_1000.m` reproduce `s15` and `s16` (function definition
first, figures left open, PNG output; `s15` uses `nufft`, R2020a or later).  `matlab/txt/` holds `.txt` copies.

## Integrity

`MANIFEST_SHA256.txt` contains SHA-256 hashes for every file in this package except the manifest itself.
