# Entry step of the staged construction measured in l^2 as well as in l^infinity.
# Same sections, tests (Gaussians), starting points and square selections as entry.py; for each of the
# band-only and full square systems the Banach test for T(x) = x - Q F(x) is evaluated in both norms:
#   l(r) = d0 + ||Q B|| r + (1/2) || |Q| A3(r) || r^2 < 1  and  ||Q F(x0)|| <= (1 - l(r)) r,
# with d0 = ||I - Q J||, B the diagonal-structured matrix of second derivatives and A3(r) an entrywise
# bound for the third derivatives on the ball.  In l^2 the second-order term is bounded by
# ||Q B diag(e)||_2 <= ||Q B||_2 ||e||_inf <= ||Q B||_2 ||e||_2, so the same inequality with 2-norms
# certifies a zero in the l^2 ball, hence in the l^infinity ball of the same radius.
# Double precision throughout (floating-point evidence, not a proof).  The zeta ordinates are not used.
import numpy as np, json
from scipy.linalg import qr, solve
from core import *
tau=clock(60000)
q,s0,sp,INT=0.85,0.08,1.0,2.4
def d2(c,s,k):
    a=s*s; e=s*SQ2PI*np.exp(-a*k*k/2)
    return e*(((a*k)**2-a-c*c)*np.cos(c*k)+2*a*k*c*np.sin(c*k))
def A3b(c,s,k,r):
    a=s*s; kl=np.maximum(np.abs(k)-r,0); ku=np.abs(k)+r; w=a*ku+c
    return s*SQ2PI*np.exp(-a*kl*kl/2)*(w**3+3*a*w)
def nrm(M,p): return float(np.max(np.sum(np.abs(M),axis=1))) if p=='inf' else float(np.linalg.norm(M,2))
def vn(v,p): return float(np.max(np.abs(v))) if p=='inf' else float(np.linalg.norm(v))
def test(Q,F,B,A3fun,J,p):
    n=Q.shape[0]; d0=nrm(np.eye(n)-Q@J,p); QB=nrm(Q@B,p); eta=vn(Q@F,p)
    radii=np.geomspace(1e-9,1e-1,80)
    ls=[d0+QB*r+0.5*nrm(np.abs(Q)@A3fun(r),p)*r*r for r in radii]
    marg=max((1-l)*r for l,r in zip(ls,radii))
    ok=any(l<1 and eta<=(1-l)*r for l,r in zip(ls,radii))
    return eta,marg,ok,nrm(Q,p),QB
rG=np.load('gonekF_X8.npy'); kG=tau.copy(); kG[:len(rG)]=rG
tests=[]; lev=[]; out=[]; prev=None
for m in range(1,16):
    s=s0*q**(m-1); T=4.0/s; U=np.log(max(T,7)/(2*np.pi))+2.0
    new=[(float(c),s) for c in np.arange(9*s,U+1e-9,sp*s)]; tests+=new; lev+=[m]*len(new)
    n=int(np.sum(tau<=INT/s)); cs=np.array([t[0] for t in tests]); ss=np.array([t[1] for t in tests]); lv=np.array(lev)
    if prev is not None:
        x0=kG.copy(); x0[:prev[1]]=prev[0][:prev[1]]
        band=np.arange(prev[1],n); idx=np.where(lv==m)[0]
        Jb=dFphi(cs[idx][:,None],ss[idx][:,None],x0[None,band]); _,_,pv=qr(Jb.T,pivoting=True); sb=idx[np.sort(pv[:len(band)])]
        Jbs=dFphi(cs[sb][:,None],ss[sb][:,None],x0[None,band]); Qb=solve(Jbs,np.eye(len(band))); Fb=residual([tests[i] for i in sb],x0)
        Bb=d2(cs[sb][:,None],ss[sb][:,None],x0[None,band]); A3f=lambda r: A3b(cs[sb][:,None],ss[sb][:,None],x0[None,band],r)
        J=dFphi(cs[:,None],ss[:,None],x0[None,:n]); _,_,pv=qr(J.T,pivoting=True); sf=np.sort(pv[:n])
        Jf=J[sf]; Qf=solve(Jf,np.eye(n)); Ff=residual([tests[i] for i in sf],x0)
        Bf=d2(cs[sf][:,None],ss[sf][:,None],x0[None,:n]); A3g=lambda r: A3b(cs[sf][:,None],ss[sf][:,None],x0[None,:n],r)
        rec=dict(m=m,T=T,band=len(band),n=n)
        line=f"m={m:2d} T={T:5.0f} band={len(band):2d} n={n:3d}"
        for name,(Q,F,B,A,Jm) in (("band",(Qb,Fb,Bb,A3f,Jbs)),("full",(Qf,Ff,Bf,A3g,Jf))):
            for p in ('inf','2'):
                eta,marg,ok,LQ,QB=test(Q,F,B,A,Jm,p)
                rec[f"{name}_{p}"]=dict(eta=eta,margin=marg,float_pass=bool(ok),normQ=LQ,QB=QB)
                line+=f" | {name} l{p}: |QF|={eta:.1e} margin={marg:.1e} |Q|={LQ:.1e} {'PASS' if ok else 'no'}"
        out.append(rec); print(line,flush=True)
    kk=kG.copy() if prev is None else x0.copy()
    J=dFphi(cs[:,None],ss[:,None],kk[None,:n]); _,_,pv=qr(J.T,pivoting=True); sel=np.sort(pv[:n]); tsel=[tests[i] for i in sel]
    try:
        for it in range(10):
            Jc=dFphi(cs[sel][:,None],ss[sel][:,None],kk[None,:n]); kk[:n]-=np.linalg.solve(Jc,residual(tsel,kk))
    except np.linalg.LinAlgError: print("singular at",m); break
    prev=(kk.copy(),n)
json.dump(out,open('entry2.json','w'),indent=1)
