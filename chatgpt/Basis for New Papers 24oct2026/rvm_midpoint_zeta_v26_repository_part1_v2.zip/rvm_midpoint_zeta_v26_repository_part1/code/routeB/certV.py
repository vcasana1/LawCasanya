# Verified certificates for square sections of the rung system with prescribed von Mangoldt masses,
# with compactly supported B-spline tests and ball arithmetic (python-flint / Arb).
#
# Tests.  phi_{c,h}(u) = N_R((u-c)/h + R/2), with N_R the cardinal B-spline of order R = 8 on [0,R]
# (piecewise polynomial of degree R-1, class C^{R-2} = C^6, support [c-Rh/2, c+Rh/2] inside (0,inf)).
# Its cosine transform is c_phi(t) = h cos(ct) (sin(ht/2)/(ht/2))^R, and |c_phi(t)| <= h (2/(ht))^R.
# Stage m: s_m = 0.08*0.85^(m-1), h_m = s_m*sqrt(12/R) (same variance as the Gaussian of width s_m used
# before), centres c in [9 s_j, log(max(T_j,7)/2pi)+2] in steps of s_j for every level j <= m, T_j = 4/s_j.
# Unknowns: the interior ordinates kappa_k with tau_k <= 2.4/s_m (n of them).  Frozen list: the receding-
# horizon iterate kappa^H (double precision numbers, taken as exact) for n < k <= 60000, the midpoint
# clock tau_k beyond.  Square system: n tests chosen by pivoted QR on J^T at kappa^H.
#
# Float phase (double precision): Newton polishing of the square system from kappa^H.
# Ball phase (Arb, 128 bits): every quantity below is an enclosure.
#   F_j(x) = sum_{k<=n} c_j(x_k) + sum_{n<k<=60000} c_j(kappa^H_k) + [tail over k>60000, bounded]
#            + sum_n Lambda(n)/(2 sqrt n) phi_j(log n) - <k, phi_j>,
#   <k,phi> by acb.integral on the R polynomial pieces of phi; tail by
#   sum_{k>K} |c_j(tau_k)| <= h (pi a h)^(-R) (log K)^R K^(1-R) / ((R-1)(1 - R/((R-1) log K))),
#   from tau_k >= 2 pi a k / log k (W(x) <= log x for x >= e), a = 1 - 11/(8K), and the integral test.
#   Two Newton refinements x <- x - Q mid F(x) in Arb (Q = float inverse of the square Jacobian, exact as a
#   matrix of doubles).  Krawczyk/Banach test on the l^infinity ball B = B(x1, rho):
#     l(rho) >= sup_{x in B} ||I - Q J(x)||  (J evaluated on the ball, interval matrix product),
#     eta >= ||Q F(x1)||;  if l(rho) < 1 and eta <= (1 - l(rho)) rho, then x -> x - Q F(x) maps B into
#     itself and contracts, Q is invertible, and F has exactly one zero in B.
# Diagnostics: ordering of the solution (gaps > 2 rho), tube constant max|x_k - tau_k| + rho (tau_k by
# Arb's Lambert W), and the distance to the zeta ordinates gamma_k computed in Arb (acb.zeta_zero,
# rigorous enclosures); the zeros are used only for this diagnostic, after the certificate.
# Bound eps of Proposition rb-nonfinitary for every test of the stage (r = R-1 = 7, H0 = 3e12): the residual
# of the zeta list with the von Mangoldt masses on these tests is at most eps whether or not RH holds.
# A sampled lower bound for the verified margin: max over rho in a grid of (1 - l(rho)) rho, each value
# rigorous.  Output: out_certV.txt (console), certV.json, certV_points.npz (centres as doubles),
# certV_centres.json (exact binary centres and radii of the verified balls).
import numpy as np, json, time
from math import comb, factorial
from scipy.linalg import qr
from scipy.special import lambertw
from flint import arb, acb, arb_mat, ctx
ctx.prec = 128
R = 8
K = 60000
kH = np.load('horizonG_kap_M16_I2.4.npy')
assert len(kH) == K and np.all(np.diff(kH) > 0)
kk = np.arange(1, K + 2); tauF = np.real(2 * np.pi * (kk - 11 / 8) / lambertw((kk - 11 / 8) / np.e))
assert kH[-1] < tauF[K] - 0.5            # the frozen list followed by the clock is increasing
q, s0, sp, INT = 0.85, 0.08, 1.0, 2.4
import sys
MSTAGES = int(sys.argv[1]) if len(sys.argv) > 1 else 16

# ---------------- float part ----------------
def sinc(x): return np.sin(x) / x
def dsinc(x): return (x * np.cos(x) - np.sin(x)) / (x * x)
def cphi(c, h, t):
    x = h * t / 2
    return h * np.cos(c * t) * sinc(x) ** R
def dcphi(c, h, t):
    x = h * t / 2; S = sinc(x)
    return h * (-c * np.sin(c * t) * S ** R + np.cos(c * t) * R * S ** (R - 1) * dsinc(x) * h / 2)
BIN = np.array([comb(R, j) for j in range(R + 1)], float); FAC = float(factorial(R - 1))
def NR_float(x):
    x = np.asarray(x, float); out = np.zeros_like(x)
    for j in range(R + 1):
        y = x - j; out += (-1) ** j * BIN[j] * np.where(y > 0, y, 0.0) ** (R - 1)
    out /= FAC; out[(x <= 0) | (x >= R)] = 0.0
    return out
def kfun(u): return np.cosh(u / 2) - np.exp(-u / 2) / (2 * (1 - np.exp(-2 * u)))
GLx, GLw = np.polynomial.legendre.leggauss(40)
def kpair_float(c, h):
    tot = 0.0
    for i in range(R):
        x = i + (GLx + 1) / 2; u = c + h * (x - R / 2)
        tot += np.sum(GLw / 2 * kfun(u) * NR_float(x))
    return h * tot
def vonmangoldt(N):
    L = np.zeros(N + 1)
    sieve = np.ones(N + 1, bool); sieve[:2] = False
    for p in range(2, N + 1):
        if sieve[p]:
            sieve[p * p::p] = False
            pk = p
            while pk <= N: L[pk] = np.log(p); pk *= p
    return L
LAM = vonmangoldt(20000)
def nrange(c, h):
    lo = max(2, int(np.floor(np.exp(c - R * h / 2)))); hi = int(np.ceil(np.exp(c + R * h / 2)))
    return np.arange(lo, hi + 1)
def masspair_float(c, h):
    n = nrange(c, h); a = LAM[n] / (2 * np.sqrt(n))
    return np.sum(a * NR_float((np.log(n) - c) / h + R / 2))
_fcache = {}
def frozen_float(c, h, n0):
    key = (c, h)
    if key not in _fcache: _fcache[key] = np.cumsum(cphi(c, h, kH)[::-1])[::-1]   # suffix sums
    S = _fcache[key]
    return S[n0] if n0 < K else 0.0
_kc = {}
def const_float(c, h):
    if (c, h) not in _kc: _kc[(c, h)] = masspair_float(c, h) - kpair_float(c, h)
    return _kc[(c, h)]
def F_float(tests, x, n):
    return np.array([np.sum(cphi(c, h, x[:n])) + frozen_float(c, h, n) + const_float(c, h) for c, h in tests])
def J_float(tests, x, n):
    cs = np.array([t[0] for t in tests])[:, None]; hs = np.array([t[1] for t in tests])[:, None]
    return dcphi(cs, hs, x[None, :n])

# ---------------- ball part ----------------
PI = arb.pi()
def a_(v): return arb(v)
def cphi_b(c, h, t):
    x = h * t / 2
    return h * (c * t).cos() * (x.sin() / x) ** R
def dcphi_b(c, h, t):
    x = h * t / 2; sx, cx = x.sin(), x.cos(); S = sx / x; dS = (x * cx - sx) / (x * x)
    return h * (-c * (c * t).sin() * S ** R + (c * t).cos() * R * S ** (R - 1) * dS * h / 2)
BINb = [arb(comb(R, j)) for j in range(R + 1)]; FACb = arb(factorial(R - 1))
def tpow_b(y):            # (y)_+^(R-1) for a ball y
    if y > 0: return y ** (R - 1)
    if y < 0: return arb(0)
    up = y.upper()
    up = up if up > 0 else arb(0)
    return arb(0).union(up ** (R - 1))
def NR_b(x):
    tot = arb(0)
    for j in range(R + 1): tot += (-1) ** j * BINb[j] * tpow_b(x - j)
    return tot / FACb
def piece_poly(i):
    # polynomial of N_R on [i, i+1]: (1/(R-1)!) sum_{j<=i} (-1)^j C(R,j) (x-j)^(R-1)
    def P(x):
        tot = acb(0)
        for j in range(i + 1): tot += (-1) ** j * comb(R, j) * (x - j) ** (R - 1)
        return tot / factorial(R - 1)
    return P
PIECES = [piece_poly(i) for i in range(R)]
def kpair_b(c, h):
    cb, hb = acb(c), acb(h); tot = acb(0)
    for i in range(R):
        P = PIECES[i]
        def f(x, analytic, P=P):
            u = cb + hb * (x - R / 2)
            return ((u / 2).cosh() - (-u / 2).exp() / (2 * (1 - (-2 * u).exp()))) * P(x)
        tot += acb.integral(f, i, i + 1)
    v = tot * hb
    assert abs(v.imag) < 1e-30
    return v.real
def logp_b(n):
    for p in range(2, n + 1):
        if n % p == 0:
            m = n
            while m % p == 0: m //= p
            return arb(p).log() if m == 1 else None
def masspair_b(c, h):
    cb, hb = arb(c), arb(h); tot = arb(0)
    for n in nrange(c, h):
        n = int(n); lp = logp_b(n)
        if lp is None: continue
        x = ((arb(n).log() - cb) / hb) + R / 2
        if x < 0 or x > R: continue
        tot += lp / (2 * arb(n).sqrt()) * NR_b(x)
    return tot
aK = 1 - arb(11) / (8 * K); LK = arb(K).log()
TAILI = LK ** R * arb(K) ** (1 - R) / ((R - 1) * (1 - arb(R) / ((R - 1) * LK)))
def tail_b(h):
    hb = arb(h); return hb * (PI * aK * hb) ** (-R) * TAILI
_bfroz = {}
def frozen_b(c, h, n0, N1=1000):
    # sum_{n0<k<=K} c(kH_k) + ball for the clock tail k>K; the part k>N1 is cached per test
    key = (c, h); cb, hb = arb(c), arb(h)
    if key not in _bfroz:
        s = arb(0)
        for t in kH[N1:]: s += cphi_b(cb, hb, arb(float(t)))
        _bfroz[key] = s
    s = _bfroz[key]
    for t in kH[n0:N1]: s += cphi_b(cb, hb, arb(float(t)))
    tb = tail_b(h)
    return s + arb(0, tb.upper())
def tau_b(k):
    a = arb(k) - arb(11) / 8
    return 2 * PI * a / (a / arb(1).exp()).lambertw()
H0 = arb(3) * arb(10) ** 12; RF = R - 1
def eps_bound(c, h):
    # Proposition rb-nonfinitary with r = R-1: |<R(gamma, a^zeta), phi>| <= r/(4(r-1)) W_r(phi) H0^(1-r) log H0,
    # W_r(phi) <= (1+u*^2) cosh(u*/2) h (1+2/h)^r for phi = N_R((u-c)/h + R/2), u* = c + R h/2
    hb = arb(h); us = arb(c) + R * hb / 2
    W = (1 + us * us) * (us / 2).cosh() * hb * (1 + 2 / hb) ** RF
    return float((arb(RF) / (4 * (RF - 1)) * W * H0 ** (1 - RF) * H0.log()).upper())
def norm_inf_upper(M, n, m):
    best = 0.0
    for i in range(n):
        r = arb(0)
        for j in range(m): r += M[i, j].abs_upper()
        best = max(best, float(r.upper()))
    return best

# ---------------- the frozen list, rigorously ----------------
# kappa^H is strictly increasing (exact comparison of doubles), its last entry lies below tau_{K+1}, and
# |kappa^H_k - tau_k| <= FROZEN_TUBE for all k <= K, with tau_k enclosed by Arb's Lambert W.
t0 = time.time()
FROZEN_TUBE = 0.0
for k in range(1, K + 1):
    d = float(abs(arb(float(kH[k - 1])) - tau_b(k)).upper())
    if d > FROZEN_TUBE: FROZEN_TUBE = d
assert arb(float(kH[-1])) < tau_b(K + 1)
print(f"frozen list: increasing, max_k<={K} |kappa^H_k - tau_k| <= {FROZEN_TUBE:.6f}, kappa^H_K < tau_(K+1)  ({time.time()-t0:.0f}s)", flush=True)

# ---------------- stages ----------------
tests = []; out = []; points = {}; centres = {}   # centres: exact binary centres x_1 = man * 2^exp of the verified balls
t_start = time.time()
for m in range(1, MSTAGES + 1):
    ts = time.time()
    s = s0 * q ** (m - 1); h = s * np.sqrt(12.0 / R); T = 4.0 / s; U = np.log(max(T, 7) / (2 * np.pi)) + 2.0
    tests += [(float(c), float(h)) for c in np.arange(9 * s, U + 1e-9, sp * s)]
    n = int(np.sum(tauF[:K] <= INT / s))
    J = J_float(tests, kH, n); _, _, piv = qr(J.T, pivoting=True); sel = np.sort(piv[:n]); tsel = [tests[i] for i in sel]
    x = kH.copy(); ok = True
    try:
        for it in range(12):
            Fx = F_float(tsel, x, n); x[:n] -= np.linalg.solve(J_float(tsel, x, n), Fx)
    except np.linalg.LinAlgError:
        ok = False
    Fx = F_float(tsel, x, n); Jx = J_float(tsel, x, n)
    condJ = np.linalg.cond(Jx) if ok else np.inf
    if not ok or not np.all(np.isfinite(x[:n])) or np.max(np.abs(Fx)) > 1e-8 or condJ > 1e14:
        print(f"m={m:2d} T={T:5.0f} n={n:3d} float Newton polishing failed (max|F|={np.max(np.abs(Fx)):.1e}, cond={condJ:.1e})", flush=True)
        out.append(dict(m=m, T=T, n=n, verified=False, reason="float polishing failed")); break
    Q = np.linalg.solve(Jx, np.eye(n))
    x0 = x[:n].copy()
    # ---- ball phase ----
    Qb = arb_mat(n, n, [float(v) for v in Q.ravel()])
    const = []
    for c, hh in tsel:
        const.append(frozen_b(c, hh, n) + masspair_b(c, hh) - kpair_b(c, hh))
    xb = [arb(float(v)) for v in x0]
    def Fint(xb):
        return [sum((cphi_b(arb(c), arb(hh), xk) for xk in xb), arb(0)) + const[j] for j, (c, hh) in enumerate(tsel)]
    F0 = Fint(xb)
    for ref in range(2):                       # Newton refinements in ball arithmetic (midpoints kept)
        Fv = arb_mat(n, 1, [f.mid() for f in F0]); dx = Qb * Fv
        xb = [arb((xb[k] - dx[k, 0]).mid()) for k in range(n)]
        F0 = Fint(xb)
    Fv = arb_mat(n, 1, F0); QF = Qb * Fv
    eta = max(float(QF[k, 0].abs_upper().upper()) for k in range(n))
    Frad = max(float(f.rad()) for f in F0)
    def lfun(rho):
        Jb = arb_mat(n, n, [dcphi_b(arb(c), arb(hh), xb[k] + arb(0, rho)) for (c, hh) in tsel for k in range(n)])
        M = arb_mat(n, n, [1 if i == j else 0 for i in range(n) for j in range(n)]) - Qb * Jb
        return norm_inf_upper(M, n, n)
    rho = max(4 * eta, 1e-34); l = lfun(rho)
    verified = (l < 1) and (eta <= (1 - l) * rho)
    d0 = lfun(0.0)
    grid = list(np.geomspace(1e-8, 1e-1, 36))
    margins = []
    for r_ in grid:
        lr = lfun(r_); margins.append((r_, lr, (1 - lr) * r_ if lr < 1 else 0.0))
    vmargin = max(mg[2] for mg in margins)
    xm = np.array([float(v.mid()) for v in xb])
    gaps = np.diff(np.concatenate([xm, [kH[n]]]))
    order_ok = bool(np.min(gaps) > 2 * rho + 1e-300)
    taub = [tau_b(k) for k in range(1, n + 1)]
    tube = max(float(abs(xb[k] - taub[k]).upper()) for k in range(n)) + rho
    gam = [acb.zeta_zero(k).imag for k in range(1, n + 1)]
    dg = [float(abs(xb[k] - gam[k]).upper()) + rho for k in range(n)]
    Linf = float(np.max(np.sum(np.abs(Q), axis=1)))
    allres = F_float(tests, x, n); rho_all = float(np.max(np.abs(allres)))
    eps_sel = max(eps_bound(c, hh) for c, hh in tsel); eps_all = max(eps_bound(c, hh) for c, hh in tests)
    points[f'm{m}'] = xm
    centres[f'm{m}'] = dict(rho=rho, centre_man_exp=[[int(a), int(b)] for a, b in (v.mid().man_exp() for v in xb)])
    rec = dict(m=m, T=T, n=n, R=R, h=h, n_tests_level_le_m=len(tests), verified=bool(verified), rho=rho, l_rho=l, eta=eta,
               defect_upper=d0, Frad=Frad, Linf=Linf, verified_margin_lower=vmargin,
               margins=[dict(r=a, l=b, margin=c_) for a, b, c_ in margins], order_ok=order_ok,
               min_gap=float(np.min(gaps)), tube=tube, max_dist_gamma=max(dg), max_dist_gamma_k_le_20=max(dg[:20]),
               rho_all_float=rho_all, eps_zeta_selected=eps_sel, eps_zeta_all_tests=eps_all, seconds=time.time() - ts)
    out.append(rec)
    print(f"m={m:2d} T={T:5.0f} n={n:3d} h={h:.4f} | {'VERIFIED' if verified else 'not verified'} rho={rho:.2e} l(rho)={l:.2e} "
          f"eta={eta:.2e} ||I-QJ||<={d0:.1e} ||Q||={Linf:.1e} margin>={vmargin:.1e} | order={'ok' if order_ok else 'NO'} "
          f"mingap={np.min(gaps):.3f} tube<={tube:.3f} | max|x-gamma|<={max(dg):.1e} (k<=20: {max(dg[:20]):.1e}) | "
          f"float residual all tests<=m {rho_all:.1e} | zeta-list bound eps<={eps_all:.1e} | {time.time()-ts:.0f}s", flush=True)
    json.dump(out, open('certV.json', 'w'), indent=1); np.savez('certV_points.npz', **points)
    json.dump(centres, open('certV_centres.json', 'w'))
json.dump(out, open('certV.json', 'w'), indent=1); np.savez('certV_points.npz', **points)
print(f"total {time.time()-t_start:.0f}s")
