# Version 26 (15 October 2026)

Source: the request to strengthen Route B (Section "Route B for finite sections") with the improvements planned in
`claude/notas-v24-plan-paper-C.md`, and the combination of Route B with the exponential sums over the ordinates
(Cramér's function, the window form of RH).  Base: the v25 manuscript.

## Manuscript: Route B, uniqueness

* Hypothesis U (uniqueness in the box) is now a theorem.  New Lemma `lem:rb-mass-ms`: for an exact solution of
  the rung system with ordinates in a tube and arbitrary real masses, sum_{X<n<=2X} a_n^2 << X^eps (one test of
  width 1/X isolates each mass; the remaining exponential sum over the ordinates is bounded by a Sobolev-type
  inequality and the local mean value lemma).  New Theorem `thm:rb-uniqueness`: such a solution is the zeta list
  with the von Mangoldt masses, and RH holds (Proposition rung-apriori with t = 1 gives b = 0 and the Euler form;
  the lemma gives abscissa 1; Hamburger's theorem).  Corollaries `cor:rb-U`, `cor:rb-selection` (without U),
  `cor:rb-equivalence` (B(C,M) <=> (D)); Remark `rem:rb-uniqueness-input` (what replaces the third condition of O).
  The remarks on the logical status, on prescribed masses and on the bearing of the obstruction were rewritten.
* New Proposition `prop:rb-nonfinitary` (subsubsection "Finite stages do not decide route B"): without hypothesis,
  |<R(gamma, a^zeta), f>| <= r/(4(r-1)) W_r(f) H0^(1-r) log H0 with H0 = 3e12 (Platt-Trudgian;
  Hasanalizade-Shen-Wong for N(T)); so every finite stage has sections with residual of that size whether or not
  RH holds.  Remark `rem:rb-nonfinitary`.  This replaces the heuristic reading (i) of the numerics.

## Manuscript: Route B on a window (new subsection `subsec:rb-window`)

* Lemma `lem:rb-peel` (Laplace transforms against the zeros; positivity on the side of the unknown measure).
* Theorem `thm:rb-window-unknown`: an unknown list reproducing Cramér's function on one window without prime
  powers exists iff RH, and then it is the zeta list (Lemma edge + peeling; no masses, no tube, no Hamburger).
* Theorem `thm:rb-bernstein`: RH <=> y -> exp(-iy/2) V_+(iy) is completely monotone (Bernstein's theorem +
  peeling).  Literature not searched; novelty not claimed.
* Lemma `lem:rb-minimizer` (minimizers of the window residual in the compact box: exact solution on the window, or
  interior coordinates on at most (u2/log 2) r + c distinct values, by Jensen's formula) and Theorem
  `thm:rb-window-equivalence` (RH <=> solvability on every window in a fixed box); Remark `rem:rb-minimizer-open`.
* Heuristic `heur:rb-window-zerofree`: window solvability on (0,U) would exclude zeros with
  |d| >~ log(C log gamma)/U; open points (clustered zeros off the line; the converse) stated.

## Manuscript: Route B, numerics

* New subsubsection `subsec:rb-num-verified`: B-spline tests of order 8 (transform, C^2 admissibility of tests,
  density of B-splines in C^2), sections, clock-tail bound, ball arithmetic (Arb through python-flint), Krawczyk
  form of the Banach test.  New Theorem `thm:rb-verified` (computer-assisted): the square sections of fifteen
  stages, up to T = 487, have exactly one zero in explicit balls (radii 6.4e-21 to 1.1e-12), strictly increasing,
  0.995-admissible; rigorous distances to the zeta ordinates.  Table `tab:rb-verified` (upper bounds rounded up,
  lower bounds down).  Remark `rem:rb-verified` (no bearing on RH by Proposition rb-nonfinitary).
* Entry step: the same test in l2 (margins larger by factors 1.0-2.8; the pass/fail pattern is unchanged).
* Reading (i) rewritten with Proposition rb-nonfinitary.

## Manuscript: literature

* Remark `rem:rb-price`: Hruščev-Nikol'skii-Pavlov (via Kozma-Lev, Thm 5.1), Avdonin with fixed block length
  (Kozma-Lev, Thm 3.3); the variable-length version was not found in the sources consulted (weak evidence).
* New Remark `rem:rb-obstruction-literature`: Bondarenko-Radchenko-Seip, Fourier interpolation with zeros of zeta.
* Bibliography: HruscevNikolskiiPavlov1981, KozmaLev2011, BondarenkoRadchenkoSeip2023, Johansson2017,
  Johansson2018, Bernstein1929, Widder1941, Conrey1989 (DOIs checked against Crossref or the publisher).

## Manuscript: global

* Abstract, introduction table, section introduction, section status table, conclusions (lists of equivalences
  and of open statements, dependence table, new results), notation table, software versions, Route B appendix.
* Corrected the numbering in the conclusions: statements (1)-(41) and (43)-(51) are unconditional and (42)
  assumes RH (the text said (1)-(40), (42)-(50) and (41)).
* Section title: "Route B for finite sections: compactness, uniqueness, certificates, and a Kadec-Avdonin
  criterion with blocks of variable length".

## Check

An independent referee pass (a subagent of the same model that had not seen the work being produced; report and
resolution in `review/V26_REFEREE_CHECK.md`) checked the proofs of
Lemma rb-mass-ms, Theorem rb-uniqueness and its corollaries, Proposition rb-nonfinitary, Lemma rb-peel, Theorems
rb-window-unknown and rb-bernstein, Lemma rb-minimizer and Theorem rb-window-equivalence and found them correct.
Its remarks led to: real test functions in Lemma rb-minimizer; the precision qualifier in the statements that no
finite computation decides route B; "no sum over the zeros" instead of "data from the primes only" for the
Bernstein form; a justification of the non-vanishing gradient at the zeta list (Remark rb-minimizer-open, with
Conrey's simple zeros); the drift sentence in Remark rb-uniqueness-input; and a third open point and the window
(U^-1, U) in Heuristic rb-window-zerofree.

## Code and outputs

* New `code/routeB/certV.py` (ball arithmetic; console `out_certV.txt`, `certV.json`, `certV_points.npz`,
  `certV_centres.json` with the exact centres of the verified balls).
* New `code/routeB/entry2.py` (entry test in l-inf and l2; `out_entry2.txt`, `entry2.json`).
* `results_summary.py` extended; `RESULTS.txt` regenerated; `requirements.txt` adds python-flint 0.9.0;
  `.txt` copies of the new and changed programs.
