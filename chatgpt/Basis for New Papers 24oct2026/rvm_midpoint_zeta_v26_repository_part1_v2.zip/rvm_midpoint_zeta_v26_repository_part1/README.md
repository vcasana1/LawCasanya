# The midpoint Riemann-von Mangoldt synthetic zeta system

Paper, code, data description and results for

> Rotkiv Aynäsac, *The midpoint Riemann-von Mangoldt synthetic zeta system: canonical products,
> exponential sums, prime counts, Mertens transforms, and the transformation to zeta_Z1*
> (15 October 2026, version 25).

The manuscript is `rvm_zeta_pi_mertens_v26.tex` (single file); `rvm_zeta_pi_mertens_v26.txt` is an identical
copy and `rvm_zeta_pi_mertens_v26.pdf` the compiled paper.  Sections are referred to below by their titles.

## What is constructed

* The **midpoint clock** (due to Franca and LeClair, arXiv:1307.8395, Eqs. (24)-(25))
  `N_RVM(T) = T/(2 pi) log(T/(2 pi e)) + 7/8`, the smooth part of the Riemann-von Mangoldt formula
  `N(T) = N_RVM(T) + S(T) + O(1/T)`.  Its **midpoint ordinates** `tau_k` solve `N_RVM(tau_k) = k - 1/2`;
  in closed form `tau_k = 2 pi (k - 11/8) / W_0((k - 11/8)/e)` with the principal Lambert branch `W_0`.
* `zeta_RVM(s) = prod_k (1 + s(s-1)/(1/4 + tau_k^2)) / G(s)`, `G(s) = s(s-1) Gamma(s/2) pi^(-s/2)`,
  with zeros exactly at `1/2 +- i tau_k`.  The transition constant satisfies `0 < varpi_RVM < 0.9796`
  (theorem, with the explicit inequalities checked in interval arithmetic by `code/s14_varpi_bound.py`);
  its floating-point value is `0.9619415789`.
* **Exponential sums over the ordinates of zeta**: Cramer's function `V_+` with a zero-free representation,
  the defect as a sum over the zeros off the line, RH at one imaginary frequency, the window form of RH on
  `(log 2, log 3)`, the endpoint rung functional, the Frullani form, the clock centroid (without hypothesis)
  and the ordinate centroid (under RH).
* **Prime coordinate**: `J_RVM` (explicit formula with the `tau_k`), `pi_RVM` (finite Moebius inversion;
  a real-valued function, not an integer count), cell masses `c_n = pi_RVM(n) - pi_RVM(n-1)`, real RVM prime
  levels `p_j^RVM` (first crossings `inf{x : pi_RVM(x) >= j}`).  Unconditionally
  `pi_RVM(x) - li(x) = O(sqrt(x) (log log x)^2 / log x)`.
* **Mertens coordinate**: `M_RVM^crit`, the inverse Mellin transform of `1/zeta_RVM`, with
  `M_RVM^crit(x) = L + O(x^(1/2+eps))`, `L = 1/varpi_RVM`; its ternary integer version `M_h` with values of
  `mu_h` in `{-1, 0, +1}` on the squarefree support.
* **The lambda-family**: ordinates `gamma_k(lambda) = (1 - lambda) gamma_k + lambda tau_k`,
  `zeta_1 = zeta_RVM`, `zeta_0 = zeta_Z1`; all zeros stay on `Re s = 1/2`.  The final step of the method is
  the identity `zeta_Z1 = zeta`, equivalently `prod_k (1/4+gamma_k^2)/(1/4+tau_k^2) = varpi_RVM`; the paper
  proves that it implies `M(x) = O(x^(1/2+eps))` and that it is equivalent to Hamburger's condition (D).
  The identity itself is not proved.
* **Criteria for the final step**: no `zeta_lambda` with `0 < lambda <= 1` is a Dirichlet series;
  `log zeta_lambda(sigma)` is strictly convex in `lambda` for real `sigma > 1`; the crossing point of the
  family; Hamburger's theorem for the pair `(zeta_lambda, atomized zeta_lambda)`; the cell-mass, ladder and
  bridge criteria; the transport from the clock on each cell and the exact defect of the clock by Poisson
  summation; the rung system with free masses, whose solvability is equivalent to (D).
* **Multiscale Jacobian at the clock**: `Delta_T >= 2 pi / log(T/(2 pi))` for the minimum clock gap below
  `T`; a lower Ingham frame bound on windows of length `(1+varkappa_win) log(T/(2 pi))`; no height-uniform
  bound on a fixed window.  These are stability statements, not an existence theorem.
* **Route B for finite sections**: compactness of near-solutions in a box; uniqueness of exact solutions in
  every tube with free masses (an exact solution is the zeta list with the von Mangoldt masses, and RH holds),
  so that route B is equivalent to (D); prescribed von Mangoldt masses; finite stages do not decide route B
  (the zeta list solves every finite set of tests up to `(3e12)^(1-r)`); route B on one window (an unknown
  list reproducing Cramer's function; a Bernstein form: RH iff `exp(-iy/2) V_+(iy)` is completely
  monotone); minimizers of the window residual (exact or degenerate) and RH iff solvability on every window;
  staged certificate theorem; exact solutions of fifteen square sections up to `T = 487` verified in ball
  arithmetic with B-spline tests (`code/routeB/certV.py`, python-flint/Arb); Gonek lists in a tube around the
  clock; the a priori displacement bound for exact rung solutions (drift `-4 b kappa_k / log(s_k/2pi)`
  governed by the mass `b` at the origin; bounded displacement exactly when `b = 0`); and the block
  Kadec-Avdonin criterion.
* **Models without zeta**: the acceptance criterion, a non-periodic accepted list, the finite Euler products
  (for which the final step is a theorem) and the diagonal operator over the primes.
* **Tables of the first 1000 values** (Appendix A of the paper) and walks in three dimensions.
* Proved / not proved: every statement of the paper is proved except the identity `zeta_Z1 = zeta`
  (equivalently (D) and the criteria listed in the introduction), which is the open step.  The experiments
  are computations and are not part of any proof, except the interval evaluation of a few inequalities in
  the proof of `varpi_RVM < 1` (`code/s14_varpi_bound.py`) and the ball-arithmetic verification of the
  finite sections of the Route B theorem on verified sections (`code/routeB/certV.py`).

## Repository layout

```
rvm_zeta_pi_mertens_v26.tex   the paper; .txt identical copy; .pdf compiled paper
code/        Python programs s01 ... s17 and rvm_common.py; code/txt: .txt copies of every program
code/routeB/ Route B programs (floating-point candidate certificates, verified B-spline certificates, Gonek lists, receding horizon), with _py.txt copies
matlab/      MATLAB versions of s15 and s16; matlab/txt: .txt copies
data/        zeross.bin and zLamb.bin: NOT included in this package (see data/README.md)
output/      console output, CSV, MAT and binary results used by the paper (output/routeB for Route B)
figures/     PNG figures used by the paper
tools/       tooltip generator for the PDF (make_tips.py, replace_tips.py)
review/      changelogs, reviews and working notes (the history of the manuscript is kept only here)
supplementary/, recovered_claude/   archival material (not used by the paper's programs)
```

## Data format

The two binary files are not included in this package (16 MB each).  Both are raw little-endian IEEE float64
arrays, one ordinate per entry, 2,001,052 entries, sorted:

* `zeross.bin`: `gamma_1 = 14.134725142, ..., gamma_2001052 = 1132490.658714`
* `zLamb.bin`: `tau_1 = 14.521346953, ..., tau_2001052 = 1132490.722588`,
  `max |N_RVM(tau_k) - (k - 1/2)| = 7.0e-10`

The loader `code/rvm_common.py` refuses files whose size is not a multiple of 8 bytes, files of different
lengths, non-finite or non-positive values, a list `tau_k` that is not strictly increasing or starts below
`2 pi`, and a decreasing list `gamma_k`.  Also not included: the large output `output/s05_walks.csv` (29 MB),
regenerated by `code/s05_mertens.py`.

## Running

```
python3 -m pip install -r code/requirements.txt   # pinned: numpy 2.5.3, scipy 1.18.1, mpmath 1.4.1,
                                                  # matplotlib 3.11.2, finufft 2.5.1 (Python 3.13.16)
./run_all_python.sh                               # s01 ... s17 in the required order
```

Order and dependencies: `s02` writes `output/s02_varpi.txt`, read by `s05`, `s07`, `s14` (comparison only)
and `s15`; `s06` reads the CSV written by `s04`; `s15` compares its prime levels with those of `s04`.
`s14` needs no data file.  `s11` (RVM-Z1 difference analysis up to `x = 100000`) is the heaviest program
(about 20 minutes on two cores); `s13` (bounded and nested finite sections) about 10 minutes.

Route B programs, run from `output/routeB/` (they need no data file):

```
cd output/routeB
python3 ../../code/routeB/zeros.py 400
python3 ../../code/routeB/gonek_fast.py 8 1400
python3 ../../code/routeB/horizonG.py 16 2.4 4 > out_horizonG.txt
python3 ../../code/routeB/cert7.py > out_cert7.txt
python3 ../../code/routeB/diag_cert7_gamma.py > out_cert7_gamma.txt
python3 ../../code/routeB/entry.py > out_entry.txt
python3 ../../code/routeB/entry2.py > out_entry2.txt
python3 ../../code/routeB/certV.py > out_certV.txt        # needs python-flint (ball arithmetic), about 3 minutes
python3 ../../code/routeB/laplace_check.py > out_laplace_check.txt
python3 ../../code/routeB/figs.py
python3 ../../code/routeB/results_summary.py
```

`RESULTS.txt` lists every file with its SHA-256 and the status criteria.  A stage marked `FLOAT_PASS` satisfies
the Banach inequalities in floating point: a candidate certificate, not a proof.

## Building the paper

```
./build_pdf.sh          # or: make pdf
```

After editing the TeX, regenerate the hover tooltips: compile twice, then
`python3 tools/make_tips.py rvm_zeta_pi_mertens_v26.tex rvm_zeta_pi_mertens_v26.aux tips.tex &&
python3 tools/replace_tips.py rvm_zeta_pi_mertens_v26.tex tips.tex`, then compile three times.
Required LaTeX packages: amsart, amsmath, mathrsfs, mathtools, longtable, booktabs, graphicx, listings,
xcolor, hyperref, bookmark, pdfcomment.

## Main numerical results (from `output/*_console.txt`)

| quantity | value |
|---|---|
| `max_k |tau_k - gamma_k|` over 2,001,052 zeros | 0.9937 |
| `max |zeta_Z1/zeta - 1|`, `sigma = 2, 1.25, 0.75`, `t <= 2000` (balanced metric) | 8.7e-10, 1.1e-9, 2.6e-9 (7.5e-10, 1.1e-9, 1.9e-9) |
| `varpi_RVM` (Richardson on `Re s = 2`; s14 value agrees to 2.1e-11) | 0.9619415789 |
| `max_N |sum_{k<=N} x^(i tau_k)|`, `x = 2, 3, 4, 6, 10` (all `N`) | 3.58, 3.98, 3.96, 4.53, 10.34 |
| `|sum_{k<=N} 2^(i gamma_k)|` at `N = 2,001,052` (main term of Landau's formula: 88,342) | 88,301 |
| `pi_RVM(100)`, `pi(100)`, `li(100)` | 26.08, 25, 30.13 |
| `pi_RVM(1000)`, `pi(1000)`, `li(1000)` | 169.98, 168, 177.61 |
| `prod_{k<=N} (1/4+gamma_k^2)/(1/4+tau_k^2)` (zeta_Z1 = zeta exactly when the limit is `varpi_RVM`) | 0.9619415390 |
| densities of `-1, 0, +1` for `mu_h`, `n <= 10^6` | 0.304003, 0.392074, 0.303923 |
| `max |M_h - target for M_RVM^crit|`, `10^4 <= n <= 10^6` | 1.65 |
| `exp(-1/2) V_+(1)` (zero-free representation) | 0.7768942607932536 + 0.76785566886 i |
| triangular centroid of `exp(i gamma_k)`, `N = 2,001,052` | 0.7769071196 + 0.7678445908 i |
| limit of the triangular centroid of `exp(i tau_k)` | 0.041569 + 1.757541 i |
| `p_1000^RVM`, `p_1000` | 7928.195, 7919 |
| `max_{j<=1000} |p_j^RVM - p_j| / sqrt(p_j)` | 1.069 |
| `pi_RVM(n) - pi(n)`, `n <= 1000` | in [-2.957, 3.779], rms 1.187 |
| `M_RVM^crit(n) - M(n)`, `n <= 1000` (tapered target) | in [-17.08, 13.88], rms 6.44 |
| first rung, test function on `[0.10, 0.62]`: defect of the clock `R_f(1)` | -0.042463282161 |
| first rung: transport `S_f(0)` from the clock to the zeros | -0.042463282147 |
| rung system solved from the clock (s10): `max |solution - gamma_k|`, `k <= 10` | 4.3e-4 |
| multiscale clock, `K = 2,001,052`: minimum gap / rigorous lower bound | 0.51918344 / 0.51918343 |

The history of the manuscript (changelogs of earlier versions, reviews, the earlier README) is in `review/`.
