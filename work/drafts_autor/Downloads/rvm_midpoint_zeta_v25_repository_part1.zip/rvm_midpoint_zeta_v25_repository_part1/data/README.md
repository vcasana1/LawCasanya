# Raw ordinate data

The two raw arrays used by `code/s01`--`s13` and `code/s15`--`s17` are NOT included in this package
(16 MB each):

- `zeross.bin`: ordinates gamma_k of the nontrivial zeros of the Riemann zeta function.
- `zLamb.bin`: midpoint RVM ordinates tau_k satisfying N_RVM(tau_k) = k - 1/2.

Both are little-endian IEEE float64 arrays (8 bytes per entry, no header) with 2,001,052 entries each,
sorted by ordinate (gamma_1 = 14.134725142..., tau_1 = 14.521346953...).  A double-precision ordinate near
the top of the files (1.13e6) is resolved to 2.3e-10 (one unit in the last place).  Place the two files in
this directory before running `./run_all_python.sh`.  The loader `code/rvm_common.py` checks the file sizes
(multiples of 8 bytes), equal lengths, finiteness, positivity, `tau_1 > 2 pi`, strict increase of `tau_k`
and monotonicity of `gamma_k`.

The large output file `output/s05_walks.csv` (29 MB) is likewise not included; `code/s05_mertens.py`
regenerates it.  The programs of `code/routeB/` do not need these files: they compute their own 400 zeta
ordinates with mpmath (`zeros.py`) for the diagnostic columns only.
