# Version 25 (15 October 2026)

Sources: six reviews covering the whole of `rvm_zeta_pi_mertens_v24_1.txt` (lines 1-10109), and the consolidated
list of 130 items; the item-by-item audit is `review/V25_REVIEW_AUDIT.md`.

## Manuscript: history removed

Every reference to earlier versions and to the history of the paper was removed from the manuscript (abstract,
introduction, remarks, status paragraphs, captions, appendices).  The history is kept only in `review/`.

## Manuscript: mathematics

* A priori displacement bound for exact rung solutions (Proposition prop:rung-apriori), rewritten: Laplace
  convention stated; explicit choice eps_0 = sigma_0 - 3/2 for the mass series; the derivative of
  n^(1/2-s)/log n shown; C_t normalised at s = 2 with e^(2b(s-2)); order at most one; right half-strip
  2 <= Re s <= 4; symmetry and conjugation on Re s = -1, with the non-symmetric factor G handled by the bound
  for G(2+it)/G(-1+it); bottom side of the half-strip bounded by 5 sum kappa_k^-2 + c_7; Jensen's formula valid
  with zeros on the circle (Rudin, Thm 15.18); extension to T in {kappa_k} by right continuity; the displacement
  kept with the intermediate point s_k, and the drift-corrected clock point tau_k^(b) with |kappa_k - tau_k^(b)|
  <= C*; Corollary for b = 0; the scope remark speaks of a uniform drift-corrected class.
* Verified-zero bound for varpi_Z1: rigorous tail sum over gamma > T from Trudgian's bound for S(t), constant
  0.255 per zero, log varpi_Z1 < 3.78e-13.
* Local corrections from the reviews (majorants, van der Corput step, Abel regularisation, sawtooth primitive,
  Bromwich range, Hadamard absolute convergence, residues, three-circles radii, binomial definition, joining
  factor facts, extremal-function roots, bubble interval, power-of-two indicator, defect kernel, Theta_lambda
  prefactor, branch of arg G, rigidity, positivity factor bound, c_phi boundary terms, the frame heuristic,
  Gonek rearrangement, Herglotz vague limit, open problem (i) as equivalences (a)-(g)), and first-crossing
  definition of the real prime levels next to its first use.

## Manuscript: numerics

* varpi_RVM = 0.9619415789 (Richardson with an accurate product: 10^6 exact factors and eight power sums),
  agreeing with the value of `s14` to 2.1e-11; L = 1.0395641710; stability of the extrapolation reported.
* Exponential sums: maxima over all N; Landau comparison as an illustration with Theorem thm:known-landau.
* Prime counts: first grid crossings refined linearly; interpolation error of the Moebius inversion measured;
  sensitivity of the levels to truncation and grid reported in the caption of Table tab:primes-1000.
* Mertens: RMS for three exclusion widths, trivial-term and Riemann-Siegel checks, target validated near 10^6,
  unit test of the sign of zeta_RVM'(rho_k), sensitivity to the residue model; values for the target labelled.
* Transition: computed residual and the slow vertical limit on sigma' = 0.25.
* Product identity: auxiliary slope and truncated flow integral.  Poisson split: oscillatory series not summed.
* Route B: FLOAT_PASS labels, defect ||I - QJ|| in the Banach inequality, sampled margin, fragility of
  rounding-size radii, slopes with standard errors, frozen-tail statement.
* Finite-section appendix rewritten from the reproducible output of `s13`: single sections, nested sections
  (continuation up to N = 70, failure at N = 100), repeatability (non-unique near-solutions), numerical rank and
  conditioning, active bounds; Status divided into Proved / Numerical evidence / Open.
* Tables: full formulas in the difference headings; automated read-back checks; differences from unrounded values.
* Appendix B: software versions, run order and data precision; consoles of `s12` and `s13` listed.
* Bibliography: one style for all entries.

## Code and outputs

* `rvm_common.py`: data validation (size, lengths, finiteness, positivity, monotonicity), safeguarded
  `clock_inverse`, documented tail approximations and branches, Moebius self-test.
* `s01`-`s05`, `s07`-`s10`, `s13`-`s15`: the corrections listed in the audit; `s02` writes `output/s02_varpi.txt`,
  read by `s05`, `s07`, `s14`, `s15`; `s11` made compatible with NumPy 2.5 (`np.trapezoid`).
* `s13`: rewritten main program (single sections with cross-validation, nested sections with 3000
  evaluations, repeatability, numerical rank, active bounds, new Figures 16-17, console file).
* Route B: `cert7.py` as floating-point candidate (LU solve, defect, sampled margin, no zeta ordinates);
  `cert5.py`, `cert6.py` with the same labels; new `diag_cert7_gamma.py`, `results_summary.py`; `gonek_fast.py`
  detects multi-level jumps; `horizonG.py` reports status and inversions.
* `code/requirements.txt` pins the versions; `.txt` copies of every program regenerated.
* Tooltip generator rewritten (token-based, `\CGref` numbers, balanced arguments, `\texorpdfstring`).
* Outputs regenerated: `s01`-`s05`, `s07`-`s09`, `s11`, `s13`-`s15`, Route B (`out_horizonG`, `out_gonek_fast`,
  `out_cert5`, `out_cert6`, `out_cert7`, `out_cert7_gamma`, `out_entry`, `out_laplace_check`, `RESULTS.txt`).
  The tables of the first 1000 values are unchanged.
