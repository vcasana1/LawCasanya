"""Common routines for the midpoint Riemann-von Mangoldt (RVM) zeta system.

Data files (little-endian float64, one ordinate per entry):
    data/zeross.bin  ordinates gamma_k of the nontrivial zeros of zeta (2,001,052 values)
    data/zLamb.bin   midpoint RVM ordinates tau_k, N_RVM(tau_k) = k - 1/2

Notation follows the paper: N_RVM is the clock, tau_k the midpoint ordinates,
gamma_k the ordinates of zeta, eta_k = tau_k - gamma_k, q(s) = s(s-1),
G(s) = s(s-1) Gamma(s/2) pi^(-s/2), zeta_lambda = P_lambda / G with ordinates
gamma_k(lambda) = (1-lambda) gamma_k + lambda tau_k.
"""
import os
import sys
import time
import numpy as np
from scipy import special

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data")
OUT = os.path.join(ROOT, "output")
FIG = os.path.join(ROOT, "figures")
os.makedirs(OUT, exist_ok=True)
os.makedirs(FIG, exist_ok=True)

TWO_PI = 2.0 * np.pi


class Tee:
    """Write console output both to the screen and to output/<name>_console.txt."""

    def __init__(self, name):
        self.f = open(os.path.join(OUT, name + "_console.txt"), "w")
        self.t0 = time.time()

    def __call__(self, fmt, *args):
        s = fmt % args if args else fmt
        sys.stdout.write(s + "\n")
        sys.stdout.flush()
        self.f.write(s + "\n")
        self.f.flush()

    def close(self):
        self("total run time %.1f s" % (time.time() - self.t0))
        self.f.close()


def read_bin(name):
    """Read a data file of little-endian IEEE float64 values (8 bytes each, no header)."""
    path = os.path.join(DATA, name)
    size = os.path.getsize(path)
    if size == 0 or size % 8 != 0:
        raise ValueError("%s has %d bytes, which is not a positive multiple of 8: it is not a "
                         "little-endian float64 file" % (name, size))
    return np.fromfile(path, dtype="<f8")


def load_ordinates(n_required=None):
    """Read gamma_k (zeross.bin) and tau_k (zLamb.bin) and validate them.

    The two files must be little-endian float64 (size a multiple of 8 bytes) and have the same
    length; a different length is an error, never a silent truncation.  Both lists must be finite; tau_k must be strictly increasing (the
    clock is strictly increasing on [2 pi, oo)); gamma_k must be nondecreasing (a repeated
    value would be a multiple zero; the supplied file has none, which is reported).
    If n_required is given, at least that many ordinates must be present."""
    gam = read_bin("zeross.bin")
    tau = read_bin("zLamb.bin")
    if gam.size != tau.size:
        raise ValueError("zeross.bin has %d entries and zLamb.bin has %d: the ordinate files have "
                         "different lengths" % (gam.size, tau.size))
    if n_required is not None and gam.size < n_required:
        raise ValueError("%d ordinates required, %d supplied" % (n_required, gam.size))
    if not (np.all(np.isfinite(gam)) and np.all(np.isfinite(tau))):
        raise ValueError("non-finite ordinate in the data files")
    if not (gam[0] > 0 and tau[0] > TWO_PI):
        raise ValueError("the ordinates must be positive and tau_1 > 2 pi (increasing branch of the clock)")
    if not np.all(np.diff(tau) > 0):
        raise ValueError("zLamb.bin is not strictly increasing")
    dg = np.diff(gam)
    if not np.all(dg >= 0):
        raise ValueError("zeross.bin is not nondecreasing")
    if not np.all(dg > 0):
        sys.stdout.write("warning: zeross.bin contains repeated ordinates (multiple zeros)\n")
    return gam, tau


def clock(T):
    """N_RVM(T) = T/(2 pi) log(T/(2 pi e)) + 7/8 (real or complex T, principal log)."""
    return T / TWO_PI * (np.log(T / TWO_PI) - 1.0) + 0.875


def tail_coefficients(U):
    """Midpoint-rule tail of sum_{k>N} log(1 + q/tau_k^2), N = N_RVM(U):
    returns (c1, c2, c3) with tail(q) = c1 q - c2 q^2 + c3 q^3.

    Approximations, all used for the factors beyond the supplied file only:
    (i) the unknown ordinates beyond the file are replaced by the clock (the 'clock tail');
    (ii) the sum over the clock points is replaced by the integral against dN_RVM, which is
        the midpoint rule because N_RVM(tau_k) = k - 1/2; its error is O(|q| log U / U^3);
    (iii) 1/4 + tau_k^2 is replaced by tau_k^2, a relative change O(U^-2) of each term,
        hence O(|q| log U / U^3) in total;
    (iv) the expansion of log(1 + q/t^2) is cut after q^3; the omitted terms are
        O(|q|^4 log U / U^7).
    For the file used here U = tau_N ~ 1.13e6 and |q| <= 4.1e6 (|s| <= 2000), so (ii)-(iv)
    are below 1e-10; (i) is not bounded here and is part of what the experiments measure."""
    LU = np.log(U / TWO_PI)
    c1 = (LU + 1.0) / U / TWO_PI
    c2 = (3.0 * LU + 1.0) / (9.0 * U ** 3) / 2.0 / TWO_PI
    c3 = (5.0 * LU + 1.0) / (25.0 * U ** 5) / 3.0 / TWO_PI
    return c1, c2, c3


def clock_inverse(y, tol=1e-15, max_iter=60):
    """Solve N_RVM(U) = y on the increasing branch U > 2 pi (y > -1/8).

    Safeguarded Newton iteration: the iterates are kept in a bracket [lo, hi] with
    N_RVM(lo) < y < N_RVM(hi) inside (2 pi, oo), where N_RVM' > 0; a Newton step that
    leaves the bracket is replaced by bisection.  Stops when the relative step is below
    tol and raises RuntimeError if max_iter iterations do not suffice."""
    y = float(y)
    if y <= -0.125:
        raise ValueError("N_RVM(U) = y has no solution with U > 2 pi for y <= -1/8")
    lo = TWO_PI * (1.0 + 1e-12)
    hi = TWO_PI * np.e * 2.0
    while clock(hi) <= y:
        hi *= 2.0
    U = min(max(TWO_PI * max(y, 2.0) / np.log(max(y, 3.0)), lo), hi)
    for _ in range(max_iter):
        f = clock(U) - y
        if f > 0:
            hi = U
        else:
            lo = U
        Unew = U - f / (np.log(U / TWO_PI) / TWO_PI)
        if not (lo < Unew < hi):
            Unew = 0.5 * (lo + hi)
        if abs(Unew - U) <= tol * max(1.0, abs(U)):
            return Unew
        U = Unew
    raise RuntimeError("clock_inverse did not converge for y = %r" % y)


class Product:
    """log P(s) = sum_k log(1 + q(s)/(1/4 + o_k^2)) for an ordinate list o_k.

    Exact summation for k <= K1, power sums (nterms powers of q) for K1 < k <= N, and
    the clock tail for k > N (tail_coefficients).  The power sums are accurate for
    |q(s)| << o_{K1}^2; the omitted power terms are O(|q|^(nterms+1) o_{K1}^(-2 nterms))
    times the number of factors.  The logarithm is the principal one, factor by factor;
    use the result through exp(logP) unless branch continuity is checked separately.  In the
    programs of this repository logP and logG enter only through exp(.) or through their real
    parts (logarithms of moduli); no program reads an argument or a phase from them."""

    def __init__(self, ords, K1=100000, nterms=6):
        self.o = np.asarray(ords, dtype=float)
        self.N = self.o.size
        self.K1 = min(K1, self.N)
        A = 0.25 + self.o[self.K1:] ** 2
        self.pw = [np.sum(A ** (-j)) for j in range(1, nterms + 1)]
        self.A1 = 0.25 + self.o[: self.K1] ** 2
        self.tail = tail_coefficients(clock_inverse(float(self.N)))

    def logP(self, s):
        s = np.atleast_1d(np.asarray(s, dtype=complex))
        q = s * (s - 1.0)
        out = np.empty(s.shape, dtype=complex)
        for i, qi in enumerate(q):
            v = np.sum(np.log1p(qi / self.A1))
            for j, p in enumerate(self.pw, start=1):
                v += (-1) ** (j + 1) * qi ** j / j * p
            c1, c2, c3 = self.tail
            v += c1 * qi - c2 * qi ** 2 + c3 * qi ** 3
            out[i] = v
        return out


def logG(s):
    """Sum of principal-branch logarithms of s, s - 1, Gamma(s/2) and pi^(-s/2).

    This is a logarithm of G(s) = s(s-1) Gamma(s/2) pi^(-s/2), not necessarily the branch
    continuous along a given path: use it only through exp(logG) unless branch continuity
    has been checked separately (arguments, phases and their derivatives)."""
    s = np.asarray(s, dtype=complex)
    return np.log(s) + np.log(s - 1.0) + special.loggamma(s / 2.0) - s / 2.0 * np.log(np.pi)


def zeta_from_product(prod, s):
    s = np.atleast_1d(np.asarray(s, dtype=complex))
    return np.exp(prod.logP(s) - logG(s))


def chi(s):
    s = np.asarray(s, dtype=complex)
    return np.exp((s - 0.5) * np.log(np.pi) + special.loggamma((1 - s) / 2) - special.loggamma(s / 2))


def w_transition(s):
    """w(s) = exp(-2 pi i N_RVM(tau_*)), tau_* = -i (s - 1/2)."""
    s = np.asarray(s, dtype=complex)
    tstar = -1j * (s - 0.5)
    return np.exp(-2j * np.pi * clock(tstar))


def theta_rs(t):
    t = np.asarray(t, dtype=float)
    return t / 2 * np.log(t / TWO_PI) - t / 2 - np.pi / 8 + 1 / (48 * t) + 7 / (5760 * t ** 3)


def gamma_lambda(gam, tau, lam):
    return (1.0 - lam) * gam + lam * tau


def ei_upper(w):
    """Ei on Im w != 0 along the horizontal line (paper, eq. Ei-def): Ei(w) = -E1(-w)."""
    return -special.exp1(-np.asarray(w, dtype=complex))


def mobius_sieve(X):
    """mu(n) for 0 <= n <= X (mu(0) = 0), by a sieve over the primes p <= X."""
    mu = np.ones(X + 1, dtype=np.int8)
    mu[0] = 0
    is_comp = np.zeros(X + 1, dtype=bool)
    for p in range(2, X + 1):
        if not is_comp[p]:
            is_comp[2 * p::p] = True        # p itself stays marked prime
            mu[p::p] *= -1
            if p * p <= X:
                mu[p * p::p * p] = 0
    if X >= 12:                              # self-test on the first values
        ref = [0, 1, -1, -1, 0, -1, 1, -1, 0, 0, 1, -1, 0]
        if list(mu[:13]) != ref:
            raise AssertionError("mobius_sieve self-test failed")
    return mu


def primes_upto(X):
    s = np.ones(X + 1, dtype=bool)
    s[:2] = False
    for p in range(2, int(X ** 0.5) + 1):
        if s[p]:
            s[p * p::p] = False
    return np.nonzero(s)[0]


def write_csv(name, header, cols):
    A = np.column_stack(cols)
    np.savetxt(os.path.join(OUT, name), A, delimiter=",", header=",".join(header), comments="", fmt="%.12g")


def savefig(fig, name):
    fig.savefig(os.path.join(FIG, name), dpi=150, bbox_inches="tight")
