"""Experiment 4: the prime-power count J_RVM, the synthetic prime count pi_RVM, the cell
masses c_n^RVM and the real RVM prime levels p_j^RVM, compared with J, pi(x) and the primes.

J_o(x) = li(x) - 2 Re sum_k Ei((1/2 + i o_k) log x) - log 2 + int_x^inf dt/(t(t^2-1) log t)
for an ordinate list o_k (o = tau: J_RVM; o = gamma: Riemann's explicit formula for J),
pi_o(x) = sum_{m <= log2 x} mu(m)/m J_o(x^(1/m)).
The zero sums are evaluated on a uniform grid in u = log x by the recurrence
exp(i o_k (u + du)) = exp(i o_k u) exp(i o_k du), recomputed exactly every 200 steps (the
discrepancy between the recurrence and the exact value is measured and printed); Ei is
exact (scipy exp1) for k <= KE = 300 and uses Ei(w) = e^w (1/w + 1/w^2 + 2/w^3 + 6/w^4) for
k > KE.  For w = (1/2 + i o_k) u, -w has |ph(-w)| = pi/2 + arctan(1/(2 o_k)), and the remainder
of the four-term expansion is bounded by csc|ph(-w)| times the first neglected term,
24 |e^w| / |w|^5 (DLMF 6.12(i)); the program prints min |w| and the resulting bound for the
whole tail sum, and compares the expansion with the exact Ei on a sample."""
import os
import numpy as np
import scipy.io as sio
from scipy import special, integrate
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from rvm_common import (Tee, load_ordinates, ei_upper, mobius_sieve, primes_upto, write_csv,
                        savefig, clock_inverse, OUT)

say = Tee("s04_primes")
gam, tau = load_ordinates()
KE = 300


def zero_sum_ei(ords, u, K=None, taper=None):
    """sum_k Ei((1/2 + i o_k) u) on a uniform grid u, k <= K, optional weights."""
    o = ords if K is None else ords[:K]
    wts = np.ones(o.size) if taper is None else taper
    rho = 0.5 + 1j * o
    out = np.zeros(u.size, dtype=complex)
    ke = min(KE, o.size)                 # safe for lists shorter than KE
    # exact part
    for i in range(ke):
        out += wts[i] * ei_upper(rho[i] * u)
    if ke == o.size:
        return out
    # asymptotic part by recurrence
    r = rho[ke:]
    wmin = np.min(np.abs(r)) * u[0]
    phase = np.pi / 2 + np.arctan(1.0 / (2.0 * o[ke:]))
    csc = 1.0 / np.sin(phase)
    bound = np.max(np.exp(u / 2)) * np.sum(np.abs(wts[ke:]) * csc * 24.0 / (np.abs(r) * u[0]) ** 5)
    samp = np.arange(ke, min(ke + 50, o.size))
    rel = 0.0
    for uu in (u[0], u[-1]):
        w = rho[samp] * uu
        asym = np.exp(w) * (1 / w + 1 / w ** 2 + 2 / w ** 3 + 6 / w ** 4)
        rel = max(rel, np.max(np.abs(asym - ei_upper(w)) / np.abs(np.exp(w) / w)))
    say("  Ei expansion for k > %d: min |w| = %.1f, bound for the total remainder %.2e; "
        "max |expansion - Ei| / |e^w/w| on a sample of %d ordinates = %.2e", ke, wmin, bound, samp.size, rel)
    b = [wts[ke:] / r ** m for m in (1, 2, 3, 4)]
    du = u[1] - u[0]
    stepf = np.exp(1j * o[ke:] * du)
    drift = 0.0
    for j in range(u.size):
        if j % 200 == 0:
            Ex = np.exp(1j * o[ke:] * u[j])
            if j > 0:
                drift = max(drift, np.max(np.abs(E - Ex)))
            E = Ex
        A = [E @ bm for bm in b]
        uj = u[j]
        out[j] += np.exp(uj / 2) * (A[0] / uj + A[1] / uj ** 2 + 2 * A[2] / uj ** 3 + 6 * A[3] / uj ** 4)
        E = E * stepf
    say("  recurrence check: max |recurrent - exact| of exp(i o_k u) before each recomputation = %.2e", drift)
    return out


def tail_integral(x):
    return integrate.quad(lambda t: 1.0 / (t * (t * t - 1.0) * np.log(t)), x, np.inf, limit=200)[0]


def J_from(ords, u, K=None, taper=None):
    x = np.exp(u)
    S = zero_sum_ei(ords, u, K, taper)
    ti = np.array([tail_integral(v) for v in x])
    return special.expi(u) - 2 * S.real - np.log(2.0) + ti


def pi_from_J(u, J):
    # J(x^(1/m)) = J(e^(u/m)) is read by linear interpolation on the u-grid; this adds an
    # interpolation error of order (du)^2 max|J''|, measured below by a run on the double step
    mu = mobius_sieve(int(np.floor(u.max() / np.log(2.0))) + 2)
    out = np.zeros(u.size)
    for i, ui in enumerate(u):
        m = 1
        while ui / m >= np.log(2.0) - 1e-12:
            if mu[m] != 0:
                out[i] += mu[m] / m * np.interp(ui / m, u, J)
            m += 1
    return out


def exact_J_pi(x):
    P = primes_upto(int(x.max()) + 1)
    pi = np.searchsorted(P, x, side="right").astype(float)
    J = np.zeros(x.size)
    m = 1
    while 2.0 ** m <= x.max():
        J += np.searchsorted(P, x ** (1.0 / m) + 1e-12, side="right") / m
        m += 1
    return J, pi


def run(xmax, npts, K, label):
    u = np.linspace(np.log(2.0), np.log(xmax), npts)
    if K is None:
        tg = tr = None
        Kg = Kr = None
    else:
        Kg = Kr = K
        v = np.arange(K) / K
        tg = tr = np.where(v < 0.6, 1.0, np.cos(np.pi / 2 * (v - 0.6) / 0.4) ** 2)
    JR = J_from(tau, u, Kr, tr)
    JG = J_from(gam, u, Kg, tg)
    PR = pi_from_J(u, JR)
    PG = pi_from_J(u, JG)
    x = np.exp(u)
    Je, Pe = exact_J_pi(x)
    write_csv("s04_prime_counts_%s.csv" % label, ["x", "J_exact", "J_from_zeta_zeros", "J_RVM",
                                                  "pi_exact", "pi_from_zeta_zeros", "pi_RVM", "li"],
              [x, Je, JG, JR, Pe, PG, PR, special.expi(u)])
    return x, Je, JG, JR, Pe, PG, PR


# x <= 100 with all zeros; x <= 1000 with a smooth cut at K zeros
x1, Je1, JG1, JR1, Pe1, PG1, PR1 = run(100.0, 3000, None, "x100_allzeros")
say("x <= 100, all %d zeros of each list, %d grid points:" % (gam.size, x1.size))
say("  max |pi_from_zeta_zeros - pi| away from primes (distance > 0.2): %.4f",
    np.max(np.abs(PG1 - Pe1)[np.min(np.abs(x1[:, None] - primes_upto(101)[None, :]), axis=1) > 0.2]))
say("  pi_RVM(100) = %.4f, pi(100) = %d, li(100) = %.4f, J_RVM(100) = %.4f, J(100) = %.4f",
    PR1[-1], Pe1[-1], special.expi(np.log(100.0)), JR1[-1], Je1[-1])
dPR = np.diff(PR1)
say("  pi_RVM increasing on the sampled grid of [2,100]: %s (min increment on the grid %.3e)", bool(np.all(dPR > 0)), dPR.min())

# Cut height: the harmonic m = 1 of the clock resonates at tau ~ 2 pi x (stationary point of
# exp(i tau u) against the clock), so tau_K = 2.5 * 2 pi x_max keeps every ordinate up to
# 2.5 times the resonant height of the largest x, and the cos^2 taper acts only above
# 0.6 K, that is, above 1.5 times that height.  The factor is a choice, not optimized.
tauK = 2 * np.pi * 1000.0 * 2.5
K = int(np.searchsorted(tau, tauK))
x2, Je2, JG2, JR2, Pe2, PG2, PR2 = run(1000.0, 40000, K, "x1000_K%d" % K)
say("x <= 1000, smooth cut at K = %d zeros (tau_K = %.1f), %d grid points:" % (K, tau[K - 1], x2.size))
say("  pi_RVM(1000) = %.4f, pi(1000) = %d, li(1000) = %.4f", PR2[-1], Pe2[-1], special.expi(np.log(1000.0)))
# interpolation check: the Moebius inversion reads J(x^(1/m)) by linear interpolation in u;
# repeating it on the grid of double step (every second node, same values of J) changes pi_RVM
# by about 3 times the interpolation error of the step used (error O(du^2))
u2 = np.log(x2)
PR2c = pi_from_J(u2[::2], JR2[::2])
dI = np.max(np.abs(PR2c - PR2[::2]))
say("  interpolation check: max |pi_RVM(step du) - pi_RVM(step 2 du)| at the common nodes = %.2e "
    "(estimated interpolation error of the step du: %.1e)", dI, dI / 3)

# cell masses and real prime levels from the fine x<=1000 run
# convention: pi_RVM(1) = 0, so c_2 = pi_RVM(2) and c_n = pi_RVM(n) - pi_RVM(n-1) for n >= 3
n = np.arange(2, 1001)
pin = np.interp(n, x2, PR2)
c = np.diff(np.concatenate([[0.0], pin]))
P = primes_upto(1000)
isp = np.isin(n, P).astype(float)
say("cell masses c_n = pi_RVM(n) - pi_RVM(n-1):")
say("%5s %10s %10s %8s" % ("n", "c_n", "1/log n", "prime"))
for i in range(0, 40):
    say("%5d %10.5f %10.5f %8d" % (n[i], c[i], 1 / np.log(n[i]), isp[i]))
say("sum_{n<=1000} c_n = pi_RVM(1000) = %.4f (telescoping, with pi_RVM(1) = 0);  pi(1000) = %d", c.sum(), len(P))
levels = np.arange(1, int(np.floor(PR2.max())) + 1)


def first_crossing(xg, F, j):
    """First grid point with F >= j, refined by linear interpolation from the previous point;
    a discrete version of inf{x : F(x) >= j}.  Raises if the level is not reached."""
    hit = np.nonzero(F >= j)[0]
    if hit.size == 0:
        raise RuntimeError("level %d not reached on the grid" % j)
    i = hit[0]
    if i == 0:
        return xg[0]
    return xg[i - 1] + (j - F[i - 1]) / (F[i] - F[i - 1]) * (xg[i] - xg[i - 1])


pj = np.array([first_crossing(x2, PR2, j) for j in levels])
say("real RVM prime levels p_j^RVM (first grid crossing of level j, refined linearly) versus p_j:")
say("%5s %12s %8s %10s" % ("j", "p_j^RVM", "p_j", "diff"))
for j in range(min(30, levels.size)):
    say("%5d %12.4f %8d %10.4f" % (levels[j], pj[j], P[j], pj[j] - P[j]))
write_csv("s04_cell_masses.csv", ["n", "c_n_RVM", "inv_log_n", "is_prime"], [n, c, 1 / np.log(n), isp])
m = min(levels.size, P.size)
write_csv("s04_rvm_prime_levels.csv", ["j", "p_j_RVM", "p_j"], [levels[:m], pj[:m], P[:m]])

# ---- figures (linear axes)
fig, ax = plt.subplots(1, 2, figsize=(12, 4))
ax[0].step(x1, Pe1, where="post", color="k", lw=1.6, label=r"$\pi(x)$")
ax[0].plot(x1, PG1, "b-", lw=0.6, label=r"$\pi(x)$ from %d zeros of $\zeta$" % gam.size)
ax[0].plot(x1, PR1, "r-", lw=1.4, label=r"$\pi_{\rm RVM}(x)$ from %d $\tau_k$" % tau.size)
ax[0].plot(x1, special.expi(np.log(x1)) - special.expi(np.log(2.0)), "g--", lw=1, label=r"$\mathrm{li}(x)-\mathrm{li}(2)$")
ax[0].set_xlabel("x")
ax[0].set_title(r"Prime counts on $[2,100]$")
ax[0].legend(fontsize=7)
ax[1].step(x2, Pe2, where="post", color="k", lw=1.2, label=r"$\pi(x)$")
ax[1].plot(x2, PR2, "r-", lw=1.0, label=r"$\pi_{\rm RVM}(x)$")
ax[1].set_xlabel("x")
ax[1].set_title(r"Prime counts on $[2,1000]$ ($K=%d$ ordinates, smooth cut)" % K)
ax[1].legend(fontsize=8)
fig.tight_layout()
savefig(fig, "fig05_prime_counts.png")

fig, ax = plt.subplots(1, 2, figsize=(12, 4))
nn = n[:98]
ax[0].bar(nn, isp[:98], width=0.8, color="0.75", label="prime indicator")
ax[0].plot(nn, c[:98], "r.-", lw=0.8, ms=4, label=r"$c_n^{\rm RVM}$")
ax[0].plot(nn, 1 / np.log(nn), "g--", lw=1, label=r"$1/\log n$")
ax[0].set_xlabel("n")
ax[0].set_title(r"Cell masses $c_n^{\rm RVM}=\pi_{\rm RVM}(n)-\pi_{\rm RVM}(n-1)$")
ax[0].legend(fontsize=8)
ax[1].plot(P[:m], pj[:m], "r.", ms=4, label=r"$(p_j,\,p_j^{\rm RVM})$")
ax[1].plot([0, 1000], [0, 1000], "k-", lw=0.8, label="diagonal")
ax[1].set_xlabel(r"$p_j$")
ax[1].set_ylabel(r"$p_j^{\rm RVM}$")
ax[1].set_title(r"First grid crossings $p_j^{\rm RVM}$ of $\pi_{\rm RVM}\geq j$ versus primes")
ax[1].legend(fontsize=8)
fig.tight_layout()
savefig(fig, "fig06_rvm_primes.png")

sio.savemat(os.path.join(OUT, "s04_results.mat"), {"x100": x1, "pi100": Pe1, "piZeta100": PG1, "piRVM100": PR1,
                                                   "x1000": x2, "pi1000": Pe2, "piRVM1000": PR2,
                                                   "c_n": c, "p_RVM": pj, "K": K})
say.close()
