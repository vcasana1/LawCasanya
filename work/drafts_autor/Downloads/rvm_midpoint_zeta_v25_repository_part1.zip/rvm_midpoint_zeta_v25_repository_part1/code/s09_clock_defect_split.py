#!/usr/bin/env python3
"""s09_clock_defect_split.py
Splits the clock defect R_psi(1) of s08 (same psi) by Poisson summation on the clock:
  sum_{k>=1} c_psi(tau_k) = I_0 + 2 sum_{m>=1} (-1)^m I_m,
  I_m = int_{t_0}^infty c_psi(t) cos(2 pi m N_RVM(t)) N_RVM'(t) dt,   N_RVM(t_0) = 0,
  I_0 = int psi(u) K_0(u) du,  K_0(u) = -(1/(2 pi u)) [ sin(u t_0) log(t_0/(2 pi)) + pi/2 - Si(u t_0) ].
Reports W_psi, I_0, the smooth mismatch W_psi - I_0 and the oscillating part  -2 sum_{m>=1}(-1)^m I_m
(obtained as R_psi(1) - (W_psi - I_0), with sum_k c_psi(tau_k) read from data/zLamb.bin).
Output: output/s09_clock_defect_split_console.txt
"""
import os, math
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, '..', 'output'); DATA = os.path.join(HERE, '..', 'data')
A, B, NU, K = 0.10, 0.62, 4001, 20000
u = np.linspace(A, B, NU); v = (u - 0.5*(A+B)) / (0.5*(B-A))
psi = np.zeros_like(u); ins = np.abs(v) < 1; psi[ins] = np.exp(-1.0/(1.0 - v[ins]**2))
du = u[1]-u[0]; psi /= psi.sum()*du

def NR(t): return t/(2*np.pi)*np.log(t/(2*np.pi*np.e)) + 7.0/8.0
t0 = 9.7
for _ in range(60): t0 -= NR(t0) / (np.log(t0/(2*np.pi))/(2*np.pi))

def Si(x, n=20001):
    s = np.linspace(0.0, 1.0, n)[None, :] * np.atleast_1d(x)[:, None]
    f = np.ones_like(s); nz = s != 0; f[nz] = np.sin(s[nz]) / s[nz]
    h = np.atleast_1d(x) / (n - 1)
    return (f.sum(axis=1) - 0.5*(f[:, 0] + f[:, -1])) * h

K0 = -(1.0/(2*np.pi*u)) * (np.sin(u*t0)*np.log(t0/(2*np.pi)) + np.pi/2 - Si(u*t0))
I0 = (psi*K0).sum()*du
W = 0.5*(psi*(np.exp(u/2) - np.exp(-u/2)/(np.exp(2*u)-1))).sum()*du
tau = np.fromfile(os.path.join(DATA, 'zLamb.bin'), dtype='<f8')
if tau.size < K or not np.all(np.isfinite(tau[:K])) or not np.all(np.diff(tau[:K]) > 0):
    raise ValueError('zLamb.bin must contain at least %d finite, strictly increasing ordinates' % K)
tau = tau[:K]
w = psi*du; ctau = sum((np.cos(np.outer(tau[a:a+2000], u)) @ w).sum() for a in range(0, K, 2000))
R1 = W - ctau
L = [f's09: Poisson split of the clock defect (psi of s08 on [{A},{B}])',
     f't_0 (N_RVM(t_0)=0)                 = {t0:.12f}   (2 pi = {2*np.pi:.6f}, tau_1 = {tau[0]:.6f})',
     f'W_psi                              = {W:+.12f}',
     f'I_0  (m = 0, smooth clock density) = {I0:+.12f}',
     f'sum_k c_psi(tau_k)                 = {ctau:+.12f}',
     f'R_psi(1)                           = {R1:+.12f}',
     f'smooth mismatch  W_psi - I_0       = {W - I0:+.12f}',
     f'oscillating part -2 sum_(m>=1)(-1)^m I_m = {R1 - (W - I0):+.12f}',
     '  (obtained as R_psi(1) - (W_psi - I_0); the I_m, m >= 1, are not summed, so the convergence of the',
     '   oscillatory Poisson series is not verified independently by this program)',
     f'stationary heights 2 pi e^u, u in supp psi: [{2*np.pi*np.exp(A):.4f}, {2*np.pi*np.exp(B):.4f}];  part above t_0: u > {np.log(t0/(2*np.pi)):.6f}']
print('\n'.join(L)); open(os.path.join(OUT, 's09_clock_defect_split_console.txt'), 'w').write('\n'.join(L)+'\n')
