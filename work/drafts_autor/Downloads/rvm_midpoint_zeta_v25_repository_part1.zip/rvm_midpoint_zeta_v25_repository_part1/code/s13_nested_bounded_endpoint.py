"""Bounded finite-section experiments for the endpoint rung system.

This program is diagnostic only.  It solves finite sections using the midpoint RVM clock as
input; the ordinates of zeta, if present, are read only after the solves, for diagnostics.
The ordinate shifts are bounded by |kappa_k - tau_k| <= 1.2 and the free masses by
|a_n| <= 0.5 (numerical regularizations, not hypotheses of a theorem).

Part 1 (single sections N = 20, 34, 50): each section is solved alone, started at the clock;
  outputs s13_bounded_mass_summary.csv, _ordinates.csv, _masses.csv, and a cross-validation on
  test bumps not used in the solve (other supports, frequencies on the shifted grid
  omega = (j + 1/2) * 0.25 up to 0.8 Omega): s13_cross_validation.csv.
Part 2 (nested sections N = 13, 20, 34, 50, 70, 100): every earlier test block stays active in
  later sections, each section warm-started from the previous one; output
  s13_nested_metric_summary.csv and a repeatability check of the N = 50 section from three
  perturbed starting points.
Figures: fig16_nested_bounded_endpoint.png (Part 2), fig17_bounded_mass_stability.png (Part 1).
Test functions: a C_c^infinity bump of unit integral, exp(-1/(1-v^2)) on its support, multiplied
by cos(omega u) and sin(omega u).  Part 1: support [0, log(N+1/2)], omega = 0, 0.25, ..., Omega,
one block of equations.  Part 2: support [0.08, log(N+1/2)] for the block introduced by section N,
omega = 0, 1, ..., Omega_N; the rows of each block are divided by sqrt(number of rows), so every
block has the same weight.
Solver: scipy.optimize.least_squares, trust-region reflective with bounds, analytic Jacobian,
x_scale='jac', double precision; Part 1: ftol = xtol = gtol = 1e-11, at most 1200 evaluations;
Part 2: ftol = xtol = gtol = 2e-10, at most MAX_NFEV evaluations.  For every solve the program
prints the termination status, nfev, the numerical rank of the (weighted) Jacobian at the solution
(singular values above 1e-12 of the largest), its condition number on that subspace, the number of
masses at the edge of the test supports whose columns are below 1e-12 (not determined by the tests),
and the number of shifts and masses at their bounds (active box constraints).
"""

from pathlib import Path
import math
import numpy as np
from scipy.optimize import least_squares
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
DATA = ROOT / "data"
OUT = ROOT / "output"
FIG = ROOT / "figures"
OUT.mkdir(exist_ok=True)
FIG.mkdir(exist_ok=True)

TAU_FILE = DATA / "zLamb.bin"
GAMMA_FILE = DATA / "zeross.bin"

SHIFT_BOUND = 1.2
MASS_BOUND = 0.5
U_MIN = 0.08
OMEGA_STEP = 1.0
MARGIN = 14.0
LEVELS = [(13, 50.0), (20, 70.0), (34, 110.0), (50, 150.0), (70, 210.0), (100, 300.0)]
MAX_NFEV = 3000            # function evaluations per nested section


LINES = []


def say(msg):
    print(msg, flush=True)
    LINES.append(msg)


def load_data():
    tau = np.fromfile(TAU_FILE, dtype="<f8")
    if tau.size == 0:
        raise RuntimeError("zLamb.bin is required in data/")
    if not np.all(np.isfinite(tau)) or not np.all(np.diff(tau) > 0):
        raise ValueError("zLamb.bin must be finite and strictly increasing")
    gamma = None
    if GAMMA_FILE.exists():
        gamma = np.fromfile(GAMMA_FILE, dtype="<f8")
        if gamma.size != tau.size:
            raise ValueError("the ordinate files have different lengths")
    return tau, gamma


def svd_report(J, mass_cols):
    """Numerical rank of J (singular values above 1e-12 sigma_max), the condition number on that
    subspace, and the number of mass columns whose largest entry is below 1e-12 of the largest
    entry of J (masses at the edge of the test supports, which the tests do not determine)."""
    sv = np.linalg.svd(J, compute_uv=False)
    rank = int(np.sum(sv > 1e-12 * sv[0]))
    weak = int(np.sum(np.max(np.abs(J[:, mass_cols]), axis=0) < 1e-12 * np.max(np.abs(J))))
    return rank, float(sv[0] / sv[rank - 1]), weak


def von_mangoldt(n):
    """Lambda(n) by trial division (no zeta data)."""
    p = 2
    while p * p <= n:
        if n % p == 0:
            m = n
            while m % p == 0:
                m //= p
            return math.log(p) if m == 1 else 0.0
        p += 1
    return math.log(n) if n >= 2 else 0.0


def choose_grid_size(U, omega):
    """Keep the Nyquist frequency safely above the largest tested frequency."""
    target_nyquist = 2.5 * (omega + MARGIN)
    n = int(math.ceil(target_nyquist * (U - U_MIN) / math.pi)) + 1
    return max(701, n)


def build_block(tau, n_max, omega_max, active_k, mass_nodes):
    U = math.log(n_max + 0.5)
    n_grid = choose_grid_size(U, omega_max)
    grid = np.linspace(U_MIN, U, n_grid)
    u = grid[1:-1]
    du = (U - U_MIN) / (n_grid - 1)

    mid = 0.5 * (U_MIN + U)
    half = 0.5 * (U - U_MIN)
    v = (u - mid) / half
    raw = np.exp(-1.0 / (1.0 - v * v))
    norm = raw.sum() * du
    w = raw / norm

    omega = np.arange(0.0, omega_max + 1e-12, OMEGA_STEP)
    psi = np.vstack([
        np.cos(np.outer(omega, u)) * w[None, :] * du,
        np.sin(np.outer(omega[1:], u)) * w[None, :] * du,
    ])

    smooth = 0.5 * (np.exp(u / 2.0) - np.exp(-u / 2.0) / (np.exp(2.0 * u) - 1.0))
    target = psi @ smooth

    clock = np.zeros_like(u)
    for start in range(0, tau.size, 500):
        clock += np.cos(np.outer(u, tau[start:start + 500])).sum(axis=1)
    low_clock = psi @ np.cos(np.outer(u, tau[:active_k])).sum(axis=1)
    fixed = psi @ clock - low_clock - target

    logs = np.log(mass_nodes.astype(float))
    env = np.zeros_like(logs)
    mask = (logs > U_MIN) & (logs < U)
    if np.any(mask):
        vv = (logs[mask] - mid) / half
        env[mask] = np.exp(-1.0 / (1.0 - vv * vv)) / norm

    mass_matrix = np.vstack([
        np.cos(np.outer(omega, logs)) * env[None, :],
        np.sin(np.outer(omega[1:], logs)) * env[None, :],
    ])

    return {
        "n_max": n_max,
        "omega_max": omega_max,
        "u": u,
        "psi": psi,
        "fixed": fixed,
        "mass_matrix": mass_matrix,
        "n_grid": n_grid,
    }


def solve_nested_level(tau, gamma, level_index, previous=None, start=None):
    n_max, omega_max = LEVELS[level_index]
    mass_nodes = np.arange(2, n_max + 1, dtype=int)
    active_k = int(np.sum(tau <= omega_max + MARGIN))

    blocks = []
    for j in range(level_index + 1):
        nb, ob = LEVELS[j]
        blocks.append(build_block(tau, nb, ob, active_k, mass_nodes))

    x0 = np.r_[tau[:active_k], np.zeros(mass_nodes.size)]
    if previous is not None:
        k_copy = min(previous["active_k"], active_k)
        n_copy = min(previous["masses"].size, mass_nodes.size)
        x0[:k_copy] = previous["ordinates"][:k_copy]
        x0[active_k:active_k + n_copy] = previous["masses"][:n_copy]

    lower = np.r_[tau[:active_k] - SHIFT_BOUND, -MASS_BOUND * np.ones(mass_nodes.size)]
    upper = np.r_[tau[:active_k] + SHIFT_BOUND, MASS_BOUND * np.ones(mass_nodes.size)]
    if start is not None:
        x0 = start
    x0 = np.clip(x0, lower + 1e-10, upper - 1e-10)

    def residual(z):
        ordinates = z[:active_k]
        masses = z[active_k:]
        pieces = []
        for block in blocks:
            spectral = block["psi"] @ np.cos(np.outer(block["u"], ordinates)).sum(axis=1)
            r = spectral + block["fixed"] + block["mass_matrix"] @ masses
            pieces.append(r / math.sqrt(r.size))
        return np.concatenate(pieces)

    def jacobian(z):
        ordinates = z[:active_k]
        pieces = []
        for block in blocks:
            jk = block["psi"] @ (-block["u"][:, None] * np.sin(np.outer(block["u"], ordinates)))
            j = np.hstack([jk, block["mass_matrix"]])
            pieces.append(j / math.sqrt(j.shape[0]))
        return np.vstack(pieces)

    sol = least_squares(
        residual,
        x0,
        jac=jacobian,
        method="trf",
        tr_solver="lsmr",
        bounds=(lower, upper),
        max_nfev=MAX_NFEV,
        ftol=2e-10,
        xtol=2e-10,
        gtol=2e-10,
        x_scale="jac",
    )

    ordinates = sol.x[:active_k]
    masses = sol.x[active_k:]
    # conditioning and active box constraints at the solution
    rank, cond, weak = svd_report(jacobian(sol.x), slice(active_k, None))
    n_rows = int(sum(b["psi"].shape[0] for b in blocks))
    act_shift = int(np.sum(np.abs(ordinates - tau[:active_k]) >= SHIFT_BOUND - 1e-6))
    act_mass = int(np.sum(np.abs(masses) >= MASS_BOUND - 1e-6))

    block_rows = []
    for block in blocks:
        spectral = block["psi"] @ np.cos(np.outer(block["u"], ordinates)).sum(axis=1)
        r = spectral + block["fixed"] + block["mass_matrix"] @ masses
        block_rows.append((block["n_max"], float(np.sqrt(np.mean(r * r))), float(np.max(np.abs(r))), block["n_grid"]))

    result = {
        "n_max": n_max,
        "omega_max": omega_max,
        "active_k": active_k,
        "mass_nodes": mass_nodes,
        "ordinates": ordinates,
        "masses": masses,
        "blocks": block_rows,
        "nfev": sol.nfev,
        "status": sol.status,
        "rank": rank,
        "cond": cond,
        "weak_masses": weak,
        "rows": n_rows,
        "n_blocks": len(blocks),
        "active_shift": act_shift,
        "active_mass": act_mass,
    }

    if gamma is not None and gamma.size >= min(10, active_k):
        q = min(10, active_k)
        result["rms_first10_diagnostic"] = float(np.sqrt(np.mean((ordinates[:q] - gamma[:q]) ** 2)))
    else:
        result["rms_first10_diagnostic"] = float("nan")
    return result


def single_section(tau, gamma, n_max, omega_max, dom=0.25, nu=2201, kt=14000):
    """One bounded section with free masses, solved alone from the clock (Part 1)."""
    U = math.log(n_max + 0.5)
    grid = np.linspace(0.0, U, nu)
    u = grid[1:-1]
    du = U / (nu - 1)
    v = (u - U / 2) / (U / 2)
    w = np.exp(-1.0 / (1.0 - v * v))
    w /= w.sum() * du
    smooth = 0.5 * (np.exp(u / 2) - np.exp(-u / 2) / (np.exp(2 * u) - 1))
    ns = np.arange(2, n_max + 1)
    om = np.arange(0.0, omega_max + 1e-12, dom)
    Psi = np.vstack([w * np.cos(o * u) for o in om] + [w * np.sin(o * u) for o in om[1:]]) * du
    Pn = np.vstack([np.interp(np.log(ns), u, Psi[j] / du) for j in range(Psi.shape[0])])
    clock = np.zeros_like(u)
    for a in range(0, kt, 400):
        clock += np.cos(np.outer(u, tau[a:min(kt, a + 400)])).sum(axis=1)
    K = int(np.sum(tau <= omega_max + MARGIN))
    tail = clock - np.cos(np.outer(u, tau[:K])).sum(axis=1)

    def fun(z):
        return Psi @ (np.cos(np.outer(u, z[:K])).sum(axis=1) + tail - smooth) + Pn @ z[K:]

    def jac(z):
        return np.hstack([Psi @ (-u[:, None] * np.sin(np.outer(u, z[:K]))), Pn])

    z0 = np.r_[tau[:K], np.zeros(ns.size)]
    lo = np.r_[tau[:K] - SHIFT_BOUND, -MASS_BOUND * np.ones(ns.size)]
    hi = np.r_[tau[:K] + SHIFT_BOUND, MASS_BOUND * np.ones(ns.size)]
    sol = least_squares(fun, z0, jac=jac, method="trf", bounds=(lo, hi), max_nfev=1200,
                        ftol=1e-11, xtol=1e-11, gtol=1e-11, x_scale="jac")
    x, a = sol.x[:K], sol.x[K:]
    nrms = np.linalg.norm(sol.fun) / math.sqrt(Psi.shape[0])
    rank, cond, weak = svd_report(jac(sol.x), slice(K, None))
    act_shift = int(np.sum(np.abs(x - tau[:K]) >= SHIFT_BOUND - 1e-6))
    act_mass = int(np.sum(np.abs(a) >= MASS_BOUND - 1e-6))
    rms10 = float(np.sqrt(np.mean((x[:10] - gamma[:10]) ** 2))) if gamma is not None else float("nan")
    # cross-validation on tests not used in the solve: other supports, shifted frequency grid
    cv = []
    for name, af, bf in (("full", 0.0, 1.0), ("inner80", 0.1, 0.9), ("left", 0.05, 0.55),
                         ("right", 0.45, 0.95), ("middle", 0.25, 0.75)):
        A, B = af * U, bf * U
        vv = (u - (A + B) / 2) / ((B - A) / 2)
        wc = np.zeros_like(u)
        ins = np.abs(vv) < 1
        wc[ins] = np.exp(-1.0 / (1.0 - vv[ins] ** 2))
        wc /= wc.sum() * du
        omc = (np.arange(int(0.8 * omega_max / dom)) + 0.5) * dom
        Pc = np.vstack([wc * np.cos(o * u) for o in omc] + [wc * np.sin(o * u) for o in omc]) * du
        Pnc = np.vstack([np.interp(np.log(ns), u, Pc[j] / du) for j in range(Pc.shape[0])])
        r = Pc @ (np.cos(np.outer(u, x)).sum(axis=1) + tail - smooth) + Pnc @ a
        cv.append((n_max, name, af, bf, 0.8 * omega_max, float(np.sqrt(np.mean(r * r))), float(np.max(np.abs(r)))))
    return dict(N=n_max, Omega=omega_max, K=K, x=x, a=a, ns=ns, nrms=nrms, rms10=rms10, status=sol.status,
                nfev=sol.nfev, rows=Psi.shape[0], cv=cv, rank=rank, cond=cond, weak=weak, act_shift=act_shift,
                act_mass=act_mass)


def main():
    tau, gamma = load_data()
    # ---------------- Part 1: single bounded sections
    say("Part 1: single bounded sections, solved alone from the clock (|shift| <= %.1f, |mass| <= %.1f)"
        % (SHIFT_BOUND, MASS_BOUND))
    singles = [single_section(tau, gamma, N, Om) for N, Om in ((20, 70.0), (34, 110.0), (50, 150.0))]
    summ, ordrows, massrows, cvrows = [], [], [], []
    for r in singles:
        say("N=%3d Omega=%.0f K=%3d masses=%d rows=%d: normalized residual %.3e (status %d, nfev %d); "
            "rms(first 10 - gamma) = %.3e; mass energy %.4f, max |mass| %.4f"
            % (r["N"], r["Omega"], r["K"], r["ns"].size, r["rows"], r["nrms"], r["status"], r["nfev"], r["rms10"],
               np.sum(r["a"] ** 2), np.max(np.abs(r["a"]))))
        say("    Jacobian at the solution: numerical rank %d of %d columns, condition number %.2e on that subspace, "
            "%d edge masses with weight < 1e-12; active bounds: %d of %d shifts at |shift| = %.1f, %d of %d masses at |mass| = %.1f"
            % (r["rank"], r["K"] + r["ns"].size, r["cond"], r["weak"], r["act_shift"], r["K"], SHIFT_BOUND,
               r["act_mass"], r["ns"].size, MASS_BOUND))
        summ.append((r["N"], r["Omega"], r["K"], r["nrms"], r["rms10"], np.sum(r["a"] ** 2), np.max(np.abs(r["a"]))))
        for k in range(r["K"]):
            g = gamma[k] if gamma is not None else float("nan")
            ordrows.append((r["N"], k + 1, tau[k], r["x"][k], g, r["x"][k] - g, r["x"][k] - tau[k]))
        for n, a in zip(r["ns"], r["a"]):
            e = von_mangoldt(int(n)) / (2 * math.sqrt(n))
            massrows.append((r["N"], n, a, e, a - e))
        for c in r["cv"]:
            say("    cross-validation %-8s support [%.2f, %.2f] U, omega <= %.0f: rms %.3e, max %.3e" % c[1:])
            cvrows.append(c)
    np.savetxt(OUT / "s13_bounded_mass_summary.csv", np.array(summ, dtype=float), delimiter=",",
               header="N,Omega,K,nrms,rms10_gamma_diagnostic,mass_energy,mass_max", comments="")
    np.savetxt(OUT / "s13_bounded_mass_ordinates.csv", np.array(ordrows, dtype=float), delimiter=",",
               header="N,k,tau,solved,gamma_diagnostic,solved_minus_gamma,solved_minus_tau", comments="")
    np.savetxt(OUT / "s13_bounded_mass_masses.csv", np.array(massrows, dtype=float), delimiter=",",
               header="N,n,solved_mass,von_mangoldt_diagnostic,difference", comments="")
    with open(OUT / "s13_cross_validation.csv", "w") as f:
        f.write("N,support,a_frac,b_frac,omega_max,rms,max_abs\n")
        for c in cvrows:
            f.write("%d,%s,%.2f,%.2f,%.1f,%.6e,%.6e\n" % c)

    # ---------------- Part 2: nested sections with permanent blocks
    say("")
    say("Part 2: nested sections; every earlier test block stays active (max_nfev = %d per section)" % MAX_NFEV)
    rows = []
    previous = None
    nested = {}
    for level_index in range(len(LEVELS)):
        result = solve_nested_level(tau, gamma, level_index, previous)
        previous = result
        nested[result["n_max"]] = result
        say(
            f"N={result['n_max']:3d} K={result['active_k']:3d} "
            f"max_shift={np.max(np.abs(result['ordinates'] - tau[:result['active_k']])):.6f} "
            f"max_mass={np.max(np.abs(result['masses'])):.6f} "
            f"diagnostic_rms10={result['rms_first10_diagnostic']:.3e} status={result['status']} nfev={result['nfev']}"
        )
        say(f"  equations={result['rows']} in {result['n_blocks']} blocks, unknowns={result['active_k']}+{result['masses'].size}, "
            f"weighted Jacobian: numerical rank {result['rank']} of {result['active_k'] + result['masses'].size}, "
            f"condition number {result['cond']:.2e} on that subspace, {result['weak_masses']} edge masses with weight < 1e-12; active bounds: "
            f"{result['active_shift']} shifts, {result['active_mass']} masses")
        for block_n, rms, max_abs, n_grid in result["blocks"]:
            say(f"  block N={block_n:3d}: RMS={rms:.3e}, max={max_abs:.3e}, grid={n_grid}")
            rows.append((result["n_max"], block_n, rms, max_abs, n_grid))

    np.savetxt(
        OUT / "s13_nested_metric_summary.csv",
        np.asarray(rows, dtype=float),
        delimiter=",",
        header="section_N,block_N,rms,max_abs,n_grid",
        comments="",
    )

    # repeatability of the N = 50 nested section from perturbed starts
    i50 = [L[0] for L in LEVELS].index(50)
    base = nested[50]
    rng = np.random.default_rng(2025)
    say("repeatability of the N = 50 section (same blocks) from three perturbed starts:")
    for trial in range(3):
        Kb = base["active_k"]
        x0 = np.r_[tau[:Kb] + rng.uniform(-0.5, 0.5, Kb), rng.uniform(-0.2, 0.2, base["masses"].size)]
        r = solve_nested_level(tau, gamma, i50, None, start=x0)
        say("  start %d: max block RMS %.3e (reference %.3e), max |ordinate difference| %.3e, "
            "max |mass difference| %.3e, status %d, nfev %d"
            % (trial + 1, max(b[1] for b in r["blocks"]), max(b[1] for b in base["blocks"]),
               np.max(np.abs(r["ordinates"] - base["ordinates"])), np.max(np.abs(r["masses"] - base["masses"])),
               r["status"], r["nfev"]))

    # ---------------- figures
    fig, ax = plt.subplots(1, 1, figsize=(9.6, 6.0))
    for N in (50, 70, 100):
        bl = nested[N]["blocks"]
        r_ = nested[N]
        ax.semilogy([b[0] for b in bl], [b[1] for b in bl], "o-",
                    label="section N=%d: %d equations in %d blocks, %d ordinates + %d masses (%d at the box)"
                    % (N, r_["rows"], r_["n_blocks"], r_["active_k"], r_["masses"].size, r_["active_mass"]))
    ax.set_xlabel("test block (N of the section that introduced it)")
    ax.set_ylabel("RMS residual of the block")
    ax.set_title("Nested bounded endpoint sections: residual on every permanent block")
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(FIG / "fig16_nested_bounded_endpoint.png", dpi=150)
    fig, ax = plt.subplots(1, 1, figsize=(9.6, 6.0))
    n15 = np.arange(2, 16)
    ax.plot(n15, [von_mangoldt(int(n)) / (2 * math.sqrt(n)) for n in n15], "ks", ms=8, mfc="none",
            label=r"$\Lambda(n)/(2\sqrt{n})$ (diagnostic only)")
    for r, mk in zip(singles, ("o", "^", "v")):
        ax.plot(n15, r["a"][:n15.size], mk + "-", ms=5, lw=0.8,
                label="free masses, section N=%d (%d ordinates, %d masses, %d equations)"
                % (r["N"], r["K"], r["ns"].size, r["rows"]))
        atb = np.abs(r["a"][:n15.size]) >= MASS_BOUND - 1e-6
        ax.plot(n15[atb], r["a"][:n15.size][atb], mk, ms=9, mfc="none", mec="r", mew=1.5)
    at_box = ["n=" + ",".join(str(int(n)) for n, a in zip(r["ns"], r["a"]) if abs(a) >= MASS_BOUND - 1e-6)
              + " (N=%d)" % r["N"] for r in singles]
    n_in = sum(int(np.sum(np.abs(r["a"][:n15.size]) >= MASS_BOUND - 1e-6)) for r in singles)
    ax.plot([], [], "o", ms=9, mfc="none", mec="r", mew=1.5,
            label="mass at the box $|a_n|=0.5$ (active bound): %d with $n\\leq15$; all at the box: %s"
            % (n_in, "; ".join(at_box)))
    ax.axhline(MASS_BOUND, color="0.6", lw=0.6, ls="--")
    ax.axhline(-MASS_BOUND, color="0.6", lw=0.6, ls="--")
    ax.set_xlabel("n")
    ax.set_title(r"Recovered free masses, $n\leq15$ (all masses of this range shown), single bounded sections; box $|a_n|\leq0.5$ dashed",
                 fontsize=10)
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(FIG / "fig17_bounded_mass_stability.png", dpi=150)
    with open(OUT / "s13_nested_bounded_endpoint_console.txt", "w") as f:
        f.write("\n".join(LINES) + "\n")


if __name__ == "__main__":
    main()
