#!/usr/bin/env python3
"""s11_rvm_z1_difference_analysis.py

Python reproduction of the focused MATLAB program RVM_Z1_DIFFERENCE_ANALYSIS.m.

The script reads the two separately distributed binary ordinate files and
computes, for K = 1e3, 1e4, 1e5, 5e5, Kmax on 2 <= x <= 1e5:
  * the Perron-based Mertens difference M_RVM,K^crit - M_Z1,K^crit;
  * the explicit-formula prime-counting difference pi_RVM,K - pi_Z1,K;
  * K-convergence errors, spectral-shell contributions, normalizations,
    running suprema, and band statistics.

The numerical conventions and default parameters match the MATLAB analysis
used for the figures discussed in the paper.  The raw binaries are not
included in the archive; place zeross.bin and zLamb.bin in data/ before use.
"""

import os
import math
import time
import numpy as np
_trapz = getattr(np, "trapezoid", None) or np.trapz   # np.trapz was removed in NumPy 2.4
from scipy.special import expi, loggamma
from scipy.integrate import quad
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
DATA = os.path.join(ROOT, "data")
OUT = os.path.join(ROOT, "output")
FIG = os.path.join(ROOT, "figures")
os.makedirs(OUT, exist_ok=True)
os.makedirs(FIG, exist_ok=True)

XMAX = 100000.0
NX = 500
CP = 0.75
TPERRON = 80.0
NTP = 401
KHEAD = 30000
RPROD = 5
SBLOCK = 40
KEI = 5000
REI = 5
ZERO_BLOCK = 100000
ARG_BLOCK = 16


def say(lines, text=""):
    print(text)
    lines.append(text)


def load_ordinates():
    tau_path = os.path.join(DATA, "zLamb.bin")
    gam_path = os.path.join(DATA, "zeross.bin")
    if not os.path.exists(tau_path) or not os.path.exists(gam_path):
        raise FileNotFoundError(
            "Place data/zLamb.bin and data/zeross.bin in the archive tree before running s11."
        )
    tau = np.fromfile(tau_path, dtype="<f8")
    gam = np.fromfile(gam_path, dtype="<f8")
    kmax = min(len(tau), len(gam))
    return tau[:kmax], gam[:kmax]


def zeta_snapshots(s, ords, klist):
    """Canonical-product snapshots using the same head+moment expansion as MATLAB."""
    s = np.asarray(s, dtype=np.complex128).ravel()
    ords = np.asarray(ords, dtype=float).ravel()
    klist = np.asarray(klist, dtype=np.int64).ravel()
    ns = len(s)
    nk = len(klist)
    kmax = int(klist.max())
    aord = 0.25 + ords[:kmax] ** 2

    moments = np.zeros((RPROD, nk), dtype=float)
    for ik, K in enumerate(klist):
        if K > KHEAD:
            tail = aord[KHEAD:K]
            for r in range(1, RPROD + 1):
                moments[r - 1, ik] = np.sum(tail ** (-r))

    zout = np.empty((ns, nk), dtype=np.complex128)
    for i0 in range(0, ns, SBLOCK):
        i1 = min(ns, i0 + SBLOCK)
        ss = s[i0:i1]
        q = ss * (ss - 1.0)
        logG = np.log(ss * (ss - 1.0)) + loggamma(ss / 2.0) - (ss / 2.0) * math.log(math.pi)

        for ik, K in enumerate(klist):
            kh = min(int(K), KHEAD)
            head = aord[:kh]
            logP = np.sum(np.log(1.0 + q[:, None] / head[None, :]), axis=1)
            if K > KHEAD:
                tail = np.zeros_like(q)
                qpow = np.ones_like(q)
                for r in range(1, RPROD + 1):
                    qpow *= q
                    tail += ((-1) ** (r + 1)) * qpow * moments[r - 1, ik] / r
                logP += tail
            zout[i0:i1, ik] = np.exp(logP - logG)
    return zout


def tail_integral(y):
    val, _ = quad(
        lambda q: 1.0 / (q * (q * q - 1.0) * math.log(q)),
        float(y), np.inf, epsrel=2e-9, epsabs=2e-11, limit=200,
    )
    return val


def j_snapshots(y, ords, klist, label, lines):
    y = np.asarray(y, dtype=float).ravel()
    ords = np.asarray(ords, dtype=float).ravel()
    klist = np.asarray(klist, dtype=np.int64).ravel()
    ny = len(y)
    nk = len(klist)
    kmax = int(klist.max())
    jout = np.zeros((ny, nk), dtype=float)
    nblocks = (ny + ARG_BLOCK - 1) // ARG_BLOCK

    for ib in range(nblocks):
        a0 = ib * ARG_BLOCK
        a1 = min(ny, a0 + ARG_BLOCK)
        yy = y[a0:a1]
        u = np.log(yy)
        B = len(u)
        sum_at_k = np.zeros((B, nk), dtype=np.complex128)

        kbase = min(KEI, kmax)
        rho = 0.5 + 1j * ords[:kbase]
        ehead = expi(rho[:, None] * u[None, :])
        cumulative = np.sum(ehead, axis=0)

        for ik, K in enumerate(klist):
            if K <= KEI:
                sum_at_k[:, ik] = np.sum(expi((0.5 + 1j * ords[:K])[:, None] * u[None, :]), axis=0)
            elif K == kbase:
                sum_at_k[:, ik] = cumulative

        kstart = kbase
        while kstart < kmax:
            higher = klist[klist > kstart]
            next_target = int(higher.min()) if len(higher) else kmax
            kend = min(kmax, kstart + ZERO_BLOCK, next_target)
            ok = ords[kstart:kend]
            rk = 0.5 + 1j * ok
            E = np.exp(1j * ok[:, None] * u[None, :])
            local = np.zeros(B, dtype=np.complex128)
            rpow = 1.0 / rk
            for qidx in range(REI):
                Sq = np.sum(rpow[:, None] * E, axis=0)
                coeff = math.factorial(qidx) * np.exp(u / 2.0) / (u ** (qidx + 1))
                local += coeff * Sq
                rpow /= rk
            cumulative += local
            hits = np.where(klist == kend)[0]
            for ik in hits:
                sum_at_k[:, ik] = cumulative
            kstart = kend

        lix = expi(u).real
        corr = np.array([tail_integral(v) for v in yy])
        jout[a0:a1, :] = lix[:, None] - 2.0 * sum_at_k.real - math.log(2.0) + corr[:, None]
        say(lines, f"  {label}: argument block {ib+1}/{nblocks}")
    return jout


def mobius_vector(N):
    mu = np.ones(N + 1, dtype=np.int8)
    is_prime = np.ones(N + 1, dtype=bool)
    is_prime[:2] = False
    for p in range(2, N + 1):
        if not is_prime[p]:
            continue
        mu[p::p] *= -1
        p2 = p * p
        if p2 <= N:
            mu[p2::p2] = 0
        if p * p <= N:
            is_prime[p * p::p] = False
    return mu


def save_lines_plot(x, data, labels, ylabel, title, filename, zero=True):
    fig, ax = plt.subplots(figsize=(7.4, 4.8))
    for j, lab in enumerate(labels):
        ax.plot(x, data[:, j], linewidth=1.0, label=lab)
    if zero:
        ax.axhline(0.0, linestyle="--", linewidth=0.8)
    ax.set_xlabel("x")
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.grid(True, alpha=0.25)
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, filename), dpi=180)
    plt.close(fig)


def main():
    t0 = time.time()
    lines = []
    tau, gam = load_ordinates()
    kmax = min(len(tau), len(gam))
    klist = np.unique(np.array([1000, 10000, 100000, 500000, kmax], dtype=np.int64))
    klist = klist[klist <= kmax]
    nk = len(klist)
    x = np.linspace(2.0, XMAX, NX)

    say(lines, "s11: Python reproduction of the MATLAB RVM-Z1 difference analysis")
    say(lines, f"Kmax = {kmax}")
    say(lines, "Klist = " + " ".join(str(int(v)) for v in klist))

    tp = np.linspace(0.0, TPERRON, NTP)
    sp = CP + 1j * tp
    say(lines, "Computing Perron-line zeta snapshots...")
    zRP = zeta_snapshots(sp, tau, klist)
    zGP = zeta_snapshots(sp, gam, klist)

    MR = np.zeros((NX, nk))
    MG = np.zeros((NX, nk))
    for ik in range(nk):
        baseR = (1.0 / zRP[:, ik]) / sp
        baseG = (1.0 / zGP[:, ik]) / sp
        for ix, xx in enumerate(x):
            ph = np.exp(1j * tp * math.log(xx))
            MR[ix, ik] = xx ** CP / math.pi * np.real(_trapz(baseR * ph, tp))
            MG[ix, ik] = xx ** CP / math.pi * np.real(_trapz(baseG * ph, tp))
    dM = MR - MG

    say(lines, "Building Mobius-inversion arguments...")
    mu = mobius_vector(int(math.floor(XMAX)))
    all_y = []
    all_coeff = []
    maps = []
    for xx in x:
        start = len(all_y)
        mmax = int(math.floor(math.log(xx) / math.log(2.0)))
        for m in range(1, mmax + 1):
            if mu[m] == 0:
                continue
            y = xx ** (1.0 / m)
            if y >= 2.0:
                all_y.append(y)
                all_coeff.append(float(mu[m]) / m)
        maps.append((start, len(all_y) - start))
    all_y = np.asarray(all_y)
    all_coeff = np.asarray(all_coeff)
    y_unique, inverse = np.unique(all_y, return_inverse=True)

    say(lines, "Computing J snapshots...")
    JRu = j_snapshots(y_unique, tau, klist, "RVM", lines)
    JGu = j_snapshots(y_unique, gam, klist, "Z1", lines)
    JRa = JRu[inverse]
    JGa = JGu[inverse]

    piR = np.zeros((NX, nk))
    piG = np.zeros((NX, nk))
    for ix, (start, count) in enumerate(maps):
        if count:
            sl = slice(start, start + count)
            piR[ix, :] = all_coeff[sl] @ JRa[sl, :]
            piG[ix, :] = all_coeff[sl] @ JGa[sl, :]
    dPi = piR - piG

    sqrtx = np.sqrt(x)
    logx = np.log(x)
    nPi = dPi / (sqrtx[:, None] / logx[:, None])
    nM_sqrt = dM / sqrtx[:, None]
    nM_sqrtlog = dM / (sqrtx[:, None] * logx[:, None])

    errM = dM - dM[:, [-1]]
    errPi = dPi - dPi[:, [-1]]
    shellM = np.column_stack([dM[:, 0], np.diff(dM, axis=1)])
    shellPi = np.column_stack([dPi[:, 0], np.diff(dPi, axis=1)])
    runSupPi = np.maximum.accumulate(np.abs(nPi), axis=0)
    runSupMsqrt = np.maximum.accumulate(np.abs(nM_sqrt), axis=0)
    runSupMsqrtlog = np.maximum.accumulate(np.abs(nM_sqrtlog), axis=0)

    rmsErrM = np.sqrt(np.mean(errM ** 2, axis=0))
    maxErrM = np.max(np.abs(errM), axis=0)
    rmsErrPi = np.sqrt(np.mean(errPi ** 2, axis=0))
    maxErrPi = np.max(np.abs(errPi), axis=0)
    shellRMSM = np.sqrt(np.mean(shellM ** 2, axis=0))
    shellMaxM = np.max(np.abs(shellM), axis=0)
    shellRMSPi = np.sqrt(np.mean(shellPi ** 2, axis=0))
    shellMaxPi = np.max(np.abs(shellPi), axis=0)

    summary = np.column_stack([
        klist, rmsErrM, maxErrM, rmsErrPi, maxErrPi,
        shellRMSM, shellMaxM, shellRMSPi, shellMaxPi,
        runSupPi[-1], runSupMsqrt[-1], runSupMsqrtlog[-1],
    ])
    np.savetxt(
        os.path.join(OUT, "s11_difference_summary.csv"), summary, delimiter=",",
        header=("K,rms_err_M,max_err_M,rms_err_pi,max_err_pi,rms_shell_M,max_shell_M,"
                "rms_shell_pi,max_shell_pi,final_run_sup_pi,final_run_sup_M_sqrt,"
                "final_run_sup_M_sqrtlog"), comments="", fmt="%.15e"
    )
    np.savez_compressed(
        os.path.join(OUT, "s11_difference_analysis.npz"),
        x=x, Klist=klist, MR=MR, MG=MG, dM=dM, piR=piR, piG=piG, dPi=dPi,
        nPi=nPi, nM_sqrt=nM_sqrt, nM_sqrtlog=nM_sqrtlog,
        errM=errM, errPi=errPi, shellM=shellM, shellPi=shellPi,
        runSupPi=runSupPi, runSupMsqrt=runSupMsqrt, runSupMsqrtlog=runSupMsqrtlog,
    )

    labels = [f"K={int(v)}" + (" (max)" if v == kmax else "") for v in klist]
    shell_labels = [f"1...{int(klist[0])}"] + [f"{int(klist[j-1])+1}...{int(klist[j])}" for j in range(1, nk)]
    save_lines_plot(x, dM, labels, "M_RVM,K^crit - M_Z1,K^crit",
                    "Mertens difference: RVM - Z1", "s11_difference_mertens.png")
    save_lines_plot(x, dPi, labels, "pi_RVM,K - pi_Z1,K",
                    "Prime-counting difference: RVM - Z1", "s11_difference_pi.png")
    save_lines_plot(x, shellM, shell_labels, "Mertens shell contribution",
                    "Spectral shell contributions to the Mertens difference", "s11_shells_mertens.png")
    save_lines_plot(x, shellPi, shell_labels, "Prime-counting shell contribution",
                    "Spectral shell contributions to the prime-counting difference", "s11_shells_pi.png")
    save_lines_plot(x, runSupMsqrt, labels, "max_{x<=X} |dM_K(x)| / sqrt(x)",
                    "Running normalized supremum: Mertens / sqrt(x)", "s11_runsup_mertens.png", zero=False)
    save_lines_plot(x, runSupPi, labels, "max_{x<=X} |dpi_K(x)| / (sqrt(x)/log(x))",
                    "Running normalized supremum: prime-counting difference", "s11_runsup_pi.png", zero=False)

    say(lines, "")
    say(lines, "K-convergence and shell summary")
    for j, K in enumerate(klist):
        say(lines, f"K={int(K):8d}  rmsErrM={rmsErrM[j]:.8g}  maxErrM={maxErrM[j]:.8g}  "
                   f"rmsErrPi={rmsErrPi[j]:.8g}  maxErrPi={maxErrPi[j]:.8g}")
        say(lines, f"            rmsShellM={shellRMSM[j]:.8g} maxShellM={shellMaxM[j]:.8g}  "
                   f"rmsShellPi={shellRMSPi[j]:.8g} maxShellPi={shellMaxPi[j]:.8g}")
    say(lines, f"Total elapsed time: {(time.time()-t0)/60.0:.2f} min")
    with open(os.path.join(OUT, "s11_difference_analysis_console.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")


if __name__ == "__main__":
    main()
