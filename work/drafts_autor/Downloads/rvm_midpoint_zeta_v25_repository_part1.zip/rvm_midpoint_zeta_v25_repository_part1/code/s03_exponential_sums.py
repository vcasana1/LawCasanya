"""Experiment 3: exponential sums S(N;u) = sum_{k<=N} exp(i u o_k) over the midpoint
ordinates tau_k and over the ordinates gamma_k of zeta, and the height transforms M_H(x)."""
import os
import numpy as np
import scipy.io as sio
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from rvm_common import Tee, load_ordinates, write_csv, savefig, OUT

say = Tee("s03_exponential_sums")
gam, tau = load_ordinates()
N = gam.size
step = 2000
Nk = np.arange(step, N + 1, step)
xs = [2.0, 3.0, 4.0, 6.0, 10.0]
Lam = {2.0: np.log(2), 3.0: np.log(3), 4.0: np.log(2), 6.0: 0.0, 10.0: 0.0}
res = {}
# max|S_RVM| is taken over ALL N <= N_max (full cumulative sum); the CSV files and the
# figure keep every 2000th N only.  Landau's formula (Landau 1912): for fixed x > 1,
# sum_{0<gamma<=T} x^(i gamma) = -(T/2pi) Lambda(x)/sqrt(x) + O_x(log T); it is used here
# only as an illustrative comparison.  |M_H^RVM(x)| = |S_RVM(N)|/N with n_RVM(H) = N, the
# normalization of eq. (MH-RVM) of the paper.
say("%6s %14s %14s %14s %14s %16s %14s" % ("x", "max_N|S_RVM|", "max sampled", "max|S|/log N",
                                          "|S_zeta(N)|", "Landau -T/2pi*L/sqrt(x)", "|M_H^RVM(x)|"))
k_all = np.arange(1, N + 1)
for x in xs:
    u = np.log(x)
    SRall = np.cumsum(np.exp(1j * u * tau))
    SR = SRall[Nk - 1]
    SZ = np.cumsum(np.exp(1j * u * gam))[Nk - 1]
    res[x] = (SR, SZ)
    landau = -gam[-1] / (2 * np.pi) * Lam[x] / np.sqrt(x)
    sel = k_all >= 3
    say("%6.1f %14.4f %14.4f %14.4f %14.2f %16.2f %14.3e" % (x, np.max(np.abs(SRall)), np.max(np.abs(SR)),
                                                            np.max(np.abs(SRall[sel]) / np.log(k_all[sel])),
                                                            np.abs(SZ[-1]), landau, np.abs(SR[-1]) / N))
    write_csv("s03_expsum_x%g.csv" % x, ["N", "re_S_RVM", "im_S_RVM", "re_S_zeta", "im_S_zeta"],
              [Nk, SR.real, SR.imag, SZ.real, SZ.imag])

fig, ax = plt.subplots(1, 2, figsize=(12, 4))
cols = {2.0: "tab:blue", 3.0: "tab:green", 4.0: "tab:purple", 6.0: "tab:orange", 10.0: "tab:red"}
for x in xs:
    ax[0].plot(Nk, np.abs(res[x][0]), "-", color=cols[x], lw=0.8, label=r"$x=%g$" % x)
ax[0].plot(Nk, np.log(Nk), "k--", lw=1, label=r"$\log N$")
ax[0].set_xlabel("N")
ax[0].set_ylabel(r"$|S_{\rm RVM}(N;\log x)|$")
ax[0].set_title(r"Midpoint ordinates: observed $|\sum_{k\leq N}x^{i\tau_k}|$ compared with $\log N$", fontsize=10)
ax[0].legend(fontsize=8, ncol=2)
for x in xs:
    ax[1].plot(Nk, res[x][1].real, "-", color=cols[x], lw=0.8, label=r"$x=%g$" % x)
T = np.interp(Nk, np.arange(1, N + 1), gam)
for x in (2.0, 3.0, 4.0):
    ax[1].plot(Nk, -T / (2 * np.pi) * Lam[x] / np.sqrt(x), ":", color=cols[x], lw=1.5)
ax[1].set_xlabel("N")
ax[1].set_ylabel(r"$\mathrm{Re}\sum_{k\leq N}x^{i\gamma_k}$")
ax[1].set_title(r"Zeros of $\zeta$: Landau term $-\frac{T}{2\pi}\frac{\Lambda(x)}{\sqrt{x}}$ (dotted), illustrative", fontsize=10)
ax[1].legend(fontsize=8, ncol=2)
fig.tight_layout()
savefig(fig, "fig04_exponential_sums.png")
sio.savemat(os.path.join(OUT, "s03_results.mat"), {"N": Nk, "x": np.array(xs),
                                                   "S_RVM": np.array([res[x][0] for x in xs]),
                                                   "S_zeta": np.array([res[x][1] for x in xs])})
say.close()
