# Block-entry test: from the polished stage-m solution x^(m) (square section polished as in
# cert7), put the NEW band (tau_k in (2.4/s_m, 2.4/s_{m+1}]) and everything beyond at Gonek X=8
# values, and ask whether the floating-point Banach inequalities hold for
# (a) the band-only square system (new band unknowns, tests from level m+1),
# (b) the full square system of stage m+1, started there (no polishing).
# Double precision throughout; "FLOAT_PASS" means the inequalities hold in floating point, not that
# existence is proved.  Q solves J_sel Q = I and its defect ||I - Q J_sel||_inf enters k(r); margins
# are maxima over sampled radii.  gamma.npy is read only for the diagnostic column "Gonek band err".
import numpy as np, json
from scipy.linalg import qr, solve
from core import *
g=np.load('gamma.npy'); tau=clock(60000)
q,s0,sp,INT=0.85,0.08,1.0,2.4
def d2(c,s,k):
    a=s*s; e=s*SQ2PI*np.exp(-a*k*k/2)
    return e*(((a*k)**2-a-c*c)*np.cos(c*k)+2*a*k*c*np.sin(c*k))
def A3b(c,s,k,r):
    a=s*s; kl=np.maximum(np.abs(k)-r,0); ku=np.abs(k)+r; w=a*ku+c
    return s*SQ2PI*np.exp(-a*kl*kl/2)*(w**3+3*a*w)
def inv_defect(Jm):
    Q=solve(Jm,np.eye(Jm.shape[0])); return Q,float(np.max(np.sum(np.abs(np.eye(Jm.shape[0])-Q@Jm),axis=1)))
rG=np.load('gonekF_X8.npy'); kG=tau.copy(); kG[:len(rG)]=rG
def certify(Q,F,QBn,A3fun,d0):
    eta=np.max(np.abs(Q@F))
    for r in np.geomspace(max(eta,1e-15)*1.0001,1.0,300):
        kr=d0+QBn*r+0.5*np.max(np.sum(np.abs(Q)@A3fun(r),axis=1))*r*r
        if kr<1 and eta<=(1-kr)*r: return eta,r
    return eta,None
def margin(QBn,Q,A3fun,d0): return max((1-(d0+QBn*r+0.5*np.max(np.sum(np.abs(Q)@A3fun(r),axis=1))*r*r))*r for r in np.geomspace(1e-9,1e-1,50))
tests=[]; lev=[]; out=[]; prev=None
for m in range(1,16):
    s=s0*q**(m-1); T=4.0/s; U=np.log(max(T,7)/(2*np.pi))+2.0
    new=[(float(c),s) for c in np.arange(9*s,U+1e-9,sp*s)]; tests+=new; lev+=[m]*len(new)
    n=int(np.sum(tau<=INT/s)); cs=np.array([t[0] for t in tests]); ss=np.array([t[1] for t in tests]); lv=np.array(lev)
    if prev is not None:
        x0=kG.copy(); x0[:prev[1]]=prev[0][:prev[1]]          # old interior: polished stage-(m-1) solution; rest Gonek
        band=np.arange(prev[1],n); idx=np.where(lv==m)[0]
        Jb=dFphi(cs[idx][:,None],ss[idx][:,None],x0[None,band]); _,_,pv=qr(Jb.T,pivoting=True); sb=idx[np.sort(pv[:len(band)])]
        Qb,db=inv_defect(dFphi(cs[sb][:,None],ss[sb][:,None],x0[None,band])); Fb=residual([tests[i] for i in sb],x0)
        QBb=np.max(np.sum(np.abs(Qb@d2(cs[sb][:,None],ss[sb][:,None],x0[None,band])),axis=1))
        A3f=lambda r: A3b(cs[sb][:,None],ss[sb][:,None],x0[None,band],r)
        eb,rb=certify(Qb,Fb,QBb,A3f,db); mb=margin(QBb,Qb,A3f,db)
        J=dFphi(cs[:,None],ss[:,None],x0[None,:n]); _,_,pv=qr(J.T,pivoting=True); sf=np.sort(pv[:n])
        Qf,df=inv_defect(J[sf]); Ff=residual([tests[i] for i in sf],x0)
        QBf=np.max(np.sum(np.abs(Qf@d2(cs[sf][:,None],ss[sf][:,None],x0[None,:n])),axis=1))
        A3g=lambda r: A3b(cs[sf][:,None],ss[sf][:,None],x0[None,:n],r)
        ef,rf=certify(Qf,Ff,QBf,A3g,df); mf=margin(QBf,Qf,A3g,df)
        bandG=float(np.max(np.abs(x0[band]-g[band]))) if band[-1]<len(g) else float('nan')
        rec=dict(m=m,T=T,band=len(band),eta_band=float(eb),margin_band=float(mb),pass_band=rb is not None,
                 eta_full=float(ef),margin_full=float(mf),pass_full=rf is not None,gonek_band_err=bandG)
        out.append(rec)
        print(f"m={m:2d} T={T:5.0f} band={len(band):2d} | band-only: eta={eb:.1e} sampled margin={mb:.1e} {'FLOAT_PASS' if rb else 'no pass'} "
              f"| full: eta={ef:.1e} sampled margin={mf:.1e} {'FLOAT_PASS' if rf else 'no pass'} | Gonek band err={bandG:.1e}",flush=True)
    kk=kG.copy() if prev is None else x0.copy(); tsel=None
    J=dFphi(cs[:,None],ss[:,None],kk[None,:n]); _,_,pv=qr(J.T,pivoting=True); sel=np.sort(pv[:n]); tsel=[tests[i] for i in sel]
    try:
        for it in range(10):
            Jc=dFphi(cs[sel][:,None],ss[sel][:,None],kk[None,:n]); kk[:n]-=np.linalg.solve(Jc,residual(tsel,kk))
    except np.linalg.LinAlgError: print("singular at",m); break
    prev=(kk.copy(),n)
json.dump(out,open('entry.json','w'),indent=1)
