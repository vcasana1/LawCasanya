# Writes RESULTS.txt in the current directory (output/routeB) from the JSON outputs of the Route B
# programs, with the SHA-256 of the programs and input files used, so that the summary is tied to
# the code and data rather than to a date.  Run from output/routeB after the other programs.
import hashlib, json, os
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))


def sha(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        h.update(f.read())
    return h.hexdigest()


progs = ['core.py', 'zeros.py', 'gonek_fast.py', 'horizon.py', 'horizonG.py', 'cert7.py', 'diag_cert7_gamma.py',
         'entry.py', 'laplace_check.py', 'figs.py', 'results_summary.py']
inputs = ['gamma.npy', 'gonekF_X8.npy', 'horizonG_kap_M16_I2.4.npy', 'horizon_M16_I2.4_L4.json',
          'horizonG_M16_I2.4_L4.json', 'cert7.json', 'entry.json']
L = []
P = L.append
P('RVM rung system - staged floating-point candidate certificates (Route B numerics)')
P('Tests: Gaussians phi(u)=exp(-(u-c)^2/(2 s^2)), c>=9s; stage m: s_m=0.08*0.85^(m-1), T_m=4/s_m,')
P('centres spaced 1.0*s_m in [9 s_m, log(max(T_m,7)/2pi)+2]. Interior unknowns: tau_k <= 2.4/s_m.')
P('Masses a_n = Lambda(n)/(2 sqrt n); k(u)=cosh(u/2)-e^{-u/2}/(2(1-e^{-2u})).')
P('Gonek list X=8: roots of (theta(t)+alpha_X(t)-pi/2)/pi in Z (gonek_fast.py).')
P('gamma (400 zeros, mpmath, stored as doubles) is used ONLY for diagnostics, never in the constructions.')
P('Double precision throughout; no interval arithmetic.  FLOAT_PASS = the Banach inequalities hold in')
P('floating point (a candidate certificate), not a proof of existence.')
P('')
P('SHA-256 of the programs (code/routeB) and of the inputs/outputs read here (output/routeB):')
for p in progs:
    P('  %-28s %s' % (p, sha(os.path.join(HERE, p))))
for p in inputs:
    P('  %-28s %s' % (p, sha(p)))
P('')
hz = json.load(open('horizon_M16_I2.4_L4.json'))
hg = json.load(open('horizonG_M16_I2.4_L4.json'))
c7 = json.load(open('cert7.json'))
en = json.load(open('entry.json'))
P('STATUS CRITERIA: a receding horizon "reaches the threshold" if every one of its 16 stages ends with')
P('res_all < 1e-2 inside the box |kappa_k - tau_k| <= 3; it "does not reach" it if res_all >= 1e-2 at')
P('some stage.  A certificate test "passes" if its floating-point inequalities hold.')
P('')
P('FILES')
P(' core.py          residual, Jacobian, clock, k(u), mass pairing')
P(' validate.py      R(gamma)~1e-16 normalisation check            -> out_validate.txt')
P(' gonek*.py        Gonek lists, distance to gamma                 -> out_gonek.txt, out_gonek_fast.txt, gonek*.npy')
P(' horizon.py       receding horizon from the clock: does not reach (res_all in [%.1e, %.1e])  -> horizon_M16_I2.4_L4.json'
  % (min(x['res_all'] for x in hz), max(x['res_all'] for x in hz)))
P(' horizonG.py      receding horizon from Gonek X=8: reaches (res_all in [%.1e, %.1e])  -> horizonG_M16_I2.4_L4.json, out_horizonG.txt'
  % (min(x['res_all'] for x in hg), max(x['res_all'] for x in hg)))
P(' certG.py         l-inf Kantorovich test at the Gonek list (no stage passes)  -> out_certG.txt')
P(' cert2/3/4.py     l2 / Gauss-Newton / diagonal l-inf constants at Gonek list -> out_cert2/3/4.txt')
P(' cert5/6/7.py     floating-point Banach tests of square finite sections (cert7 = the one reported; cert5, cert6 = variants); '
  'cert7: %d stages pass -> out_cert7.txt, cert7.json, cert7_points.npz' % sum(1 for x in c7 if x['float_pass']))
P(' diag_cert7_gamma.py  distance of the cert7 points to gamma (diagnostic) -> out_cert7_gamma.txt')
P(' entry.py         block-entry test: band-only passes at %d of %d stages, full system at %d  -> out_entry.txt, entry.json'
  % (sum(1 for x in en if x['pass_band']), len(en), sum(1 for x in en if x['pass_full'])))
P(' laplace_check.py the identity (1/2)G\'/G = L[K]                  -> out_laplace_check.txt')
P(' staged.py, lsq*.py, floor.py, basin*.py, reg.py, coupling.py: exploratory runs, not used in the paper (logs *.json)')
P('')
for name, d in (('horizon_M16_I2.4_L4.json', hz), ('horizonG_M16_I2.4_L4.json', hg)):
    P(name)
    for x in d:
        P(' m=%2d T=%5.0f n=%3d res_all=%.1e res_lag4=%.1e max|k-g|(k<=20)=%.1e front(1e-2)=%d max|k-tau|=%.2f'
          % (x['m'], x['T'], x['interior'], x['res_all'], x['res_lag'], x['dev20'], x['f2'], x['dev_tau']))
T = np.array([x['T'] for x in c7]); fit = {}; err = {}
for key in ('Linf', 'QB', 'margin'):
    y = np.array([x[key] for x in c7])
    coef, cov = np.polyfit(np.log(T[3:]), np.log(y[3:]), 1, cov=True)
    fit[key], err[key] = coef[0], float(np.sqrt(cov[0, 0]))
P('')
P('Least-squares log-log fits over the computed stages m>=4 of cert7 (%d stages; regressions on the computed'
  % (T.size - 3))
P('range, not asymptotic laws; +- one standard error of the slope from the fit residuals):')
P('  Linf ~ T^(%.2f +- %.2f), ||QB|| ~ T^(%.2f +- %.2f), sampled Banach margin ~ T^(%.2f +- %.2f)'
  % (fit['Linf'], err['Linf'], fit['QB'], err['QB'], fit['margin'], err['margin']))
open('RESULTS.txt', 'w').write('\n'.join(L) + '\n')
print('\n'.join(L))
