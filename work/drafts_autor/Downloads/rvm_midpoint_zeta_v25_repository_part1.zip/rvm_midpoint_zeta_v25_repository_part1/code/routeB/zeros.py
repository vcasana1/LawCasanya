# The first N ordinates of zeta from mpmath.zetazero (20 digits), stored as doubles in gamma.npy.
# The conversion to double precision (relative accuracy 1.1e-16, i.e. better than 1e-13 at t <= 1000)
# is intentional: every Route B computation is done in double precision, and gamma is used only for
# diagnostics (distances of computed lists to the zeros), never in the constructions.
import mpmath as mp, numpy as np, sys
mp.mp.dps=20
N=int(sys.argv[1])
g=[float(mp.zetazero(n).imag) for n in range(1,N+1)]
np.save('gamma.npy',np.array(g)); print(len(g), g[-1])
