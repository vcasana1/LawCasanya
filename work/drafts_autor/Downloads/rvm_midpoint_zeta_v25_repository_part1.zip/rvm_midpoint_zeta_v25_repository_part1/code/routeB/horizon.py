import numpy as np, json, sys
from scipy.optimize import least_squares
from core import *
g=np.load('gamma.npy'); tau=clock(60000)
q,s0,sp,M,INT,LAG=0.85,0.08,1.0,int(sys.argv[1]),float(sys.argv[2]),int(sys.argv[3])
kap=tau.copy(); tests=[]; level=[]; log=[]
for m in range(1,M+1):
    s=s0*q**(m-1); T=4.0/s; U=np.log(max(T,7)/(2*np.pi))+2.0
    new=[(float(c),s) for c in np.arange(9*s,U+1e-9,sp*s)]; tests+=new; level+=[m]*len(new)
    cs=np.array([t[0] for t in tests]); ss=np.array([t[1] for t in tests])
    ki=int(np.sum(tau<=INT/s))
    const=np.array([masspair(c,s_)-kpair(c,s_) for c,s_ in tests])
    # Frozen tail: the non-interior ordinates are kept at their current values during the solve of the
    # stage, so every residual printed below is that of a frozen-tail finite model, not of the infinite system.
    tail=np.array([np.sum(Fphi(c,s_,kap[ki:])) for c,s_ in tests])  # edges & beyond: current values (clock)
    F=lambda y: np.sum(Fphi(cs[:,None],ss[:,None],y[None,:]),axis=1)+tail+const
    Jf=lambda y: dFphi(cs[:,None],ss[:,None],y[None,:])
    y0=kap[:ki].copy()
    sol=least_squares(F,y0,jac=Jf,method='trf',bounds=(tau[:ki]-3,tau[:ki]+3),xtol=1e-15,ftol=1e-15,gtol=1e-15,max_nfev=3000)
    kap=kap.copy(); kap[:ki]=np.sort(sol.x)
    Fall=F(kap[:ki]); lv=np.array(level)
    lag=np.max(np.abs(Fall[lv<=m-LAG])) if np.any(lv<=m-LAG) else float('nan')
    nk=min(ki,len(g)); dev=np.abs(kap[:nk]-g[:nk])
    front=lambda tol: (int(np.where(dev>tol)[0][0]) if np.any(dev>tol) else nk)
    rec=dict(m=m,s=s,T=T,interior=ki,tests=len(tests),res_all=float(np.max(np.abs(Fall))),res_lag=float(lag),
             dev5=float(dev[:5].max()),dev10=float(dev[:10].max()),dev20=float(dev[:min(20,nk)].max()),
             f6=front(1e-6),f4=front(1e-4),f2=front(1e-2),dev_tau=float(np.max(np.abs(kap[:ki]-tau[:ki]))))
    log.append(rec)
    print(f"m={m:2d} T={T:5.0f} interior={ki:3d} tests={len(tests):4d} res_all={rec['res_all']:.1e} res_lag{LAG}={rec['res_lag']:.1e} |k-g| k<=5:{rec['dev5']:.1e} k<=10:{rec['dev10']:.1e} k<=20:{rec['dev20']:.1e} front(1e-6/1e-4/1e-2)={rec['f6']}/{rec['f4']}/{rec['f2']} |k-tau|max={rec['dev_tau']:.2f}",flush=True)
json.dump(log,open(f'horizon_M{M}_I{INT}_L{LAG}.json','w'),indent=1); np.save(f'horizon_kap_M{M}_I{INT}.npy',kap)
