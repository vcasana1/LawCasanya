import numpy as np
from scipy.optimize import brentq
from core import LAM
def theta(t): t=np.asarray(t,float); return t/2*np.log(t/(2*np.pi))-t/2-np.pi/8+1/(48*t)+7/(5760*t**3)
def make_alpha(X):
    n=np.arange(2,int(X*X)+1); L=LAM[n]; w=np.where(n<=X,1.0,2-np.log(n)/np.log(X))
    w=np.maximum(w,0.0)                      # weight log(X^2/n)/log X on (X, X^2]; guard against rounding at n = X^2
    c=L*w/(np.sqrt(n)*np.log(n)); ln=np.log(n)
    return lambda t: -(np.sin(np.multiply.outer(np.atleast_1d(t),ln))@c)
def gonek_list(X,tmax,t0=10.0,h=0.005):
    # Crossings of the levels (Theta_X - pi/2)/pi in Z are located between consecutive grid points
    # where the floor changes.  A cell in which the floor changes by more than one level is detected
    # (the number of such cells is printed) and resolved by solving for every intermediate level in
    # the cell.  The largest change of the level function over one cell is printed: when it is far
    # below 1, an excursion that crosses a level and returns inside one cell would need a change of
    # sign of Theta_X' and an excursion of that small size inside the cell.
    al=make_alpha(X); ph=lambda t: theta(t)+al(t)
    ts=np.arange(t0,tmax,h); v=(ph(ts)-np.pi/2)/np.pi; j=np.floor(v); dj=np.diff(j); idx=np.where(dj!=0)[0]; roots=[]
    nbig=int(np.sum(np.abs(dj)>1))
    for i in idx:
        a,b=ts[i],ts[i+1]
        levs=range(int(min(j[i],j[i+1]))+1,int(max(j[i],j[i+1]))+1)
        for lev in levs:
            f=lambda t,lev=lev:(ph(np.array([t]))[0]-np.pi/2)/np.pi-lev
            if f(a)*f(b)<0: roots.append(brentq(f,a,b,xtol=1e-13))
    dv=np.max(np.abs(np.diff(v)))
    print(f'X={X}: grid h={h}, max |Delta level| per grid cell = {dv:.3f}, cells with a jump of more than one level: {nbig}')
    return np.sort(np.array(roots))
if __name__=='__main__':
    import sys
    X=float(sys.argv[1]); r=gonek_list(X,float(sys.argv[2])); np.save(f'gonekF_X{int(X)}.npy',r); print(len(r),r[:3],r[-1])
