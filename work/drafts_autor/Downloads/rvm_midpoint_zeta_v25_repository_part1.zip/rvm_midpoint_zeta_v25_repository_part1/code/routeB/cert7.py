# Floating-point candidate certificate for finite square sections (gamma-free construction), at the
# receding-horizon iterate kappa^H (horizonG, Gonek X=8 initialization, M=16).
# Everything is computed in double precision (QR, Newton, the approximate inverse, norms, the
# radius search); no interval arithmetic and no rounding bounds are used.  "FLOAT_PASS" means that
# the inequalities below hold in floating point, NOT that existence has been proved.
# Stage m: tests = levels <= m (spacing 1.0 s), unknowns = interior ordinates (tau_k <= 2.4/s_m),
# other ordinates frozen at kappa^H. Square subset of tests chosen by pivoted QR on J^T.
# F_j separable in kappa_k  =>  J(x)-J(x0) has columns f_j''(x0_k) delta_k + R_jk, |R_jk|<=A3_jk delta_k^2/2.
# x0 = kappa^H polished by 8 Newton steps on the square system (gamma-free).
# Q is an approximate inverse of J_sel(x0), obtained by solving J_sel Q = I (LU); its defect
# d0 = ||I - Q J_sel(x0)||_inf enters the contraction constant.
# Banach for Psi(x)=x-Q F_sel(x) on {||x-x0||_inf<=r}:  k(r)=d0+||QB||r + 0.5*|| |Q|A3(r) || r^2 < 1,
# eta<=(1-k(r)) r.  The margin is the maximum of (1-k(r)) r over 60 sampled radii (a sampled maximum).
# The ordinates of zeta are NOT used here; the distances of the polished points to them are computed
# separately by diag_cert7_gamma.py from cert7_points.npz.
import numpy as np, json
from scipy.linalg import qr, solve
from core import *
tau=clock(60000); kH=np.load('horizonG_kap_M16_I2.4.npy')
q,s0,sp,INT=0.85,0.08,1.0,2.4
def d2(c,s,k):
    a=s*s; e=s*SQ2PI*np.exp(-a*k*k/2)
    return e*(((a*k)**2-a-c*c)*np.cos(c*k)+2*a*k*c*np.sin(c*k))
def A3b(c,s,k,r):
    a=s*s; kl=np.maximum(np.abs(k)-r,0); ku=np.abs(k)+r; w=a*ku+c
    return s*SQ2PI*np.exp(-a*kl*kl/2)*(w**3+3*a*w)
tests=[]; out=[]; points={}
for m in range(1,17):
    s=s0*q**(m-1); T=4.0/s; U=np.log(max(T,7)/(2*np.pi))+2.0
    tests+=[(float(c),s) for c in np.arange(9*s,U+1e-9,sp*s)]
    n=int(np.sum(tau<=INT/s))
    cs=np.array([t[0] for t in tests]); ss=np.array([t[1] for t in tests])
    x0=kH[:n]
    J=dFphi(cs[:,None],ss[:,None],x0[None,:])
    _,_,piv=qr(J.T,pivoting=True); sel=np.sort(piv[:n])
    kk=kH.copy(); tsel=[tests[i] for i in sel]
    try:
        for it in range(8):                      # gamma-free Newton polishing on the square system
            Jc=dFphi(cs[sel][:,None],ss[sel][:,None],kk[None,:n]); kk[:n]=kk[:n]-np.linalg.solve(Jc,residual(tsel,kk))
    except np.linalg.LinAlgError:
        print(f"m={m:2d} Newton polishing failed (singular square Jacobian)"); break
    x0=kk[:n]; J=dFphi(cs[:,None],ss[:,None],x0[None,:])
    Jsel=J[sel]; Q=solve(Jsel,np.eye(n)); F=residual(tsel,kk)
    d0=float(np.max(np.sum(np.abs(np.eye(n)-Q@Jsel),axis=1)))
    eta=np.max(np.abs(Q@F))
    QB=np.max(np.sum(np.abs(Q@d2(cs[sel][:,None],ss[sel][:,None],x0[None,:])),axis=1))
    C3=lambda r: np.max(np.sum(np.abs(Q)@A3b(cs[sel][:,None],ss[sel][:,None],x0[None,:],r),axis=1))
    best=None
    for r in np.geomspace(max(eta,1e-15)*1.0001,1.0,400):
        kr=d0+QB*r+0.5*C3(r)*r*r
        if kr<1 and eta<=(1-kr)*r: best=(r,kr); break
    margin=max((1-(d0+QB*r+0.5*C3(r)*r*r))*r for r in np.geomspace(1e-12,1e-1,60))
    rho_all=float(np.max(np.abs(residual(tests,kk))))
    Linf=np.max(np.sum(np.abs(Q),axis=1))
    devt=float(np.max(np.abs(x0-tau[:n])))
    points[f'm{m}']=x0.copy()
    rec=dict(m=m,T=T,n=n,Linf=float(Linf),eta=float(eta),QB=float(QB),defect=d0,float_pass=best is not None,margin=float(margin),
             rho_all_levels=rho_all,r=(float(best[0]) if best else None),k_r=(float(best[1]) if best else None),dev_tau=devt)
    out.append(rec)
    print(f"m={m:2d} T={T:5.0f} n={n:3d} Linf={Linf:.1e} eta={eta:.1e} ||QB||={QB:.1e} ||I-QJ||={d0:.1e} "
          + (f"FLOAT_PASS r={best[0]:.2e} k(r)={best[1]:.2e}" if best else "no float pass")
          + f" sampled margin={margin:.1e} rho(all tests<=m)={rho_all:.1e} | max|x0-tau|={devt:.2f}",flush=True)
json.dump(out,open('cert7.json','w'),indent=1)
np.savez('cert7_points.npz',**points)
