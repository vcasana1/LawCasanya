# Diagnostic only: distance of the polished points of cert7.py to the ordinates of zeta
# (gamma.npy, from zeros.py).  Kept separate so that cert7.py does not read the zeros.
import numpy as np, json
g=np.load('gamma.npy'); pts=np.load('cert7_points.npz'); rec=json.load(open('cert7.json'))
for r in rec:
    x0=pts[f"m{r['m']}"]; nk=min(len(x0),len(g))
    print(f"m={r['m']:2d} T={r['T']:5.0f} n={r['n']:3d}  max|x0-gamma| over k<={nk}: {np.max(np.abs(x0[:nk]-g[:nk])):.1e}")
