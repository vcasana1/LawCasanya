"""Experiment 1: the midpoint clock, the displacements eta_k = tau_k - gamma_k,
the lambda-family zeta_lambda, and the numerical comparison zeta_Z1 versus zeta."""
import numpy as np
import mpmath as mp
import scipy.io as sio
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from rvm_common import (Tee, load_ordinates, clock, Product, zeta_from_product, gamma_lambda,
                        write_csv, savefig, OUT)
import os

say = Tee("s01_clock_and_family")
gam, tau = load_ordinates()
N = gam.size
k = np.arange(1, N + 1)
say("zeros loaded: N = %d, gamma_1 = %.9f, gamma_N = %.6f, tau_1 = %.9f, tau_N = %.6f",
    N, gam[0], gam[-1], tau[0], tau[-1])

# ---- clock check and displacements
clock_err = np.max(np.abs(clock(tau) - (k - 0.5)))
eta = tau - gam
say("max |N_RVM(tau_k) - (k - 1/2)| = %.3e", clock_err)
say("eta_k = tau_k - gamma_k:  max |eta| = %.6f (k = %d),  mean |eta| = %.6f,  rms = %.6f,  mean eta = %.3e",
    np.max(np.abs(eta)), int(np.argmax(np.abs(eta))) + 1, np.mean(np.abs(eta)),
    np.sqrt(np.mean(eta ** 2)), np.mean(eta))
blocks = [(1, 10), (11, 100), (101, 1000), (1001, 10 ** 4), (10 ** 4 + 1, 10 ** 5), (10 ** 5 + 1, 10 ** 6), (10 ** 6 + 1, N)]
blocks = [(a, min(b, N)) for a, b in blocks if a <= N]   # no empty block for a shorter file
rows = []
say("%12s %12s %12s %12s", "k from", "k to", "max|eta|", "rms eta")
for a, b in blocks:
    e = eta[a - 1:b]
    rows.append([a, b, np.max(np.abs(e)), np.sqrt(np.mean(e ** 2))])
    say("%12d %12d %12.6f %12.6f", a, b, rows[-1][2], rows[-1][3])
rows = np.array(rows)
write_csv("s01_eta_blocks.csv", ["k_from", "k_to", "max_abs_eta", "rms_eta"], [rows[:, i] for i in range(4)])
say("first ordinates:")
say("%4s %16s %16s %12s", "k", "gamma_k", "tau_k", "eta_k")
for i in range(12):
    say("%4d %16.9f %16.9f %12.6f", i + 1, gam[i], tau[i], eta[i])

# ---- zeta_Z1 versus zeta on vertical lines
PZ = Product(gam)
PR = Product(tau)
tline = np.concatenate([np.linspace(1.0, 100.0, 199), np.linspace(101.0, 2000.0, 300)])
mp.mp.dps = 20
cmp_rows = []
for sigma in (2.0, 1.25, 0.75):
    s = sigma + 1j * tline
    zz1 = zeta_from_product(PZ, s)
    ze = np.array([complex(mp.zeta(complex(x))) for x in s])
    rel = np.abs(zz1 / ze - 1.0)
    # the relative error can be amplified near a zero of zeta; report also a balanced metric
    bal = np.abs(zz1 - ze) / np.maximum(1.0, np.maximum(np.abs(zz1), np.abs(ze)))
    cmp_rows.append([sigma, np.max(rel), np.median(rel), np.max(bal)])
    say("sigma = %.2f, t in [1,2000] (%d points): max |zeta_Z1/zeta - 1| = %.3e, median = %.3e; "
        "max |zeta_Z1 - zeta|/max(1,|zeta_Z1|,|zeta|) = %.3e",
        sigma, tline.size, np.max(rel), np.median(rel), np.max(bal))
    write_csv("s01_zetaZ1_vs_zeta_sigma%.2f.csv" % sigma, ["t", "abs_zeta", "abs_zetaZ1", "rel_err", "balanced_err"],
              [tline, np.abs(ze), np.abs(zz1), rel, bal])
cmp_rows = np.array(cmp_rows)

# ---- Hardy-type functions Z_lambda(t) = exp(i theta(t)) zeta_lambda(1/2+it) on the critical line
def theta_exact(t):
    return np.array([float(mp.siegeltheta(x)) for x in t])

tc = np.linspace(0.5, 60.0, 1200)
th = theta_exact(tc)
lams = [0.0, 0.25, 0.5, 0.75, 1.0]
Zl = {}
for lam in lams:
    P = PZ if lam == 0.0 else (PR if lam == 1.0 else Product(gamma_lambda(gam, tau, lam)))
    Zc = np.exp(1j * th) * zeta_from_product(P, 0.5 + 1j * tc)
    # Z_lambda is real in exact arithmetic; measure the imaginary part before discarding it
    say("lambda = %.2f: max |Im Z_lambda| / max(1,|Z_lambda|) on [0.5,60] = %.3e",
        lam, np.max(np.abs(Zc.imag) / np.maximum(1.0, np.abs(Zc))))
    Zl[lam] = np.real(Zc)
Zhardy = np.array([float(mp.siegelz(x)) for x in tc])
dZ = np.max(np.abs(Zl[0.0] - Zhardy) / np.maximum(1.0, np.abs(Zhardy)))
say("critical line, t in [0.5,60]: max |Z_Z1(t) - Z(t)| / max(1,|Z(t)|) = %.3e", dZ)
write_csv("s01_Z_lambda_critical_line.csv", ["t", "Z_hardy"] + ["Z_lambda_%.2f" % l for l in lams],
          [tc, Zhardy] + [Zl[l] for l in lams])

# ---- figures
dec = np.arange(0, N, 50)
fig, ax = plt.subplots(2, 2, figsize=(12, 8))
ax[0, 0].plot(k[dec], eta[dec], ".", ms=1.5, color="tab:blue")
ax[0, 0].axhline(0, color="k", lw=0.5)
ax[0, 0].set_xlabel("k")
ax[0, 0].set_ylabel(r"$\eta_k=\tau_k-\gamma_k$")
ax[0, 0].set_title(r"Observed displacements in the supplied range, $N=%d$" % N)
ax[0, 1].hist(eta, bins=200, density=True, color="tab:blue")
ax[0, 1].set_xlabel(r"$\eta_k$")
ax[0, 1].set_title(r"Empirical distribution of the supplied displacements ($k\leq N$)")
lam = np.linspace(0, 1, 101)
for kk in range(30):
    gl = (1 - lam) * gam[kk] + lam * tau[kk]
    ax[1, 0].plot(lam, clock(gl) - (kk + 0.5), "-", lw=1)
ax[1, 0].axhline(0, color="k", lw=0.5)
ax[1, 0].set_xlabel(r"$\lambda$")
ax[1, 0].set_ylabel(r"$\mathcal{N}_{\rm RVM}(\gamma_k(\lambda))-(k-\frac{1}{2})$")
ax[1, 0].set_title(r"Moving ordinates in clock units, $k\leq30$ ($\lambda=0$: $\zeta_{Z1}$, $\lambda=1$: $\zeta_{\rm RVM}$)", fontsize=9)
ax[1, 1].plot(tc, Zhardy, "k-", lw=2.2, label=r"Hardy $Z(t)$ of $\zeta$")
cols = ["tab:red", "tab:orange", "tab:green", "tab:cyan", "tab:blue"]
for lam, c in zip(lams, cols):
    ax[1, 1].plot(tc, Zl[lam], "-", color=c, lw=1.0, label=r"$Z_\lambda$, $\lambda=%.2f$" % lam)
ax[1, 1].axhline(0, color="k", lw=0.5)
ax[1, 1].set_xlabel("t")
ax[1, 1].set_title(r"$e^{i\vartheta(t)}\zeta_\lambda(\frac{1}{2}+it)$ along the family")
ax[1, 1].legend(fontsize=7, ncol=2)
fig.tight_layout()
savefig(fig, "fig01_clock_family.png")

fig, ax = plt.subplots(1, 2, figsize=(12, 4))
for sigma, c in zip((2.0, 1.25, 0.75), ("tab:blue", "tab:green", "tab:red")):
    d = np.loadtxt(os.path.join(OUT, "s01_zetaZ1_vs_zeta_sigma%.2f.csv" % sigma), delimiter=",", skiprows=1)
    ax[0].plot(d[:, 0], d[:, 3], ".", ms=2, color=c, label=r"$\sigma=%.2f$" % sigma)
ax[0].set_xlabel("t")
ax[0].set_ylabel(r"$|\zeta_{Z1}/\zeta-1|$")
ax[0].set_title(r"$\zeta_{Z1}$ from %d supplied ordinates and the clock tail, versus $\zeta$" % N, fontsize=9)
ax[0].legend()
ax[1].plot(tc, Zhardy, "k-", lw=2.5, label=r"$Z(t)$ (mpmath)")
ax[1].plot(tc, Zl[0.0], "r--", lw=1.0, label=r"$Z_{Z1}(t)$ (product)")
ax[1].set_xlabel("t")
ax[1].legend()
ax[1].set_title(r"Critical line: $\lambda=0$ endpoint and Hardy $Z$")
fig.tight_layout()
savefig(fig, "fig02_zetaZ1_vs_zeta.png")

sio.savemat(os.path.join(OUT, "s01_results.mat"), {
    "N": N, "clock_err": clock_err, "eta_blocks": rows, "zetaZ1_cmp": cmp_rows,
    "t_critical": tc, "Z_hardy": Zhardy, "Z_lambda": np.array([Zl[l] for l in lams]), "lambdas": np.array(lams)})
say.close()

# ---- zoom: how the smooth clock places the midpoint ordinates next to the zeros
say2 = Tee("s01b_clock_zoom")
fig, ax = plt.subplots(1, 2, figsize=(12, 4))
T = np.linspace(9.0, 52.0, 4000)
ax[0].step(T, np.searchsorted(gam, T, side="right"), where="post", color="k", lw=1.5, label=r"$N_\zeta(T)$")
ax[0].plot(T, clock(T), "r-", lw=1.5, label=r"$\mathcal{N}_{\rm RVM}(T)$")
for i in range(9):
    ax[0].plot([gam[i], gam[i]], [0, i + 1], "k:", lw=0.8)
ax[0].plot(tau[:9], np.arange(9) + 0.5, "ro", ms=5, label=r"$\tau_k$: $\mathcal{N}_{\rm RVM}(\tau_k)=k-\frac{1}{2}$")
ax[0].plot(gam[:9], np.arange(9) + 0.5, "ks", ms=4, mfc="none", label=r"$(\gamma_k,\,k-\frac{1}{2})$")
ax[0].set_xlabel("T")
ax[0].set_title("Clock and staircase at the first zeros")
ax[0].legend(loc="upper left", fontsize=8)
kz = np.arange(N - 12, N)
T_OFF = 10.0 * np.floor(gam[kz[0]] / 10.0)          # offsets computed from the file, not hard-coded
N_OFF = 1000 * ((N - 12) // 1000)
T3 = np.linspace(gam[kz[0]] - 0.3, gam[kz[-1]] + 0.3, 6000)
ax[1].step(T3 - T_OFF, np.searchsorted(gam, T3, side="right") - N_OFF, where="post", color="k", lw=1.5, label=r"$N_\zeta(T)$")
ax[1].plot(T3 - T_OFF, clock(T3) - N_OFF, "r-", lw=1.5, label=r"$\mathcal{N}_{\rm RVM}(T)$")
ax[1].plot(tau[kz] - T_OFF, kz + 0.5 - N_OFF, "ro", ms=5, label=r"$\tau_k$")
ax[1].plot(gam[kz] - T_OFF, kz + 0.5 - N_OFF, "ks", ms=4, mfc="none", label=r"$(\gamma_k,\,k-\frac{1}{2})$")
ax[1].set_xlabel(r"$T-%d$" % T_OFF)
ax[1].set_ylabel(r"count $-\,%d$" % N_OFF)
ax[1].set_title(r"Zoom at the last 12 zeros of the file (mean spacing %.3f)" % (2 * np.pi / np.log(gam[-1] / (2 * np.pi))))
ax[1].legend(loc="upper left", fontsize=8)
fig.tight_layout()
savefig(fig, "fig00_clock_zoom.png")
fig, ax = plt.subplots(1, 1, figsize=(12, 3))
T2 = np.linspace(9.0, 200.0, 20000)
ax.plot(T2, np.searchsorted(gam, T2, side="right") - clock(T2), "k-", lw=0.8)
ax.axhline(0, color="r", lw=0.8)
ax.set_xlabel("T")
ax.set_ylabel(r"$N_{\rm file}(T)-\mathcal{N}_{\rm RVM}(T)$")
ax.set_title(r"$N_{\rm file}(T)-\mathcal{N}_{\rm RVM}(T)$ from the supplied ordinates (jump $+1$ at each $\gamma_k$); "
             r"the file is complete here, so this is $S(T)+O(1/T)$", fontsize=9)
fig.tight_layout()
savefig(fig, "fig00b_remainder.png")
say2("zoom table near the top of the file:")
say2("%9s %18s %18s %10s %10s", "k", "gamma_k", "tau_k", "eta_k", "N*-N_RVM")
for i in kz:
    say2("%9d %18.6f %18.6f %10.6f %10.6f", i + 1, gam[i], tau[i], tau[i] - gam[i],
         np.searchsorted(gam, gam[i], side="right") - 0.5 - clock(gam[i]))
say2.close()
