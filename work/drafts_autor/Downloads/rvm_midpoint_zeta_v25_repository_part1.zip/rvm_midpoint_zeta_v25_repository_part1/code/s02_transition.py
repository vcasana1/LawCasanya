"""Experiment 2: the transition theorem zeta_RVM = varpi (1 + w)(1 + O(1/t)),
the constant varpi_RVM, the vertical limit of 1/zeta_RVM, and zeta_RVM versus zeta."""
import os
import numpy as np
import mpmath as mp
import scipy.io as sio
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from rvm_common import (Tee, load_ordinates, Product, zeta_from_product, chi, w_transition,
                        write_csv, savefig, OUT)

say = Tee("s02_transition")
gam, tau = load_ordinates()
PR = Product(tau)

# ---- varpi_RVM by Richardson extrapolation on Re s = 2
# The model v(T) = c0 + c1/T + c2/T^2 is an empirical extrapolation: the transition theorem
# gives an error O(1/T), not a full expansion in powers of 1/T.  Its stability is checked
# below with other heights and with the linear model; c0 is kept complex until its
# imaginary part has been checked.


# The extrapolation uses a more accurate evaluation of the product than the default one:
# K1 = 10^6 factors summed exactly and 8 power sums.  With the default evaluation
# (K1 = 10^5, 6 power sums) the relative error of zeta_RVM(2 + iT) is 7e-10 at T = 10^4
# and 1.2e-5 at T = 2*10^4, because |q(s)|/o_{K1}^2 is no longer small there.
PRX = Product(tau, K1=10 ** 6, nterms=8)


def v_at(T):
    return zeta_from_product(PRX, 2 + 1j * T)[0] / (1 + w_transition(2 + 1j * T))


def richardson(Tl, order=2):
    Tl = np.asarray(Tl, dtype=float)
    A = np.column_stack([Tl ** (-j) for j in range(order + 1)]).astype(complex)
    return np.linalg.solve(A, np.array([v_at(T) for T in Tl]))


Ts = 1.0e4 * np.array([0.25, 0.5, 1.0])
c = richardson(Ts, 2)
if abs(c[0].imag) > 1e-8 * abs(c[0]):
    raise RuntimeError("extrapolated varpi has a large imaginary part: %r" % c[0])
varpi = c[0].real
L = 1.0 / varpi
say("varpi_RVM (Richardson, sigma = 2, T = 2500, 5000, 10000, accurate product) = %.10f %+.2e i", c[0].real, c[0].imag)
say("L = 1/varpi_RVM = %.10f", L)
c2 = richardson(2.0 * Ts, 2)
c3 = richardson([4000.0, 7000.0, 10000.0], 2)
c1 = richardson(Ts[1:], 1)
say("stability of the extrapolation (empirical, no error bound):")
say("  quadratic, T = 5000, 10000, 20000: %.10f %+.2e i  (difference %.1e)", c2[0].real, c2[0].imag, abs(c2[0] - c[0]))
say("  quadratic, T = 4000, 7000, 10000:  %.10f %+.2e i  (difference %.1e)", c3[0].real, c3[0].imag, abs(c3[0] - c[0]))
say("  linear,    T = 5000, 10000:        %.10f %+.2e i  (difference %.1e)", c1[0].real, c1[0].imag, abs(c1[0] - c[0]))
for T in (1.0e4, 2.0e4):
    sT = 2 + 1j * T
    say("  evaluation check at T = %.0f: |zeta_RVM(default) / zeta_RVM(accurate) - 1| = %.1e", T,
        abs(zeta_from_product(PR, sT)[0] / zeta_from_product(PRX, sT)[0] - 1))

# ---- relative error of the transition formula
tt = np.exp(np.linspace(np.log(10.0), np.log(1.0e4), 160))
rows = [tt]
hdr = ["t"]
fits = []
err_by_sp = {}
for sp in (0.25, 0.5, 1.5):
    s = 0.5 + sp + 1j * tt
    zr = zeta_from_product(PR, s)
    # computed residual of the transition formula: it contains the theoretical O(1/t) term
    # and the numerical errors (truncated product, tail approximation, extrapolated varpi, rounding)
    err_w = np.abs(zr / (varpi * (1 + w_transition(s))) - 1)
    err_by_sp[sp] = err_w
    rows.append(err_w)
    hdr.append("err_w_sigmap%.2f" % sp)
    sel = tt > 100
    slope = np.polyfit(np.log(tt[sel]), np.log(err_w[sel]), 1)[0]
    fits.append([sp, slope, np.max(err_w[sel] * tt[sel])])
    say("sigma' = %.2f: |zeta_RVM/(varpi(1+w)) - 1|: log-log slope on t>100 = %.3f, max t*err = %.4f",
        sp, slope, np.max(err_w[sel] * tt[sel]))
    if sp < 0.5:
        err_c = np.abs(zr / (varpi * (1 + chi(s))) - 1)
        rows.append(err_c)
        hdr.append("err_chi_sigmap%.2f" % sp)
        say("sigma' = %.2f: |zeta_RVM/(varpi(1+chi)) - 1|: max t*err (t>100) = %.4f",
            sp, np.max(err_c[sel] * tt[sel]))
    wmod = np.abs(w_transition(s))
    rows.append(wmod)
    hdr.append("abs_w_sigmap%.2f" % sp)
    Fv = 1 / zr
    rows.append(np.abs(Fv - L))
    hdr.append("abs_F_minus_L_sigmap%.2f" % sp)
    say("          |w| * t^sigma' in [%.4f, %.4f];  |1/zeta_RVM - L| at t = 1e4: %.3e",
        np.min(wmod * tt ** sp), np.max(wmod * tt ** sp), np.abs(Fv[-1] - L))
write_csv("s02_transition_errors.csv", hdr, rows)

# ---- zeta_RVM versus zeta on two vertical lines and on the critical line
mp.mp.dps = 20
tl = np.linspace(1.0, 120.0, 900)
cmp = {}
for sigma in (2.0, 0.75):
    s = sigma + 1j * tl
    zr = zeta_from_product(PR, s)
    ze = np.array([complex(mp.zeta(complex(x))) for x in s])
    cmp[sigma] = (zr, ze)
    write_csv("s02_zetaRVM_vs_zeta_sigma%.2f.csv" % sigma, ["t", "abs_zeta", "abs_zetaRVM", "abs_varpi_1_plus_w"],
              [tl, np.abs(ze), np.abs(zr), np.abs(varpi * (1 + w_transition(s)))])

fig, ax = plt.subplots(2, 2, figsize=(12, 8))
cols = {0.25: "tab:red", 0.5: "tab:green", 1.5: "tab:blue"}
for sp in (0.25, 0.5, 1.5):
    ax[0, 0].plot(tt, tt * err_by_sp[sp], "-", color=cols[sp], label=r"$\sigma'=%.2f$" % sp)
ax[0, 0].set_xlabel("t")
ax[0, 0].set_ylabel(r"$t\,|\zeta_{\rm RVM}/(\varpi_{\rm RVM}(1+w))-1|$")
ax[0, 0].set_title(r"Computed residual of the transition formula times $t$, $\varpi_{\rm RVM}=%.10f$" % varpi, fontsize=9)
ax[0, 0].legend()
for sp in (0.25, 0.5, 1.5):
    s = 0.5 + sp + 1j * tt
    ax[0, 1].plot(tt, np.abs(1 / zeta_from_product(PR, s) - L) * tt ** min(sp, 1.0), "-", color=cols[sp], label=r"$\sigma'=%.2f$" % sp)
ax[0, 1].set_xlabel("t")
ax[0, 1].set_ylabel(r"$t^{\min(\sigma',1)}\,|1/\zeta_{\rm RVM}(\sigma+it)-L|$")
ax[0, 1].set_title(r"Vertical limit $L=1/\varpi_{\rm RVM}$, rescaled error", fontsize=9)
ax[0, 1].legend()
for a, sigma in zip((ax[1, 0], ax[1, 1]), (2.0, 0.75)):
    zr, ze = cmp[sigma]
    a.plot(tl, np.abs(ze), "k-", lw=1.2, label=r"$|\zeta(\sigma+it)|$")
    a.plot(tl, np.abs(zr), "r-", lw=1.2, label=r"$|\zeta_{\rm RVM}(\sigma+it)|$")
    a.set_xlabel("t")
    a.set_title(r"$\sigma=%.2f$" % sigma)
    a.legend()
fig.tight_layout()
savefig(fig, "fig03_transition.png")

sio.savemat(os.path.join(OUT, "s02_results.mat"), {"varpi": varpi, "L": L, "richardson": c,
                                                   "richardson_2T": c2, "richardson_alt": c3, "linear": c1,
                                                   "slopes": np.array(fits), "t": tt})
with open(os.path.join(OUT, "s02_varpi.txt"), "w") as fh:     # read by s05, s07, s15
    fh.write("%.15f\n" % varpi)
say.close()
