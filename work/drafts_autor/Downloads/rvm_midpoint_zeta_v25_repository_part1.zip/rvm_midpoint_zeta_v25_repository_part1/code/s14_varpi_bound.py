"""Theorem (label thm:varpi-less-one): the transition constant satisfies varpi_RVM < 1.

varpi_RVM = P_RVM^crit(1/2) * exp(nu_3 + nu_4)                      (eq:varpi-def)
  P_RVM^crit(1/2) = prod_k tau_k^2 / (1/4 + tau_k^2)  in (0, 1)        (no computation needed)
  nu_3 = 8 - (33/4) log 2 - 2 log pi                                   (closed form, proof of the theorem, step (b))
  nu_4 = -2 int_{tau_0}^inf psi(N_RVM(tau) + 1/2) dtau / tau           (eq:nu4-limit)
       <= -2 M(tau_1)                                                  (eq:nu4-bound),
  M(t) = I_0(t) - W_1(t)/12 - (sqrt3/216) |W_1'(t)|,  with  l = log(t/2pi),
  I_0(t) = (t l - 2t - tau_0 log 2 + 2 tau_0)/(2 pi) + (7/8) log(t/tau_0),
  W_1(t) = W(1) = 2 pi/(t l),   |W_1'(t)| = |W'(1)| = 4 pi^2 (l + 1)/(t^2 l^3),   tau_0 = 4 pi,
  W(u) = 2 pi/(T log(T/2pi)), T = inverse clock at u - 1/2, the weight dtau/tau = W(u) du (eq:nu4-weight),
  tau_1 = first midpoint ordinate, N_RVM(tau_1) = 1/2.

PART A is the proof: every inequality is checked in interval arithmetic (mpmath.iv, outward rounding).
PART B is a floating-point cross-check (not part of the proof): high-precision values of nu_4,
P_RVM^crit(1/2) and varpi_RVM, compared with the Richardson value of s02_transition.py.
The program does not read data/zeross.bin or data/zLamb.bin: the clock is the Lambert formula.
"""
import mpmath as mp
import numpy as np
from scipy.special import lambertw
import os
from rvm_common import Tee, OUT

say = Tee("s14_varpi_bound")
iv = mp.iv
iv.dps = 40


def hi(x):
    """Upper endpoint of an interval, as an exact mpf."""
    return mp.make_mpf(x._mpi_[1])


def lo(x):
    """Lower endpoint of an interval, as an exact mpf."""
    return mp.make_mpf(x._mpi_[0])


# ----------------------------------------------------------------------------- PART A: proof
say("PART A. Interval-arithmetic verification of the inequalities in the proof of the theorem varpi_RVM < 1")
say("(mpmath.iv, %d digits, outward rounding)" % iv.dps)
PI = iv.pi
LOG2 = iv.log(2)
TAU0 = 4 * PI

# (a) nu_3 = 8 - 33/4 log 2 - 2 log pi < 0
nu3 = 8 - iv.mpf(33) / 4 * LOG2 - 2 * iv.log(PI)
say("(a) nu_3 = 8 - (33/4) log 2 - 2 log pi in [%s, %s]" % (mp.nstr(lo(nu3), 15), mp.nstr(hi(nu3), 15)))
assert hi(nu3) < 0
say("    sup nu_3 < 0: verified")


def clock(t):
    return t / (2 * PI) * (iv.log(t / (2 * PI)) - 1) + iv.mpf(7) / 8


# (b) N_RVM(tau_0) in (0, 1/2): on [tau_0, tau_1) the sawtooth psi(N + 1/2) equals N
NT0 = clock(TAU0)
say("(b) N_RVM(tau_0) = 2 log(2/e) + 7/8 in [%s, %s]" % (mp.nstr(lo(NT0), 15), mp.nstr(hi(NT0), 15)))
assert lo(NT0) > 0 and hi(NT0) < iv.mpf(1) / 2
say("    0 < N_RVM(tau_0) < 1/2: verified")

# (c) enclosure of tau_1: N_RVM is increasing on [2 pi, inf)
A, B = "14.52134", "14.52135"
NA, NB = clock(iv.mpf(A)), clock(iv.mpf(B))
say("(c) N_RVM(%s) in [%s, %s]" % (A, mp.nstr(lo(NA), 15), mp.nstr(hi(NA), 15)))
say("    N_RVM(%s) in [%s, %s]" % (B, mp.nstr(lo(NB), 15), mp.nstr(hi(NB), 15)))
assert hi(NA) < iv.mpf(1) / 2 < lo(NB)
say("    N_RVM(%s) < 1/2 < N_RVM(%s): tau_1 in [%s, %s] verified" % (A, B, A, B))
T1 = iv.mpf([A, B])

# (d) the lower bound m(tau_1) > 0, evaluated on the whole interval containing tau_1
L1 = iv.log(T1 / (2 * PI))
I0 = (T1 * L1 - 2 * T1 - TAU0 * LOG2 + 2 * TAU0) / (2 * PI) + iv.mpf(7) / 8 * iv.log(T1 / TAU0)
W1 = 2 * PI / (T1 * L1)
DW1 = 4 * PI ** 2 * (L1 + 1) / (T1 ** 2 * L1 ** 3)
C3 = iv.sqrt(3) / 216
M = I0 - W1 / 12 - C3 * DW1
say("(d) l_1 = log(tau_1/2pi)      in [%s, %s]   (> 0, so W is decreasing and convex on u >= 1)" % (mp.nstr(lo(L1), 12), mp.nstr(hi(L1), 12)))
assert lo(L1) > 0
say("    I_0(tau_1)                in [%s, %s]" % (mp.nstr(lo(I0), 12), mp.nstr(hi(I0), 12)))
say("    W(1)/12                   in [%s, %s]" % (mp.nstr(lo(W1 / 12), 12), mp.nstr(hi(W1 / 12), 12)))
say("    (sqrt3/216)|W'(1)|        in [%s, %s]" % (mp.nstr(lo(C3 * DW1), 12), mp.nstr(hi(C3 * DW1), 12)))
say("    M(tau_1)                  in [%s, %s]" % (mp.nstr(lo(M), 12), mp.nstr(hi(M), 12)))
assert lo(M) > 0
say("    inf M(tau_1) > 0: verified")

# (e) conclusion
nu4_up = -2 * lo(M)                       # exact: negation and doubling of a binary float
sum_iv = iv.mpf(hi(nu3)) + iv.mpf(nu4_up)   # outward-rounded sum
sum_up = hi(sum_iv)
varpi_up = hi(iv.exp(sum_iv))
say("(e) nu_4 <= -2 inf M(tau_1) = %s" % mp.nstr(nu4_up, 12))
say("    nu_3 + nu_4 <= %s" % mp.nstr(sum_up, 12))
say("    varpi_RVM = P(1/2) exp(nu_3 + nu_4) < exp(nu_3 + nu_4) <= %s < 1" % mp.nstr(varpi_up, 12))
assert varpi_up < 1
say("    ALL INEQUALITIES OF THE PROOF VERIFIED: varpi_RVM < %s" % mp.nstr(varpi_up, 6))

# ----------------------------------------------------------------------------- PART B: cross-check
say("")
say("PART B. Floating-point cross-check (not part of the proof)")
mp.mp.dps = 25
pi = mp.pi
tau0 = 4 * pi


def N(t):
    return t / (2 * pi) * mp.log(t / (2 * pi * mp.e)) + mp.mpf(7) / 8


def tau_of(u):
    """Inverse clock: N_RVM(tau) = u - 1/2 (Lambert formula)."""
    x = (u - mp.mpf(1) / 2 - mp.mpf(7) / 8) / mp.e
    return 2 * pi * mp.e * mp.exp(mp.lambertw(x))


def w(u):
    t = tau_of(u)
    return 2 * pi / (t * mp.log(t / (2 * pi)))


tau1 = tau_of(1)
I0f = mp.quad(lambda t: N(t) / t, [tau0, tau1])
MMAX = 2000
S = mp.mpf(0)
for n in range(1, MMAX + 1):
    S += mp.quad(lambda u: (u - n - mp.mpf(1) / 2) * w(u), [n, n + 1])
tail = -w(MMAX + 1) / 12
SI = S + tail
nu3f = 8 - mp.mpf(33) / 4 * mp.log(2) - 2 * mp.log(pi)
nu4f = -2 * (I0f + SI)
say("tau_1 = %s (Lambert formula)" % mp.nstr(tau1, 20))
say("I_0 = int_{tau_0}^{tau_1} N_RVM(t) dt/t = %s (quadrature)" % mp.nstr(I0f, 15))
say("sum_{n<=%d} I_n = %s; Euler-Maclaurin tail -W(%d)/12 = %s" % (MMAX, mp.nstr(S, 15), MMAX + 1, mp.nstr(tail, 6)))
em = SI + w(1) / 12
say("sum_n I_n + W(1)/12 = %s, Euler-Maclaurin bound (sqrt3/216)|W'(1)| = %s" % (mp.nstr(em, 8), mp.nstr(mp.sqrt(3) / 216 * abs(mp.diff(w, 1)), 8)))
say("nu_3 = %s" % mp.nstr(nu3f, 15))
say("nu_4 = %s   (rigorous upper bound of Part A: %s)" % (mp.nstr(nu4f, 15), mp.nstr(nu4_up, 12)))
say("exp(nu_3 + nu_4) = %s" % mp.nstr(mp.e ** (nu3f + nu4f), 15))

K = 2_000_000
k = np.arange(1, K + 1, dtype=np.float64)
tau = (2 * np.pi * np.e) * np.exp(lambertw((k - 0.5 - 0.875) / np.e).real)
logP_K = -np.sum(np.log1p(0.25 / tau ** 2))
TK = tau[-1]
lK = np.log(TK / (2 * np.pi))
logP_tail = -(lK + 1) / (8 * np.pi * TK)
logP = logP_K + logP_tail
say("tau_1, tau_2, tau_3 (numpy) = %.10f, %.10f, %.10f" % tuple(tau[:3]))
say("log P_RVM^crit(1/2): k <= %d: %.15f; tail (integral): %.3e; total %.15f" % (K, logP_K, logP_tail, logP))
say("P_RVM^crit(1/2) = %.12f" % np.exp(logP))
varpi = mp.e ** (mp.mpf(logP) + nu3f + nu4f)
say("varpi_RVM = P(1/2) exp(nu_3 + nu_4) = %s" % mp.nstr(varpi, 12))
fv = os.path.join(OUT, "s02_varpi.txt")
if os.path.exists(fv):
    vr = open(fv).read().strip()
    say("Richardson value of s02_transition.py (sigma = 2, T = 2500, 5000, 10000), read from output/s02_varpi.txt: %s" % vr)
    say("difference = %.2e" % float(varpi - mp.mpf(vr)))
else:
    say("output/s02_varpi.txt not found: run s02_transition.py for the comparison with the Richardson value")
say.close()
