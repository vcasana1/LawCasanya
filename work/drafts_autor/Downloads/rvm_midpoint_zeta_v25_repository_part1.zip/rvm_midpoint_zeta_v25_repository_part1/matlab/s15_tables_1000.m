function s15_tables_1000
% S15_TABLES_1000  The first 1000 values of the four comparisons of the paper.
%   (a) midpoint ordinates tau_k against the ordinates gamma_k of zeta, k <= 1000;
%   (b) real RVM primes p_j^RVM (first grid crossing of the level j by pi_RVM, refined by linear
%       interpolation; a discrete version of inf{x : pi_RVM(x) >= j}) against p_j;
%   (c) pi_RVM(n) against pi(n), n <= 1000;
%   (d) M_RVM^crit(n) against M(n), n <= 1000.
% Data: zeross.bin (gamma_k) and zLamb.bin (tau_k), little-endian doubles, in ../data
% or in the current folder (edit DATA below).  MATLAB version of s15_tables_1000.py;
% needs R2020a or later for nufft.  Figures are saved as PNG and left open.
clc;
clear;

DATA = '../data';
if ~exist(fullfile(DATA, 'zeross.bin'), 'file'), DATA = '.'; end
gam = readbin(fullfile(DATA, 'zeross.bin'));
tau = readbin(fullfile(DATA, 'zLamb.bin'));
if numel(gam) ~= numel(tau)
    error('zeross.bin has %d entries and zLamb.bin has %d: the ordinate files have different lengths', ...
          numel(gam), numel(tau));
end
Nz  = numel(gam);
if any(~isfinite(gam)) || any(~isfinite(tau)), error('non-finite ordinate in the data files'); end
if any(diff(tau) <= 0), error('zLamb.bin is not strictly increasing'); end
if any(diff(gam) < 0), error('zeross.bin is not nondecreasing'); end
if abs(gam(1) - 14.134725141734693) > 1e-6, error('zeross.bin: first value is not gamma_1'); end
if abs(tau(1) - 14.521346953) > 1e-6, error('zLamb.bin: first value is not tau_1'); end
NT = 1000;
k  = (1:NT).';
out = fopen('s15_tables_1000_console.txt', 'w');
say = @(varargin) cellfun(@(f) fprintf(f, '%s\n', sprintf(varargin{:})), {1, out});

%% ------------------------------------------------------------ (a) clock against zeros
eta = tau(1:NT) - gam(1:NT);
[mx, im] = max(abs(eta));
say('(a) tau_k against gamma_k, k <= %d: max|eta_k| = %.6f at k = %d; mean eta = %.3e; rms = %.6f', ...
    NT, mx, im, mean(eta), sqrt(mean(eta.^2)));
say('    gamma_1000 = %.9f, tau_1000 = %.9f; mean spacing at k=1000: %.5f', gam(NT), tau(NT), ...
    2*pi/log(tau(NT)/(2*pi)));
writetable(table(k, gam(1:NT), tau(1:NT), eta, 'VariableNames', {'k','gamma_k','tau_k','eta_k'}), ...
    's15_clock_1000.csv');
% automatic checks of the table data before rounding
if ~isequal(k, (1:NT).') || max(abs((tau(1:NT) - gam(1:NT)) - eta)) ~= 0
    error('table check failed');
end
say('    table checks: indices 1..%d once each; eta_k = tau_k - gamma_k before rounding', NT);

%% ------------------------------------------------------------ (b),(c) pi_RVM on [2, XMAX]
XMAX = 8200;
KE   = 300;
K    = find(tau <= 2*pi*XMAX*2.5, 1, 'last');
v    = (0:K-1).'/K;
taper = ones(K, 1);
ramp  = v >= 0.6;
taper(ramp) = cos(pi/2*(v(ramp) - 0.6)/0.4).^2;
o   = tau(1:K);
rho = 0.5 + 1i*o;
u0 = log(2); u1 = log(XMAX);
NF = 1400000;                      % fine grid in u = log x
uf = linspace(u0, u1, NF).';
NC = 70000;                        % coarse grid for the exact Ei of the first KE ordinates
uc = linspace(u0, u1, NC).';
say('(b),(c) pi_RVM on [2, %g]: K = %d ordinates (tau_K = %.1f), smooth cut; %d fine / %d coarse points', ...
    XMAX, K, o(end), NF, NC);
% exact part: Ei(w) = -E1(-w) on the horizontal line Im w = const (principal branch)
Sc = zeros(NC, 1);
for j = 1:KE
    Sc = Sc + taper(j) * (-expint(-rho(j)*uc));
end
S = spline(uc, real(Sc), uf) + 1i*spline(uc, imag(Sc), uf);
% asymptotic part: A_m(u) = sum_{k>KE} w_k exp(i o_k u) / rho_k^m by the nonuniform FFT
% (MATLAB nufft computes sum_k X_k exp(-2 pi i t_k f); take t_k = -o_k/(2 pi), f = u).
A = cell(1, 4);
for m = 1:4
    c = taper(KE+1:K) ./ rho(KE+1:K).^m;
    A{m} = nufft(c, -o(KE+1:K)/(2*pi), uf);
end
S = S + exp(uf/2) .* (A{1}./uf + A{2}./uf.^2 + 2*A{3}./uf.^3 + 6*A{4}./uf.^4);
% tail integral int_x^inf dt / (t (t^2-1) log t) on a coarse grid, cubic interpolation
ut = linspace(u0, u1, 3000).';
ti = zeros(3000, 1);
tf = @(t) 1 ./ (t .* (t.^2 - 1) .* log(t));
for j = 1:3000
    x = exp(ut(j));
    ti(j) = integral(tf, x, 100*x, 'AbsTol', 1e-14, 'RelTol', 1e-12) + ...
            integral(tf, 100*x, 1e7, 'AbsTol', 1e-14, 'RelTol', 1e-12);
end
li = @(u) expint_i(u);             % li(e^u) = Ei(u)
J = li(uf) - 2*real(S) - log(2) + spline(ut, ti, uf);
mu64 = mobius(64);
PR = zeros(NF, 1);
m = 1;
while u1/m >= u0
    if mu64(m) ~= 0
        um = uf/m;
        ok = um >= u0 - 1e-12;
        PR(ok) = PR(ok) + mu64(m)/m * interp1(uf, J, um(ok), 'linear');
    end
    m = m + 1;
end
xf = exp(uf);
P = primes(XMAX + 1).';
% (c) integers n <= 1000
n = (1:NT).';
pin = zeros(NT, 1);
pin(2:end) = interp1(uf, PR, log(n(2:end)), 'linear');
pi_exact = arrayfun(@(x) sum(P <= x), n);
lin = zeros(NT, 1); lin(2:end) = expint_i(log(n(2:end)));
say('    pi_RVM(100) = %.4f, pi(100) = %d;  pi_RVM(1000) = %.4f, pi(1000) = %d;  pi_RVM(%g) = %.4f, pi = %d', ...
    pin(100), pi_exact(100), pin(end), pi_exact(end), XMAX, PR(end), sum(P <= XMAX));
d = pin - pi_exact;
[dmax, imax] = max(d); [dmin, imin] = min(d);
say('    pi_RVM(n) - pi(n), n <= 1000: max %.4f at n = %d, min %.4f at n = %d, mean %.4f, rms %.4f', ...
    dmax, imax, dmin, imin, mean(d), sqrt(mean(d.^2)));
say('    pi_RVM(n) - li(n), n <= 1000: mean %.4f;  pi(n) - li(n): mean %.4f', ...
    mean(pin(2:end) - lin(2:end)), mean(pi_exact(2:end) - lin(2:end)));
writetable(table(n, pi_exact, pin, d, lin, 'VariableNames', {'n','pi_n','pi_RVM_n','pi_RVM_minus_pi','li_n'}), ...
    's15_pi_1000.csv');
% (b) real RVM primes: first crossing of the level j, linear interpolation between grid points
levels = (1:NT).';
pj = zeros(NT, 1);
for j = 1:NT
    i = find(PR >= j, 1, 'first');
    if isempty(i) || i == 1, error('level %d not reached below XMAX', j); end
    pj(j) = xf(i-1) + (j - PR(i-1)) / (PR(i) - PR(i-1)) * (xf(i) - xf(i-1));
end
dp = pj - P(1:NT);
[dmax, imax] = max(dp); [dmin, imin] = min(dp);
say(['    real RVM primes p_j^RVM, j <= 1000: p_1000^RVM = %.4f, p_1000 = %d; max(p_j^RVM - p_j) = %.4f at j = %d, ' ...
     'min = %.4f at j = %d, mean %.4f, rms %.4f'], pj(end), P(NT), dmax, imax, dmin, imin, mean(dp), sqrt(mean(dp.^2)));
say('    |p_j^RVM - p_j| / p_j^(1/2): max %.4f;  |p_j^RVM - p_j| / log p_j: max %.4f', ...
    max(abs(dp)./sqrt(P(1:NT))), max(abs(dp)./log(P(1:NT))));
say('    first 12 levels: %s', strjoin(arrayfun(@(x) sprintf('%.4f', x), pj(1:12), 'UniformOutput', false), ', '));
writetable(table(levels, P(1:NT), pj, dp, 'VariableNames', {'j','p_j','p_j_RVM','p_j_RVM_minus_p_j'}), ...
    's15_rvm_primes_1000.csv');

%% ------------------------------------------------------------ (d) M_RVM^crit(n) against M(n)
% residues 1/(rho_k zeta_RVM'(rho_k)): exact for k <= K0 from the Hadamard product over all
% ordinates plus the clock tail; beyond K0 the fit varpi log(tau_k/2pi)(1 + c/tau_k) of s05.
K0 = 1000;
[c1, c2, c3] = tail_coefficients(clock_inverse(Nz));
t2 = tau.^2;
zpR = zeros(K0, 1);
for kk = 1:K0
    tk  = tau(kk);
    fac = (t2 - tk^2) ./ (t2 + 0.25);
    fac(kk) = 1;
    q   = -0.25 - tk^2;
    lmod = sum(log(abs(fac))) + c1*q - c2*q^2 + c3*q^3;
    r   = 0.5 + 1i*tk;
    lP  = log(2i*tk/(0.25 + tk^2)) + lmod;
    zpR(kk) = (-1)^(kk-1) * exp(lP - logG(r));
end
ratio = zpR ./ log(tau(1:K0)/(2*pi));
% varpi_RVM: read from ../output/s02_varpi.txt (program s02_transition.py) when present, as the
% Python programs do; otherwise Richardson extrapolation of zeta_RVM(2+iT)/(1+w(2+iT)) in 1/T
% with the product evaluated by 10^6 exact factors and 8 power sums (as in s02).
K1 = 1000000;
A1 = 0.25 + tau(1:K1).^2;
Ar = 0.25 + tau(K1+1:end).^2;
pw = zeros(8, 1);
for j = 1:8, pw(j) = sum(Ar.^(-j)); end
logP = @(s) logP_fun(s, A1, pw, c1, c2, c3);
Ts = 1e4*[0.25 0.5 1.0];
vv = zeros(3, 1);
for j = 1:3
    s = 2 + 1i*Ts(j);
    tstar = -1i*(s - 0.5);
    w = exp(-2i*pi*(tstar/(2*pi)*(log(tstar/(2*pi)) - 1) + 0.875));
    vv(j) = exp(logP(s) - logG(s)) / (1 + w);
end
coef = [ones(3,1), 1./Ts.', 1./Ts.'.^2] \ vv;
varpi = real(coef(1));
vfile = fullfile('..', 'output', 's02_varpi.txt');
if exist(vfile, 'file') == 2
    varpi = str2double(strtrim(fileread(vfile)));
end
sel = (K0/2+1):K0;
cfit = mean((ratio(sel)/varpi - 1) .* tau(sel));
zR = varpi * log(tau/(2*pi)) .* (1 + cfit./tau);
zR(1:K0) = zpR;
bR = 1 ./ ((0.5 + 1i*tau) .* zR);
say('(d) residues: varpi_RVM = %.10f, c = %.4f %+.4f i (as in s05_mertens)', varpi, real(cfit), imag(cfit));
% trivial terms of the RVM explicit formula
triv = zeros(NT, 1);
xn = (1:NT).';
for j = 1:6
    lPj = real(logP(-2*j));
    triv = triv - xn.^(-2*j) * (2*j + 1) * pi^j * 2 * (-1)^j / (factorial(j) * exp(lPj));
end
% tapered target (C1 = 2, C2 = 4 in units of 2 pi sqrt(x)) and ordered sum over all ordinates
Kx = find(tau <= 4*2*pi*sqrt(NT), 1, 'last');
uu = tau(1:Kx).' ./ (2*pi*sqrt(xn));                        % NT x Kx
wt = ones(size(uu));
wt(uu >= 4) = 0;
mid = uu > 2 & uu < 4;
wt(mid) = cos(pi/2*(uu(mid) - 2)/2).^2;
E  = exp(1i*log(xn) .* tau(1:Kx).');
MR = -2 + 2*real(sqrt(xn) .* sum(E .* wt .* bR(1:Kx).', 2)) + triv;
MR_all = zeros(NT, 1);
for i = 1:NT
    MR_all(i) = -2 + 2*real(sqrt(xn(i)) * sum(exp(1i*log(xn(i))*tau) .* bR)) + triv(i);
end
mu = mobius(NT);
M  = cumsum(mu);
Mh = zeros(NT, 1); muh = zeros(NT, 1); cur = 0;
for i = 1:NT
    if mu(i) ~= 0
        if cur < MR(i), sg = 1; else, sg = -1; end
        cur = cur + sg; muh(i) = sg;
    end
    Mh(i) = cur;
end
dM = MR - M;
say('    M_RVM^crit(n) (tapered target, Table tab:ternary) against the ordered sum over all %d ordinates: max |diff| = %.4f', ...
    Nz, max(abs(MR - MR_all)));
say('    M(1000) = %d, M_RVM^crit(1000) = %.4f, M_h(1000) = %d', M(end), MR(end), Mh(end));
[dmax, imax] = max(dM); [dmin, imin] = min(dM);
say('    M_RVM^crit(n) - M(n), n <= 1000: max %.4f at n = %d, min %.4f at n = %d, mean %.4f, rms %.4f', ...
    dmax, imax, dmin, imin, mean(dM), sqrt(mean(dM.^2)));
sq = mu ~= 0;
say('    max |M(n)|/sqrt n = %.4f, max |M_RVM^crit(n)|/sqrt n = %.4f on [10,1000]; sign agreement mu_h = mu on squarefrees: %.4f', ...
    max(abs(M(10:end))./sqrt(xn(10:end))), max(abs(MR(10:end))./sqrt(xn(10:end))), mean(muh(sq) == mu(sq)));
writetable(table(n, mu, M, MR, dM, Mh, MR_all, 'VariableNames', ...
    {'n','mu_n','M_n','M_RVM_crit_n','M_RVM_minus_M','M_h_n','M_RVM_allzeros_n'}), 's15_mertens_1000.csv');
fclose(out);
save('s15_results.mat', 'k', 'gam', 'tau', 'eta', 'P', 'pj', 'pi_exact', 'pin', 'M', 'MR', 'Mh', 'varpi', 'cfit', 'K', 'XMAX');

%% ------------------------------------------------------------ figures (linear axes, PNG, left open)
f1 = figure('Color', 'w', 'Position', [60 60 1200 750]);
subplot(2,2,1); plot(k, gam(1:NT), 'k-', k, tau(1:NT), 'r--', 'LineWidth', 0.8);
xlabel('k'); title('Ordinates \gamma_k and midpoint ordinates \tau_k, k \leq 1000'); legend({'\gamma_k','\tau_k'});
subplot(2,2,2); plot(k, eta, 'b.', 'MarkerSize', 5); yline(0, 'k');
xlabel('k'); title('\eta_k = \tau_k - \gamma_k');
subplot(2,2,3); hold on;
for j = 1:60
    plot([gam(j) gam(j)], [0 1], 'k-', 'LineWidth', 0.8);
    plot([tau(j) tau(j)], [0 -1], 'r-', 'LineWidth', 0.8);
end
ylim([-1.3 1.3]); set(gca, 'YTick', []); xlabel('t');
title('The two spectra for k \leq 60: \gamma_k up, \tau_k down'); box on;
subplot(2,2,4); histogram(eta, 40, 'FaceColor', [0.7 0.7 0.7]); xlabel('\eta_k');
title('Empirical distribution of \eta_k, k \leq 1000');
print(f1, 'fig20_clock_1000.png', '-dpng', '-r150');

f2 = figure('Color', 'w', 'Position', [80 80 1200 420]);
subplot(1,2,1); plot(levels, P(1:NT), 'k-', levels, pj, 'r--', 'LineWidth', 1);
xlabel('j'); title('Primes and real RVM primes (first grid crossings), j \leq 1000'); legend({'p_j','p_j^{RVM}'}, 'Location', 'northwest');
subplot(1,2,2); plot(levels, dp, 'b.', 'MarkerSize', 5); yline(0, 'k'); xlabel('j'); title('p_j^{RVM} - p_j');
print(f2, 'fig21_rvm_primes_1000.png', '-dpng', '-r150');

f3 = figure('Color', 'w', 'Position', [100 100 1200 420]);
subplot(1,2,1); stairs(n, pi_exact, 'k-', 'LineWidth', 1); hold on;
plot(n, pin, 'r-', 'LineWidth', 0.9); plot(n(2:end), lin(2:end) - expint_i(log(2)), 'g--', 'LineWidth', 0.8);
xlabel('n'); title('\pi(n) and \pi_{RVM}(n), n \leq 1000');
legend({'\pi(n)','\pi_{RVM}(n)','li(n) - li(2)'}, 'Location', 'northwest');
subplot(1,2,2); plot(n, d, 'b-', 'LineWidth', 0.7); yline(0, 'k'); xlabel('n'); title('\pi_{RVM}(n) - \pi(n)');
print(f3, 'fig22_pi_1000.png', '-dpng', '-r150');

f4 = figure('Color', 'w', 'Position', [120 120 1200 420]);
subplot(1,2,1); stairs(n, M, 'k-', 'LineWidth', 1); hold on;
plot(n, MR, 'r-', 'LineWidth', 0.9); plot(n, sqrt(xn), 'k--', n, -sqrt(xn), 'k--', 'LineWidth', 0.6);
xlabel('n'); title('M(n) and M_{RVM}^{crit}(n), n \leq 1000');
legend({'M(n)','M_{RVM}^{crit}(n)','\pm n^{1/2}'}, 'Location', 'northwest');
subplot(1,2,2); plot(n, dM, 'b-', 'LineWidth', 0.7); yline(0, 'k'); xlabel('n'); title('M_{RVM}^{crit}(n) - M(n)');
print(f4, 'fig23_mertens_1000.png', '-dpng', '-r150');
end

%% ====================================================================== helpers
function x = readbin(name)
fid = fopen(name, 'r', 'ieee-le');
if fid < 0, error('cannot open %s', name); end
x = fread(fid, inf, 'double');
fclose(fid);
x = x(:);
end

function mu = mobius(X)
mu = ones(X, 1);
isc = false(X, 1);
for p = 2:X
    if ~isc(p)
        isc(2*p:p:X) = true;
        mu(p:p:X) = -mu(p:p:X);
        if p*p <= X, mu(p*p:p*p:X) = 0; end
    end
end
end

function v = expint_i(u)
% Ei(u) for real u > 0 (so that li(e^u) = Ei(u)); principal value through -E1(-u) is not
% defined for real negative argument in MATLAB, hence the series/continued-fraction form.
v = zeros(size(u));
for j = 1:numel(u)
    x = u(j);
    if x < 40
        % Ei(x) = gamma + log x + sum_{n>=1} x^n / (n n!)
        s = 0; term = 1;
        for nn = 1:200
            term = term * x / nn;
            s = s + term / nn;
            if abs(term/nn) < 1e-17*abs(s), break; end
        end
        v(j) = 0.5772156649015329 + log(x) + s;
    else
        % asymptotic series e^x/x sum_{n>=0} n!/x^n
        s = 1; term = 1;
        for nn = 1:60
            term = term * nn / x;
            if term < 1e-17, break; end
            s = s + term;
        end
        v(j) = exp(x)/x * s;
    end
end
end

function [c1, c2, c3] = tail_coefficients(U)
LU = log(U/(2*pi));
c1 = (LU + 1) / U / (2*pi);
c2 = (3*LU + 1) / (9*U^3) / 2 / (2*pi);
c3 = (5*LU + 1) / (25*U^5) / 3 / (2*pi);
end

function U = clock_inverse(y)
U = 2*pi*max(y, 2) / log(max(y, 3));
for it = 1:80
    U = U - ((U/(2*pi)*(log(U/(2*pi)) - 1) + 0.875) - y) / (log(U/(2*pi))/(2*pi));
end
end

function v = logP_fun(s, A1, pw, c1, c2, c3)
% log P(s) = sum_k log(1 + q(s)/(1/4 + tau_k^2)), q = s(s-1): exact for k <= K1, power sums
% for K1 < k <= N, clock tail beyond N.
q = s*(s - 1);
v = sum(log(1 + q./A1));
for j = 1:numel(pw)
    v = v + (-1)^(j+1) * q^j / j * pw(j);
end
v = v + c1*q - c2*q^2 + c3*q^3;
end

function v = logG(s)
% log G(s) = log s + log(s-1) + log Gamma(s/2) - (s/2) log pi
v = log(s) + log(s - 1) + clgamma(s/2) - s/2*log(pi);
end

function v = clgamma(z)
% principal log Gamma for complex z with Re z > 0: shift to Re z >= 12 and Stirling.
sh = 0;
while real(z) < 12
    sh = sh + log(z);
    z = z + 1;
end
B = [1/12, -1/360, 1/1260, -1/1680, 1/1188, -691/360360, 1/156, -3617/122400];
v = (z - 0.5)*log(z) - z + 0.5*log(2*pi);
zz = z;
for j = 1:numel(B)
    v = v + B(j)/zz;
    zz = zz*z^2;
end
v = v - sh;
end
