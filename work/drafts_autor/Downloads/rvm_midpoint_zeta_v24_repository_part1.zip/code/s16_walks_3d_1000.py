"""Experiment 16: the three exponential walks of the first 1000 ordinates, drawn in 3D with k
on the vertical axis, and their triangular centroids.

  S_k(x) = sum_{j <= k} exp(i x_j),  x = gamma (zeros of zeta), tau (midpoint clock),
  theta = (gamma + tau)/2 (the midpoint of each zero and its clock ordinate);
  C_N(x) = (1/N) sum_{k <= N} S_k(x) = sum_{k <= N} (1 - (k-1)/N) exp(i x_k).

Data: data/zeross.bin (gamma_k) and data/zLamb.bin (tau_k)."""
import os
import numpy as np
import scipy.io as sio
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator
from rvm_common import Tee, load_ordinates, write_csv, savefig, OUT

say = Tee("s16_walks_3d_1000")
gam, tau = load_ordinates()
N = 1000
k = np.arange(1, N + 1)
g, t = gam[:N], tau[:N]
th = (g + t) / 2
w = 1 - (k - 1) / N
names = ["gamma", "tau", "theta"]
X = {"gamma": g, "tau": t, "theta": th}
S = {nm: np.cumsum(np.exp(1j * X[nm])) for nm in names}
C = {nm: np.sum(w * np.exp(1j * X[nm])) for nm in names}
for nm in names:
    say("C_%-6s = %+.10f %+.10f i   (|S_N| = %.4f, max_k |S_k| = %.4f, check mean(S_k) - C = %.1e)",
        nm, C[nm].real, C[nm].imag, abs(S[nm][-1]), np.abs(S[nm]).max(), abs(S[nm].mean() - C[nm]))
ch = (C["gamma"] + C["tau"]) / 2
say("(C_gamma + C_tau)/2 = %+.10f %+.10f i;  C_theta - chord midpoint = %+.6f %+.6f i, modulus %.6f",
    ch.real, ch.imag, (C["theta"] - ch).real, (C["theta"] - ch).imag, abs(C["theta"] - ch))
eps = g - t
say("gamma_k - tau_k, k <= %d: mean %+.6f, std %.6f, max |.| %.6f", N, eps.mean(), eps.std(), np.abs(eps).max())
say("reference values with all %d ordinates: C_gamma = %+.10f %+.10f i, C_tau = %+.10f %+.10f i", gam.size,
    *[f(np.sum((1 - (np.arange(gam.size)) / gam.size) * np.exp(1j * o))) for o in (gam, tau) for f in (np.real, np.imag)])
write_csv("s16_walks_1000.csv", ["k", "gamma", "tau", "theta", "ReS_gamma", "ImS_gamma", "ReS_tau", "ImS_tau",
                                 "ReS_theta", "ImS_theta"],
          [k, g, t, th, S["gamma"].real, S["gamma"].imag, S["tau"].real, S["tau"].imag, S["theta"].real, S["theta"].imag])

cols = {"gamma": "#1f5fa8", "tau": "#d0582a", "theta": "#3d9a3d"}
lab = {"gamma": r"$\gamma_k$ (zeros of $\zeta$)", "tau": r"$\tau_k$ (midpoint clock)", "theta": r"$\theta_k=(\gamma_k+\tau_k)/2$"}
mk = {"gamma": "o", "tau": "s", "theta": "D"}
zc = (N + 1) / 2

# one 3D panel per walk, k on the vertical axis
fig = plt.figure(figsize=(16, 6))
for i, nm in enumerate(names):
    ax = fig.add_subplot(1, 3, i + 1, projection="3d")
    ax.plot(S[nm].real, S[nm].imag, k, lw=0.6, color=cols[nm])
    ax.scatter([C[nm].real], [C[nm].imag], [zc], s=60, marker=mk[nm], color=cols[nm], edgecolor="k", depthshade=False)
    ax.set_xlabel(r"Re $S_k$"); ax.set_ylabel(r"Im $S_k$"); ax.set_zlabel("$k$")
    ax.set_title(lab[nm] + "\n$C$ = %.4f %+.4f i" % (C[nm].real, C[nm].imag), fontsize=10)
    ax.view_init(22, -55)
    ax.xaxis.set_major_locator(MaxNLocator(5)); ax.yaxis.set_major_locator(MaxNLocator(5))
fig.tight_layout()
savefig(fig, "fig24_walks_3d_1000.png")

# the three walks together, and the projection on the complex plane
fig = plt.figure(figsize=(15, 6.5))
ax = fig.add_subplot(1, 2, 1, projection="3d")
for nm in names:
    ax.plot(S[nm].real, S[nm].imag, k, lw=0.6, color=cols[nm], label=lab[nm])
    ax.scatter([C[nm].real], [C[nm].imag], [zc], s=60, marker=mk[nm], color=cols[nm], edgecolor="k", depthshade=False)
ax.set_xlabel(r"Re $S_k$"); ax.set_ylabel(r"Im $S_k$"); ax.set_zlabel("$k$")
ax.view_init(22, -55); ax.set_title("The three walks, $N=%d$ (centroids at height $(N+1)/2$)" % N, fontsize=10)
ax.legend(loc="upper left", fontsize=8)
ax = fig.add_subplot(1, 2, 2)
for nm in names:
    ax.plot(S[nm].real, S[nm].imag, lw=0.4, color=cols[nm], label=lab[nm])
for nm in names:
    ax.plot(C[nm].real, C[nm].imag, mk[nm], ms=10, color=cols[nm], mec="k", mew=1.2, zorder=10,
            label="$C$ = %.4f %+.4f i" % (C[nm].real, C[nm].imag))
ax.plot(ch.real, ch.imag, "kx", ms=12, mew=2, zorder=11, label=r"$(C_\gamma+C_\tau)/2$")
ax.set_aspect("equal"); ax.grid(alpha=0.3)
ax.set_xlabel(r"Re $S_k$"); ax.set_ylabel(r"Im $S_k$"); ax.set_title("Projection on the complex plane", fontsize=10)
ax.legend(fontsize=7, loc="upper left")
fig.tight_layout()
savefig(fig, "fig25_walks_projection_1000.png")

sio.savemat(os.path.join(OUT, "s16_results.mat"), {"k": k, "gamma": g, "tau": t, "theta": th,
                                                   "S_gamma": S["gamma"], "S_tau": S["tau"], "S_theta": S["theta"],
                                                   "C_gamma": C["gamma"], "C_tau": C["tau"], "C_theta": C["theta"]})
say.close()
