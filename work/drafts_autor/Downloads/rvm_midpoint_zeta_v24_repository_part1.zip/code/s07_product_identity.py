"""Experiment 7: the value at infinity of the endpoint.

varpi_Z1 = lim_{sigma -> +inf} zeta_Z1(sigma) = varpi_RVM * prod_k (1/4 + tau_k^2) / (1/4 + gamma_k^2),
so zeta_Z1 = zeta holds exactly when the ordered partial products
P_K = prod_{k <= K} (1/4 + gamma_k^2) / (1/4 + tau_k^2)
converge to varpi_RVM.  The partial products are computed from data/zeross.bin (gamma_k) and
data/zLamb.bin (tau_k) and compared with varpi_RVM from s02_transition.py."""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from rvm_common import Tee, load_ordinates, savefig, write_csv

say = Tee("s07_product_identity")
gam, tau = load_ordinates()
VARPI = 0.9619415807          # Richardson value of varpi_RVM (s02_transition.py)
N = gam.size
logP = np.cumsum(np.log1p(0.25 / gam ** 2) + 2 * np.log(gam) - np.log1p(0.25 / tau ** 2) - 2 * np.log(tau))
P = np.exp(logP)
say("N = %d ordinates; varpi_RVM = %.10f" % (N, VARPI))
say("%10s %16s %14s" % ("K", "P_K", "P_K - varpi"))
for K in [10, 100, 1000, 10 ** 4, 10 ** 5, 10 ** 6, N]:
    say("%10d %16.10f %14.3e" % (K, P[K - 1], P[K - 1] - VARPI))
for K0 in [10 ** 4, 10 ** 5, 10 ** 6]:
    seg = P[K0 - 1:]
    say("K >= %7d: min P_K = %.10f, max P_K = %.10f, mean = %.10f" % (K0, seg.min(), seg.max(), seg.mean()))
# the flow along the family: Upsilon(lam) = sum_k 2 gamma_k(lam) eta_k / (1/4 + gamma_k(lam)^2),
# eta_k = tau_k - gamma_k, gamma_k(lam) = (1 - lam) gamma_k + lam tau_k; d/dlam log varpi_lam = -Upsilon(lam)
eta = tau - gam
say("")
say("flow along the lambda-family")
for lam in [0.0, 0.25, 0.5, 0.75, 1.0]:
    gl = (1 - lam) * gam + lam * tau
    say("Upsilon(%.2f) = %.10f" % (lam, np.sum(2 * gl * eta / (0.25 + gl ** 2))))
say("sum_k 2 eta_k^2 / gamma_k^2 = %.10f" % np.sum(2 * eta ** 2 / gam ** 2))
total = np.sum(np.log((0.25 + tau ** 2) / (0.25 + gam ** 2)))
say("integral_0^1 Upsilon = sum_k log((1/4+tau_k^2)/(1/4+gamma_k^2)) = %.10f" % total)
say("log L = log(1/varpi_RVM)                               = %.10f" % np.log(1 / VARPI))
step = 50
idx = np.arange(step - 1, N, step)
write_csv("s07_partial_products.csv", ["K", "P_K"], [idx + 1, P[idx]])

fig, ax = plt.subplots(1, 2, figsize=(12, 4))
k1 = np.arange(1, 10 ** 4 + 1)
ax[0].plot(k1, P[:10 ** 4], "r-", lw=0.6, label=r"$P_K$")
ax[0].axhline(VARPI, color="k", lw=0.8, ls="--", label=r"$\varpi_{\rm RVM}$")
ax[0].set_xlabel("K")
ax[0].set_title(r"Partial products $P_K$, $K\leq 10^4$")
ax[0].legend(fontsize=8)
sel = idx >= 10 ** 5 - 1
ax[1].plot(idx[sel] + 1, (P[idx[sel]] - VARPI) * 1e6, "r-", lw=0.6)
ax[1].axhline(0.0, color="k", lw=0.8, ls="--")
ax[1].set_xlabel("K")
ax[1].set_ylabel(r"$(P_K-\varpi_{\rm RVM})\cdot 10^{6}$")
ax[1].set_title(r"$10^5\leq K\leq %d$" % N)
fig.tight_layout()
savefig(fig, "fig11_product_identity.png")
say.close()
