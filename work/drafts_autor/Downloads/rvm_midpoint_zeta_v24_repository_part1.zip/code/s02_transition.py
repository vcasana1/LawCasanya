"""Experiment 2: the transition theorem zeta_RVM = varpi (1 + w)(1 + O(1/t)),
the constant varpi_RVM, the vertical limit of 1/zeta_RVM, and zeta_RVM versus zeta."""
import os
import numpy as np
import mpmath as mp
import scipy.io as sio
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from rvm_common import (Tee, load_ordinates, Product, zeta_from_product, chi, w_transition,
                        write_csv, savefig, OUT)

say = Tee("s02_transition")
gam, tau = load_ordinates()
PR = Product(tau)

# ---- varpi_RVM by Richardson extrapolation on Re s = 2
Ts = 1.0e4 * np.array([0.25, 0.5, 1.0])
v = np.array([zeta_from_product(PR, 2 + 1j * T)[0] / (1 + w_transition(2 + 1j * T)) for T in Ts])
A = np.column_stack([np.ones(3), 1 / Ts, 1 / Ts ** 2])
c = np.linalg.solve(A.astype(complex), v)
varpi = c[0].real
L = 1.0 / varpi
say("varpi_RVM (Richardson, sigma = 2, T = 2500, 5000, 10000) = %.10f %+.2e i", c[0].real, c[0].imag)
say("L = 1/varpi_RVM = %.10f", L)

# ---- relative error of the transition formula
tt = np.exp(np.linspace(np.log(10.0), np.log(1.0e4), 160))
rows = [tt]
hdr = ["t"]
fits = []
for sp in (0.25, 0.5, 1.5):
    s = 0.5 + sp + 1j * tt
    zr = zeta_from_product(PR, s)
    err_w = np.abs(zr / (varpi * (1 + w_transition(s))) - 1)
    rows.append(err_w)
    hdr.append("err_w_sigmap%.2f" % sp)
    sel = tt > 100
    slope = np.polyfit(np.log(tt[sel]), np.log(err_w[sel]), 1)[0]
    fits.append([sp, slope, np.max(err_w[sel] * tt[sel])])
    say("sigma' = %.2f: |zeta_RVM/(varpi(1+w)) - 1|: log-log slope on t>100 = %.3f, max t*err = %.4f",
        sp, slope, np.max(err_w[sel] * tt[sel]))
    if sp < 0.5:
        err_c = np.abs(zr / (varpi * (1 + chi(s))) - 1)
        rows.append(err_c)
        hdr.append("err_chi_sigmap%.2f" % sp)
        say("sigma' = %.2f: |zeta_RVM/(varpi(1+chi)) - 1|: max t*err (t>100) = %.4f",
            sp, np.max(err_c[sel] * tt[sel]))
    wmod = np.abs(w_transition(s))
    rows.append(wmod)
    hdr.append("abs_w_sigmap%.2f" % sp)
    Fv = 1 / zr
    rows.append(np.abs(Fv - L))
    hdr.append("abs_F_minus_L_sigmap%.2f" % sp)
    say("          |w| * t^sigma' in [%.4f, %.4f];  |1/zeta_RVM - L| at t = 1e4: %.3e",
        np.min(wmod * tt ** sp), np.max(wmod * tt ** sp), np.abs(Fv[-1] - L))
write_csv("s02_transition_errors.csv", hdr, rows)

# ---- zeta_RVM versus zeta on two vertical lines and on the critical line
mp.mp.dps = 20
tl = np.linspace(1.0, 120.0, 900)
cmp = {}
for sigma in (2.0, 0.75):
    s = sigma + 1j * tl
    zr = zeta_from_product(PR, s)
    ze = np.array([complex(mp.zeta(complex(x))) for x in s])
    cmp[sigma] = (zr, ze)
    write_csv("s02_zetaRVM_vs_zeta_sigma%.2f.csv" % sigma, ["t", "abs_zeta", "abs_zetaRVM", "abs_varpi_1_plus_w"],
              [tl, np.abs(ze), np.abs(zr), np.abs(varpi * (1 + w_transition(s)))])

fig, ax = plt.subplots(2, 2, figsize=(12, 8))
cols = {0.25: "tab:red", 0.5: "tab:green", 1.5: "tab:blue"}
j = 1
for sp in (0.25, 0.5, 1.5):
    ax[0, 0].plot(tt, tt * rows[j], "-", color=cols[sp], label=r"$\sigma'=%.2f$" % sp)
    j += 4 if sp < 0.5 else 3
ax[0, 0].set_xlabel("t")
ax[0, 0].set_ylabel(r"$t\,|\zeta_{\rm RVM}/(\varpi_{\rm RVM}(1+w))-1|$")
ax[0, 0].set_title(r"Transition theorem: error times $t$ stays bounded, $\varpi_{\rm RVM}=%.10f$" % varpi, fontsize=9)
ax[0, 0].legend()
for sp in (0.25, 0.5, 1.5):
    s = 0.5 + sp + 1j * tt
    ax[0, 1].plot(tt, np.abs(1 / zeta_from_product(PR, s) - L) * tt ** min(sp, 1.0), "-", color=cols[sp], label=r"$\sigma'=%.2f$" % sp)
ax[0, 1].set_xlabel("t")
ax[0, 1].set_ylabel(r"$t^{\min(\sigma',1)}\,|1/\zeta_{\rm RVM}(\sigma+it)-L|$")
ax[0, 1].set_title(r"Vertical limit $L=1/\varpi_{\rm RVM}$, rescaled error", fontsize=9)
ax[0, 1].legend()
for a, sigma in zip((ax[1, 0], ax[1, 1]), (2.0, 0.75)):
    zr, ze = cmp[sigma]
    a.plot(tl, np.abs(ze), "k-", lw=1.2, label=r"$|\zeta(\sigma+it)|$")
    a.plot(tl, np.abs(zr), "r-", lw=1.2, label=r"$|\zeta_{\rm RVM}(\sigma+it)|$")
    a.set_xlabel("t")
    a.set_title(r"$\sigma=%.2f$" % sigma)
    a.legend()
fig.tight_layout()
savefig(fig, "fig03_transition.png")

sio.savemat(os.path.join(OUT, "s02_results.mat"), {"varpi": varpi, "L": L, "richardson": c,
                                                   "slopes": np.array(fits), "t": tt})
say.close()
