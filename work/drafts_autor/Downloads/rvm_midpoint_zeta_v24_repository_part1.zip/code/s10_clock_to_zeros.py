#!/usr/bin/env python3
"""s10_clock_to_zeros.py
Solves, starting from the clock (eta = 0), the system of rung equations

   sum_k c_j(gamma_k) + sum_n a_n psi_j(log n) = W_j ,   j = 1..J,

for the unknown ordinates gamma_k (below a height) and the unknown masses a_n at the log-integers.
  psi_j(u) = w(u) cos(omega_j u), w(u) sin(omega_j u);  w = smooth bump on (0, U), U = log(N + 1/2)
  c_j(t)   = int psi_j(u) cos(t u) du
  W_j      = int psi_j(u) (1/2)( e^{u/2} - e^{-u/2}/(e^{2u}-1) ) du      (lambda-independent part)
Ordinates above the free range are kept on the clock (tau_k from data/zLamb.bin).
The masses enter linearly and are eliminated exactly at every step (ridge RIDGE).
Continuation in height: the band omega <= Omega is enlarged step by step (OMEGAS); at each stage the
ordinates with tau_k <= Omega + MARGIN are free.  Start: gamma_k = tau_k.  Method: Levenberg-Marquardt.
data/zeross.bin is used only AFTER the iteration, to compare.
Outputs: output/s10_clock_to_zeros_console.txt, s10_ordinates.csv, s10_masses.csv
"""
import os, math
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, '..', 'output'); DATA = os.path.join(HERE, '..', 'data')
N = 13; U = math.log(N + 0.5)
KT = 6000; DOM = 0.1; NU = 8001; ITER = 400
OMEGAS = [18, 22, 26, 30, 34, 38, 42, 46, 50]; MARGIN = 12.0
WMIN = 5e-2; STEP = 0.2; RIDGE = 1e-10

u = np.linspace(0.0, U, NU)[1:-1]; du = U / (NU - 1)
v = (u - U/2) / (U/2); w = np.exp(-1.0/(1.0 - v**2)); w /= w.sum()*du
Wfun = 0.5*(np.exp(u/2) - np.exp(-u/2)/(np.exp(2*u) - 1))
ns = np.array([n for n in range(2, N + 1) if np.interp(math.log(n), u, w)/w.max() >= WMIN])
tau = np.fromfile(os.path.join(DATA, 'zLamb.bin'), dtype='<f8')[:KT]
COS_TAU = np.zeros_like(u)                       # sum over all clock ordinates of cos(tau_k u)
for a in range(0, KT, 500): COS_TAU += np.cos(np.outer(u, tau[a:a+500])).sum(axis=1)

lines = []
def P(s=''):
    print(s); lines.append(s)
P('s10: from the clock to the ordinates through the rung equations (continuation in height)')
P(f'N = {N}, U = log({N}+1/2) = {U:.6f}; free masses n = {ns[0]}..{ns[-1]}; start gamma_k = tau_k')
g_all = tau.copy()
for OM in OMEGAS:
    om = np.arange(0.0, OM + 1e-9, DOM)
    Psi = np.vstack([w*np.cos(o*u) for o in om] + [w*np.sin(o*u) for o in om[1:]]) * du
    Wj = Psi @ Wfun
    Pn = np.vstack([np.interp(np.log(ns), u, Psi[j]/du) for j in range(Psi.shape[0])])
    Q = np.linalg.solve(Pn.T @ Pn + RIDGE*np.eye(len(ns)), Pn.T)
    K = int((tau <= OM + MARGIN).sum())
    g = g_all[:K].copy()
    fixed = Psi @ (COS_TAU - np.cos(np.outer(u, tau[:K])).sum(axis=1)) - Wj
    def r0(g): return Psi @ np.cos(np.outer(u, g)).sum(axis=1) + fixed
    def res(g):
        x = r0(g); a = -Q @ x; return x + Pn @ a, a
    r, a = res(g); n0 = np.linalg.norm(r); damp = 1e-3
    for it in range(1, ITER + 1):
        Jg = Psi @ (-u[:, None]*np.sin(np.outer(u, g))); Jg = Jg - Pn @ (Q @ Jg)
        A = Jg.T @ Jg; b = -Jg.T @ r
        while True:
            d = np.linalg.solve(A + damp*np.diag(np.diag(A) + 1e-14), b)
            d *= min(1.0, STEP/max(np.abs(d).max(), 1e-300))
            r2, a2 = res(g + d)
            if np.linalg.norm(r2) < np.linalg.norm(r) or damp > 1e12: break
            damp *= 4
        g = g + d; r, a = r2, a2; damp = max(damp/3, 1e-14)
        if np.abs(d).max() < 1e-11: break
    g_all[:K] = g
    P(f'band omega <= {OM:2d}: {K:2d} free ordinates, {Psi.shape[0]} tests, |residual| {n0:.3e} -> {np.linalg.norm(r):.3e} in {it} iterations')
P()
gam = np.fromfile(os.path.join(DATA, 'zeross.bin'), dtype='<f8')[:K]
P('  k      tau_k (start)    solved ordinate    gamma_k (zeross.bin)   solved - gamma_k    tau_k - gamma_k')
for k in range(K):
    P(f'{k+1:3d}   {tau[k]:14.9f}   {g_all[k]:14.9f}   {gam[k]:14.9f}   {g_all[k]-gam[k]:+.3e}   {tau[k]-gam[k]:+.6f}')
P()
def Lam(n):
    for p in range(2, n + 1):
        if n % p == 0:
            m = n
            while m % p == 0: m //= p
            return math.log(p) if m == 1 else 0.0
    return 0.0
P('  n     solved mass a_n     Lambda(n)/(2 sqrt n)     difference     w(log n)/max w')
for i, n in enumerate(ns):
    ex = Lam(int(n))/(2*math.sqrt(n))
    P(f'{n:3d}   {a[i]:+.9f}   {ex:+.9f}   {a[i]-ex:+.3e}   {np.interp(math.log(n), u, w)/w.max():.3e}')
np.savetxt(os.path.join(OUT, 's10_ordinates.csv'), np.c_[np.arange(1, K+1), tau[:K], g_all[:K], gam], delimiter=',',
           header='k,tau_k,solved,gamma_k', comments='', fmt=['%d'] + ['%.12f']*3)
np.savetxt(os.path.join(OUT, 's10_masses.csv'), np.c_[ns, a, [Lam(int(n))/(2*math.sqrt(n)) for n in ns]], delimiter=',',
           header='n,solved_mass,Lambda(n)/(2sqrt(n))', comments='', fmt=['%d'] + ['%.12f']*2)
open(os.path.join(OUT, 's10_clock_to_zeros_console.txt'), 'w').write('\n'.join(lines) + '\n')
