#!/usr/bin/env python3
"""s12_multiscale_jacobian.py

Clock-only diagnostics for the multiscale Jacobian analysis.

No genuine zeta ordinates and no displacement data are used.  The midpoint
ordinates are generated directly from the Lambert-W formula

    tau_k = 2*pi*(k - 11/8) / W_0((k - 11/8)/e).

The program computes:
  1. the minimum clock gap up to several heights and the rigorous lower bound
     2*pi/log(T/(2*pi));
  2. the associated Ingham window threshold 2*pi/min_gap and the natural
     scale log(T/(2*pi));
  3. fixed-window adjacent-pair upper bounds showing that no uniform lower
     frame bound can hold on a fixed u-window as k -> infinity.

Outputs:
  output/s12_multiscale_summary.csv
  output/s12_fixed_window_pairs.csv
  output/s12_multiscale_jacobian_console.txt
  figures/fig14_multiscale_gap.png
  figures/fig15_fixed_window_degeneracy.png
"""

import os
import math
import numpy as np
from scipy.special import lambertw
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
OUT = os.path.join(ROOT, "output")
FIG = os.path.join(ROOT, "figures")
os.makedirs(OUT, exist_ok=True)
os.makedirs(FIG, exist_ok=True)

KMAX = 2_001_052
K_VALUES = np.array([100, 1_000, 10_000, 100_000, 500_000, KMAX], dtype=np.int64)
PAIR_K = np.unique(np.geomspace(10, KMAX - 1, 240).astype(np.int64))
FIXED_WINDOWS = (0.5, 1.0, 2.0, 4.0)


def midpoint_ordinates(k):
    """Return midpoint RVM ordinates for a NumPy array of positive indices."""
    k = np.asarray(k, dtype=np.float64)
    a = k - 11.0 / 8.0
    w = lambertw(a / math.e, k=0).real
    return 2.0 * math.pi * a / w


def main():
    lines = []

    def say(text=""):
        print(text)
        lines.append(text)

    say("s12: multiscale Jacobian diagnostics from the midpoint clock")
    say("No zeross.bin, zLamb.bin, or displacement sequence is used.")
    say(f"KMAX = {KMAX}")
    say()

    indices = np.arange(1, KMAX + 1, dtype=np.float64)
    tau = midpoint_ordinates(indices)
    gaps = np.diff(tau)
    prefix_min_gap = np.minimum.accumulate(gaps)

    rows = []
    say("       K              T        min gap      gap lower     min/lower      Ucrit       log(T/2pi)   Ucrit/log")
    for K in K_VALUES:
        T = tau[K - 1]
        min_gap = prefix_min_gap[K - 2] if K >= 2 else np.nan
        gap_lower = 2.0 * math.pi / math.log(T / (2.0 * math.pi))
        ucrit = 2.0 * math.pi / min_gap
        unatural = math.log(T / (2.0 * math.pi))
        rows.append((K, T, min_gap, gap_lower, min_gap / gap_lower,
                     ucrit, unatural, ucrit / unatural))
        say(f"{K:9d} {T:14.6f} {min_gap:13.8f} {gap_lower:13.8f} "
            f"{min_gap/gap_lower:13.8f} {ucrit:11.6f} {unatural:14.8f} {ucrit/unatural:11.8f}")

    np.savetxt(
        os.path.join(OUT, "s12_multiscale_summary.csv"),
        np.asarray(rows, dtype=float),
        delimiter=",",
        header="K,T,min_gap,gap_lower_bound,min_gap_over_lower,Ucrit,log_T_over_2pi,Ucrit_over_log",
        comments="",
        fmt="%.15e",
    )

    # Fixed-window adjacent-pair upper bounds.
    # For h_k = 1, h_{k+1} = -1, ||h||_2 = sqrt(2), and
    # |sin(tau_{k+1}u)-sin(tau_ku)| <= gap_k * u, hence
    # ||u[sin(tau_{k+1}u)-sin(tau_ku)]||_L2(0,U) / ||h||_2
    # <= gap_k * U^(5/2) / sqrt(10).
    pair_rows = []
    for K in PAIR_K:
        gap = gaps[K - 1]
        row = [K, tau[K - 1], gap]
        for U in FIXED_WINDOWS:
            row.append(gap * U ** 2.5 / math.sqrt(10.0))
        pair_rows.append(row)
    pair_rows = np.asarray(pair_rows, dtype=float)

    header = "k,tau_k,gap_k," + ",".join(
        f"adjacent_pair_upper_U_{U:g}" for U in FIXED_WINDOWS
    )
    np.savetxt(
        os.path.join(OUT, "s12_fixed_window_pairs.csv"),
        pair_rows,
        delimiter=",",
        header=header,
        comments="",
        fmt="%.15e",
    )

    say()
    say("Fixed-window adjacent-pair upper bounds at the largest sampled k:")
    K = int(PAIR_K[-1])
    gap = gaps[K - 1]
    say(f"k = {K}, tau_k = {tau[K-1]:.6f}, gap = {gap:.9f}")
    for U in FIXED_WINDOWS:
        bound = gap * U ** 2.5 / math.sqrt(10.0)
        say(f"  U = {U:3.1f}: normalized upper bound <= {bound:.9e}")

    # Figure 14: minimum gap and rigorous lower bound.
    fig, ax = plt.subplots(figsize=(7.2, 4.6))
    arr = np.asarray(rows, dtype=float)
    ax.loglog(arr[:, 1], arr[:, 2], marker="o", label="minimum observed clock gap")
    ax.loglog(arr[:, 1], arr[:, 3], marker="s", label=r"$2\pi/\log(T/2\pi)$ lower bound")
    ax.set_xlabel("clock height T")
    ax.set_ylabel("gap")
    ax.set_title("Midpoint-clock gap and the multiscale window threshold")
    ax.grid(True, which="both", alpha=0.25)
    ax.legend()
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, "fig14_multiscale_gap.png"), dpi=180)
    plt.close(fig)

    # Figure 15: failure of a fixed-window lower bound.
    fig, ax = plt.subplots(figsize=(7.2, 4.6))
    for j, U in enumerate(FIXED_WINDOWS, start=3):
        ax.loglog(pair_rows[:, 0], pair_rows[:, j], label=f"U = {U:g}")
    ax.set_xlabel("clock index k")
    ax.set_ylabel("adjacent-pair normalized upper bound")
    ax.set_title("Fixed-window near-degeneracy of adjacent clock frequencies")
    ax.grid(True, which="both", alpha=0.25)
    ax.legend()
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, "fig15_fixed_window_degeneracy.png"), dpi=180)
    plt.close(fig)

    say()
    say("Saved numerical tables and figures.")
    say("The decreasing fixed-window bounds are a diagnostic of the rigorous fact")
    say("that no T-independent lower frame bound can hold on a fixed u-window.")

    with open(os.path.join(OUT, "s12_multiscale_jacobian_console.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")


if __name__ == "__main__":
    main()
