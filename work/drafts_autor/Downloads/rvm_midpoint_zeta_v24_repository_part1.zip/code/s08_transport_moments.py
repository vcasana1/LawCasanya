#!/usr/bin/env python3
"""s08_transport_moments.py
Transport tau -> gamma on the first rung (support of psi inside (0, log 2)).

Input (not recomputed): data/zeross.bin (gamma_k), data/zLamb.bin (tau_k), little-endian float64.

For a fixed normalized smooth bump psi supported in [A,B] subset (0, log 2):
  c_psi^{(j)}(t) = int psi(u) u^j cos(t u + j pi/2) du
  W_psi    = (1/2) int psi(u) ( e^{u/2} - e^{-u/2}/(e^{2u}-1) ) du       (lambda-independent part)
  R_psi(1) = W_psi - sum_k c_psi(tau_k)                                   (clock defect; clock side only)
  S_psi(lambda) = sum_k [ c_psi(gamma_k + lambda*eta_k) - c_psi(tau_k) ]  (transport), eta_k = tau_k - gamma_k
  m_j(psi) = sum_k eta_k^j c_psi^{(j)}(tau_k)                             (clock-sampled moments)
and the partial sums of  S_psi(0) = sum_{j>=1} (-1)^j m_j / j!.
Outputs: output/s08_transport_console.txt, s08_moments.csv, s08_transport_lambda.csv, s08_first_moment_terms.csv
"""
import os, math
import numpy as np

K = 20000
A, B = 0.10, 0.62            # support of psi, inside (0, log 2 = 0.6931)
NU = 4001                    # quadrature nodes
JMAX = 12
HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, '..', 'output')
DATA = os.path.join(HERE, '..', 'data')
os.makedirs(OUT, exist_ok=True)

u = np.linspace(A, B, NU)
v = (u - 0.5 * (A + B)) / (0.5 * (B - A))
psi = np.zeros_like(u)
ins = np.abs(v) < 1
psi[ins] = np.exp(-1.0 / (1.0 - v[ins] ** 2))
du = u[1] - u[0]
psi /= psi.sum() * du                      # int psi = 1

def c(t, j=0, chunk=2000):
    t = np.atleast_1d(np.asarray(t, dtype=float))
    w = psi * u ** j * du
    out = np.empty_like(t)
    for a in range(0, len(t), chunk):
        out[a:a + chunk] = np.cos(np.outer(t[a:a + chunk], u) + j * np.pi / 2) @ w
    return out

def main():
    lines = []
    def P(s=''):
        print(s); lines.append(s)
    g_all = np.fromfile(os.path.join(DATA, 'zeross.bin'), dtype='<f8')
    t_all = np.fromfile(os.path.join(DATA, 'zLamb.bin'), dtype='<f8')
    g = g_all[:K]; tau = t_all[:K]; eta = tau - g
    W = 0.5 * (psi * (np.exp(u / 2) - np.exp(-u / 2) / (np.exp(2 * u) - 1))).sum() * du
    c_tau = c(tau); c_gam = c(g)
    R1 = W - c_tau.sum()
    S0 = (c_gam - c_tau).sum()
    P('s08: transport tau -> gamma on the first rung')
    P(f'entries in zeross.bin / zLamb.bin: {len(g_all)} / {len(t_all)};  used K = {K}')
    P(f'gamma_1 = {g[0]:.9f}, tau_1 = {tau[0]:.9f};  gamma_K = {g[-1]:.6f}, tau_K = {tau[-1]:.6f}')
    P(f'psi: normalized bump on [{A}, {B}] (log 2 = {math.log(2):.6f}), {NU} nodes')
    P(f'max|eta_k| = {np.abs(eta).max():.6f} at k = {np.abs(eta).argmax()+1};  rms eta = {np.sqrt((eta**2).mean()):.6f}')
    for k0 in (100, 300, 1000, 3000, 10000, K - 1):
        P(f'  max_(k>={k0:5d}) |c_psi(tau_k)| = {np.abs(c_tau[k0:]).max():.3e}')
    P()
    P(f'W_psi                          = {W:+.12f}')
    P(f'sum_k c_psi(tau_k)             = {c_tau.sum():+.12f}')
    P(f'sum_k c_psi(gamma_k)           = {c_gam.sum():+.12f}')
    P(f'R_psi(1) = W - sum c(tau)      = {R1:+.12f}   (clock defect)')
    P(f'S_psi(0) = sum[c(gam)-c(tau)]  = {S0:+.12f}   (transport)')
    P(f'R_psi(0) = R_psi(1) - S_psi(0) = {R1 - S0:+.3e}')
    P()
    P(' j        m_j(psi)        (-1)^j m_j/j!      partial sum      partial - R_psi(1)')
    rows = []; part = 0.0
    for j in range(1, JMAX + 1):
        mj = (eta ** j * c(tau, j)).sum()
        term = (-1) ** j * mj / math.factorial(j)
        part += term
        rows.append((j, mj, term, part, part - R1))
        P(f'{j:2d}  {mj:+.10e}  {term:+.10e}  {part:+.12f}  {part - R1:+.3e}')
    np.savetxt(os.path.join(OUT, 's08_moments.csv'), np.array(rows), delimiter=',',
               header='j,m_j,term,partial_sum,partial_minus_R1', comments='', fmt=['%d'] + ['%.15e'] * 4)
    # which k carry the first two moments
    t1 = -eta * c(tau, 1); t2 = 0.5 * eta ** 2 * c(tau, 2)
    kk = np.arange(1, K + 1)
    np.savetxt(os.path.join(OUT, 's08_first_moment_terms.csv'), np.c_[kk, tau, eta, c_tau, c_gam - c_tau, t1, t2][:400], delimiter=',',
               header='k,tau_k,eta_k,c_psi(tau_k),c_psi(gamma_k)-c_psi(tau_k),-eta_k*c1(tau_k),0.5*eta_k^2*c2(tau_k)', comments='',
               fmt=['%d'] + ['%.12e'] * 6)
    P()
    P(' cumulative over k (first K0 ordinates):  K0   sum[c(gam)-c(tau)]   W - sum c(tau)   -m_1 part   +m_2/2 part')
    for K0 in (1, 2, 3, 5, 10, 20, 50, 100, 200, 400):
        P(f'   {K0:4d}   {(c_gam-c_tau)[:K0].sum():+.10f}   {W - c_tau[:K0].sum():+.10f}   {t1[:K0].sum():+.10f}   {t2[:K0].sum():+.10f}')
    P()
    P(' lambda     S_psi(lambda)     R_psi(lambda) = R_psi(1) - S_psi(lambda)')
    lam = np.linspace(-1.0, 2.0, 61); rows = []
    for L in lam:
        S = (c(g + L * eta) - c_tau).sum()
        rows.append((L, S, R1 - S))
    for L, S, R in rows[::5]:
        P(f'{L:+.2f}   {S:+.12f}   {R:+.12f}')
    np.savetxt(os.path.join(OUT, 's08_transport_lambda.csv'), np.array(rows), delimiter=',',
               header='lambda,S_psi,R_psi', comments='', fmt='%.15e')
    with open(os.path.join(OUT, 's08_transport_console.txt'), 'w') as f:
        f.write('\n'.join(lines) + '\n')

if __name__ == '__main__':
    main()
