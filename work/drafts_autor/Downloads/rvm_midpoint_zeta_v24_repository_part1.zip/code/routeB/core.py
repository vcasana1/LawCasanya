import numpy as np
from scipy.special import lambertw
from scipy.integrate import quad
SQ2PI=np.sqrt(2*np.pi)
def clock(K):
    k=np.arange(1,K+1); a=(k-11/8)/np.e
    return np.real(2*np.pi*(k-11/8)/lambertw(a))
def vonmangoldt(Nmax):
    L=np.zeros(Nmax+1)
    for p in range(2,Nmax+1):
        if all(p%q for q in range(2,int(p**0.5)+1)):
            q=p
            while q<=Nmax: L[q]=np.log(p); q*=p
    return L
LAM=vonmangoldt(200000)
def kfun(u): return np.cosh(u/2)-np.exp(-u/2)/(2*(1-np.exp(-2*u)))
def gauss(c,s,u): return np.exp(-(u-c)**2/(2*s*s))
def Fphi(c,s,kap):  # int_R gauss cos(kap u) du
    return s*SQ2PI*np.exp(-0.5*(s*kap)**2)*np.cos(c*kap)
def dFphi(c,s,kap):
    return s*SQ2PI*np.exp(-0.5*(s*kap)**2)*(-(s*s)*kap*np.cos(c*kap)-c*np.sin(c*kap))
_kcache={}
def kpair(c,s):
    key=(round(c,12),round(s,12))
    if key not in _kcache:
        a=max(c-9*s,1e-9); b=c+9*s
        _kcache[key]=quad(lambda u:kfun(u)*gauss(c,s,u),a,b,limit=400,epsabs=1e-13,epsrel=1e-12)[0]
    return _kcache[key]
def masspair(c,s):
    nmax=int(np.exp(c+9*s))+1
    n=np.arange(2,nmax+1); a=LAM[n]/(2*np.sqrt(n))
    return np.sum(a*gauss(c,s,np.log(n)))
def residual(tests,kap):
    """tests: list of (c,s); kap: full list (must extend far enough)"""
    out=[]
    for c,s in tests:
        out.append(np.sum(Fphi(c,s,kap))+masspair(c,s)-kpair(c,s))
    return np.array(out)
def jac(tests,kap,K):
    return np.array([dFphi(c,s,kap[:K]) for c,s in tests])
