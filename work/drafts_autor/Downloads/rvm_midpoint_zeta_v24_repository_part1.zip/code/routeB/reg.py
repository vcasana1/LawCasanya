import numpy as np, sys
from scipy.optimize import least_squares
from core import *
g=np.load('gamma.npy'); tau=clock(60000)
q,s0,VIS,sp=0.85,0.08,4.0,1.0
mu=float(sys.argv[1]); TE=float(sys.argv[2])
for m in [3,6,9,12]:
    tests=[]
    for mm in range(1,m+1):
        s=s0*q**(mm-1); T=VIS/s; U=np.log(max(T,7)/(2*np.pi))+2.0
        tests+= [(float(c),s) for c in np.arange(9*s,U+1e-9,sp*s)]
    smin=s; Ke=int(np.sum(tau<=TE/smin)); ki=int(np.sum(g<0.6*T))
    cs=np.array([t[0] for t in tests]); ss=np.array([t[1] for t in tests])
    const=np.array([masspair(c,s_)-kpair(c,s_) for c,s_ in tests])
    tail=np.array([np.sum(Fphi(c,s_,tau[Ke:])) for c,s_ in tests])   # clock beyond TE/smin
    def F(y): return np.concatenate([np.sum(Fphi(cs[:,None],ss[:,None],y[None,:]),axis=1)+tail+const, mu*(y-tau[:Ke])])
    def Jf(y): return np.vstack([dFphi(cs[:,None],ss[:,None],y[None,:]), mu*np.eye(Ke)])
    sol=least_squares(F,tau[:Ke].copy(),jac=Jf,method='trf',bounds=(tau[:Ke]-3,tau[:Ke]+3),xtol=1e-15,ftol=1e-15,gtol=1e-15,max_nfev=4000)
    y=np.sort(sol.x); nk=min(Ke,len(g)); dev=np.abs(y[:nk]-g[:nk])
    res=np.max(np.abs(F(y)[:len(tests)]))
    # largest index such that all below recovered to 1e-4 / 1e-6
    def front(tol): 
        bad=np.where(dev>tol)[0]; return int(bad[0]) if len(bad) else nk
    print(f"m={m:2d} T={T:5.0f} interior n={ki} unknowns={Ke} tests={len(tests)} residual={res:.1e} recovered-front(1e-6)={front(1e-6)} (1e-4)={front(1e-4)} (1e-2)={front(1e-2)} maxdev_int={dev[:ki].max():.1e}",flush=True)
