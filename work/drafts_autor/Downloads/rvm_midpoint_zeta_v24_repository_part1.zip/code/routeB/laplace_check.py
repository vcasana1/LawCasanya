# Numerical check of the identity  (1/2) G'/G(s) = L[K](s)  with
# K = (1/2)e^{u/2} 1_+ - (1/2) g 1_+ - (1/4) fp(1_+/u) + c0 delta_0,
# g(u)=e^{-u/2}/(e^{2u}-1)-1/(2u),  c0=-(1/4)log(2 pi e^{gamma_E}),  z=s-1/2,
# L[fp(1_+/u)](z) = -log z - gamma_E.   Also checks k(u)=cosh(u/2)-e^{-u/2}/(2(1-e^{-2u})) = K|_(0,inf).
from mpmath import mp, mpf, exp, expm1, log, pi, euler, quad, digamma, cosh, inf, mpc
mp.dps=50
def g(u):
    if u<mpf('1e-12'): return -mpf(3)/4       # g(0+)=-3/4; avoids cancellation
    return exp(-u/2)/expm1(2*u)-1/(2*u)
def k_v18(u): return (exp(u/2)-exp(-u/2)/(exp(2*u)-1))/2
def k_mine(u): return cosh(u/2)-exp(-u/2)/(2*(1-exp(-2*u)))
def K_restr(u): return exp(u/2)/2-g(u)/2-1/(4*u)
for u in [mpf('0.1'),mpf(1),mpf('2.5')]:
    print('u=%s  k_v18=%s  k_mine=%s  K|=%s'%(u,k_v18(u),k_mine(u),K_restr(u)))
def halfGG(s): return (1/s+1/(s-1)-log(pi)/2+digamma(s/2)/2)/2
def LK(s):
    z=s-mpf(1)/2
    c0=-(euler+log(2)+log(pi))/4
    I1=1/(2*(z-mpf(1)/2))                      # L[(1/2)e^{u/2}]
    I2=-quad(lambda u: exp(-z*u)*g(u),[0,1,inf])/2
    I3=-(-log(z)-euler)/4
    return I1+I2+I3+c0
for s in [mpf(2),mpf('1.3'),mpc(2,5),mpc('1.5',-3)]:
    print('s=%s  (1/2)G\'/G=%s  L[K]=%s'%(s,halfGG(s),LK(s)))
