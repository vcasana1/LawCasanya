import numpy as np
from scipy.optimize import least_squares
from core import *
g=np.load('gamma.npy'); tau=clock(60000); rng=np.random.default_rng(2)
q,s0,VIS,sp=0.85,0.08,4.0,1.0
spacing=lambda t: 2*np.pi/np.log(t/(2*np.pi))
for m in [3,6,9]:
    tests=[]
    for mm in range(1,m+1):
        s=s0*q**(mm-1); T=VIS/s; K=int(np.sum(tau<=T)); U=np.log(max(T,7)/(2*np.pi))+2.0
        tests+= [(float(c),s) for c in np.arange(9*s,U+1e-9,sp*s)]
    cs=np.array([t[0] for t in tests]); ss=np.array([t[1] for t in tests])
    ki=int(np.sum(g<0.6*T))
    const=np.array([masspair(c,s_)-kpair(c,s_) for c,s_ in tests])
    kfix=np.concatenate([g,tau[len(g):]])     # edges fixed at TRUE values (diagnostic)
    tail=np.array([np.sum(Fphi(c,s_,kfix[ki:])) for c,s_ in tests])
    F=lambda y: np.sum(Fphi(cs[:,None],ss[:,None],y[None,:]),axis=1)+tail+const
    Jf=lambda y: dFphi(cs[:,None],ss[:,None],y[None,:])
    sv=np.linalg.svd(Jf(g[:ki]),compute_uv=False)
    sk=spacing(g[:ki]); line=f"m={m} interior n={ki} cond(J_int at gamma)={sv[0]/sv[-1]:.1e} smin={sv[-1]:.1e} | "
    for a in [0.1,0.25,0.4,0.5,0.6,0.8]:
        ok=0
        for t in range(4):
            y0=g[:ki]+a*sk*rng.uniform(-1,1,ki)
            sol=least_squares(F,y0,jac=Jf,method='lm',xtol=1e-15,ftol=1e-15,gtol=1e-15,max_nfev=4000)
            ok+= np.max(np.abs(np.sort(sol.x)-g[:ki]))<1e-6
        line+=f"a={a}:{ok}/4 "
    sol=least_squares(F,tau[:ki].copy(),jac=Jf,method='lm',xtol=1e-15,ftol=1e-15,gtol=1e-15,max_nfev=4000)
    line+=f"| from clock: {int(np.sum(np.abs(np.sort(sol.x)-g[:ki])<1e-6))}/{ki} recovered"
    print(line,flush=True)
