# Computer-assisted (gamma-free) existence certificate for finite square sections, at the
# receding-horizon iterate kappa^H (horizonG, Gonek X=8 initialization, M=16).
# Stage m: tests = levels <= m (spacing 1.0 s), unknowns = interior ordinates (tau_k <= 2.4/s_m),
# other ordinates frozen at kappa^H. Square subset of tests chosen by pivoted QR on J^T.
# F_j separable in kappa_k  =>  J(x)-J(x0) has columns f_j''(x0_k) delta_k + R_jk, |R_jk|<=A3_jk delta_k^2/2.
# x0 = kappa^H polished by 8 Newton steps on the square system (gamma-free).
# Banach for Psi(x)=x-Q F_sel(x) on {||x-x0||_inf<=r}:  k(r)=||QB||r + 0.5*|| |Q|A3 || r^2 < 1,  eta<=(1-k(r)) r.
import numpy as np, json
from scipy.linalg import qr
from core import *
g=np.load('gamma.npy'); tau=clock(60000); kH=np.load('horizonG_kap_M16_I2.4.npy')
q,s0,sp,INT=0.85,0.08,1.0,2.4
def d2(c,s,k):
    a=s*s; e=s*SQ2PI*np.exp(-a*k*k/2)
    return e*(((a*k)**2-a-c*c)*np.cos(c*k)+2*a*k*c*np.sin(c*k))
def A3b(c,s,k,r):
    a=s*s; kl=np.maximum(np.abs(k)-r,0); ku=np.abs(k)+r; w=a*ku+c
    return s*SQ2PI*np.exp(-a*kl*kl/2)*(w**3+3*a*w)
tests=[]; out=[]
for m in range(1,17):
    s=s0*q**(m-1); T=4.0/s; U=np.log(max(T,7)/(2*np.pi))+2.0
    tests+=[(float(c),s) for c in np.arange(9*s,U+1e-9,sp*s)]
    n=int(np.sum(tau<=INT/s))
    cs=np.array([t[0] for t in tests]); ss=np.array([t[1] for t in tests])
    x0=kH[:n]
    J=dFphi(cs[:,None],ss[:,None],x0[None,:])
    _,_,piv=qr(J.T,pivoting=True); sel=np.sort(piv[:n])
    kk=kH.copy(); tsel=[tests[i] for i in sel]
    try:
        for it in range(8):                      # gamma-free Newton polishing on the square system
            Jc=dFphi(cs[sel][:,None],ss[sel][:,None],kk[None,:n]); kk[:n]=kk[:n]-np.linalg.solve(Jc,residual(tsel,kk))
    except np.linalg.LinAlgError:
        print(f"m={m:2d} Newton polishing failed (singular square Jacobian)"); break
    x0=kk[:n]; J=dFphi(cs[:,None],ss[:,None],x0[None,:])
    Q=np.linalg.inv(J[sel]); F=residual(tsel,kk)
    eta=np.max(np.abs(Q@F))
    QB=np.max(np.sum(np.abs(Q@d2(cs[sel][:,None],ss[sel][:,None],x0[None,:])),axis=1))
    best=None
    for r in np.geomspace(max(eta,1e-15)*1.0001,1.0,400):
        C3=np.max(np.sum(np.abs(Q)@A3b(cs[sel][:,None],ss[sel][:,None],x0[None,:],r),axis=1)) if best is None or r<10*best[0] else C3
        kr=QB*r+0.5*C3*r*r
        if kr<1 and eta<=(1-kr)*r: best=(r,kr); break
    margin=max((1-(QB*r+0.5*np.max(np.sum(np.abs(Q)@A3b(cs[sel][:,None],ss[sel][:,None],x0[None,:],r),axis=1))*r*r))*r for r in np.geomspace(1e-12,1e-1,60))
    rho_all=float(np.max(np.abs(residual(tests,kk))))
    Linf=np.max(np.sum(np.abs(Q),axis=1))
    nk=min(n,len(g)); devg=float(np.max(np.abs(x0[:nk]-g[:nk]))); devt=float(np.max(np.abs(x0-tau[:n])))
    rec=dict(m=m,T=T,n=n,Linf=float(Linf),eta=float(eta),QB=float(QB),certified=best is not None,margin=float(margin),rho_all_levels=rho_all,
             r=(float(best[0]) if best else None),k_r=(float(best[1]) if best else None),dev_gamma=devg,dev_tau=devt)
    out.append(rec)
    print(f"m={m:2d} T={T:5.0f} n={n:3d} Linf={Linf:.1e} eta={eta:.1e} ||QB||={QB:.1e} "
          + (f"CERTIFIED r={best[0]:.1e} k(r)={best[1]:.2f}" if best else "not certified")
          + f" margin={margin:.1e} rho(all tests<=m)={rho_all:.1e} | max|x0-tau|={devt:.2f} max|x0-gamma|={devg:.1e}",flush=True)
json.dump(out,open('cert7.json','w'),indent=1)
