# Block-entry test (item (i) of the review): from the certified stage-m solution x^(m)
# (square section polished as in cert7), put the NEW band (tau_k in (2.4/s_m, 2.4/s_{m+1}]) and
# everything beyond at Gonek X=8 values, and ask whether a Banach certificate holds for
# (a) the band-only square system (new band unknowns, tests from level m+1),
# (b) the full square system of stage m+1, started there (no polishing).
import numpy as np, json
from scipy.linalg import qr
from core import *
exec(open('cert5.py').read().split("tests=[]; out=[]")[0].split("import numpy as np, json")[1])  # d2, A3b, data
rG=np.load('gonekF_X8.npy'); kG=tau.copy(); kG[:len(rG)]=rG
def certify(Q,F,QBn,A3fun):
    eta=np.max(np.abs(Q@F))
    for r in np.geomspace(max(eta,1e-15)*1.0001,1.0,300):
        kr=QBn*r+0.5*np.max(np.sum(np.abs(Q)@A3fun(r),axis=1))*r*r
        if kr<1 and eta<=(1-kr)*r: return eta,r
    return eta,None
def margin(QBn,Q,A3fun): return max((1-(QBn*r+0.5*np.max(np.sum(np.abs(Q)@A3fun(r),axis=1))*r*r))*r for r in np.geomspace(1e-9,1e-1,50))
tests=[]; lev=[]; out=[]; prev=None
for m in range(1,16):
    s=s0*q**(m-1); T=4.0/s; U=np.log(max(T,7)/(2*np.pi))+2.0
    new=[(float(c),s) for c in np.arange(9*s,U+1e-9,sp*s)]; tests+=new; lev+=[m]*len(new)
    n=int(np.sum(tau<=INT/s)); cs=np.array([t[0] for t in tests]); ss=np.array([t[1] for t in tests]); lv=np.array(lev)
    if prev is not None:
        x0=kG.copy(); x0[:prev[1]]=prev[0][:prev[1]]          # old interior: certified stage-(m-1) solution; rest Gonek
        band=np.arange(prev[1],n); idx=np.where(lv==m)[0]
        Jb=dFphi(cs[idx][:,None],ss[idx][:,None],x0[None,band]); _,_,pv=qr(Jb.T,pivoting=True); sb=idx[np.sort(pv[:len(band)])]
        Qb=np.linalg.inv(dFphi(cs[sb][:,None],ss[sb][:,None],x0[None,band])); Fb=residual([tests[i] for i in sb],x0)
        QBb=np.max(np.sum(np.abs(Qb@d2(cs[sb][:,None],ss[sb][:,None],x0[None,band])),axis=1))
        A3f=lambda r: A3b(cs[sb][:,None],ss[sb][:,None],x0[None,band],r)
        eb,rb=certify(Qb,Fb,QBb,A3f); mb=margin(QBb,Qb,A3f)
        J=dFphi(cs[:,None],ss[:,None],x0[None,:n]); _,_,pv=qr(J.T,pivoting=True); sf=np.sort(pv[:n])
        Qf=np.linalg.inv(J[sf]); Ff=residual([tests[i] for i in sf],x0)
        QBf=np.max(np.sum(np.abs(Qf@d2(cs[sf][:,None],ss[sf][:,None],x0[None,:n])),axis=1))
        A3g=lambda r: A3b(cs[sf][:,None],ss[sf][:,None],x0[None,:n],r)
        ef,rf=certify(Qf,Ff,QBf,A3g); mf=margin(QBf,Qf,A3g)
        bandG=float(np.max(np.abs(x0[band]-g[band]))) if band[-1]<len(g) else float('nan')
        rec=dict(m=m,T=T,band=len(band),eta_band=float(eb),margin_band=float(mb),cert_band=rb is not None,
                 eta_full=float(ef),margin_full=float(mf),cert_full=rf is not None,gonek_band_err=bandG)
        out.append(rec)
        print(f"m={m:2d} T={T:5.0f} band={len(band):2d} | band-only: eta={eb:.1e} margin={mb:.1e} {'CERT' if rb else 'no'} "
              f"| full: eta={ef:.1e} margin={mf:.1e} {'CERT' if rf else 'no'} | Gonek band err={bandG:.1e}",flush=True)
    kk=kG.copy() if prev is None else x0.copy(); tsel=None
    J=dFphi(cs[:,None],ss[:,None],kk[None,:n]); _,_,pv=qr(J.T,pivoting=True); sel=np.sort(pv[:n]); tsel=[tests[i] for i in sel]
    try:
        for it in range(10):
            Jc=dFphi(cs[sel][:,None],ss[sel][:,None],kk[None,:n]); kk[:n]-=np.linalg.solve(Jc,residual(tsel,kk))
    except np.linalg.LinAlgError: print("singular at",m); break
    prev=(kk.copy(),n)
json.dump(out,open('entry.json','w'),indent=1)
