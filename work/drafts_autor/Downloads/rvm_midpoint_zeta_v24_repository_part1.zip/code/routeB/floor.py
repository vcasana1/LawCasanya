import numpy as np
from core import *
g=np.load('gamma.npy'); tau=clock(60000)
q,s0,VIS,sp=0.85,0.08,4.0,1.0
tests=[]
for m in range(1,13):
    s=s0*q**(m-1); T=VIS/s; K=int(np.sum(tau<=T)); U=np.log(max(T,7)/(2*np.pi))+2.0
    tests+= [(float(c),s) for c in np.arange(9*s,U+1e-9,sp*s)]
    kg=tau.copy(); kg[:K]=g[:K]
    kfull=np.concatenate([g,tau[len(g):]]) # gamma everywhere known (to 680), clock beyond
    rK=np.max(np.abs(residual(tests,kg))); rall=np.max(np.abs(residual(tests,kfull)))
    print(f"m={m:2d} K={K:3d} d={len(tests):4d}  res(gamma up to K, clock beyond)={rK:.2e}   res(gamma up to 400)={rall:.2e}",flush=True)
