import mpmath as mp, numpy as np, sys
mp.mp.dps=20
N=int(sys.argv[1])
g=[float(mp.zetazero(n).imag) for n in range(1,N+1)]
np.save('gamma.npy',np.array(g)); print(len(g), g[-1])
