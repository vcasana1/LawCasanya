import numpy as np
from scipy.optimize import brentq
from core import *
g=np.load('gamma.npy'); tau=clock(2000)
import mpmath as mp
def theta(t): return float(mp.siegeltheta(t))
def alphaX(t,X):
    n=np.arange(2,int(X*X)+1); L=LAM[n].copy()
    w=np.where(n<=X,1.0,2-np.log(n)/np.log(X)); w[n>X*X]=0
    return -np.sum(L*w*np.sin(t*np.log(n))/(np.sqrt(n)*np.log(n)))
def phase(t,X): return theta(t)+alphaX(t,X)
def gonek_list(X,K):
    # zeros of cos(phase): phase = pi/2 + j*pi ; scan fine grid
    ts=np.arange(10,tau[K-1]+20,0.01); ph=np.array([phase(t,X) for t in ts])
    v=(ph-np.pi/2)/np.pi; j=np.floor(v); idx=np.where(np.diff(j)!=0)[0]
    roots=[]
    for i in idx:
        # crossing(s) of integer between ts[i],ts[i+1]
        lev=max(j[i],j[i+1]); f=lambda t:(phase(t,X)-np.pi/2)/np.pi-lev
        try: roots.append(brentq(f,ts[i],ts[i+1],xtol=1e-12))
        except ValueError: pass
    return np.array(roots)
K=160
sp_=2*np.pi/np.log(g[:K]/(2*np.pi))
dc=np.abs(tau[:K]-g[:K])/sp_
print(f"clock : mean|.-g|/sp={dc.mean():.3f} max={dc.max():.3f}  #>0.25sp={int(np.sum(dc>0.25))}")
for X in [3,5,8,12,20]:
    r=gonek_list(X,K)
    if len(r)<K: print('X',X,'only',len(r)); continue
    # align: choose offset minimizing distance
    best=None
    for off in range(-3,4):
        a=r[max(0,off):max(0,off)+K]; 
        if len(a)<K: continue
        d=np.abs(a-g[:K]).mean()
        if best is None or d<best[0]: best=(d,off,a)
    a=best[2]; dg=np.abs(a-g[:K])/sp_
    print(f"Gonek X={X:2d} (offset {best[1]}): mean|.-g|/sp={dg.mean():.3f} max={dg.max():.3f} #>0.25sp={int(np.sum(dg>0.25))}  k=34: {a[33]:.3f} (g={g[33]:.3f})",flush=True)
    np.save(f'gonek_X{X}.npy',r)
