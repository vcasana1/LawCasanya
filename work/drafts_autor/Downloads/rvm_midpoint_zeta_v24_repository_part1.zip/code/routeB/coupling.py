import numpy as np
from core import *
g=np.load('gamma.npy'); tau=clock(60000)
q,s0,VIS,sp=0.85,0.08,4.0,1.0
for m in [3,6,9,12]:
    tests=[]
    for mm in range(1,m+1):
        s=s0*q**(mm-1); T=VIS/s; U=np.log(max(T,7)/(2*np.pi))+2.0
        tests+= [(float(c),s) for c in np.arange(9*s,U+1e-9,sp*s)]
    cs=np.array([t[0] for t in tests]); ss=np.array([t[1] for t in tests])
    kfull=np.concatenate([g,tau[len(g):]])
    ki=int(np.sum(g<0.6*T)); ke=int(np.sum(g<min(6/s,g[-1])))
    J=dFphi(cs[:,None],ss[:,None],kfull[None,:ke])
    JI=J[:,:ki]; JE=J[:,ki:ke]
    P=np.linalg.pinv(JI)@JE          # interior response to unit edge errors
    amp_inf=np.max(np.sum(np.abs(P),axis=1))   # l_inf->l_inf
    amp2=np.linalg.norm(P,2)
    sv=np.linalg.svd(JI,compute_uv=False)
    # typical edge error: clock displacement on edge
    eE=(tau[ki:ke]-g[ki:ke]); induced=np.max(np.abs(P@eE))
    print(f"m={m:2d} T={T:5.0f} interior={ki} edge={ke-ki} smin(J_I)={sv[-1]:.2e} cond={sv[0]/sv[-1]:.1e} ||J_I^+J_E||inf={amp_inf:.2e} ||.||2={amp2:.2e} interior shift from clock-valued edges={induced:.2e}",flush=True)
print("--- induced shift on fixed low ordinates (linearized), edge = sigma*kappa in [2.4,6] at clock values")
for m in [2,4,6,8,10,12,14]:
    tests=[]
    for mm in range(1,m+1):
        s=s0*q**(mm-1); T=VIS/s; U=np.log(max(T,7)/(2*np.pi))+2.0
        tests+= [(float(c),s) for c in np.arange(9*s,U+1e-9,sp*s)]
    cs=np.array([t[0] for t in tests]); ss=np.array([t[1] for t in tests])
    kfull=np.concatenate([g,tau[len(g):]])
    ki=int(np.sum(g<0.6*T)); ke=int(np.sum(g<min(6/s,g[-1])))
    J=dFphi(cs[:,None],ss[:,None],kfull[None,:ke]); P=np.linalg.pinv(J[:,:ki])@J[:,ki:ke]
    sh=np.abs(P@(tau[ki:ke]-g[ki:ke]))
    print(f"m={m:2d} T={T:5.0f} edge starts at k={ki}: |shift| k<=5: {sh[:5].max():.1e}  k<=10: {sh[:10].max():.1e}  k<=20: {sh[:min(20,ki)].max():.1e}",flush=True)
