import numpy as np, json, sys
from core import *
g=np.load('gamma.npy')
tau=clock(60000)
def NofT(T): return int(np.sum(tau<=T))
q=float(sys.argv[1]) if len(sys.argv)>1 else 0.85
rho=float(sys.argv[2]) if len(sys.argv)>2 else 0.5
M=int(sys.argv[3]) if len(sys.argv)>3 else 14
s0=float(sys.argv[4]) if len(sys.argv)>4 else 0.15
VIS=float(sys.argv[5]) if len(sys.argv)>5 else 3.5
kap=tau.copy(); tests=[]; cum=0.0; log=[]
for m in range(1,M+1):
    s=s0*q**(m-1); T=VIS/s; K=NofT(T); U=np.log(max(T,7)/(2*np.pi))+1.5
    grid=np.arange(9*s,U+1e-9,2*s)
    room=int(rho*K)-len(tests)
    if room<=0: grid=grid[:0]
    elif len(grid)>room: grid=grid[np.linspace(0,len(grid)-1,room).round().astype(int)]
    new=[(float(c),s) for c in grid]
    tests=tests+new
    d=len(tests)
    F0=residual(tests,kap); eta=np.max(np.abs(F0))
    J=jac(tests,kap,K)
    Q=np.linalg.pinv(J,rcond=1e-14)
    L=np.max(np.sum(np.abs(Q),axis=1))
    H=K*max(quad(lambda u:u*u*gauss(c,s_,u),max(c-9*s_,0),c+9*s_)[0] for c,s_ in tests)
    A=2*L*L*H*eta
    # Newton with fixed Q (Banach), then a few updated steps if needed
    x=np.zeros(K); conv='fixedQ'
    for it in range(60):
        k2=kap.copy(); k2[:K]+=x; Fx=residual(tests,k2)
        if np.max(np.abs(Fx))<1e-13: break
        x=x-Q@Fx
    if np.max(np.abs(Fx))>1e-10:
        conv='updated'; x=np.zeros(K)
        for it in range(60):
            k2=kap.copy(); k2[:K]+=x; Fx=residual(tests,k2)
            if np.max(np.abs(Fx))<1e-13: break
            Jx=jac(tests,k2,K); x=x-np.linalg.lstsq(Jx,Fx,rcond=1e-12)[0]
    kap=kap.copy(); kap[:K]+=x; kap=np.sort(kap)
    step=np.max(np.abs(x)); cum+=2*L*eta
    nk=min(K,len(g)); dist_g=np.abs(kap[:nk]-g[:nk]); dist_t=np.max(np.abs(kap[:K]-tau[:K]))
    rec=dict(m=m,sigma=s,T=round(T,1),U=round(U,2),K=K,d=d,eta=eta,L=L,H=H,A=A,step=step,
             predicted=2*L*eta,cum=cum,res=float(np.max(np.abs(Fx))),conv=conv,
             max_dev_tau=dist_t,dev_gamma_first10=float(np.max(dist_g[:10])),dev_gamma_all=float(np.max(dist_g)),
             med_dev_gamma=float(np.median(dist_g)))
    log.append(rec)
    print(f"m={m:2d} s={s:.4f} T={T:6.1f} K={K:3d} d={d:3d} eta={eta:.2e} L={L:.2e} H={H:.2e} A={A:.2e} step={step:.2e} res={rec['res']:.1e} {conv} |k-tau|max={dist_t:.3f} |k-g| first10={rec['dev_gamma_first10']:.2e} all={rec['dev_gamma_all']:.2e} med={rec['med_dev_gamma']:.2e}",flush=True)
json.dump(log,open(f'log_q{q}_r{rho}.json','w'),indent=1)
np.save(f'kap_q{q}_r{rho}.npy',kap)
