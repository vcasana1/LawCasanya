# Overdetermined Gauss-Newton constants at the Gonek list X=8, ALL tests, interior unknowns.
# beta = 1/sigma_min(J), delta = ||J^+ F||_2 (actual GN step), K_sharp = Lipschitz bound of J in l2
# using the diagonal structure of D^2F and the Gaussian decay in kappa (|kappa shift|<=1).
import numpy as np
from core import *
g=np.load('gamma.npy'); tau=clock(60000); r=np.load('gonekF_X8.npy')
kapG=tau.copy(); kapG[:len(r)]=r
q,s0,sp,INT=0.85,0.08,1.0,2.4
tests=[]
for m in range(1,15):
    s=s0*q**(m-1); T=4.0/s; U=np.log(max(T,7)/(2*np.pi))+2.0
    tests+=[(float(c),s) for c in np.arange(9*s,U+1e-9,sp*s)]
    ki=int(np.sum(tau<=INT/s))
    cs=np.array([t[0] for t in tests]); ss=np.array([t[1] for t in tests])
    J=dFphi(cs[:,None],ss[:,None],kapG[None,:ki])
    F=residual(tests,kapG)
    sv=np.linalg.svd(J,compute_uv=False); beta=1/sv[-1]
    d=np.linalg.lstsq(J,F,rcond=None)[0]; delta=np.linalg.norm(d)
    a=ss[:,None]**2; kl=np.maximum(kapG[None,:ki]-1,0); ku=kapG[None,:ki]+1
    A2=ss[:,None]*SQ2PI*np.exp(-a*kl**2/2)*((a*ku+cs[:,None])**2+a)
    K=np.max(np.sqrt(np.sum(A2**2,axis=0)))
    gi=min(ki,len(g)); dist=np.linalg.norm(kapG[:gi]-g[:gi]); dnew=np.linalg.norm(kapG[:gi]-d[:gi]-g[:gi])
    print(f"m={m:2d} T={T:5.0f} n={ki:3d} tests={len(tests):4d} beta={beta:6.2f} K={K:.2e} delta={delta:.2e} h={beta*K*delta:.2e} |kG-g|={dist:.2e} after1GN={dnew:.2e}",flush=True)
