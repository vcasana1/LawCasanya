# Kantorovich in l2 with the ACTUAL Newton step (delta=||J^{-1}F||) instead of L*eta,
# at the Gonek list X=8; square subsystem chosen by pivoted QR (as certG.py).
import numpy as np
from scipy.linalg import qr
from core import *
g=np.load('gamma.npy'); tau=clock(60000); r=np.load('gonekF_X8.npy')
kapG=tau.copy(); kapG[:len(r)]=r
q,s0,sp,INT=0.85,0.08,1.0,2.4
tests=[]
for m in range(1,15):
    s=s0*q**(m-1); T=4.0/s; U=np.log(max(T,7)/(2*np.pi))+2.0
    tests+=[(float(c),s) for c in np.arange(9*s,U+1e-9,sp*s)]
    ki=int(np.sum(tau<=INT/s))
    cs=np.array([t[0] for t in tests]); ss=np.array([t[1] for t in tests])
    J=dFphi(cs[:,None],ss[:,None],kapG[None,:ki])
    _,_,piv=qr(J.T,pivoting=True); sel=np.sort(piv[:ki])
    Js=J[sel]; F=residual([tests[i] for i in sel],kapG)
    beta=1/np.linalg.svd(Js,compute_uv=False)[-1]
    M=ss[sel]*np.sqrt(2*np.pi)*(cs[sel]**2+ss[sel]**2)      # int |phi_j| u^2 du, exact
    K=np.sqrt(np.sum(M**2))
    d=np.linalg.solve(Js,F); delta=np.linalg.norm(d)
    gi=min(ki,len(g)); dist=np.linalg.norm((kapG[:gi]-g[:gi]))
    print(f"m={m:2d} T={T:5.0f} n={ki:3d} beta={beta:.2e} K={K:.2e} delta={delta:.2e} h=beta*K*delta={beta*K*delta:.2e} |kapG-gamma|_2={dist:.2e}",flush=True)
