import numpy as np, json, sys
from scipy.optimize import least_squares
from core import *
g=np.load('gamma.npy'); tau=clock(60000)
NofT=lambda T:int(np.sum(tau<=T))
q,M,s0,VIS,sp,C=[float(a) for a in sys.argv[1:7]]; M=int(M)
kap=tau.copy(); tests=[]; log=[]
for m in range(1,M+1):
    s=s0*q**(m-1); T=VIS/s; K=NofT(T); U=np.log(max(T,7)/(2*np.pi))+2.0
    tests+= [(float(c),s) for c in np.arange(9*s,U+1e-9,sp*s)]
    d=len(tests); cs=np.array([t[0] for t in tests]); ss=np.array([t[1] for t in tests])
    const=np.array([masspair(c,s_)-kpair(c,s_) for c,s_ in tests])
    tail=np.array([np.sum(Fphi(c,s_,kap[K:])) for c,s_ in tests])
    def F(y):
        return (ss*SQ2PI)[:,None]*0+0 if False else (np.sum(Fphi(cs[:,None],ss[:,None],y[None,:]),axis=1)+tail+const)
    def Jf(y): return dFphi(cs[:,None],ss[:,None],y[None,:])
    y0=kap[:K].copy(); lo=tau[:K]-C; hi=tau[:K]+C
    y0=np.clip(y0,lo+1e-9,hi-1e-9)
    r0=np.max(np.abs(F(y0)))
    sol=least_squares(F,y0,jac=Jf,bounds=(lo,hi),method='trf',xtol=1e-15,ftol=1e-15,gtol=1e-15,max_nfev=2000)
    kap=kap.copy(); kap[:K]=np.sort(sol.x)
    Fend=F(kap[:K]); sv=np.linalg.svd(Jf(kap[:K]),compute_uv=False)
    nk=min(K,len(g)); dg=np.abs(kap[:nk]-g[:nk])
    good=int(np.argmax(dg>1e-3)) if np.any(dg>1e-3) else nk
    atb=int(np.sum((np.abs(kap[:K]-tau[:K])>C-1e-6)))
    rec=dict(m=m,s=s,T=T,U=U,K=K,d=d,res0=float(r0),res=float(np.max(np.abs(Fend))),cond=float(sv[0]/max(sv[-1],1e-300)),
             dev_tau=float(np.max(np.abs(kap[:K]-tau[:K]))),dev_g_first10=float(np.max(dg[:10])),dev_g_med=float(np.median(dg)),good=good,at_bound=atb)
    log.append(rec)
    print(f"m={m:2d} s={s:.4f} T={T:6.1f} U={U:.2f} K={K:3d} d={d:4d} res {rec['res0']:.2e} -> {rec['res']:.2e} cond={rec['cond']:.1e} |k-tau|max={rec['dev_tau']:.3f} atbound={atb} |k-g|first10={rec['dev_g_first10']:.1e} med={rec['dev_g_med']:.1e} good={good}",flush=True)
tag='_'.join(sys.argv[1:7]); json.dump(log,open(f'lsq2_{tag}.json','w'),indent=1); np.save(f'lsq2_kap_{tag}.npy',kap)
