# Sharp l-infinity Newton contraction using the DIAGONAL structure of D^2F:
#   Psi(x)=x-QF(x), Q=J^+ (fixed, at Gonek list X=8), interior unknowns, all tests.
#   ||DPsi(x)||_{inf} <= C*||x-x0||_inf,  C = || |Q| A2 ||_{inf->inf},  A2_jk = sup|d^2F_j/dkappa_k^2| on |shift|<=1.
#   Banach on the ball ||x-x0||_inf<=2*eta:  sufficient  2*C*eta<1  (eta=||QF(x0)||_inf), radius 2*eta<=1.
import numpy as np
from core import *
g=np.load('gamma.npy'); tau=clock(60000); r=np.load('gonekF_X8.npy')
kapG=tau.copy(); kapG[:len(r)]=r
q,s0,sp,INT=0.85,0.08,1.0,2.4
tests=[]
for m in range(1,17):
    s=s0*q**(m-1); T=4.0/s; U=np.log(max(T,7)/(2*np.pi))+2.0
    tests+=[(float(c),s) for c in np.arange(9*s,U+1e-9,sp*s)]
    ki=int(np.sum(tau<=INT/s))
    cs=np.array([t[0] for t in tests]); ss=np.array([t[1] for t in tests])
    J=dFphi(cs[:,None],ss[:,None],kapG[None,:ki]); F=residual(tests,kapG)
    Q=np.linalg.pinv(J)
    a=ss[:,None]**2; kl=np.maximum(kapG[None,:ki]-1,0); ku=kapG[None,:ki]+1
    A2=ss[:,None]*SQ2PI*np.exp(-a*kl**2/2)*((a*ku+cs[:,None])**2+a)
    C=np.max(np.sum(np.abs(Q)@A2,axis=1))
    d=Q@F; eta=np.max(np.abs(d))
    gi=min(ki,len(g)); e0=np.max(np.abs(kapG[:gi]-g[:gi])); e1=np.max(np.abs(kapG[:gi]-d[:gi]-g[:gi]))
    Linf=np.max(np.sum(np.abs(Q),axis=1))
    print(f"m={m:2d} T={T:5.0f} n={ki:3d} Linf={Linf:.2e} C={C:.2e} eta={eta:.2e} 2C*eta={2*C*eta:.2e} | maxerr0={e0:.2e} after1={e1:.2e}",flush=True)
