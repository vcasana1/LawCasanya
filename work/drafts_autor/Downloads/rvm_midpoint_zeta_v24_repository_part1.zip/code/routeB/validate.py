import numpy as np
from core import *
g=np.load('gamma.npy'); tau=clock(20000)
for (c,s) in [(1.0,0.1),(2.0,0.1),(2.5,0.05),(3.0,0.05),(1.5,0.2)]:
    T=9/s
    kg=np.concatenate([g[g<T], tau[tau>=T]]) if g[-1]>T else None
    rg=residual([(c,s)],np.concatenate([g,tau[tau>g[-1]+5]]))[0]
    rt=residual([(c,s)],tau)[0]
    print(f"c={c} s={s}  R(gamma)={rg:+.3e}  R(clock)={rt:+.3e}  k={kpair(c,s):.4f} mass={masspair(c,s):.4f}")
