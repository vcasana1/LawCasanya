import numpy as np, json, sys
from core import *
g=np.load('gamma.npy'); tau=clock(60000)
NofT=lambda T:int(np.sum(tau<=T))
q,M,s0,VIS,sp=float(sys.argv[1]),int(sys.argv[2]),float(sys.argv[3]),float(sys.argv[4]),float(sys.argv[5])
kap=tau.copy(); tests=[]; log=[]
for m in range(1,M+1):
    s=s0*q**(m-1); T=VIS/s; K=NofT(T); U=np.log(max(T,7)/(2*np.pi))+2.0
    tests+= [(float(c),s) for c in np.arange(9*s,U+1e-9,sp*s)]
    d=len(tests)
    r0=residual(tests,kap); x=np.zeros(K); lam=1e-3
    def Fx(x):
        k2=kap.copy(); k2[:K]+=x; return residual(tests,k2),k2
    F,_=Fx(x); cost=F@F
    for it in range(80):
        J=jac(tests,kap+np.concatenate([x,np.zeros(len(kap)-K)]),K)
        A=J.T@J; gvec=J.T@F
        while True:
            dx=-np.linalg.solve(A+lam*np.diag(np.diag(A)+1e-12),gvec)
            F2,_=Fx(x+dx); c2=F2@F2
            if c2<cost: x=x+dx; F=F2; cost=c2; lam=max(lam/3,1e-12); break
            lam*=4
            if lam>1e12: break
        if lam>1e12 or np.max(np.abs(dx))<1e-12: break
    kap=kap.copy(); kap[:K]+=x; kap=np.sort(kap)
    sv=np.linalg.svd(jac(tests,kap,K),compute_uv=False)
    nk=min(K,len(g)); dg=np.abs(kap[:nk]-g[:nk])
    # which index range is determined to 1e-3
    good=int(np.argmax(dg>1e-3)) if np.any(dg>1e-3) else nk
    rec=dict(m=m,s=s,T=T,U=U,K=K,d=d,res0=float(np.max(np.abs(r0))),res=float(np.max(np.abs(F))),
             cond=float(sv[0]/sv[-1]),dev_tau=float(np.max(np.abs(kap[:K]-tau[:K]))),
             dev_g_first10=float(np.max(dg[:10])),dev_g_med=float(np.median(dg)),good=good)
    log.append(rec)
    print(f"m={m:2d} s={s:.4f} T={T:6.1f} U={U:.2f} K={K:3d} d={d:4d} res_start={rec['res0']:.2e} res_end={rec['res']:.2e} cond={rec['cond']:.1e} |k-tau|max={rec['dev_tau']:.3f} |k-g|first10={rec['dev_g_first10']:.1e} med={rec['dev_g_med']:.1e} first k with|k-g|>1e-3: {good}",flush=True)
json.dump(log,open(f'lsq_{q}_{s0}_{VIS}_{sp}.json','w'),indent=1); np.save(f'lsq_kap_{q}_{s0}_{VIS}_{sp}.npy',kap)
