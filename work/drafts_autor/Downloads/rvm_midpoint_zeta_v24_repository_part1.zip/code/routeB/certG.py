import numpy as np
from scipy.linalg import qr
from scipy.integrate import quad
from core import *
g=np.load('gamma.npy'); tau=clock(60000); r=np.load('gonekF_X8.npy')
kapG=tau.copy(); kapG[:len(r)]=r
q,s0,sp,INT=0.85,0.08,1.0,2.4
tests=[]
for m in range(1,15):
    s=s0*q**(m-1); T=4.0/s; U=np.log(max(T,7)/(2*np.pi))+2.0
    tests+=[(float(c),s) for c in np.arange(9*s,U+1e-9,sp*s)]
    ki=int(np.sum(tau<=INT/s))
    cs=np.array([t[0] for t in tests]); ss=np.array([t[1] for t in tests])
    J=dFphi(cs[:,None],ss[:,None],kapG[None,:ki])
    _,_,piv=qr(J.T,pivoting=True); sel=np.sort(piv[:ki])     # ki best-conditioned tests
    Js=J[sel]; Q=np.linalg.inv(Js)                               # square: right inverse = inverse
    L=np.max(np.sum(np.abs(Q),axis=1))
    H=ki*max(quad(lambda u:u*u*gauss(cs[i],ss[i],u),max(cs[i]-9*ss[i],0),cs[i]+9*ss[i])[0] for i in sel)
    eta=np.max(np.abs(residual([tests[i] for i in sel],kapG)))
    eta_all=np.max(np.abs(residual(tests,kapG)))
    print(f"m={m:2d} T={T:5.0f} interior={ki:3d} L={L:.2e} H={H:.2e} eta_sel={eta:.2e} eta_all={eta_all:.2e} A=2L^2H eta={2*L*L*H*eta:.2e}  2L*eta={2*L*eta:.2e}",flush=True)
