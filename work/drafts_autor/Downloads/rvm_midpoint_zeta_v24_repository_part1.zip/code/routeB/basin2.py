import numpy as np, sys
from scipy.optimize import least_squares
from core import *
g=np.load('gamma.npy'); tau=clock(60000)
rng=np.random.default_rng(1)
q,s0,VIS,sp=0.85,0.08,4.0,1.0
def setup(m):
    tests=[]
    for mm in range(1,m+1):
        s=s0*q**(mm-1); T=VIS/s; K=int(np.sum(tau<=T)); U=np.log(max(T,7)/(2*np.pi))+2.0
        tests+= [(float(c),s) for c in np.arange(9*s,U+1e-9,sp*s)]
    cs=np.array([t[0] for t in tests]); ss=np.array([t[1] for t in tests])
    kap=tau.copy(); kap[:K]=g[:K]
    const=np.array([masspair(c,s_)-kpair(c,s_) for c,s_ in tests])
    tail=np.array([np.sum(Fphi(c,s_,kap[K:])) for c,s_ in tests])
    F=lambda y: np.sum(Fphi(cs[:,None],ss[:,None],y[None,:]),axis=1)+tail+const
    Jf=lambda y: dFphi(cs[:,None],ss[:,None],y[None,:])
    return K,F,Jf,T
spacing=lambda t: 2*np.pi/np.log(t/(2*np.pi))
for m in [3,6,9]:
    K,F,Jf,T=setup(m); sp_k=spacing(g[:K])
    disp=np.abs(g[:K]-tau[:K])/sp_k
    line=f"m={m:2d} K={K:3d} T={T:5.0f} |g-tau|/spacing: mean={disp.mean():.2f} max={disp.max():.2f} | "
    for a in [0.1,0.25,0.4,0.6]:
        ok=0; trials=4
        for t in range(trials):
            y0=g[:K]+a*sp_k*rng.uniform(-1,1,K)
            sol=least_squares(F,y0,jac=Jf,method='lm',xtol=1e-14,ftol=1e-14,gtol=1e-14,max_nfev=3000)
            ki=int(np.sum(g[:K]<0.6*T)); ok+= np.max(np.abs(np.sort(sol.x)[:ki]-g[:ki]))<1e-3
        line+=f"a={a}:{ok}/{trials} "
    # from clock directly
    sol=least_squares(F,tau[:K].copy(),jac=Jf,method='lm',xtol=1e-14,ftol=1e-14,gtol=1e-14,max_nfev=3000)
    ki=int(np.sum(g[:K]<0.6*T)); dev=np.abs(np.sort(sol.x)-g[:K]); line+=f"| interior n={ki} | from clock: res={np.max(np.abs(sol.fun)):.1e} interior recovered={int(np.sum(dev[:ki]<1e-3))}/{ki} maxdev_int={dev[:ki].max():.2e}"
    print(line,flush=True)
