# Figures for lemas_B_v4 / v19: (1) certificate scaling, (2) distance to gamma of clock and Gonek lists.
import numpy as np, json, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from core import clock
g=np.load('gamma.npy'); K=400; tau=clock(2000)
def align(r,K):
    best=None
    for off in range(0,6):
        a=r[off:off+K]
        if len(a)<K: continue
        d=np.abs(a-g[:K]).mean()
        if best is None or d<best[0]: best=(d,off,a)
    return best[2]
sp=2*np.pi/np.log(g[:K]/(2*np.pi))
fig,ax=plt.subplots(figsize=(7.2,4.2))
ax.plot(np.arange(1,K+1),np.abs(tau[:K]-g[:K])/sp,'.',ms=3,color='0.3',label='midpoint clock $\\tau_k$')
rF=np.load('gonekF_X8.npy'); a=align(rF,K)
ax.plot(np.arange(1,K+1),np.abs(a-g[:K])/sp,'.',ms=3,color='C3',label='Gonek list, $X=8$')
K2=160; sp2=sp[:K2]
for X,c in [(3,'C0'),(20,'C2')]:
    r=np.load(f'gonek_X{X}.npy'); a=align(r,K2)
    ax.plot(np.arange(1,K2+1),np.abs(a-g[:K2])/sp2,'.',ms=3,color=c,label=f'Gonek list, $X={X}$')
ax.axhline(0.25,ls='--',color='k',lw=0.8); ax.text(5,0.26,'$0.25$ spacings',fontsize=8)
ax.set_xlabel('$k$'); ax.set_ylabel('$|\\kappa_k-\\gamma_k|/\\mathrm{spacing}$'); ax.set_ylim(0,0.75)
ax.legend(fontsize=8,loc='upper right'); ax.set_title('Distance to the zeta ordinates, in local mean spacings $2\\pi/\\log(\\gamma_k/2\\pi)$',fontsize=9)
fig.tight_layout(); fig.savefig('fig_gonek_vs_clock.png',dpi=160)
d=json.load(open('cert7.json'))
T=np.array([x['T'] for x in d]); L=np.array([x['Linf'] for x in d]); QB=np.array([x['QB'] for x in d]); mg=np.array([x['margin'] for x in d])
fig,ax=plt.subplots(figsize=(7.2,4.2))
for y,lab,c in [(L,'$L_m=\\|Q_m\\|_{\\infty\\to\\infty}$','C0'),(QB,'$\\|Q_mB_m\\|_{\\infty\\to\\infty}$','C1'),(1/mg,'1 / (Banach margin)','C3')]:
    p=np.polyfit(np.log(T[3:]),np.log(y[3:]),1); ax.loglog(T,y,'o-',ms=4,color=c,label=lab+f'  (slope {p[0]:.2f})')
e=json.load(open('entry.json')); Te=np.array([x['T'] for x in e]); eb=np.array([x['eta_band'] for x in e]); mb=np.array([x['margin_band'] for x in e])
ax.loglog(Te,1/mb,'s--',ms=4,color='C2',label='1 / (band-only margin)')
ax.loglog(Te,1/eb,'^--',ms=4,color='C4',label='1 / (Gonek entry residual $\\eta$, band)')
ax.set_xlabel('height $T_m$'); ax.legend(fontsize=7.5); ax.set_title('Certificate constants of the square finite sections (floating point)',fontsize=9)
fig.tight_layout(); fig.savefig('fig_cert_scaling.png',dpi=160)
print('ok')
