import numpy as np
from scipy.optimize import brentq
from core import LAM
def theta(t): t=np.asarray(t,float); return t/2*np.log(t/(2*np.pi))-t/2-np.pi/8+1/(48*t)+7/(5760*t**3)
def make_alpha(X):
    n=np.arange(2,int(X*X)+1); L=LAM[n]; w=np.where(n<=X,1.0,2-np.log(n)/np.log(X)); c=L*w/(np.sqrt(n)*np.log(n)); ln=np.log(n)
    return lambda t: -(np.sin(np.multiply.outer(np.atleast_1d(t),ln))@c)
def gonek_list(X,tmax,t0=10.0,h=0.005):
    al=make_alpha(X); ph=lambda t: theta(t)+al(t)
    ts=np.arange(t0,tmax,h); v=(ph(ts)-np.pi/2)/np.pi; j=np.floor(v); idx=np.where(np.diff(j)!=0)[0]; roots=[]
    for i in idx:
        lev=max(j[i],j[i+1]); f=lambda t:(ph(np.array([t]))[0]-np.pi/2)/np.pi-lev
        a,b=ts[i],ts[i+1]
        if f(a)*f(b)<0: roots.append(brentq(f,a,b,xtol=1e-13))
    return np.array(roots)
if __name__=='__main__':
    import sys
    X=float(sys.argv[1]); r=gonek_list(X,float(sys.argv[2])); np.save(f'gonekF_X{int(X)}.npy',r); print(len(r),r[:3],r[-1])
