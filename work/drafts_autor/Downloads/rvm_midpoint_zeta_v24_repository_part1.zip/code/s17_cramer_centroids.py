"""Experiment 17: Cramer's function V_+(z) = sum_{Im rho > 0} exp(rho z) from its zero-free
representation (Proposition prop:cramer-zero-free of the paper), and the limits of the triangular
centroids of the two spectra.

Zero-free representation (a > 0, Re z > 0, z not of the form log n; contour of the rectangle
-a < Re s < 1 + a, Im s > 0, functional equation xi'/xi(s) = -xi'/xi(1-s)):

  2 pi i V_+(z) = V_b(z) + V_R(z) + V_L(z) + V_p(z),
  V_b(z) = int_{-a}^{1+a} exp(s z) xi'/xi(s) ds                       (real segment),
  V_R(z) = i exp((1+a) z) int_0^{inf e^{i theta}} exp(i t z) g(1 + a + i t) dt,
  V_L(z) = i exp(-a z)    int_0^{inf e^{i theta}} exp(i t z) g(1 + a - i t) dt,
  V_p(z) = sum_n Lambda(n) [ exp((1+a)(z - log n)) / (z - log n) + n^(-1-a) exp(-a z) / (z + log n) ],
  g(s)   = 1/s + 1/(s-1) - (1/2) log pi + (1/2) psi(s/2)   (so that xi'/xi = g + zeta'/zeta),

with the rays rotated by an angle 0 < theta < pi/2.  The value must not depend on a; it is computed
for a = 1 and a = 2.  Checks: 2 Re V_+(u) = e^u - 1/(e^{2u} - 1) for log 2 < u < log 3 (explicit
formula), and the comparison with the triangular centroid of the 2 001 052 ordinates.

Clock centroid: C_RVM^path(N;u) -> C_infty(u) (Theorem thm:clock-centroid), with
S_n - b_n E_{n+1} = C_infty(u) + O(log n / n), b_n = 1/(exp(i u (tau_{n+1}-tau_n)) - 1)."""
import os
import numpy as np
import mpmath as mp
from rvm_common import Tee, load_ordinates, write_csv, primes_upto

say = Tee("s17_cramer_centroids")
mp.mp.dps = 30
PMAX = 2_000_000
P = primes_upto(PMAX)


def lambda_table():
    """von Mangoldt pairs (n, Lambda(n)) for prime powers n <= PMAX."""
    out = []
    for p in P:
        q = int(p)
        lp = mp.log(q)
        while q <= PMAX:
            out.append((q, lp))
            q *= int(p)
    out.sort()
    return out


LAM = lambda_table()


def xi_logderiv(s):
    s = mp.mpf(s)
    if abs(s - 1) < mp.mpf("1e-20") or abs(s) < mp.mpf("1e-20"):
        s += mp.mpf("1e-18")
    return 1 / s + 1 / (s - 1) - mp.log(mp.pi) / 2 + mp.digamma(s / 2) / 2 + mp.zeta(s, 1, 1) / mp.zeta(s)


def g_arch(s):
    return 1 / s + 1 / (s - 1) - mp.log(mp.pi) / 2 + mp.digamma(s / 2) / 2


def V_plus(z, a, theta=mp.pi / 3):
    z = mp.mpc(z)
    a = mp.mpf(a)
    # real segment, split at 1/2 and use xi'/xi(s) = -xi'/xi(1-s) on the left half
    Vb = mp.quad(lambda s: (mp.exp(s * z) - mp.exp((1 - s) * z)) * xi_logderiv(s), [mp.mpf(1) / 2, 1, 1 + a])
    ray = mp.exp(1j * theta)
    VR = 1j * mp.exp((1 + a) * z) * mp.quad(lambda r: mp.exp(1j * r * ray * z) * g_arch(1 + a + 1j * r * ray) * ray, [0, 1, 10, mp.inf])
    VL = 1j * mp.exp(-a * z) * mp.quad(lambda r: mp.exp(1j * r * ray * z) * g_arch(1 + a - 1j * r * ray) * ray, [0, 1, 10, mp.inf])
    Vp = mp.mpc(0)
    for n, L in LAM:
        ln = mp.log(n)
        Vp += L * (mp.exp((1 + a) * (z - ln)) / (z - ln) + mp.power(n, -1 - a) * mp.exp(-a * z) / (z + ln))
    return (Vb + VR + VL + Vp) / (2j * mp.pi)


gam, tau = load_ordinates()
N = gam.size
rows = []
for a in (1, 2):
    V1 = V_plus(1, a)
    Z1 = mp.exp(-mp.mpf(1) / 2) * V1
    say("a = %d:  e^{-1/2} V_+(1) = %s %+s i", a, mp.nstr(Z1.real, 16), mp.nstr(Z1.imag, 16))
    rows.append([a, float(Z1.real), float(Z1.imag)])
re_exact = (mp.e - 1 / (mp.e ** 2 - 1)) / (2 * mp.sqrt(mp.e))
say("explicit formula: Re e^{-1/2} V_+(1) = (e - 1/(e^2-1))/(2 sqrt e) = %s", mp.nstr(re_exact, 16))
for u in (0.75, 0.9, 1.05):
    Vu = V_plus(u, 2)
    say("u = %.2f:  2 Re V_+(u) = %s,  e^u - 1/(e^{2u}-1) = %s", u, mp.nstr(2 * Vu.real, 14),
        mp.nstr(mp.e ** u - 1 / (mp.e ** (2 * u) - 1), 14))

# triangular centroids of the ordinates (u = 1)
w = 1 - np.arange(N) / N
Cg = np.sum(w * np.exp(1j * gam))
Ct = np.sum(w * np.exp(1j * tau))
say("triangular centroids with all N = %d ordinates: C_zeta = %.10f %+.10f i,  C_RVM = %.10f %+.10f i",
    N, Cg.real, Cg.imag, Ct.real, Ct.imag)
for K in (10 ** 4, 10 ** 5, 10 ** 6):
    wK = 1 - np.arange(K) / K
    c1 = np.sum(wK * np.exp(1j * gam[:K]))
    c2 = np.sum(wK * np.exp(1j * tau[:K]))
    say("  N = %8d: C_zeta = %.8f %+.8f i,  C_RVM = %.8f %+.8f i", K, c1.real, c1.imag, c2.real, c2.imag)

# clock centroid limit from S_n - b_n E_{n+1}
E = np.exp(1j * tau)
S = np.cumsum(E)
for n in (10 ** 3, 10 ** 4, 10 ** 5, 10 ** 6, N - 1):
    b = 1 / (np.exp(1j * (tau[n] - tau[n - 1])) - 1)
    cinf = S[n - 1] - b * E[n]
    say("  n = %8d: S_n - b_n E_{n+1} = %.10f %+.10f i", n, cinf.real, cinf.imag)
write_csv("s17_cramer_values.csv", ["a", "Re_e^-1/2V+(1)", "Im_e^-1/2V+(1)"], [np.array(r) for r in zip(*rows)])
say.close()
