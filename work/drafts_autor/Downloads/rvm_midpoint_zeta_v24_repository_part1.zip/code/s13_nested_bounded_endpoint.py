"""Nested bounded finite-section experiment for the endpoint rung system.

This program is diagnostic only. It solves finite sections using the midpoint RVM
clock as input. Genuine zeta ordinates, if present, are loaded only after the solve
for diagnostics. The experiment enforces bounded ordinate displacement and bounded
free masses, and keeps every earlier test block active in later sections.
"""

from pathlib import Path
import math
import numpy as np
from scipy.optimize import least_squares

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
DATA = ROOT / "data"
OUT = ROOT / "output"
FIG = ROOT / "figures"
OUT.mkdir(exist_ok=True)
FIG.mkdir(exist_ok=True)

TAU_FILE = DATA / "zLamb.bin"
GAMMA_FILE = DATA / "zeross.bin"

SHIFT_BOUND = 1.2
MASS_BOUND = 0.5
U_MIN = 0.08
OMEGA_STEP = 1.0
MARGIN = 14.0
LEVELS = [(13, 50.0), (20, 70.0), (34, 110.0), (50, 150.0), (70, 210.0), (100, 300.0)]


def load_data():
    tau = np.fromfile(TAU_FILE, dtype="<f8")
    if tau.size == 0:
        raise RuntimeError("zLamb.bin is required in data/")
    gamma = None
    if GAMMA_FILE.exists():
        gamma = np.fromfile(GAMMA_FILE, dtype="<f8")
    return tau, gamma


def choose_grid_size(U, omega):
    """Keep the Nyquist frequency safely above the largest tested frequency."""
    target_nyquist = 2.5 * (omega + MARGIN)
    n = int(math.ceil(target_nyquist * (U - U_MIN) / math.pi)) + 1
    return max(701, n)


def build_block(tau, n_max, omega_max, active_k, mass_nodes):
    U = math.log(n_max + 0.5)
    n_grid = choose_grid_size(U, omega_max)
    grid = np.linspace(U_MIN, U, n_grid)
    u = grid[1:-1]
    du = (U - U_MIN) / (n_grid - 1)

    mid = 0.5 * (U_MIN + U)
    half = 0.5 * (U - U_MIN)
    v = (u - mid) / half
    raw = np.exp(-1.0 / (1.0 - v * v))
    norm = raw.sum() * du
    w = raw / norm

    omega = np.arange(0.0, omega_max + 1e-12, OMEGA_STEP)
    psi = np.vstack([
        np.cos(np.outer(omega, u)) * w[None, :] * du,
        np.sin(np.outer(omega[1:], u)) * w[None, :] * du,
    ])

    smooth = 0.5 * (np.exp(u / 2.0) - np.exp(-u / 2.0) / (np.exp(2.0 * u) - 1.0))
    target = psi @ smooth

    clock = np.zeros_like(u)
    for start in range(0, tau.size, 500):
        clock += np.cos(np.outer(u, tau[start:start + 500])).sum(axis=1)
    low_clock = psi @ np.cos(np.outer(u, tau[:active_k])).sum(axis=1)
    fixed = psi @ clock - low_clock - target

    logs = np.log(mass_nodes.astype(float))
    env = np.zeros_like(logs)
    mask = (logs > U_MIN) & (logs < U)
    if np.any(mask):
        vv = (logs[mask] - mid) / half
        env[mask] = np.exp(-1.0 / (1.0 - vv * vv)) / norm

    mass_matrix = np.vstack([
        np.cos(np.outer(omega, logs)) * env[None, :],
        np.sin(np.outer(omega[1:], logs)) * env[None, :],
    ])

    return {
        "n_max": n_max,
        "omega_max": omega_max,
        "u": u,
        "psi": psi,
        "fixed": fixed,
        "mass_matrix": mass_matrix,
        "n_grid": n_grid,
    }


def solve_nested_level(tau, gamma, level_index, previous=None):
    n_max, omega_max = LEVELS[level_index]
    mass_nodes = np.arange(2, n_max + 1, dtype=int)
    active_k = int(np.sum(tau <= omega_max + MARGIN))

    blocks = []
    for j in range(level_index + 1):
        nb, ob = LEVELS[j]
        blocks.append(build_block(tau, nb, ob, active_k, mass_nodes))

    x0 = np.r_[tau[:active_k], np.zeros(mass_nodes.size)]
    if previous is not None:
        k_copy = min(previous["active_k"], active_k)
        n_copy = min(previous["masses"].size, mass_nodes.size)
        x0[:k_copy] = previous["ordinates"][:k_copy]
        x0[active_k:active_k + n_copy] = previous["masses"][:n_copy]

    lower = np.r_[tau[:active_k] - SHIFT_BOUND, -MASS_BOUND * np.ones(mass_nodes.size)]
    upper = np.r_[tau[:active_k] + SHIFT_BOUND, MASS_BOUND * np.ones(mass_nodes.size)]
    x0 = np.clip(x0, lower + 1e-10, upper - 1e-10)

    def residual(z):
        ordinates = z[:active_k]
        masses = z[active_k:]
        pieces = []
        for block in blocks:
            spectral = block["psi"] @ np.cos(np.outer(block["u"], ordinates)).sum(axis=1)
            r = spectral + block["fixed"] + block["mass_matrix"] @ masses
            pieces.append(r / math.sqrt(r.size))
        return np.concatenate(pieces)

    def jacobian(z):
        ordinates = z[:active_k]
        pieces = []
        for block in blocks:
            jk = block["psi"] @ (-block["u"][:, None] * np.sin(np.outer(block["u"], ordinates)))
            j = np.hstack([jk, block["mass_matrix"]])
            pieces.append(j / math.sqrt(j.shape[0]))
        return np.vstack(pieces)

    sol = least_squares(
        residual,
        x0,
        jac=jacobian,
        method="trf",
        tr_solver="lsmr",
        bounds=(lower, upper),
        max_nfev=500,
        ftol=2e-10,
        xtol=2e-10,
        gtol=2e-10,
        x_scale="jac",
    )

    ordinates = sol.x[:active_k]
    masses = sol.x[active_k:]

    block_rows = []
    for block in blocks:
        spectral = block["psi"] @ np.cos(np.outer(block["u"], ordinates)).sum(axis=1)
        r = spectral + block["fixed"] + block["mass_matrix"] @ masses
        block_rows.append((block["n_max"], float(np.sqrt(np.mean(r * r))), float(np.max(np.abs(r))), block["n_grid"]))

    result = {
        "n_max": n_max,
        "omega_max": omega_max,
        "active_k": active_k,
        "mass_nodes": mass_nodes,
        "ordinates": ordinates,
        "masses": masses,
        "blocks": block_rows,
        "nfev": sol.nfev,
    }

    if gamma is not None and gamma.size >= min(10, active_k):
        q = min(10, active_k)
        result["rms_first10_diagnostic"] = float(np.sqrt(np.mean((ordinates[:q] - gamma[:q]) ** 2)))
    else:
        result["rms_first10_diagnostic"] = float("nan")
    return result


def main():
    tau, gamma = load_data()
    rows = []
    previous = None
    for level_index in range(len(LEVELS)):
        result = solve_nested_level(tau, gamma, level_index, previous)
        previous = result
        print(
            f"N={result['n_max']:3d} K={result['active_k']:3d} "
            f"max_shift={np.max(np.abs(result['ordinates'] - tau[:result['active_k']])):.6f} "
            f"max_mass={np.max(np.abs(result['masses'])):.6f} "
            f"diagnostic_rms10={result['rms_first10_diagnostic']:.3e}"
        )
        for block_n, rms, max_abs, n_grid in result["blocks"]:
            print(f"  block N={block_n:3d}: RMS={rms:.3e}, max={max_abs:.3e}, grid={n_grid}")
            rows.append((result["n_max"], block_n, rms, max_abs, n_grid))

    np.savetxt(
        OUT / "s13_nested_metric_summary.csv",
        np.asarray(rows, dtype=float),
        delimiter=",",
        header="section_N,block_N,rms,max_abs,n_grid",
        comments="",
    )


if __name__ == "__main__":
    main()
