"""Experiment 15: the first 1000 values of the four comparisons of the paper, side by side.

  (a) the midpoint ordinates tau_k against the ordinates gamma_k of zeta, k <= 1000;
  (b) the real RVM primes p_j^RVM (first crossing of the level j by pi_RVM) against the
      primes p_j, j <= 1000;
  (c) pi_RVM(n) against pi(n) at the integers n <= 1000;
  (d) the critical RVM Mertens function M_RVM^crit(n) against M(n), n <= 1000.

Data: data/zeross.bin (gamma_k) and data/zLamb.bin (tau_k), 2 001 052 ordinates each.

Method for (b),(c): J_RVM(x) = li(x) - 2 Re sum_k Ei((1/2 + i tau_k) log x) - log 2
+ int_x^inf dt/(t(t^2-1) log t) on a uniform grid in u = log x on [log 2, log XMAX], with the
first K ordinates and the smooth cut of s04_primes.py (tau_K = 2 pi * 2.5 * XMAX); the Ei of
the first KE = 300 ordinates are exact (scipy exp1) on a coarser grid and interpolated by cubic
splines, the remaining ones use Ei(w) = e^w (1/w + 1/w^2 + 2/w^3 + 6/w^4) with the four
exponential sums evaluated by a type-3 nonuniform FFT (finufft).  pi_RVM is the Moebius
inversion (eq. pi-RVM of the paper).
Method for (d): the integer target of s05_mertens.py (tapered explicit formula with the
residues 1/(rho_k zeta_RVM'(rho_k)), exact for k <= 1000), which is the function tabulated in
Table tab:ternary of the paper; the ternary walk M_h is recomputed on n <= 1000.
"""
import os
import math
import numpy as np
import scipy.io as sio
from scipy import special, integrate
from scipy.interpolate import CubicSpline
import finufft
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from rvm_common import (Tee, load_ordinates, ei_upper, mobius_sieve, primes_upto, write_csv,
                        savefig, clock_inverse, tail_coefficients, logG, Product,
                        zeta_from_product, w_transition, OUT)

say = Tee("s15_tables_1000")
gam, tau = load_ordinates()
Nz = gam.size
NT = 1000
k = np.arange(1, NT + 1)

# ================================================================ (a) clock against zeros
eta = tau[:NT] - gam[:NT]
say("(a) tau_k against gamma_k, k <= %d: max|eta_k| = %.6f at k = %d; mean eta = %.3e; rms = %.6f",
    NT, np.abs(eta).max(), np.argmax(np.abs(eta)) + 1, eta.mean(), np.sqrt(np.mean(eta ** 2)))
say("    gamma_1000 = %.9f, tau_1000 = %.9f; mean spacing at k=1000: %.5f", gam[NT - 1], tau[NT - 1],
    2 * np.pi / np.log(tau[NT - 1] / (2 * np.pi)))
write_csv("s15_clock_1000.csv", ["k", "gamma_k", "tau_k", "eta_k"], [k, gam[:NT], tau[:NT], eta])

# ================================================================ (b),(c) pi_RVM up to XMAX
XMAX = 8200.0
KE = 300
tauK = 2 * np.pi * XMAX * 2.5
K = int(np.searchsorted(tau, tauK))
v = np.arange(K) / K
taper = np.where(v < 0.6, 1.0, np.cos(np.pi / 2 * (v - 0.6) / 0.4) ** 2)
o = tau[:K]
rho = 0.5 + 1j * o
u0, u1 = np.log(2.0), np.log(XMAX)
NF = 1_400_000                       # fine grid: >= 1500 points per period of exp(i tau_K u)
uf = np.linspace(u0, u1, NF)
NC = 140_000                         # coarse grid for the exact Ei of the first KE ordinates
uc = np.linspace(u0, u1, NC)
say("(b),(c) pi_RVM on [2, %g]: K = %d ordinates (tau_K = %.1f), smooth cut; %d fine / %d coarse points",
    XMAX, K, o[-1], NF, NC)

# exact part on the coarse grid, cubic interpolation to the fine grid
Sc = np.zeros(NC, dtype=complex)
for i in range(KE):
    Sc += taper[i] * ei_upper(rho[i] * uc)
S = CubicSpline(uc, Sc.real)(uf) + 1j * CubicSpline(uc, Sc.imag)(uf)
# asymptotic part: A_m(u) = sum_{k>KE} w_k exp(i o_k u) / rho_k^m by a type-3 NUFFT
A = []
for m in (1, 2, 3, 4):
    c = (taper[KE:] / rho[KE:] ** m).astype(np.complex128)
    A.append(finufft.nufft1d3(o[KE:].astype(np.float64), c, uf, eps=1e-13, isign=1))
S += np.exp(uf / 2) * (A[0] / uf + A[1] / uf ** 2 + 2 * A[2] / uf ** 3 + 6 * A[3] / uf ** 4)
# tail integral on a coarse grid, interpolated
ut = np.linspace(u0, u1, 3000)
tfun = lambda t: 1.0 / (t * (t * t - 1.0) * np.log(t))
# the tail beyond 10^7 is below 1/(2 t^2 log t) at t = 10^7, i.e. < 4e-16, and is dropped
ti = np.array([integrate.quad(tfun, np.exp(w), 100 * np.exp(w), limit=200)[0]
               + integrate.quad(tfun, 100 * np.exp(w), 1.0e7, limit=200)[0] for w in ut])
J = special.expi(uf) - 2 * S.real - np.log(2.0) + CubicSpline(ut, ti)(uf)
mu64 = mobius_sieve(64)
PR = np.zeros(NF)
m = 1
while u1 / m >= u0:
    if mu64[m] != 0:
        PR += mu64[m] / m * np.where(uf / m >= u0 - 1e-12, np.interp(uf / m, uf, J), 0.0)
    m += 1
xf = np.exp(uf)
P = primes_upto(int(XMAX) + 1)
# (c) integers n <= 1000
n = np.arange(1, NT + 1)
pin = np.zeros(NT)
pin[1:] = np.interp(np.log(n[1:].astype(float)), uf, PR)
pi_exact = np.searchsorted(P, n, side="right").astype(float)
li = np.zeros(NT)
li[1:] = special.expi(np.log(n[1:].astype(float)))
say("    pi_RVM(100) = %.4f, pi(100) = %d;  pi_RVM(1000) = %.4f, pi(1000) = %d;  pi_RVM(%g) = %.4f, pi = %d",
    pin[99], int(pi_exact[99]), pin[-1], int(pi_exact[-1]), XMAX, PR[-1], np.searchsorted(P, XMAX, side="right"))
d = pin - pi_exact
say("    pi_RVM(n) - pi(n), n <= 1000: max %.4f at n = %d, min %.4f at n = %d, mean %.4f, rms %.4f",
    d.max(), n[np.argmax(d)], d.min(), n[np.argmin(d)], d.mean(), np.sqrt(np.mean(d ** 2)))
say("    pi_RVM(n) - li(n), n <= 1000: mean %.4f;  pi(n) - li(n): mean %.4f", (pin - li)[1:].mean(), (pi_exact - li)[1:].mean())
write_csv("s15_pi_1000.csv", ["n", "pi_n", "pi_RVM_n", "pi_RVM_minus_pi", "li_n"], [n, pi_exact, pin, d, li])
# (b) real RVM primes: first crossing of the level j
levels = np.arange(1, NT + 1)
pj = np.zeros(NT)
for j in levels:
    i = int(np.argmax(PR >= j))
    if i == 0:
        raise RuntimeError("level %d not reached below XMAX" % j)
    # linear interpolation of the crossing between the grid points i-1 and i
    x0, x1v = xf[i - 1], xf[i]
    f0, f1 = PR[i - 1], PR[i]
    pj[j - 1] = x0 + (j - f0) / (f1 - f0) * (x1v - x0)
dp = pj - P[:NT]
say("    real RVM primes p_j^RVM, j <= 1000: p_1000^RVM = %.4f, p_1000 = %d; max(p_j^RVM - p_j) = %.4f at j = %d, "
    "min = %.4f at j = %d, mean %.4f, rms %.4f", pj[-1], P[NT - 1], dp.max(), np.argmax(dp) + 1, dp.min(),
    np.argmin(dp) + 1, dp.mean(), np.sqrt(np.mean(dp ** 2)))
say("    |p_j^RVM - p_j| / p_j^(1/2): max %.4f;  |p_j^RVM - p_j| / log p_j: max %.4f",
    np.max(np.abs(dp) / np.sqrt(P[:NT])), np.max(np.abs(dp) / np.log(P[:NT])))
say("    first 12 levels: " + ", ".join("%.4f" % x for x in pj[:12]))
write_csv("s15_rvm_primes_1000.csv", ["j", "p_j", "p_j_RVM", "p_j_RVM_minus_p_j"], [levels, P[:NT], pj, dp])

# ================================================================ (d) M_RVM^crit(n) against M(n)
K0 = 1000
c1, c2, c3 = tail_coefficients(clock_inverse(float(Nz)))
t2 = tau ** 2
zpR = np.zeros(K0, dtype=complex)
for kk in range(K0):
    tk = tau[kk]
    fac = (t2 - tk ** 2) / (t2 + 0.25)
    fac[kk] = 1.0
    q = -0.25 - tk ** 2
    lmod = np.sum(np.log(np.abs(fac))) + c1 * q - c2 * q ** 2 + c3 * q ** 3
    rr = 0.5 + 1j * tk
    lP = np.log(2j * tk / (0.25 + tk ** 2)) + lmod
    zpR[kk] = (-1) ** kk * np.exp(lP - logG(rr))
ratio = zpR / np.log(tau[:K0] / (2 * np.pi))
PRD = Product(tau)
Ts = 1.0e4 * np.array([0.25, 0.5, 1.0])
vv = np.array([zeta_from_product(PRD, 2 + 1j * T)[0] / (1 + w_transition(2 + 1j * T)) for T in Ts])
varpi = np.linalg.solve(np.column_stack([np.ones(3), 1 / Ts, 1 / Ts ** 2]).astype(complex), vv)[0].real
sel = np.arange(K0 // 2, K0)
cfit = np.mean((ratio[sel] / varpi - 1) * tau[sel])
zR = varpi * np.log(tau / (2 * np.pi)) * (1 + cfit / tau)
zR[:K0] = zpR
bR = 1.0 / ((0.5 + 1j * tau) * zR)
say("(d) residues: varpi_RVM = %.10f, c = %.4f %+.4f i (as in s05_mertens)", varpi, cfit.real, cfit.imag)


def trivial_rvm(x, nn=6):
    val = np.zeros_like(x)
    for j in range(1, nn + 1):
        s = -2.0 * j
        lP = np.real(PRD.logP(s)[0])
        val -= x ** (-2 * j) * (2 * j + 1) * np.pi ** j * 2 * (-1) ** j / (math.factorial(j) * np.exp(lP))
    return val


def tapered(x, ords, a, C1=2.0, C2=4.0):
    Sx = np.zeros(x.size, dtype=complex)
    lx = np.log(x)
    Kx = max(1, int(np.searchsorted(ords, C2 * 2 * np.pi * np.sqrt(x[-1]))))
    uu = ords[None, :Kx] / (2 * np.pi * np.sqrt(x[:, None]))
    wt = np.where(uu <= C1, 1.0, np.where(uu >= C2, 0.0, np.cos(np.pi / 2 * (uu - C1) / (C2 - C1)) ** 2))
    E = np.exp(1j * lx[:, None] * ords[None, :Kx])
    Sx = np.sqrt(x) * np.sum(E * wt * a[None, :Kx], axis=1)
    return Sx


xn = n.astype(float)
MR = -2 + 2 * np.real(tapered(xn, tau, bR)) + trivial_rvm(xn)
MR_all = -2 + 2 * np.real(np.sqrt(xn) * np.array([np.sum(np.exp(1j * np.log(x) * tau) * bR) for x in xn])) + trivial_rvm(xn)
mu = mobius_sieve(NT)
M = np.cumsum(mu.astype(np.int64))[1:]
Mh = np.zeros(NT)
cur = 0.0
muh = np.zeros(NT, dtype=int)
for i in range(NT):
    if mu[i + 1] != 0:
        sg = 1 if cur < MR[i] else -1
        cur += sg
        muh[i] = sg
    Mh[i] = cur
dM = MR - M
say("    M_RVM^crit(n) (tapered target, Table tab:ternary) against the ordered sum over all %d ordinates: max |diff| = %.4f", Nz, np.max(np.abs(MR - MR_all)))
say("    M(1000) = %d, M_RVM^crit(1000) = %.4f, M_h(1000) = %d", M[-1], MR[-1], int(Mh[-1]))
say("    M_RVM^crit(n) - M(n), n <= 1000: max %.4f at n = %d, min %.4f at n = %d, mean %.4f, rms %.4f",
    dM.max(), n[np.argmax(dM)], dM.min(), n[np.argmin(dM)], dM.mean(), np.sqrt(np.mean(dM ** 2)))
say("    max |M(n)|/sqrt n = %.4f, max |M_RVM^crit(n)|/sqrt n = %.4f on [10,1000]; sign agreement mu_h = mu on squarefrees: %.4f",
    np.max(np.abs(M[9:]) / np.sqrt(xn[9:])), np.max(np.abs(MR[9:]) / np.sqrt(xn[9:])),
    np.mean(muh[mu[1:] != 0] == mu[1:][mu[1:] != 0]))
write_csv("s15_mertens_1000.csv", ["n", "mu_n", "M_n", "M_RVM_crit_n", "M_RVM_minus_M", "M_h_n", "M_RVM_allzeros_n"],
          [n, mu[1:], M, MR, dM, Mh, MR_all])

# ================================================================ LaTeX table bodies
def tex_rows(cols, fmts, groups, fname):
    """cols: list of arrays (same length L); write L/groups rows with `groups` column groups."""
    L = cols[0].size
    R = int(math.ceil(L / groups))
    lines = []
    for r in range(R):
        cells = []
        for g in range(groups):
            i = r + g * R
            if i < L:
                cells.append(" & ".join(f % c[i] for f, c in zip(fmts, cols)))
            else:
                cells.append(" & ".join("" for _ in cols))
        lines.append(" & ".join(cells) + r" \\")
    with open(os.path.join(OUT, fname), "w") as f:
        f.write("\n".join(lines) + "\n")


tex_rows([k, gam[:NT], tau[:NT], eta], ["%d", "%.6f", "%.6f", "$%+.4f$"], 2, "s15_table_clock_1000.tex")
tex_rows([levels, P[:NT], pj, dp], ["%d", "%d", "%.4f", "$%+.4f$"], 3, "s15_table_primes_1000.tex")
tex_rows([n, pi_exact, pin, d], ["%d", "%d", "%.4f", "$%+.4f$"], 3, "s15_table_pi_1000.tex")
tex_rows([n, mu[1:], M, MR, dM], ["%d", "$%d$", "$%d$", "$%.4f$", "$%+.4f$"], 3, "s15_table_mertens_1000.tex")

# ================================================================ figures (linear axes, PNG)
fig, ax = plt.subplots(2, 2, figsize=(12, 7.5))
ax[0, 0].plot(k, gam[:NT], "k-", lw=0.8, label=r"$\gamma_k$")
ax[0, 0].plot(k, tau[:NT], "r--", lw=0.8, label=r"$\tau_k$")
ax[0, 0].set_xlabel("k"); ax[0, 0].set_title(r"Ordinates $\gamma_k$ and midpoint ordinates $\tau_k$, $k\leq1000$")
ax[0, 0].legend(fontsize=8)
ax[0, 1].plot(k, eta, "b.", ms=2.5)
ax[0, 1].axhline(0, color="k", lw=0.6)
ax[0, 1].set_xlabel("k"); ax[0, 1].set_title(r"$\eta_k=\tau_k-\gamma_k$")
kk = np.arange(1, 61)
ax[1, 0].vlines(gam[:60], 0, 1, color="k", lw=0.8, label=r"$\gamma_k$")
ax[1, 0].vlines(tau[:60], 0, -1, color="r", lw=0.8, label=r"$\tau_k$")
ax[1, 0].set_ylim(-1.3, 1.3); ax[1, 0].set_yticks([])
ax[1, 0].set_xlabel("t"); ax[1, 0].set_title(r"The two spectra for $k\leq60$: $\gamma_k$ up, $\tau_k$ down")
ax[1, 0].legend(fontsize=8, loc="upper right")
ax[1, 1].hist(eta, bins=40, color="0.7", edgecolor="k")
ax[1, 1].set_xlabel(r"$\eta_k$"); ax[1, 1].set_title(r"Distribution of $\eta_k$, $k\leq1000$")
fig.tight_layout()
savefig(fig, "fig20_clock_1000.png")

fig, ax = plt.subplots(1, 2, figsize=(12, 4.2))
ax[0].plot(levels, P[:NT], "k-", lw=1.0, label=r"$p_j$")
ax[0].plot(levels, pj, "r--", lw=1.0, label=r"$p_j^{\rm RVM}$")
ax[0].set_xlabel("j"); ax[0].set_title(r"Primes and real RVM primes, $j\leq1000$"); ax[0].legend(fontsize=8)
ax[1].plot(levels, dp, "b.", ms=2.5)
ax[1].axhline(0, color="k", lw=0.6)
ax[1].set_xlabel("j"); ax[1].set_title(r"$p_j^{\rm RVM}-p_j$")
fig.tight_layout()
savefig(fig, "fig21_rvm_primes_1000.png")

fig, ax = plt.subplots(1, 2, figsize=(12, 4.2))
ax[0].step(n, pi_exact, where="post", color="k", lw=1.0, label=r"$\pi(n)$")
ax[0].plot(n, pin, "r-", lw=0.9, label=r"$\pi_{\rm RVM}(n)$")
ax[0].plot(n[1:], li[1:] - special.expi(np.log(2.0)), "g--", lw=0.8, label=r"$\mathrm{li}(n)-\mathrm{li}(2)$")
ax[0].set_xlabel("n"); ax[0].set_title(r"$\pi(n)$ and $\pi_{\rm RVM}(n)$, $n\leq1000$"); ax[0].legend(fontsize=8)
ax[1].plot(n, d, "b-", lw=0.7)
ax[1].axhline(0, color="k", lw=0.6)
ax[1].set_xlabel("n"); ax[1].set_title(r"$\pi_{\rm RVM}(n)-\pi(n)$")
fig.tight_layout()
savefig(fig, "fig22_pi_1000.png")

fig, ax = plt.subplots(1, 2, figsize=(12, 4.2))
ax[0].step(n, M, where="post", color="k", lw=1.0, label=r"$M(n)$")
ax[0].plot(n, MR, "r-", lw=0.9, label=r"$M_{\rm RVM}^{\rm crit}(n)$")
ax[0].plot(n, np.sqrt(xn), "k--", lw=0.6, label=r"$\pm\sqrt{n}$")
ax[0].plot(n, -np.sqrt(xn), "k--", lw=0.6)
ax[0].set_xlabel("n"); ax[0].set_title(r"$M(n)$ and $M_{\rm RVM}^{\rm crit}(n)$, $n\leq1000$"); ax[0].legend(fontsize=8)
ax[1].plot(n, dM, "b-", lw=0.7)
ax[1].axhline(0, color="k", lw=0.6)
ax[1].set_xlabel("n"); ax[1].set_title(r"$M_{\rm RVM}^{\rm crit}(n)-M(n)$")
fig.tight_layout()
savefig(fig, "fig23_mertens_1000.png")

sio.savemat(os.path.join(OUT, "s15_results.mat"), {"k": k, "gamma": gam[:NT], "tau": tau[:NT], "eta": eta,
                                                   "p_j": P[:NT], "p_j_RVM": pj, "pi_n": pi_exact, "pi_RVM_n": pin,
                                                   "M_n": M, "M_RVM_crit_n": MR, "M_h_n": Mh, "varpi": varpi,
                                                   "cfit": cfit, "K": K, "XMAX": XMAX})
say.close()
