# Encargo para Codex: continuar la cota cúbica por la ruta \(M_{\mathrm{RVM}}\)

**Proyecto de Víctor Casaña-Giner — 3 de octubre de 2026**

## 0. Orden de trabajo

Continúa el intento de demostrar, de forma **incondicional**, la cota cúbica de contracciones de las ordenadas genuinas transportadas desde el reloj de Riemann–von Mangoldt. Debes utilizar exhaustivamente:

1. todas las ecuaciones y resultados sobre \(M_{\mathrm{RVM}}\) contenidos en **excursion_area_section_v56.tex**;
2. todos los resultados potencialmente utilizables sobre \(M\), Möbius, centroides, transporte RVM, energía, correlaciones y medidas atómicas del directorio local **Documents/PACK PDF**;
3. en particular, los artículos de centroide y el manuscrito que conecta centroides con Montgomery.

No te limites a citar o resumir. Para cada teorema candidato, escribe sus hipótesis exactas, tradúcelo a las variables del objetivo cúbico y comprueba algebraicamente si produce la potencia \(v^3\), una potencia menor, una norma inadecuada o una hipótesis equivalente a RH.

No uses como premisa:

- RH;
- simplicidad de los ceros;
- GUE o la correlación de pares de Montgomery como conjetura;
- positividad previa de los gaps genuinos;
- un mínimo de gap obtenido de una tabla finita;
- la identificación \(\zeta_{\mathrm{line}}=\zeta\), pues equivale a RH;
- una cota puntual \(M(x)=O_\varepsilon(x^{1/2+\varepsilon})\), pues es un criterio equivalente a RH;
- una inversión de Mellin, intercambio de límite, transferencia de multiplicadores o eliminación de regularización que no esté demostrada en el espacio funcional concreto utilizado.

No desvíes el trabajo hacia criterios clásicos de RH. La tarea es averiguar si **las herramientas propias del corpus RVM/Möbius/centroide** demuestran la cota cúbica. Si no la demuestran, aísla el teorema nuevo mínimo que falta.

No crees ni modifiques v57. Prepara material para incorporarlo a v57 cuando Víctor lo ordene.

---

## 1. Objetivo matemático exacto

Sean

\[
t_k=\gamma_k^{\mathrm{RvM}},\qquad
\delta_k=\gamma_k-t_k,
\]

donde las \(\gamma_k\) son las ordenadas de **todos** los ceros no triviales genuinos del semiplano superior, contadas con multiplicidad y ordenadas de forma no decreciente. No se presupone que sus partes reales sean \(1/2\).

Para \(j<k\le N\), define

\[
a_{jk}=t_k-t_j>0,\qquad
g_{jk}=\gamma_k-\gamma_j\ge0,\qquad
q_{jk}=\frac{g_{jk}}{a_{jk}}.
\]

El objetivo es demostrar, sin asumir que \(g_{jk}>0\),

\[
F_N(v):=\#\{j<k\le N:q_{jk}\le v\}
\le C_Nv^3,\qquad 0<v\le\frac12,
\tag{OBJ}
\]

con una constante finita \(C_N\) obtenida de estimaciones demostradas e independiente de \(v\). No vale definir \(C_N\) mediante el mínimo gap genuino: eso introduciría precisamente la simplicidad que se intenta probar.

Para cada \(N\) fijo, cualquier cota \(F_N(v)=O_N(v^\alpha)\), \(\alpha>0\), excluye colisiones de ordenada en ese bloque. Aplicada a todos los bloques y combinada con la simetría funcional, la ausencia de ordenadas repetidas obliga a RH y simplicidad. No confundas «RH» con «RH + simplicidad»: RH por sí sola no implica que los ceros sean simples.

---

## 2. Insumos incondicionales ya disponibles en v56

Para el bloque inicial de \(N\) índices se dispone de

\[
|\delta_k|\le D,\qquad
A_N:=\sum_{k\le N}\delta_k^2
\ll \frac{N\log\log N}{(\log N)^2},\qquad
d_N:=\min_{i<N}(t_{i+1}-t_i)\gg\frac1{\log N}.
\]

Para \(n_0=\lfloor\sqrt N\rfloor\), también existe

\[
t_{i+1}-t_i\le \ell_N\ll\frac1{\log N}
\qquad (i\ge n_0).
\]

Debes comprobar las referencias exactas de v56, especialmente QT.1–QT.14 y TE.7–TE.17, sin extender sus rangos de exponentes.

La energía finita del camino es

\[
E_N(\kappa)=-\sum_{j<k}\log\bigl(x_k(\kappa)-x_j(\kappa)\bigr),
\qquad
x_k(\kappa)=t_k+\kappa\delta_k,
\]

y

\[
E_N^{(4)}(\kappa)
=6\sum_{j<k}\frac{(q_{jk}-1)^4}
{(1+\kappa(q_{jk}-1))^4}.
\]

Ya está demostrado, usando el transporte cuadrático y el telescopado cúbico de v56,

\[
E_N^{(4)}(0)\ll N\log N\log\log N.
\tag{D1}
\]

Pero el transporte absoluto inmediato solo da

\[
E_N^{(4)}(\kappa)
\le \frac{E_N^{(4)}(0)}{(1-\kappa)^4},
\]

mientras que para cerrar (OBJ) basta y esencialmente se necesita

\[
E_N^{(4)}(\kappa)\ll_N\frac1{1-\kappa}.
\tag{T-E4}
\]

Faltan tres potencias de \(1-\kappa\). No ocultes esta pérdida.

---

## 3. Reducciones ya probadas que deben conservarse

### 3.1. Reducción a gaps consecutivos

Si \(q_{jk}\le v\le1/2\), entonces \(a_{jk}\le4D\), por lo que el par está localizado en un retardo \(k-j\le H_N=O(\log N)\). Al escribir

\[
q_{jk}=\sum_{i=j}^{k-1}\frac{d_i}{a_{jk}}q_i,\qquad
d_i=t_{i+1}-t_i,\qquad
q_i=\frac{\gamma_{i+1}-\gamma_i}{d_i},
\]

se obtiene

\[
F_N(v)
\le 2H_N\frac{d_{\max}}{d_N}
\#\{i<N:q_i\le2v\}.
\tag{R1}
\]

Por tanto basta demostrar la ley cúbica para gaps consecutivos.

### 3.2. Momentos de contracción

Sea \(z_i=(1-q_i)_+\),

\[
M_p=\sum_{i<N}z_i^p,\qquad
D_p=\sum_{q_i<1}q_i(1-q_i)^p.
\]

Hay una recurrencia exacta

\[
M_{p+1}=M_p-D_p.
\tag{R2}
\]

La cota cúbica adyacente es equivalente, salvo constantes de bloque, a

\[
M_p=O_N(p^{-3}).
\tag{R3}
\]

Una condición suficiente sería

\[
D_p\ge
\left(\frac3{p+4}-\varepsilon_{N,p}\right)M_p,
\qquad
\sum_p\varepsilon_{N,p}<\infty.
\tag{T-M}
\]

No está demostrada. Busca si alguna contracción de las capas aritméticas, alguna identidad Fejér de excursiones o algún resultado de energía del PACK produce exactamente (T-M), no solo una analogía verbal.

### 3.3. Detector espectral de cuarto orden

Con \(w=(1-|\cdot|)_+*(1-|\cdot|)_+\), cuya transformada es \(\operatorname{sinc}^4\), define

\[
P^{[4]}_{N,U}(\kappa)
=N+2\sum_{j<k}
\operatorname{sinc}^4\!\left(
\frac{U(x_k(\kappa)-x_j(\kappa))}{2}
\right).
\]

Está probado que (OBJ) equivale, con constantes de bloque, a

\[
P^{[4]}_{N,U}(1)-N\ll_N U^{-3}.
\tag{T-P4}
\]

También está probado incondicionalmente, sin suponer gaps genuinos positivos,

\[
P^{[4]}_{N,U}(1-U^{-1/4})-N
\le 32N\zeta(4)d_N^{-4}U^{-3}.
\tag{D2}
\]

Falta únicamente controlar el último tramo \(1-U^{-1/4}\le\kappa\le1\). Exactamente,

\[
T^{[4]}_{N,U}(U^{-1/4})
:=P^{[4]}_{N,U}(1)
-P^{[4]}_{N,U}(1-U^{-1/4})
\ll_N U^{-3}
\tag{T-T4}
\]

sería suficiente. La cota absoluta por Cauchy–Schwarz disponible crece como \(U^{3/4}\) y no sirve; hay que obtener cancelación firmada.

El detector Fejér de segundo orden \(\operatorname{sinc}^2\) no puede satisfacer uniformemente \(O(U^{-3})\): su cola solo es cuadrática. No vuelvas a intentar obtener el cubo del núcleo de segundo orden sin una cancelación adicional explícita.

---

## 4. Ruta directa mediante \(M_{\mathrm{RVM}}\)

Esta es la ruta prioritaria.

### 4.1. Tres objetos que no deben confundirse

1. **Objeto crítico puro**

   \[
   \widehat M_{\mathrm{RVM}}^{\mathrm{crit}}(s)
   =\frac1{\zeta_{\mathrm{RVM}}(s)}.
   \]

   Sus polos están en \(1/2\pm i\gamma_k^{\mathrm{RvM}}\) por construcción. No contiene los gaps genuinos.

2. **Camino de ordenadas proyectadas**

   \[
   \widehat M_{N,\kappa}^{\mathrm{path}}(s)
   =\frac{G(s)}{P_{N,\kappa}^{\mathrm{path}}(s)}.
   \]

   Sus polos están en \(1/2\pm ix_k(\kappa)\). En \(\kappa=1\) contiene las ordenadas genuinas proyectadas sobre la recta, pero solo se identifica con el objeto clásico de zeta si se prueba RH. La extracción local de sus polos sí puede usarse sin esa identificación.

3. **Objeto transportado true-\(\beta\)**

   \[
   \widehat M_{\mathrm{RVM}}^{\mathrm{ord}}(s)
   =\frac{G(s)}{P_{\mathrm{RVM}}^{\mathrm{ord}}(s)}
   =\frac{\mathscr T_{\mathrm{RVM}}^{\mathrm{ord}}(s)}{\zeta(s)}.
   \]

   Sus polos están en \(\beta_k\pm i\gamma_k^{\mathrm{RvM}}\), con multiplicidad. Este objeto transporta las partes reales verdaderas y por ello codifica \(\Theta=\sup\beta_k\); varias de sus cotas de crecimiento tienen fuerza equivalente a RH. No usarlas circularmente para demostrar la ley de gaps.

### 4.2. Identidad de núcleos de polos

Para el factor elemental

\[
m_{k,\kappa}(s)
=\left[1+\frac{s(s-1)}{1/4+x_k(\kappa)^2}\right]^{-1},
\]

en \(s=1/2+y+it\), \(y>0\), se extrae el núcleo de Cauchy normalizado

\[
\phi_{k,\kappa,y}(t)
=\sqrt{\frac y\pi}\,
\frac1{y+i(t-x_k(\kappa))}.
\]

La identidad exacta es

\[
|\langle\phi_{j,\kappa,y},
\phi_{k,\kappa,y}\rangle|^2
=\frac{4y^2}{(x_k(\kappa)-x_j(\kappa))^2+4y^2}.
\]

Define la coherencia cuarta

\[
\mathcal C^{M,4}_{N,\kappa}(y)
=\sum_{j<k}
\frac{16y^4}
{((x_k(\kappa)-x_j(\kappa))^2+4y^2)^2}.
\tag{C-M4}
\]

Equivalentemente,

\[
\mathcal C^{M,4}_{N,\kappa}(y)
=\frac12
\|\Gamma_{\kappa,y}\circ\overline{\Gamma_{\kappa,y}}-I\|_{HS}^2,
\]

donde \(\Gamma\) es la matriz de Gram de los núcleos de polo.

En el extremo RVM,

\[
\mathcal C^{M,4}_{N,0}(y)
\le16N\zeta(4)d_N^{-4}y^4.
\tag{D3}
\]

Si \(q_{jk}\le v\le1/2\), entonces \(g_{jk}\le4Dv\). Tomando \(y=4Dv\), cada par contado aporta al menos \(16/25\), de modo que

\[
F_N(v)
\le\frac{25}{16}
\mathcal C^{M,4}_{N,1}(4Dv).
\tag{R4}
\]

Por tanto el siguiente teorema cerraría la cota cúbica:

> **Teorema de transporte de coherencia \(M_{\mathrm{RVM}}\) pendiente.** Para cada bloque \(N\), existe \(L_N^M<\infty\), obtenido sin asumir separación de los gaps genuinos, tal que
> \[
> \mathcal C^{M,4}_{N,1}(y)
> \le
> \mathcal C^{M,4}_{N,0}(y)+L_N^My^3,
> \qquad 0<y\le y_0.
> \tag{T-CM4}
> \]

Entonces

\[
F_N(v)
\le
\left(
3200N\zeta(4)D^4d_N^{-4}
+100L_N^MD^3
\right)v^3.
\]

La derivada exacta que debe controlarse es

\[
\partial_\kappa\mathcal C^{M,4}_{N,\kappa}(y)
=-64y^4\sum_{j<k}
\frac{(x_k-x_j)(\delta_k-\delta_j)}
{((x_k-x_j)^2+4y^2)^3}.
\tag{D-CM4}
\]

Hace falta una estimación **firmada e integrada en \(\kappa\)** de orden \(y^3\). Aplicar valores absolutos y solamente \(\sum\delta_k^2\) no la da.

### 4.3. Traducción funcional que Codex debe intentar

Intenta expresar (C-M4) y (D-CM4) mediante una de estas estructuras del corpus:

- una norma Schatten-4 del operador de evaluación/reproducción asociado a \(\widehat M_{N,\kappa}^{\mathrm{path}}\);
- una forma sesquilineal o una matriz de Gram ya calculada en los artículos de centroides;
- una energía conectada o un form factor residual del manuscrito de Montgomery;
- una medida atómica positiva o una derivada de la familia holomorfa del centroide;
- una identidad de excursión/Fejér de \(M\), siempre que se demuestre el puente exacto desde el índice Möbius hasta los gaps \(x_k(\kappa)-x_j(\kappa)\);
- un teorema de multiplicadores Mellin que actúe directamente sobre esta norma de coherencia, no solo sobre \(L^2\) escalar.

El resultado \(L^2\) de v56 bajo

\[
0<c_\sigma\le
|\mathscr T_{\mathrm{RVM}}^{\mathrm{ord}}(\sigma+it)|
\le C_\sigma
\]

solo compara energías Mellin cuadráticas. No controla automáticamente una norma de Gram de cuarto orden ni implica (T-CM4). Si quieres utilizarlo, debes demostrar un teorema vectorial/Schatten explícito y comprobar que sus constantes producen exactamente \(y^3\).

---

## 5. Auditoría obligatoria de v56

Revisa completas, no mediante búsquedas aisladas, estas partes de **excursion_area_section_v56.tex**:

1. **Sistema aritmético RVM y \(M_{\mathrm{RVM}}^{\mathrm{crit}}\)**, aproximadamente líneas 9125–9905:
   - reloj midpoint y desplazamiento acotado;
   - \(\zeta_{\mathrm{RVM}}\), divisor crítico y primos RVM;
   - caracterización espectral y cota gaussiana de \(M_{\mathrm{RVM}}^{\mathrm{crit}}\);
   - normalización exacta de Hadamard;
   - cociente \(\mathscr Q_{\mathrm{RVM}}=\zeta/\zeta_{\mathrm{RVM}}\);
   - identidad \(\widehat M_{\mathrm{RVM}}^{\mathrm{crit}}=\mathscr Q_{\mathrm{RVM}}\widehat M\);
   - transformada de \(M-M_{\mathrm{RVM}}^{\mathrm{crit}}\).

2. **Camino crítico de ordenadas**, aproximadamente líneas 9954–11565:
   - producto \(P_{\mathrm{RVM},\kappa}^{\mathrm{path}}\);
   - suavizado del derivado en \(\kappa\);
   - transporte distribucional y convergencia del extremo RVM;
   - fórmula exacta del defecto off-line;
   - identidad entre extremos y fórmula independiente de la ruta;
   - transporte cuadrático QT.1–QT.6;
   - interpolación logarítmica QT.7–QT.14;
   - estimaciones TE de energía/contracción.

3. **Transporte true-\(\beta\)**, aproximadamente líneas 11566–12691:
   - producto rígido y multiplicador \(\mathscr T_{\mathrm{RVM}}^{\mathrm{ord}}\);
   - divisor exacto y abscisa de polos \(\Theta\);
   - defecto positivo de reflexión;
   - energía horizontal y representación de Riesz;
   - criterios de RH y Lindelöf;
   - acumulación resonante de Poisson;
   - comparación vertical con la referencia crítica;
   - identidad umbilical exacta con \(M\);
   - obstrucción por polos;
   - criterio gaussiano;
   - hipótesis de transferencia Mellin bidireccional;
   - versión \(L^2\) de Plancherel;
   - modelo que preserva residuos.

Para cada resultado, clasifícalo así:

| Resultado | Hipótesis | Observable controlado | Escala en \(y,v,U\) | ¿Aporta a T-CM4/T-T4/T-M? | Pérdida exacta |
|---|---|---|---|---|---|

---

## 6. Artículos del PACK que deben revisarse

Los nombres corresponden a la copia disponible del PACK. En el disco local pueden estar bajo **Documents/PACK PDF**. Usa primero la versión indicada y trata los archivos de **source_archive** como duplicados salvo que el hash o el contenido muestren diferencias.

### Prioridad A: conexión directa \(M\)–RVM–gaps

1. **Mu F/ANALYTIC_MOBIUS_PRIME_SPECTRAL_MANUSCRIPT_VERSION_89-copia.tex**

   Extrae y prueba contra T-CM4, T-T4 y T-M:

   - desplazamiento exacto del paseo de fases y suma cuadrática;
   - interpolación finita de Möbius y ecuación de completitud;
   - defecto atómico positivo por ordenada;
   - formas de Gram proyectadas y descomposición exacta de varianza;
   - energía de Bohr de capas logarítmicas;
   - fórmula explícita regularizada y cola gaussiana uniforme;
   - las siete rutas condicionales, especialmente convergencia distribucional local, curvatura, agotamiento local de energía y tests positivos.

   Las siete rutas son implicaciones condicionales. No importes como teorema las hipótesis abiertas de reconstrucción local, completitud de modos o eliminación de regularización.

2. **Finite Heigh Criteria/FINITE_HEIGHT_EXPONENTIAL_CRITERIA_v9.tex**

   Revisar defecto local positivo, diferencia de medidas atómicas, expansión exponencial finita, curvatura positiva, contracción triádica con pares frescos, canal a profundidad finita, varianza sesquilineal, cierre de resonancias transferidas y escala diagonal única. Pregunta concreta: ¿alguna identidad produce una estimación atom-sensitive uniforme equivalente a \(y^3\) para la coherencia de polos?

3. **Xi Mertens Notebook/mertens_xi_vector_notebook.tex**

   Auditar la familia directa, la simetrización por \(\xi\), el operador Mellin inducido por la ecuación funcional y la ruta condicional. Ver si el operador controla una familia vectorial de núcleos de Cauchy o solo una norma escalar.

4. **A distant phase/distant_square_root_audit_reviewed.tex**

   Utilizar el lema de transferencia estable, el coste \(\ell^1\) de reconstrucción, las obstrucciones de evaluación puntual y la descomposición exacta de energía de ventanas. Debe servir para descartar transferencias falsas y, si es posible, diseñar la norma correcta para T-CM4.

5. **Odd log Prime Kernel/odd_log_prime_kernel_paper_final.tex**

   Separar continuación abeliana, transferencia fraccionaria condicionada, herencia de singularidades en ceros simples e hipótesis fuerte. Las fórmulas con \(1/\zeta'(\rho)\) no dan un recuento no ponderado de gaps sin cotas inferiores uniformes para los residuos.

6. **mu/RHC_EXTINCTION_ARGUMENT_v06-copia.tex**

   Revisar identidad de corte firmado, momentos de correlaciones de lag, supervivientes y descomposición por celdas de extinción de \(M(N)\). Buscar un puente demostrado hacia \(D_p\) o (D-CM4).

### Prioridad A: centroide y Montgomery

7. **Centroid Final/zeta_centroid_article_complete_v14/zeta_rvm_exponential_centroids_v14.tex**

   Revisar íntegramente:

   - transporte altura–índice con multiplicidades;
   - Level 1 incondicional;
   - objetivo Landau ponderado por \(M\) sobre ceros verdaderos;
   - existencia y serie de Abel del centroide RVM;
   - coordenada real simétrica y su hipótesis de compatibilidad;
   - intercambio unilateral de frontera;
   - defecto fuera de la recta;
   - familia holomorfa de centroides;
   - equivalencia de la familia de centroides con RH;
   - forma residual zeta–RVM;
   - momento horizontal de Fujii y zeta espectral.

   Preguntas obligatorias:

   1. ¿Puede invertirse la familia completa de centroides para obtener la medida de diferencias \(x_k(\kappa)-x_j(\kappa)\) con una tasa uniforme?
   2. ¿La positividad del defecto imaginario controla gaps verticales o únicamente \(\beta-1/2\)?
   3. ¿El Level 1 o el centroide triangular produce una estimación local del form factor de orden \(u^3\)?
   4. ¿Qué hipótesis de frontera reaparece al intentar pasar del centroide a T-CM4?

   Revisar además:

   - **outputs/centroid_rh_equivalence_output.txt**
   - **outputs/full_data_summary.txt**
   - **outputs/ordinal_height_transport_audit.txt**
   - **outputs/rvm_centroid_output.txt**
   - **outputs/rvm_residual_walks_output.txt**

8. **montgomery_centroid_paper_v1/montgomery_from_exponential_centroids_v1.tex**

   Revisar:

   - reducción Level 1;
   - cancelación triangular de pares por convergencia del centroide;
   - cancelación de energía de trayectorias bajo RH, sin usarla incondicionalmente;
   - inversión exacta de la familia de centroides;
   - identificación con el form factor de Montgomery;
   - rampa de Montgomery y ley seno band-limited;
   - representación residual exacta de cada par tras unfolding RVM;
   - espectro saddle del carrier Lambert;
   - contraejemplo «convergencia del centroide no implica pares»;
   - cancelación cuadrática del polinomio primo truncado;
   - hipótesis abierta de transferencia de Selberg localizada en frecuencia.

   Intenta aplicar la **inversión exacta de la familia completa**, no el centroide a frecuencia \(1\), al kernel racional de (C-M4). Determina si permite frecuencias de orden \(1/y\), mantiene multiplicidades y da error uniforme \(O(y^3)\). Si necesita la hipótesis de transferencia de Selberg, la ruta queda abierta exactamente ahí.

   Revisar también:

   - **outputs/connected_form_factor_output.txt**
   - **outputs/unfolded_residual_pair_law_output.txt**
   - **outputs/core_theorem_compatibility_output.txt**
   - **outputs/centroid_rate_validation_output.txt**
   - **outputs/rvm_counterexample_validation_output.txt**

9. **Centroid/SN_CN_Central_original.tex**

   Extraer solo resultados no absorbidos por v14: identidades finitas de producto, forma triangular, puente altura–ordinal, frecuencia \(X=e\), no resonancia de \(e\) y equidistribución.

### Prioridad B: detectores, matrices y leyes de gaps

10. **GUE Cone/cone_gue_algebra_article.tex**: el transductor recupera gaps y preserva una distribución dada; no genera una ley cúbica.

11. **Matrix Index/Prime_Index_Logarithmic_Matrix_and_Lifted_Inverse_Paths_v13.tex**: buscar una realización Schatten-4 de (C-M4) en los caminos inversos, umbrales Hilbert–Schmidt y cuadrados de fases. El criterio matricial equivalente a RH no es un insumo.

12. **Matrix Weil-Li/reflection_li_weil_matrices_v22-copia.tex**: usar v22 como principal y v21 solo para material perdido; buscar formas de Gram/positividad locales.

13. **Quartic/resumen_v_cuartica_rh.tex**: distinguir «cuártica» algebraica de la potencia cúbica de gaps. Solo es útil si el kernel coincide exactamente con C-M4, T-P4 o \(E_N^{(4)}\).

14. **LogPhaseWalk/AMP_LogPhaseWalk_Zeta_RVM_completed_tests.tex**: auditar gaps, residuos Rayleigh, controles GUE y detector lateral; las leyes empíricas no prueban OBJ.

15. **Shark Fin/shark_fin_phase_pair_criterion.tex**: comprobar si el criterio aporta una tasa cerca del origen y conserva multiplicidades.

16. **zPhases/Zfases_FINAL.tex** y **Bimodal Phases/PhaseDistribution.tex**: una ley límite sin error uniforme cuando \(v\downarrow0\) no demuestra OBJ.

17. **Three-State Gated/gated_two_harmonic_distributions_root.tex**: revisar la sección Möbius y cotas de discrepancia como posible modelo cuantitativo.

### Material de contexto

- **mu/RHC_LITERATURE_AND_RESEARCH_MAP_v8-copia.tex**: usar para localizar dependencias, no como sustituto de la comprobación.
- v4 y v6 son versiones anteriores; consultar solo diferencias.
- **source_archive/all_uploaded_material** suele duplicar versiones principales.

---

## 7. Pruebas concretas, en este orden

### Intento A: inversión del centroide aplicada al kernel de coherencia

Representa

\[
K_y(r)=\frac{16y^4}{(r^2+4y^2)^2}
\]

por Fourier/Laplace y expresa

\[
\sum_{j<k}K_y(x_k(\kappa)-x_j(\kappa))
\]

mediante el form factor o la familia completa de centroides. Usa la inversión exacta del artículo de Montgomery. Conserva diagonal, borde y multiplicidades. La transformada tiene escala \(1/y\); una estimación a frecuencia fija no basta.

### Intento B: residual RVM y cancelación conectada

Usa la representación residual exacta de cada par tras unfolding RVM. Sustitúyela en C-M4, separa carrier, residual lineal, residual cuadrático y multiplicidades. Comprueba si la cancelación triangular o la energía conectada controla la parte firmada de D-CM4.

No confundas \(N\to\infty\) con \(y\downarrow0\) para un bloque fijo. Si intercambias límites, demuestra uniformidad.

### Intento C: multiplicador \(M\leftrightarrow M_{\mathrm{RVM}}\) en Schatten-4

Formula un espacio de kernels de polos donde el multiplicador exacto \(\mathscr Q_{\mathrm{RVM}}\) o \(\mathscr T_{\mathrm{RVM}}^{\mathrm{ord}}\) actúe sobre la matriz de Gram. Demuestra, no supongas, una desigualdad de defecto \(S_4\) con pérdida \(y^3\). Explica por qué las cotas escalares \(L^2\) de v56 bastan o no.

### Intento D: medida atómica positiva y tests dependientes de \(y\)

Adapta los tests positivos de **Mu F** y **Finite Height Criteria** a una familia que localice colisiones verticales, no desplazamientos horizontales. Debe resolver una ventana de ancho \(y\), ser admisible en la fórmula explícita y tener pairing \(O(y^3)\).

### Intento E: excursiones de \(M\) y recurrencia de momentos

Busca una identidad que convierta una correlación firmada de excursiones o una celda de extinción en

\[
D_p=\sum q_i(1-q_i)^p.
\]

El puente debe ser exacto y conservar el signo. Si solo obtienes \(\sum|\delta_{i+1}-\delta_i|^2\), no alcanza.

---

## 8. Controles de no circularidad

Prueba cada supuesto nuevo sobre esta configuración finita adversaria: lleva dos puntos RVM consecutivos \(t_K,t_{K+1}\) a su punto medio y deja los demás fijos. Entonces

\[
\delta_K=d_K/2,\qquad
\delta_{K+1}=-d_K/2,\qquad
q_K=0,\qquad
\sum\delta_k^2=d_K^2/2.
\]

Satisface las cotas geométricas superiores básicas, pero viola cualquier cota cúbica. Todo teorema que la excluya debe usar información aritmética adicional real del corpus. Identifica cuál.

Comprueba además:

- si el supuesto ya excluye polos fuera de \(\Re s=1/2\), probablemente tiene fuerza RH;
- si exige polos simples en \(\kappa=1\), contiene la conclusión;
- si exige una cota inferior uniforme de \(|\zeta'(\rho)|\), decláralo como desconocido;
- si usa \(\Pr(s\le v)\sim cv^{\beta+1}/(\beta+1)\), distingue el límite estadístico del enunciado finito uniforme OBJ;
- si controla promedios globales normalizados, verifica que no diluya un átomo fijo de colisión.

---

## 9. Formato de la respuesta requerida

Entrega cuatro bloques:

1. **Teoremas efectivamente aplicados**, con derivación y referencias internas exactas.
2. **Resultados que no alcanzan**, indicando la pérdida precisa: potencia, uniformidad, signo, multiplicidad, regularización o circularidad.
3. **Mejor cota nueva demostrada** para \(F_N\), \(\mathcal C^{M,4}\), \(P^{[4]}\), \(T^{[4]}\), \(E_N^{(4)}\) o \(M_p\). Si no hay mejora, dilo.
4. **Teorema mínimo pendiente**, con cuantificadores y prueba de que implica OBJ, RH y simplicidad por esta ruta.

No presentes como avance una reformulación equivalente. Un avance debe mejorar D1–D3, reducir el teorema pendiente a una hipótesis más verificable o cerrar T-CM4, T-T4, T-E4 o T-M.

---

## 10. Archivos de estado para entregar también a Codex

Si están disponibles, acompaña este encargo con:

- **excursion_area_section_v56.tex**;
- **Intento_cota_cubica_RVM_20261003.txt**;
- **RVM_corpus_continuacion_20261003.txt**;
- **V57_handoff.txt**;
- el directorio completo **Documents/PACK PDF** o, como mínimo, los artículos de prioridad A;
- los outputs numéricos de centroide y Montgomery indicados arriba.

**Intento_cota_cubica_RVM_20261003.txt** contiene las demostraciones de D1–D3, las equivalencias de detectores y el primer intento directo mediante \(M_{\mathrm{RVM}}\). Codex debe partir de ellas, verificarlas y continuar; no reiniciar con una exposición genérica de RH.
