function leslie_gonek
% =========================================================================
%  Familia de Leslie no negativas con espectro subdominante en |lam|=sqrt(b)
%  y ajuste del perfil de amplitudes al blanco de Gonek:  a_j ~ (log j)^(1/4)/j
%
%  Estructura:
%    P(lam) = (lam-b) * prod_j (lam^2 - 2 sqrt(b) cos(th_j) lam + b)
%    a      = -P(2:end)              % coeficientes de la recursion
%    Leslie:  L(1,j) = a(j)/prod(s(1:j-1)) ,  L(j+1,j) = s(j)
%
%  Las supervivencias s NO tocan el polinomio caracteristico.
%  Solo mueven los autovectores, y con ellos las amplitudes.
% =========================================================================

K  = 32;                 % numero de pares conjugados
v0type = 'ones';         % 'ones' | 'e1'   (NO dejarlo libre: seria trampa)

%% ---------- 1. angulos admisibles: todos los coef. no lideres <= 0 -------
[b, th, worst] = buscar_angulos(K);
fprintf('K=%d  dim=%d  b=%.4f  peor coeficiente=%+.3e  %s\n', ...
        K, 2*K+1, b, worst, ternario(worst<=0,'ADMISIBLE','NO ADMISIBLE'));
if worst > 0
    warning('No se encontro configuracion admisible. Baja K o amplia el barrido de b.');
end

a = coefs(b, th);                       % 1 x m, deben ser >= 0
m = numel(a);
fprintf('min(a_j) = %+.6f   (debe ser >= 0)\n', min(a));

%% ---------- 2. blanco de Gonek -------------------------------------------
nsub   = m - 1;                          % modos subdominantes
jj     = (1:nsub)';
target = (log(jj + exp(1))).^(0.25) ./ jj;
target = target / target(1);             % normalizado a 1

%% ---------- 3. optimizacion sobre log(s) --------------------------------
% Trabajamos con u = log(s) para garantizar s>0 y controlar el rango dinamico.
u0 = zeros(m-1, 1);                      % s = 1 (punto de partida = companera)

fprintf('\ncoste inicial (s=1): %.6f\n', coste(u0, a, b, target, v0type));

opts = optimset('Display','iter','MaxFunEvals',2e5,'MaxIter',5e4, ...
                'TolX',1e-10,'TolFun',1e-12);
uopt = fminsearch(@(u) coste(u, a, b, target, v0type), u0, opts);

%% ---------- 4. resultado -------------------------------------------------
[c_fin, amp, ev, L] = evaluar(uopt, a, b, v0type);
fprintf('\ncoste final: %.6f\n', c_fin);

s = exp(uopt);
fprintf('rango de supervivencias: [%.3e , %.3e]\n', min(s), max(s));
fprintf('todas las entradas de L >= 0 : %d\n', all(L(:) >= -1e-12));

% VERIFICACION OBLIGATORIA: el espectro no se ha movido
err_spec = max(abs(abs(ev(2:end)) - sqrt(b)));
fprintf('error espectral max ||lam_j|-sqrt(b)| = %.3e   %s\n', err_spec, ...
        ternario(err_spec < 1e-6,'(espectro intacto)','(*** ESPECTRO CORROMPIDO: no fiarse ***)'));

%% ---------- 5. donde falla ----------------------------------------------
figure;
loglog(jj, amp, 'o-', jj, target, 's--', 'LineWidth', 1.2);
grid on; xlabel('j'); ylabel('amplitud normalizada');
legend('ajustado','(log j)^{1/4}/j','Location','southwest');
title(sprintf('K=%d, dim=%d, coste=%.4f', K, m, c_fin));

r = amp ./ target;
fprintf('\ncociente amp/blanco:\n');
fprintf('  primeros 8 modos : '); fprintf('%.3f ', r(1:min(8,nsub)));  fprintf('\n');
fprintf('  ultimos  8 modos : '); fprintf('%.3f ', r(max(1,nsub-7):nsub)); fprintf('\n');
fprintf('\nSi falla en los PRIMEROS modos -> la geometria de autovectores no llega.\n');
fprintf('Si falla en la COLA            -> hace falta dimension infinita.\n');

%% ---------- 6. lo que de verdad importa: la suma parcial ----------------
% El exponente alpha sale de  sum_{j<lam} a_j ~ (log lam)^alpha.
figure;
cs = cumsum(amp);
loglog(jj, cs, 'o-', jj, cumsum(target), 's--', 'LineWidth', 1.2);
grid on; xlabel('j'); ylabel('suma parcial de amplitudes');
legend('ajustado','blanco','Location','southeast');
p = polyfit(log(log(jj(5:end)+exp(1))), log(cs(5:end)), 1);
fprintf('\nalpha empirico de la suma parcial ajustada: %.4f   (blanco: 1.25)\n', p(1));
end

% =========================================================================
function [b, th, worst] = buscar_angulos(K)
best = struct('w', inf, 'b', NaN, 'th', []);
for b = 1.15:0.05:3.0
    for sd = 1:6
        rng(31*K + sd);
        t0 = rand(1, K) * pi;
        o  = optimset('Display','off','MaxFunEvals',2e4,'MaxIter',2e4, ...
                      'TolX',1e-10,'TolFun',1e-13);
        t  = fminsearch(@(t) max(coefs_raw(b, t)), t0, o);
        w  = max(coefs_raw(b, t));
        if w < best.w, best = struct('w', w, 'b', b, 'th', t); end
    end
    if best.w <= 0, break; end
end
b = best.b; th = best.th; worst = best.w;
end

function p = polyP(b, th)
p = [1, -b];
for t = th
    p = conv(p, [1, -2*sqrt(b)*cos(t), b]);
end
end

function c = coefs_raw(b, th)   % coeficientes no lideres (deben ser <= 0)
p = polyP(b, th);  c = p(2:end);
end

function a = coefs(b, th)       % coeficientes de la recursion (deben ser >= 0)
a = -coefs_raw(b, th);
end

% ------------------------------------------------------------------------
function L = montar(u, a)
% u = log(s).  Escala logaritmica acumulada para evitar overflow.
m  = numel(a);
cu = [0, cumsum(u(:)')];              % cu(j) = log prod(s(1:j-1))
L  = zeros(m);
L(1, :) = a .* exp(-cu(1:m));         % fecundidades
for j = 1:m-1
    L(j+1, j) = exp(u(j));            % supervivencias
end
end

function [c, amp, ev, L] = evaluar(u, a, b, v0type)
L = montar(u, a);
m = size(L, 1);
[V, D] = eig(L);
ev = diag(D);
[~, o] = sort(abs(ev), 'descend');
ev = ev(o); V = V(:, o);

switch v0type
    case 'ones', v0 = ones(m, 1);
    case 'e1',   v0 = [1; zeros(m-1,1)];
end

if rcond(V) < 1e-14
    c = 1e6; amp = nan(m-1,1); return
end
coef = V \ v0;
amp  = abs(coef(2:end));              % descarto el modo de Perron
amp  = sort(amp, 'descend');
if amp(1) <= 0 || ~all(isfinite(amp)), c = 1e6; return; end
amp = amp / amp(1);

jj = (1:m-1)';
target = (log(jj + exp(1))).^(0.25) ./ jj;
target = target / target(1);

% distancia en escala log: lo que importa es el perfil, no el nivel
c = norm(log(amp + 1e-300) - log(target)) / sqrt(m-1);

% penalizacion si el espectro se corrompe numericamente
c = c + 1e3 * max(0, max(abs(abs(ev(2:end)) - sqrt(b))) - 1e-6);
end

function c = coste(u, a, b, target, v0type) %#ok<INUSD>
c = evaluar(u, a, b, v0type);
end

function s = ternario(cond, si, no)
if cond, s = si; else, s = no; end
end
