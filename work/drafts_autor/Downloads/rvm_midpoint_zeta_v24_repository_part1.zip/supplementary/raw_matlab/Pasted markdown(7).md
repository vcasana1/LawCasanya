% RVM_VS_Z1_ALL9_K_OVERLAID.m

% ================================================================

% LAS 9 GRAFICAS DEPENDEN DE K

% ================================================================

%

% zLamb.bin  -> tau_k

% zeross.bin -> gamma_k

%

% Para cada truncacion K:

%

%   1 M_RVM,K^crit

%   2 pi_RVM,K

%   3 |zeta_RVM,K|

%

%   4 M_Z1,K^crit

%   5 pi_Z1,K

%   6 |zeta_Z1,K|

%

%   7 M_RVM,K^crit - M_Z1,K^crit

%   8 pi_RVM,K - pi_Z1,K

%   9 |zeta_RVM,K - zeta_Z1,K|

%

% K = 1e3, 1e4, 1e5, 5e5, Kmax (\~2,001,052)

%

% IMPORTANTE:

% - Aqui NO se usa M(x) exacta ni pi(x) exacta.

% - Todo se construye espectralmente con la misma truncacion K.

% - Asi las 9 figuras dependen realmente de K.

%

% Todos los vectores son columnas.

% Sin escalas logaritmicas.

%

% Progreso: tic/toc, k/n, porcentaje y ETA.

clear; clc;

TGLOBAL = tic;

%% ================================================================

% PARAMETROS

% ================================================================

XMAX = 1000;

NX   = 100;

TMAX = 60;

NTZ  = 300;

% Perron truncado para M_X,K

CP = 0.75;

TPERRON = 80;

NTP = 401;

% Producto canonico

KHEAD = 30000;

RPROD = 5;

SBLOCK = 40;

% J_X,K

KEI = 5000;

REI = 5;

ZERO_BLOCK = 100000;

ARG_BLOCK = 16;

%% ================================================================

% CARGA

% ================================================================

fprintf('\n============================================================\n');

fprintf('ETAPA 1: CARGA\n');

fprintf('============================================================\n');

T=tic;

fid=fopen('zLamb.bin','rb');

assert(fid>0,'No encuentro zLamb.bin');

tau=fread(fid,inf,'double=>double');

fclose(fid);

tau=tau(:);

fid=fopen('zeross.bin','rb');

assert(fid>0,'No encuentro zeross.bin');

gam=fread(fid,inf,'double=>double');

fclose(fid);

gam=gam(:);

Kmax=min(numel(tau),numel(gam));

tau=tau(1:Kmax);

gam=gam(1:Kmax);

Klist=unique([1000;10000;100000;500000;Kmax]);

Klist=Klist(Klist<=Kmax);

NK=numel(Klist);

fprintf('Kmax = %d\n',Kmax);

fprintf('Klist = ');

fprintf('%d ',Klist);

fprintf('\nCarga: %.2f s\n',toc(T));

%% ================================================================

% MALLAS

% ================================================================

x=linspace(2,XMAX,NX).';

t=linspace(0.05,TMAX,NTZ).';

scrit=0.5+1i\*t;

tp=linspace(0,TPERRON,NTP).';

sp=CP+1i\*tp;

%% ================================================================

% ZETAS TRUNCADAS PARA TODOS LOS K

% ================================================================

fprintf('\n============================================================\n');

fprintf('ETAPA 2: ZETAS TRUNCADAS\n');

fprintf('============================================================\n');

fprintf('\nzeta_RVM,K en recta critica\n');

zRcrit=zeta_snapshots(scrit,tau,Klist,KHEAD,RPROD,SBLOCK,'RVM crit');

fprintf('\nzeta_Z1,K en recta critica\n');

zGcrit=zeta_snapshots(scrit,gam,Klist,KHEAD,RPROD,SBLOCK,'Z1 crit');

fprintf('\nzeta_RVM,K en Perron\n');

zRP=zeta_snapshots(sp,tau,Klist,KHEAD,RPROD,SBLOCK,'RVM Perron');

fprintf('\nzeta_Z1,K en Perron\n');

zGP=zeta_snapshots(sp,gam,Klist,KHEAD,RPROD,SBLOCK,'Z1 Perron');

%% ================================================================

% ARGUMENTOS J PARA MOBIUS

% ================================================================

fprintf('\n============================================================\n');

fprintf('ETAPA 3: ARGUMENTOS J\n');

fprintf('============================================================\n');

T=tic;

Nint=floor(XMAX);

muAll=mobius_vector(Nint);

MMAX=floor(log(XMAX)/log(2));

maxTerms=NX\*MMAX;

allY=zeros(maxTerms,1);

allCoeff=zeros(maxTerms,1);

mapStart=zeros(NX,1);

mapCount=zeros(NX,1);

cursor=0;

for ix=1:NX

&#x20;   mapStart(ix)=cursor+1;

&#x20;   xx=x(ix);

&#x20;   mmax=floor(log(xx)/log(2));

&#x20;   q=0;

&#x20;   for m=1:mmax

&#x20;       mum=muAll(m);

&#x20;       if mum==0

&#x20;           continue

&#x20;       end

&#x20;       y=xx^(1/m);

&#x20;       if y>=2

&#x20;           cursor=cursor+1;

&#x20;           q=q+1;

&#x20;           allY(cursor)=y;

&#x20;           allCoeff(cursor)=mum/m;

&#x20;       end

&#x20;   end

&#x20;   mapCount(ix)=q;

&#x20;   progress_n(ix,NX,T,'argumentos');

end

allY=allY(1:cursor);

allCoeff=allCoeff(1:cursor);

[yUnique,\~,iYU]=unique(allY,'stable');

fprintf('\nArgumentos totales=%d; unicos=%d\n',numel(allY),numel(yUnique));

%% ================================================================

% J_RVM,K Y J_Z1,K

% ================================================================

fprintf('\n============================================================\n');

fprintf('ETAPA 4: J_RVM,K CON TODOS LOS SNAPSHOTS K\n');

fprintf('============================================================\n');

JRuniq=J_snapshots(yUnique,tau,Klist,KEI,REI,ZERO_BLOCK,ARG_BLOCK,'RVM');

fprintf('\n============================================================\n');

fprintf('ETAPA 5: J_Z1,K CON TODOS LOS SNAPSHOTS K\n');

fprintf('============================================================\n');

JGuniq=J_snapshots(yUnique,gam,Klist,KEI,REI,ZERO_BLOCK,ARG_BLOCK,'Z1');

JRall=JRuniq(iYU,:);

JGall=JGuniq(iYU,:);

%% ================================================================

% PI_RVM,K Y PI_Z1,K

% ================================================================

fprintf('\n============================================================\n');

fprintf('ETAPA 6: PI TRUNCADAS\n');

fprintf('============================================================\n');

T=tic;

piR=zeros(NX,NK);

piG=zeros(NX,NK);

for ik=1:NK

&#x20;   for ix=1:NX

&#x20;       q=mapCount(ix);

&#x20;       if q>0

&#x20;           ind=mapStart(ix):(mapStart(ix)+q-1);

&#x20;           piR(ix,ik)=sum(allCoeff(ind).\*JRall(ind,ik));

&#x20;           piG(ix,ik)=sum(allCoeff(ind).\*JGall(ind,ik));

&#x20;       end

&#x20;   end

&#x20;   fprintf('  K=%d | %d/%d | toc %.2fs\n',Klist(ik),ik,NK,toc(T));

end

piR=real(piR);

piG=real(piG);

%% ================================================================

% M_RVM,K Y M_Z1,K POR PERRON TRUNCADO

% ================================================================

fprintf('\n============================================================\n');

fprintf('ETAPA 7: MERTENS ESPECTRALES TRUNCADAS\n');

fprintf('============================================================\n');

T=tic;

MR=zeros(NX,NK);

MG=zeros(NX,NK);

for ik=1:NK

&#x20;   FR=1./zRP(:,ik);

&#x20;   FG=1./zGP(:,ik);

&#x20;   baseR=FR./sp;

&#x20;   baseG=FG./sp;

&#x20;   TK=tic;

&#x20;   for ix=1:NX

&#x20;       ph=exp(1i\*tp\*log(x(ix)));

&#x20;       intR=trapz(tp,baseR.\*ph);

&#x20;       intG=trapz(tp,baseG.\*ph);

&#x20;       % integral simetrica -T..T

&#x20;       MR(ix,ik)=x(ix)^CP/pi\*real(intR);

&#x20;       MG(ix,ik)=x(ix)^CP/pi\*real(intG);

&#x20;       if mod(ix,10)==0 || ix==NX

&#x20;           elapsed=toc(TK);

&#x20;           frac=ix/NX;

&#x20;           eta=elapsed\*(1/frac-1);

&#x20;           fprintf(['  K=%d | n=%d/%d | %.1f%% ', ...

&#x20;                    '| toc %.2fs | ETA %.2fs\n'], ...

&#x20;                   Klist(ik),ix,NX,100\*frac,elapsed,eta);

&#x20;       end

&#x20;   end

end

MR=real(MR);

MG=real(MG);

%% ================================================================

% DIFERENCIAS

% ================================================================

dM=MR-MG;

dPi=piR-piG;

dZ=abs(zRcrit-zGcrit);

%% ================================================================

% LEYENDAS

% ================================================================

leg=cell(NK,1);

for ik=1:NK

&#x20;   if Klist(ik)==Kmax

&#x20;       leg{ik}=sprintf('K=%d (max)',Klist(ik));

&#x20;   else

&#x20;       leg{ik}=sprintf('K=%d',Klist(ik));

&#x20;   end

end

%% ================================================================

% 9 GRAFICAS: TODAS DEPENDEN DE K

% ================================================================

fprintf('\n============================================================\n');

fprintf('ETAPA 8: GRAFICAS\n');

fprintf('============================================================\n');

figure(1); clf; hold on;

for ik=1:NK, plot(x,MR(:,ik),'LineWidth',1.1); end

hold off; grid on;

xlabel('x'); ylabel('M\_{RVM,K}^{crit}(x)');

title('1. M\_{RVM,K}^{crit}(x)');

legend(leg,'Location','best');

figure(2); clf; hold on;

for ik=1:NK, plot(x,piR(:,ik),'LineWidth',1.1); end

hold off; grid on;

xlabel('x'); ylabel('\pi\_{RVM,K}(x)');

title('2. \pi\_{RVM,K}(x)');

legend(leg,'Location','best');

figure(3); clf; hold on;

for ik=1:NK, plot(t,abs(zRcrit(:,ik)),'LineWidth',1.1); end

hold off; grid on;

xlabel('t'); ylabel('|\zeta\_{RVM,K}(1/2+it)|');

title('3. |\zeta\_{RVM,K}(1/2+it)|');

legend(leg,'Location','best');

figure(4); clf; hold on;

for ik=1:NK, plot(x,MG(:,ik),'LineWidth',1.1); end

hold off; grid on;

xlabel('x'); ylabel('M\_{Z1,K}^{crit}(x)');

title('4. M\_{Z1,K}^{crit}(x)');

legend(leg,'Location','best');

figure(5); clf; hold on;

for ik=1:NK, plot(x,piG(:,ik),'LineWidth',1.1); end

hold off; grid on;

xlabel('x'); ylabel('\pi\_{Z1,K}(x)');

title('5. \pi\_{Z1,K}(x)');

legend(leg,'Location','best');

figure(6); clf; hold on;

for ik=1:NK, plot(t,abs(zGcrit(:,ik)),'LineWidth',1.1); end

hold off; grid on;

xlabel('t'); ylabel('|\zeta\_{Z1,K}(1/2+it)|');

title('6. |\zeta\_{Z1,K}(1/2+it)|');

legend(leg,'Location','best');

figure(7); clf; hold on;

for ik=1:NK, plot(x,dM(:,ik),'LineWidth',1.1); end

yline(0,'--');

hold off; grid on;

xlabel('x'); ylabel('M\_{RVM,K}^{crit}-M\_{Z1,K}^{crit}');

title('7. Diferencia Mertens: RVM - Z1');

legend(leg,'Location','best');

figure(8); clf; hold on;

for ik=1:NK, plot(x,dPi(:,ik),'LineWidth',1.1); end

yline(0,'--');

hold off; grid on;

xlabel('x'); ylabel('\pi\_{RVM,K}-\pi\_{Z1,K}');

title('8. Diferencia de conteos: RVM - Z1');

legend(leg,'Location','best');

figure(9); clf; hold on;

for ik=1:NK, plot(t,dZ(:,ik),'LineWidth',1.1); end

hold off; grid on;

xlabel('t');

ylabel('|\zeta\_{RVM,K}-\zeta\_{Z1,K}|');

title('9. Diferencia de zetas: RVM - Z1');

legend(leg,'Location','best');

fprintf('\n============================================================\n');

fprintf('TODO TERMINADO EN %.2f s = %.2f min\n',toc(TGLOBAL),toc(TGLOBAL)/60);

fprintf('============================================================\n');

%% =================================================================

% FUNCIONES

% =================================================================

function Zall=zeta_snapshots(s,ord,Klist,Khead,R,sBlock,label)

&#x20;   T=tic;

&#x20;   s=s(:);

&#x20;   ord=ord(:);

&#x20;   Klist=Klist(:);

&#x20;   ns=numel(s);

&#x20;   NK=numel(Klist);

&#x20;   Kmax=max(Klist);

&#x20;   A=0.25+ord.^2;

&#x20;   % Para cada K, cabeza exacta hasta min(K,Khead)

&#x20;   % y cola Khead+1..K por momentos.

&#x20;   moments=zeros(R,NK);

&#x20;   if Kmax>Khead

&#x20;       block=100000;

&#x20;       cum=zeros(R,1);

&#x20;       k0=Khead+1;

&#x20;       while k0<=Kmax

&#x20;           k1=min(Kmax,k0+block-1);

&#x20;           aa=A(k0:k1);

&#x20;           for r=1:R

&#x20;               cum(r)=cum(r)+sum(aa.^(-r));

&#x20;           end

&#x20;           % snapshots que caen dentro/fin del bloque

&#x20;           ids=find(Klist>=k0 & Klist<=k1);

&#x20;           for jj=1:numel(ids)

&#x20;               ik=ids(jj);

&#x20;               Ktar=Klist(ik);

&#x20;               tmp=cum;

&#x20;               if Ktar\<k1

&#x20;                   extra=A(Ktar+1:k1);

&#x20;                   for r=1:R

&#x20;                       tmp(r)=tmp(r)-sum(extra.^(-r));

&#x20;                   end

&#x20;               end

&#x20;               moments(:,ik)=tmp;

&#x20;           end

&#x20;           frac=k1/Kmax;

&#x20;           elapsed=toc(T);

&#x20;           eta=elapsed\*(1/frac-1);

&#x20;           fprintf('  %s momentos k=%d/%d | %.1f%% | toc %.1fs | ETA %.1fs\n', ...

&#x20;                   label,k1,Kmax,100\*frac,elapsed,eta);

&#x20;           k0=k1+1;

&#x20;       end

&#x20;   end

&#x20;   Zall=zeros(ns,NK);

&#x20;   nBlocks=ceil(ns/sBlock);

&#x20;   for ib=1:nBlocks

&#x20;       i0=(ib-1)\*sBlock+1;

&#x20;       i1=min(ns,ib\*sBlock);

&#x20;       ss=s(i0:i1);

&#x20;       a=ss.\*(ss-1);

&#x20;       for ik=1:NK

&#x20;           K=Klist(ik);

&#x20;           Kh=min(K,Khead);

&#x20;           Ah=A(1:Kh);

&#x20;           Q=1+(1./Ah)\*a.';

&#x20;           logP=sum(log(complex(Q)),1).';

&#x20;           if K>Khead

&#x20;               tail=zeros(size(a));

&#x20;               apow=ones(size(a));

&#x20;               for r=1:R

&#x20;                   apow=apow.\*a;

&#x20;                   tail=tail+((-1)^(r+1))/r .\* apow .\* moments(r,ik);

&#x20;               end

&#x20;               logP=logP+tail;

&#x20;           end

&#x20;           P=exp(logP);

&#x20;           G=ss.\*(ss-1).\*cgamma_lanczos_vec(ss/2).\*pi.^(-ss/2);

&#x20;           Zall(i0:i1,ik)=P./G;

&#x20;       end

&#x20;       frac=ib/nBlocks;

&#x20;       elapsed=toc(T);

&#x20;       eta=elapsed\*(1/frac-1);

&#x20;       fprintf('  %s s-bloque %d/%d | %.1f%% | toc %.1fs | ETA %.1fs\n', ...

&#x20;               label,ib,nBlocks,100\*frac,elapsed,eta);

&#x20;   end

end

function Jall=J_snapshots(y,ord,Klist,Kei,Rei,zeroBlock,argBlock,label)

% J_X,K(y) con ordinadas ord_k y ceros proyectados 1/2+i ord_k.

%

% Cabeza exacta Ei.

% Cola asintotica vectorizada.

% Guarda snapshots al llegar a cada K.

&#x20;   Ttotal=tic;

&#x20;   y=y(:);

&#x20;   ord=ord(:);

&#x20;   Klist=Klist(:);

&#x20;   ny=numel(y);

&#x20;   NK=numel(Klist);

&#x20;   Kmax=max(Klist);

&#x20;   Jall=zeros(ny,NK);

&#x20;   nABlocks=ceil(ny/argBlock);

&#x20;   for ia=1:nABlocks

&#x20;       a0=(ia-1)\*argBlock+1;

&#x20;       a1=min(ny,ia\*argBlock);

&#x20;       yy=y(a0:a1);

&#x20;       u=log(yy);

&#x20;       B=numel(u);

&#x20;       sumAtK=zeros(B,NK);

&#x20;       % K pequenos: exactos completos

&#x20;       for ik=1:NK

&#x20;           K=Klist(ik);

&#x20;           if K<=Kei

&#x20;               rho=0.5+1i\*ord(1:K);

&#x20;               W=rho\*u.';

&#x20;               EE=-expint(-W)+1i\*pi;

&#x20;               sumAtK(:,ik)=sum(EE,1).';

&#x20;           end

&#x20;       end

&#x20;       Kbase=min(Kei,Kmax);

&#x20;       rhoHead=0.5+1i\*ord(1:Kbase);

&#x20;       W=rhoHead\*u.';

&#x20;       Ehead=-expint(-W)+1i\*pi;

&#x20;       cumulative=sum(Ehead,1).';

&#x20;       ids=find(Klist==Kbase);

&#x20;       for jj=1:numel(ids)

&#x20;           sumAtK(:,ids(jj))=cumulative;

&#x20;       end

&#x20;       kStart=Kbase+1;

&#x20;       while kStart<=Kmax

&#x20;           higher=Klist(Klist>=kStart);

&#x20;           nextTarget=min(higher);

&#x20;           kEnd=min([Kmax,kStart+zeroBlock-1,nextTarget]);

&#x20;           ok=ord(kStart:kEnd);

&#x20;           rk=0.5+1i\*ok;

&#x20;           E=exp(1i\*ok\*u.');

&#x20;           local=zeros(B,1);

&#x20;           invrho=1./rk;

&#x20;           rpow=invrho;

&#x20;           for q=0:Rei-1

&#x20;               Sq=(rpow.'\*E).';

&#x20;               coeff=factorial(q).\*exp(u/2)./(u.^(q+1));

&#x20;               local=local+coeff.\*Sq;

&#x20;               rpow=rpow.\*invrho;

&#x20;           end

&#x20;           cumulative=cumulative+local;

&#x20;           ids=find(Klist==kEnd);

&#x20;           for jj=1:numel(ids)

&#x20;               sumAtK(:,ids(jj))=cumulative;

&#x20;           end

&#x20;           frac=((ia-1)+kEnd/Kmax)/nABlocks;

&#x20;           elapsed=toc(Ttotal);

&#x20;           eta=elapsed\*(1/frac-1);

&#x20;           fprintf(['  %s J: u-bloque %d/%d | k=%d/%d | %.2f%% ', ...

&#x20;                    '| toc %.1fs | ETA %.1fs\n'], ...

&#x20;                   label,ia,nABlocks,kEnd,Kmax,100\*frac,elapsed,eta);

&#x20;           kStart=kEnd+1;

&#x20;       end

&#x20;       lix=zeros(B,1);

&#x20;       corr=zeros(B,1);

&#x20;       for j=1:B

&#x20;           uj=u(j);

&#x20;           lix(j)=real(-expint(-uj));

&#x20;           yj=yy(j);

&#x20;           corr(j)=integral(@(q)1./(q.\*(q.^2-1).\*log(q)), ...

&#x20;                            yj,Inf,'RelTol',2e-9,'AbsTol',2e-11);

&#x20;       end

&#x20;       for ik=1:NK

&#x20;           Jall(a0:a1,ik)=lix-2\*real(sumAtK(:,ik))-log(2)+corr;

&#x20;       end

&#x20;   end

end

function mu=mobius_vector(N)

&#x20;   mu=ones(N,1);

&#x20;   pp=primes(N);

&#x20;   for p=pp

&#x20;       mu(p:p:N)=-mu(p:p:N);

&#x20;       p2=p\*p;

&#x20;       if p2<=N

&#x20;           mu(p2:p2:N)=0;

&#x20;       end

&#x20;   end

end

function g=cgamma_lanczos_vec(z)

&#x20;   z=z(:);

&#x20;   p=[ ...

&#x20;       0.99999999999980993, ...

&#x20;       676.5203681218851, ...

&#x20;      -1259.1392167224028, ...

&#x20;       771.32342877765313, ...

&#x20;      -176.61502916214059, ...

&#x20;        12.507343278686905, ...

&#x20;        -0.13857109526572012, ...

&#x20;         9.9843695780195716e-6, ...

&#x20;         1.5056327351493116e-7 ];

&#x20;   g=zeros(size(z));

&#x20;   I=real(z)<0.5;

&#x20;   J=\~I;

&#x20;   if any(J)

&#x20;       zz=z(J)-1;

&#x20;       xx=p(1)\*ones(size(zz));

&#x20;       for k=2:numel(p)

&#x20;           xx=xx+p(k)./(zz+(k-1));

&#x20;       end

&#x20;       tt=zz+7.5;

&#x20;       g(J)=sqrt(2\*pi).\*tt.^(zz+0.5).\*exp(-tt).\*xx;

&#x20;   end

&#x20;   if any(I)

&#x20;       zz=z(I);

&#x20;       g(I)=pi./(sin(pi\*zz).\*cgamma_lanczos_vec(1-zz));

&#x20;   end

end

function progress_n(i,N,T,label)

&#x20;   if mod(i,10)\~=0 && i\~=N

&#x20;       return

&#x20;   end

&#x20;   elapsed=toc(T);

&#x20;   frac=i/N;

&#x20;   eta=elapsed\*(1/frac-1);

&#x20;   fprintf('  %s: n=%d/%d | %.1f%% | toc %.1fs | ETA %.1fs\n', ...

&#x20;           label,i,N,100\*frac,elapsed,eta);

end