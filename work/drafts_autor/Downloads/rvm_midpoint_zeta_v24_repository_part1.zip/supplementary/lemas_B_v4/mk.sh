set -e
python3 build.py >/dev/null
rm -f lemas_B_v4.aux lemas_B_v4.toc lemas_B_v4.out lemas_B_v4.brf
pdflatex -interaction=nonstopmode -halt-on-error lemas_B_v4.tex > b1.log 2>&1
pdflatex -interaction=nonstopmode -halt-on-error lemas_B_v4.tex > b1.log 2>&1
python3 make_tips.py lemas_B_v4.tex lemas_B_v4.aux tips.tex >/dev/null
python3 replace_tips.py lemas_B_v4.tex tips.tex >/dev/null
for i in 1 2 3; do pdflatex -interaction=nonstopmode -halt-on-error lemas_B_v4.tex > b2.log 2>&1; done
echo "overfull: $(grep -c Overfull b2.log)  undefined: $(grep -ci 'undefined' b2.log)  pages: $(pdfinfo lemas_B_v4.pdf | grep Pages)"
