from mpmath import mp, mpf, pi, log, e, lambertw, zetazero, sin, sqrt, findroot
def primerange(a,b):
    return [n for n in range(a,b) if n>1 and all(n%d for d in range(2,int(n**0.5)+1))]
mp.dps=20
def tau(k): return 2*pi*(k-mpf(11)/8)/lambertw((k-mpf(11)/8)/e).real
def NR(t): return t/(2*pi)*log(t/(2*pi*e))+mpf(7)/8
def Sx(t,X):
    s=mpf(0)
    for p in primerange(2,X+1):
        pm=p; m=1
        while pm<=X:
            s+= sin(t*m*log(p))/(m*mpf(p)**(mpf(m)/2)); m+=1; pm*=p
    return -s/pi
for X in (10,100,1000):
    errs=[]
    print("X=",X)
    for k in range(1,11):
        t0=tau(k); g=zetazero(k).imag
        g1=findroot(lambda t: NR(t)+Sx(t,X)-(k-mpf(1)/2), t0)
        print(k, mp.nstr(g,10), " tau err",mp.nstr(t0-g,4), " corr err", mp.nstr(g1-g,4))
