from mpmath import mp, mpf, pi, cos, log, sqrt, siegeltheta, zetazero, lambertw, e, findroot
mp.dps=15
def tau(k): return 2*pi*(k-mpf(11)/8)/lambertw((k-mpf(11)/8)/e).real
def ZM(t,M,eps=1):
    th=siegeltheta(t)
    return 2*cos(th)+2*eps*sum(cos(th-t*log(n))/sqrt(n) for n in range(2,M+1))
def zeros(M,eps,T=52,step=0.02):
    out=[]; t=mpf(5); f=ZM(t,M,eps)
    while t<T:
        t2=t+step; f2=ZM(t2,M,eps)
        if f*f2<0: out.append(findroot(lambda x: ZM(x,M,eps),(t,t2),solver='bisect'))
        t,f=t2,f2
    return out
g=[zetazero(k).imag for k in range(1,11)]
cols={'tau':[tau(k) for k in range(1,11)],'M=1':zeros(1,1),'M=2':zeros(2,1),'M=3':zeros(3,1),'M=3,e=.5':zeros(3,0.5),'M=5':zeros(5,1)}
print('k  gamma   '+'  '.join(f'{c:>9}' for c in cols))
for k in range(10):
    print(f'{k+1:2d} {float(g[k]):7.3f} '+'  '.join(f'{float(cols[c][k]):9.3f}' if k<len(cols[c]) else '      -  ' for c in cols))
print('counts up to 52:',{c:len(v) for c,v in cols.items()}, 'zeta:',sum(1 for x in g if x<52))
