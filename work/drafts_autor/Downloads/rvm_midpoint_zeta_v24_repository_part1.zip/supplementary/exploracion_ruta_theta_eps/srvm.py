import csv
from mpmath import mp, mpf, pi, log, e as E_, lambertw, zetazero, sin, si
mp.dps=20
P=[mpf(r['p_j_RVM']) for r in csv.DictReader(open('/home/claude/v16work/rvm_midpoint_zeta_v16/output/s04_rvm_prime_levels.csv'))]
def tau(k): return 2*pi*(k-mpf(11)/8)/lambertw((k-mpf(11)/8)/E_).real
def Sx(t,X,primes):
    s=mpf(0)
    for p in primes:
        if p>X: break
        pm=p;m=1
        while pm<=X:
            s+=sin(t*m*log(p))/(m*p**(mpf(m)/2)); m+=1; pm*=p
    return -s/pi
def solve(rhs,d,L):
    F=lambda u: si(u*L)/pi - d*u - rhs
    lo,hi=-pi/L,pi/L
    if F(lo)*F(hi)>0: return (hi if abs(F(hi))<abs(F(lo)) else lo),True
    for _ in range(80):
        m=(lo+hi)/2
        if F(lo)*F(m)<=0: hi=m
        else: lo=m
    return (lo+hi)/2,False
for X in (30,100):
    L=log(X); print('X=',X,'pi/logX=',float(pi/L)); mx=0
    for k in range(1,11):
        g=zetazero(k).imag; t=tau(k); d=log(t/(2*pi))/(2*pi)
        s=Sx(t,X,P); dl,cap=solve(-s,d,L); gh=t+dl; err=gh-g; mx=max(mx,abs(err))
        print(f"{k} | {float(g):.6f} | {float(t):.6f} | {float(g-t):+.4f} | {float(-s):+.4f} | {float(dl):+.4f}{'*' if cap else ''} | {float(gh):.6f} | {float(err):+.4f}")
    print('max',float(mx))
