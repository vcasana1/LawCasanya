import math, numpy as np
from scipy.special import lambertw
N=13; U=math.log(N+0.5); KT=6000; NU=8001; DOM=0.1
k=np.arange(1,KT+1); tau=2*np.pi*(k-11/8)/lambertw((k-11/8)/np.e).real
u=np.linspace(0,U,NU)[1:-1]; du=U/(NU-1); v=(u-U/2)/(U/2); w=np.exp(-1/(1-v**2)); w/=w.sum()*du
W=0.5*(np.exp(u/2)-np.exp(-u/2)/(np.exp(2*u)-1))
ns=np.array([n for n in range(2,N+1) if np.interp(math.log(n),u,w)/w.max()>=0.05])
COS=np.zeros_like(u)
for a in range(0,KT,500): COS+=np.cos(np.outer(u,tau[a:a+500])).sum(axis=1)
D=W-COS   # clock defect
for OM,K in ((18,4),(30,7),(50,14),(50,30),(50,60)):
    om=np.arange(0,OM+1e-9,DOM)
    Psi=np.vstack([w*np.cos(o*u) for o in om]+[w*np.sin(o*u) for o in om[1:]])*du
    Pn=np.vstack([np.interp(np.log(ns),u,Psi[j]/du) for j in range(Psi.shape[0])])
    L=Psi@(-u[:,None]*np.sin(np.outer(u,tau[:K])))
    A=np.hstack([L,Pn]); t=Psi@D
    x,res,rk,sv=np.linalg.lstsq(A,t,rcond=None)
    r=np.linalg.norm(A@x-t); 
    print(f'band {OM}, K={K} ordinates, {len(ns)} masses: |target| {np.linalg.norm(t):.3e}, linear LSQ residual {r:.3e} (rel {r/np.linalg.norm(t):.3f}), max|h| {np.abs(x[:K]).max():.2f}')
