#!/usr/bin/env python3
"""theta-path version of s10: rung system with target (1-theta)*sum cos(tau u) + theta*k(u).
Unknowns: ordinates below a height (start on the clock) and masses a_n at log n, n<=N.
Residual trend with growing band is the existence test."""
import sys, math
import numpy as np
from scipy.special import lambertw

THETA = float(sys.argv[1]); N = int(sys.argv[2]) if len(sys.argv) > 2 else 13
U = math.log(N + 0.5)
KT = 6000; DOM = 0.1; NU = 8001; ITER = 400
OMEGAS = [18, 22, 26, 30, 34, 38, 42, 46, 50]; MARGIN = 12.0
WMIN = 5e-2; STEP = 0.2; RIDGE = 1e-10

k = np.arange(1, KT + 1)
tau = 2*np.pi*(k - 11/8)/lambertw((k - 11/8)/np.e).real

u = np.linspace(0.0, U, NU)[1:-1]; du = U/(NU - 1)
v = (u - U/2)/(U/2); w = np.exp(-1.0/(1.0 - v**2)); w /= w.sum()*du
Wfun = 0.5*(np.exp(u/2) - np.exp(-u/2)/(np.exp(2*u) - 1))
ns = np.array([n for n in range(2, N + 1) if np.interp(math.log(n), u, w)/w.max() >= WMIN])
COS_TAU = np.zeros_like(u)
for a0 in range(0, KT, 500): COS_TAU += np.cos(np.outer(u, tau[a0:a0+500])).sum(axis=1)

print(f'theta = {THETA}, N = {N}, U = {U:.4f}, masses n = {ns[0]}..{ns[-1]}')
g_all = tau.copy()
for OM in OMEGAS:
    om = np.arange(0.0, OM + 1e-9, DOM)
    Psi = np.vstack([w*np.cos(o*u) for o in om] + [w*np.sin(o*u) for o in om[1:]])*du
    Wj = Psi @ Wfun; Cj = Psi @ COS_TAU
    Pn = np.vstack([np.interp(np.log(ns), u, Psi[j]/du) for j in range(Psi.shape[0])])
    Q = np.linalg.solve(Pn.T @ Pn + RIDGE*np.eye(len(ns)), Pn.T)
    K = int((tau <= OM + MARGIN).sum())
    g = g_all[:K].copy()
    fixed = Psi @ (COS_TAU - np.cos(np.outer(u, tau[:K])).sum(axis=1)) - (1-THETA)*Cj - THETA*Wj
    def r0(g): return Psi @ np.cos(np.outer(u, g)).sum(axis=1) + fixed
    def res(g):
        x = r0(g); a = -Q @ x; return x + Pn @ a, a
    r, a = res(g); n0 = np.linalg.norm(r); damp = 1e-3
    for it in range(1, ITER + 1):
        Jg = Psi @ (-u[:, None]*np.sin(np.outer(u, g))); Jg = Jg - Pn @ (Q @ Jg)
        A = Jg.T @ Jg; b = -Jg.T @ r
        while True:
            d = np.linalg.solve(A + damp*np.diag(np.diag(A) + 1e-14), b)
            d *= min(1.0, STEP/max(np.abs(d).max(), 1e-300))
            r2, a2 = res(g + d)
            if np.linalg.norm(r2) < np.linalg.norm(r) or damp > 1e12: break
            damp *= 4
        g = g + d; r, a = r2, a2; damp = max(damp/3, 1e-14)
        if np.abs(d).max() < 1e-11: break
    g_all[:K] = g
    print(f'band <= {OM:2d}: {K:2d} free, {Psi.shape[0]} tests, |res| {n0:.3e} -> {np.linalg.norm(r):.3e} ({it} it), max|d eta| {np.abs(g-tau[:K]).max():.3f}')
print('  k    tau_k        solved     solved-tau')
for i in range(K):
    print(f'{i+1:3d} {tau[i]:12.6f} {g_all[i]:12.6f} {g_all[i]-tau[i]:+.4f}')
print('  n   mass a_n   (1-th)*0 + th*Lambda/(2sqrt n)')
def Lam(n):
    for p in range(2, n+1):
        if n % p == 0:
            m = n
            while m % p == 0: m //= p
            return math.log(p) if m == 1 else 0.0
    return 0.0
for i, n in enumerate(ns):
    print(f'{n:3d} {a[i]:+.6f} {THETA*Lam(int(n))/(2*math.sqrt(n)):+.6f}')
