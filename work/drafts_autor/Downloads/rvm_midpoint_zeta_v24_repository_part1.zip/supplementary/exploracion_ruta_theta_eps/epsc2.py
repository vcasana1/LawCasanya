#!/usr/bin/env python3
"""eps_c(M): largest eps such that F = D + chi D*, D = 1 + eps*sum_{2<=n<=M} n^{-s}, has all its zeros
in the strip with 2 <= t <= T on the critical line.  Real zeros: sign changes of Z(t) = 2 Re(e^{i theta} D(1/2+it)).
Total zeros: winding number of F around the rectangle [-0.5, 1.5] x [2, T]."""
import sys, numpy as np
from scipy.special import loggamma

T = float(sys.argv[1]); T0L = float(sys.argv[2])
Ms = range(2, 16)

def logchi(s):   # chi(s) = 2^s pi^(s-1) sin(pi s/2) Gamma(1-s)
    return s*np.log(2) + (s-1)*np.log(np.pi) + np.log(np.sin(np.pi*s/2)) + loggamma(1-s)
def D(s, M, eps):
    n = np.arange(2, M+1)[:, None]
    return 1 + eps*np.sum(n**(-s[None, :]), axis=0)
def F(s, M, eps):
    return D(s, M, eps) + np.exp(logchi(s))*D(1-s, M, eps)
def theta(t):
    s = 0.25 + 0.5j*t
    return np.imag(loggamma(s)) - 0.5*t*np.log(np.pi)
def real_zeros(M, eps, T):
    t = np.arange(T0L, T, 0.01)
    Z = 2*np.real(np.exp(1j*theta(t))*D(0.5+1j*t, M, eps))
    return int(np.sum(Z[:-1]*Z[1:] < 0))
def total_zeros(M, eps, T, h=0.004):
    a, b = -0.5, 1.5
    pts = np.concatenate([a + 1j*np.arange(T0L, T, h), np.arange(a, b, h) + 1j*T,
                          b + 1j*np.arange(T, T0L, -h), np.arange(b, a, -h) + 1j*T0L])
    f = F(pts, M, eps)
    d = np.angle(f[1:]/f[:-1]); d = np.append(d, np.angle(f[0]/f[-1]))
    return abs(int(round(np.sum(d)/(2*np.pi))))
print(f'T = {T}')
print(' M   eps_dom = 1/sum n^-1/2    eps_c (all zeros real on [2,T])   zeros')
for M in Ms:
    edom = 1/np.sum(np.arange(2, M+1)**-0.5)
    lo, hi = 0.0, 1.0
    if real_zeros(M, 1.0, T) == total_zeros(M, 1.0, T):
        ec = 1.0
    else:
        for _ in range(14):
            mid = (lo+hi)/2
            if real_zeros(M, mid, T) == total_zeros(M, mid, T): lo = mid
            else: hi = mid
        ec = lo
    print(f'{M:2d}   {edom:.4f}                  {ec:.4f}{"  (>=1)" if ec==1.0 else ""}      {real_zeros(M, ec, T)}/{total_zeros(M, ec, T)}')
