# Exploración numérica, 7–9 oct 2026, sobre rvm_midpoint_zeta v16

Scripts Python (numpy/scipy/mpmath). Ninguno modifica v16. El reloj se recalcula como
tau_k = 2 pi (k-11/8) / W_0((k-11/8)/e); srvm.py lee output/s04_rvm_prime_levels.csv de v16.

| script | qué hace | output |
|---|---|---|
| sx.py | S_X(t) con primos reales y corrección de forma Si: gamma_k vs tau_k, k=1..10 | tablas en el chat |
| srvm.py | la misma corrección con los primos RvM p_j^RVM de v16 (signo acierta 3/10) | output/srvm_output.txt |
| side.py | lado del cero respecto a tau_k por sgn((-1)^k Z(tau_k)); k=1..200, 0 fallos; j_k in {-1,0} | output/side_output.txt |
| s10_theta.py THETA [N] | s10 de v16 con objetivo (1-theta) sum cos(tau_k u) + theta k(u): test de existencia del camino theta | output/th1.txt, th05.txt, th025.txt, th01.txt, th002.txt, th05N30.txt, th1N30.txt |
| lin.py | mínimos cuadrados de la linealización en el reloj: D_tau no está en el rango (residuo 15-18 %, h ~ 1e10) | output/lin_output.txt |
| rs.py | ceros de Z_M(t) = 2 sum_{n<=M} cos(theta(t) - t log n)/sqrt n; M=1 reproduce tau_k | output/rs_output.txt |
| epsc.py T | eps_c(M) para F = D + chi D*, D = 1 + eps sum_{2<=n<=M} n^{-s}, ceros en [2,T] | output/ec100.txt, ec300.txt |
| epsc2.py T T0 | igual en la ventana [T0,T]; T0=10 excluye el par fuera de la recta de altura baja | output/ec300_10.txt |
| epsc3.py T T0 | igual con log chi estable y M<=30 | output/ec300_10b.txt, ec1000_10.txt |
| addfam.py | familia aditiva (1-eps)(1+chi) + 2 eps zeta: niveles de Q = -Z/cos theta; salidas y retornos en [10,200] | output/addfam_output.txt |

Resultados:
- Camino theta (masas atómicas en cada paso): sin solución para 0 < theta < 1; residuo del orden del objetivo
  (1.5 theta para theta pequeño, ~3 en theta = 0.25, 0.5). La obstrucción ya está en la linealización.
- Para theta pequeño las secciones finitas se tumban sobre la familia lambda: kappa_k ~ tau_k + theta (gamma_k - tau_k).
- Reloj = término n = 1 de Riemann-Siegel: ceros de Z_1 = 2 cos theta son 14.518, 20.654, 25.492, ... vs tau_k.
- eps_c(M) ~ (1.5-2.5) eps_dom(M) ~ M^{-1/2} -> 0 (eps_dom = 1/sum_{2<=n<=M} n^{-1/2}).
- Familia aditiva G_eps = (1-eps) zeta_RVM + eps zeta: ceros reales = conjunto de nivel Q(t) = Z/Z_RVM = -(1-eps)/eps.
  En [10,200]: 25 salidas de la recta (eps in [0.14,0.34]) y 25 retornos (eps in [0.37,0.73]). eps_c = 0.14.
