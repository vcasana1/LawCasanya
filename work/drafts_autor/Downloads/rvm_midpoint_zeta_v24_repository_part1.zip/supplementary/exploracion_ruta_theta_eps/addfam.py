# additive family F_eps = (1-eps)(1+chi) + 2 eps zeta ; on the line Z_eps = 2(1-eps)cos(theta) + 2 eps Z(t)
# real zeros = level set Q(t) = -Z/cos(theta) = (1-eps)/eps.  Collisions at negative local maxima of Q.
import numpy as np
from mpmath import mp, siegelz, siegeltheta, cos, mpf
mp.dps=8
t=np.arange(10.0,200.0,0.01)
Z=np.array([float(siegelz(x)) for x in t]); th=np.array([float(siegeltheta(x)) for x in t])
Q=-Z/np.cos(th)
# local maxima of Q (finite, negative), excluding poles (cos theta ~ 0)
ok=np.abs(np.cos(th))>0.02
i=np.arange(1,len(t)-1)
lm=i[(Q[i]>Q[i-1])&(Q[i]>Q[i+1])&ok[i]&(Q[i]<0)]
ln=i[(Q[i]<Q[i-1])&(Q[i]<Q[i+1])&ok[i]&(Q[i]<0)]
print('negative local maxima of Q (zeros leave the line) : count',len(lm))
for j in lm[:15]: print(f'  t={t[j]:.3f}  Qmax={Q[j]:.4f}  eps_leave={1/(1-Q[j]):.4f}')
print('negative local minima of Q (zeros return)         : count',len(ln))
for j in ln[:15]: print(f'  t={t[j]:.3f}  Qmin={Q[j]:.4f}  eps_return={1/(1-Q[j]):.4f}')
print('eps_c = first departure =', min(1/(1-Q[j]) for j in lm) if len(lm) else 1)
