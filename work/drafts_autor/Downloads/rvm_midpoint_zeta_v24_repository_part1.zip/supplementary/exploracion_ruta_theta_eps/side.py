from mpmath import mp, mpf, pi, log, e, lambertw, zetazero, siegelz, sin, sqrt, floor
mp.dps=15
def tau(k): return 2*pi*(k-mpf(11)/8)/lambertw((k-mpf(11)/8)/e).real
bad=0; js={}
for k in range(1,201):
    t=tau(k); g=zetazero(k).imag
    side = 1 if g>t else -1          # +1: gamma to the right of tau
    z=siegelz(t)*(-1)**k
    rs=sum(sin(t*log(n))/sqrt(n) for n in range(2,int(floor(sqrt(t/(2*pi))))+1))
    pred = 1 if z>0 else -1
    # j_k = N(tau_k)-k
    j=0
    if g>t:
        j=-1; kk=k-1
        while kk>=1 and zetazero(kk).imag>t: j-=1; kk-=1
    else:
        kk=k+1
        while zetazero(kk).imag<t: j+=1; kk+=1
    js[j]=js.get(j,0)+1
    if pred!=side: bad+=1; print('fail k',k,'j',j)
    if k<=10: print(k, float(g-t), float(z), float(rs), j)
print('fails',bad,'of 200; j distribution',js)
