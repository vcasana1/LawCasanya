import re, sys, os
tex = open(sys.argv[1]).read()
aux = sys.argv[2]
out = sys.argv[3]
nums = {}
if os.path.exists(aux):
    for m in re.finditer(r"\\newlabel\{([^}]*)\}\{\{(\{[^{}]*\}|[^{}]*)\}\{([^}]*)\}", open(aux).read()):
        nums[m.group(1)] = (m.group(2).strip("{}").replace("$",""), m.group(3))

GREEK = "alpha beta gamma delta epsilon varepsilon zeta eta theta vartheta iota kappa lambda mu nu xi pi varpi rho varrho sigma varsigma tau upsilon phi varphi chi psi omega Gamma Delta Theta Lambda Xi Pi Sigma Phi Psi Omega".split()
REP = [(r"\\CGeqref\{([^}]*)\}", r"(\1)"), (r"\\CGref\{([^}]*)\}", r"\1"),
       (r"\\langle", "<"), (r"\\rangle", ">"), (r"\\iff", "<=>"), (r"\\Rightarrow", "=>"), (r"\\setminus", "\\\\"),
       (r"\\subset", " in "), (r"\\Upsilon", " Upsilon"), (r"\\Subset", " in "), (r"\\NR", "N_RVM"), (r"\\RVM", "RVM"), (r"\\crit", "crit"), (r"\\vpi", "varpi_RVM"), (r"\\eps", "eps"),
       (r"\\le(?![a-z])", "<="), (r"\\leq", "<="), (r"\\ge(?![a-z])", ">="), (r"\\geq", ">="), (r"\\ne(?![a-z])", "!="),
       (r"\\to(?![a-z])", "->"), (r"\\longrightarrow", "->"), (r"\\Longrightarrow", "=>"), (r"\\Longleftrightarrow", "<=>"),
       (r"\\Leftrightarrow", "<=>"), (r"\\infty", "inf"), (r"\\cdot", "*"), (r"\\pm", "+-"), (r"\\times", "x"),
       (r"\\ll(?![a-z])", "<<"), (r"\\asymp", "~"), (r"\\sim", "~"), (r"\\equiv", "=="), (r"\\in(?![a-z])", " in "),
       (r"\\mid", "|"), (r"\\Re", "Re"), (r"\\Im", "Im"), (r"\\sum", "sum"), (r"\\prod", "prod"), (r"\\int", "int"),
       (r"\\log", "log"), (r"\\Log", "Log"), (r"\\exp", "exp"), (r"\\sin", "sin"), (r"\\cos", "cos"), (r"\\max", "max"),
       (r"\\min", "min"), (r"\\sup", "sup"), (r"\\lim", "lim"), (r"\\Ei", "Ei"), (r"\\li", "li"), (r"\\Res", "Res"),
       (r"\\Mell", "*Mel"), (r"\\partial", "d"), (r"\\mathcal\s*", ""), (r"\\mathscr\s*", ""), (r"\\mathfrak\s*", ""),
       (r"\\mathbf\s*", ""), (r"\\mathrm\s*", ""), (r"\\operatorname\*?\s*", ""), (r"\\widehat\s*", "hat "),
       (r"\\tilde\s*", "~"), (r"\\overline\s*", "conj "), (r"\\bar\s*", "conj "), (r"\\Z(?![a-z])", "Z"),
       (r"\\C(?![a-z])", "C"), (r"\\R(?![a-z])", "R"), (r"\\N(?![a-z])", "N"), (r"\\lfloor", "floor("),
       (r"\\rfloor", ")"), (r"\\pmod", "mod"), (r"\\quad|\\qquad", " "), (r"\\,|\\;|\\!|\\ ", " "),
       (r"\\left|\\right|\\bigl|\\bigr|\\Bigl|\\Bigr|\\biggl|\\biggr|\\big|\\Big", ""), (r"\\boxed", ""),
       (r"\\tfrac|\\dfrac", r"\\frac"), (r"\\text\s*", ""), (r"\\textup\s*", ""), (r"\\emph\s*", ""),
       (r"\\CGeqref\{([^}]*)\}", r"(\1)"), (r"\\CGref\{([^}]*)\}", r"\1"), (r"\\cite(\[[^]]*\])?\{[^}]*\}", "[ref]"),
       (r"\\xrightarrow\{[^}]*\}", "->"), (r"\\overset\{\?\}\{=\}", "=?"), (r"\\dots|\\cdots|\\ldots", "..."),
       (r"\\tag\{[^}]*\}", ""), (r"\\notag", ""), (r"\\nonumber", ""), (r"\\displaystyle", ""), (r"\\vee", "v"),
       (r"\\texttt\s*", ""), (r"\\ast", "*"), (r"\\varsigma", "varsigma"), (r"\\psi", "psi")]


def _arg(s, i):
    """parse one TeX argument starting at s[i:] (after skipping spaces): braced group, macro, or single char"""
    while i < len(s) and s[i] == " ":
        i += 1
    if i >= len(s):
        return "", i
    if s[i] == "{":
        depth = 0
        j = i
        while j < len(s):
            if s[j] == "{":
                depth += 1
            elif s[j] == "}":
                depth -= 1
                if depth == 0:
                    return s[i + 1:j], j + 1
            j += 1
        return s[i + 1:], len(s)
    if s[i] == "\\":
        m = re.match(r"\\[a-zA-Z]+", s[i:])
        if m:
            return m.group(0), i + len(m.group(0))
        return s[i:i + 2], i + 2
    return s[i], i + 1


def frac(s):
    """replace every \\frac A B (braced or not, nested or not) by (A)/(B), innermost first"""
    for _ in range(20):
        k = s.rfind("\\frac")
        if k < 0:
            break
        a, i = _arg(s, k + 5)
        b, j = _arg(s, i)
        s = s[:k] + "(" + a + ")/(" + b + ")" + s[j:]
    return s


def clean(s):
    s = re.sub(r"%.*", "", s)
    s = re.sub(r"\\label\{[^}]*\}", "", s)
    s = re.sub(r"\\begin\{[^}]*\}(\[[^]]*\])?|\\end\{[^}]*\}", " ", s)
    for a, b in REP:
        s = re.sub(a, b, s)
    s = frac(s)
    s = re.sub(r"\\sqrt\s*\{([^{}]*)\}", r"sqrt(\1)", s)
    for g in sorted(GREEK, key=len, reverse=True):
        s = re.sub(r"\\" + g + r"(?![a-zA-Z])", g, s)
    s = re.sub(r"\\[a-zA-Z]+\*?", "", s)
    s = s.replace("&", " ").replace("\\\\", "; ").replace("$", "").replace("~", " ")
    s = s.replace("{", "").replace("}", "").replace("\\", "")
    s = re.sub(r"\s+", " ", s).strip()
    if len(s) > 300:
        s = s[:297] + "..."
    s = s.replace("#", "no.").replace("%", " pct")
    s = s.replace("_", r"\_").replace("^", r"\textasciicircum{}")
    return s


ENVS = {"theorem": "Theorem", "proposition": "Proposition", "lemma": "Lemma", "corollary": "Corollary",
        "definition": "Definition", "hypothesis": "Hypothesis", "remark": "Remark", "experiment": "Experiment",
        "conjecture": "Conjecture"}
tips = {}
for m in re.finditer(r"\\label\{([^}]*)\}", tex):
    lab = m.group(1)
    pos = m.start()
    num, page = nums.get(lab, ("", ""))
    before = tex[:pos]
    if lab.startswith(("sec:", "subsec:", "app:")):
        h = re.findall(r"\\(section|subsection|subsubsection)\*?\{(.*)\}", before[-400:])
        title = clean(h[-1][1]) if h else lab
        tips[lab] = "Section %s: %s (p. %s)" % (num, title, page)
    elif lab.startswith("eq:") or lab.startswith("exp") is False and False:
        pass
    if lab.startswith("eq:"):
        b = max(before.rfind(r"\begin{equation}"), before.rfind(r"\begin{align}"))
        e = tex.find(r"\end{", pos)
        body = tex[b:e]
        body = re.sub(r"\\begin\{(equation|align)\}", "", body)
        if r"\begin{align}" in tex[b:b + 15]:
            seg = body.split("\\\\")
            for sg in seg:
                if lab in sg:
                    body = sg
        tg = re.search(r"\\tag\{([^}]*)\}", body)
        if tg and not num:
            num = clean(tg.group(1))
        tips[lab] = "Eq. (%s), p. %s: %s" % (num, page, clean(body))
    elif lab.startswith(("fig:", "tab:")):
        c = tex.rfind(r"\caption{", 0, pos)
        tips[lab] = "%s %s (p. %s): %s" % ("Figure" if lab.startswith("fig") else "Table", num, page,
                                           clean(tex[c + 9:pos]))
    elif not lab.startswith(("sec:", "subsec:", "app:")):
        mm = list(re.finditer(r"\\begin\{(\w+)\}(\[(.*?)\])?", before[-1500:]))
        if mm:
            env = mm[-1].group(1)
            title = mm[-1].group(3) or ""
            e = tex.find(r"\end{" + env + "}", pos)
            body = clean(tex[pos + len(lab) + 8:e])
            tips[lab] = "%s %s%s (p. %s): %s" % (ENVS.get(env, env.capitalize()), num,
                                                 (" (" + clean(title) + ")") if title else "", page, body)
with open(out, "w") as f:
    f.write("\\makeatletter\n")
    for k, v in tips.items():
        f.write("\\expandafter\\gdef\\csname CGTip@%s\\endcsname{%s}\n" % (k, v))
    f.write("\\makeatother\n")
print(len(tips), "tips")
