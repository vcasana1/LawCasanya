# Changes from v23 to v24 (14 October 2026)

Manuscript: `rvm_zeta_pi_mertens_v24.tex` (251 pages; v23 had 198). Page numbers below are those of the v24 PDF.
Section numbers from Section 5 on are those of v23 plus one; the appendices A-E of v23 are B-F of v24.

## Sources of the new material

* The project notes `notas-v24-*` (cosine difference, transport chain, counterexample to transport, crossing point and
  convexity, estimate of E and contraction, arithmetic of both sides, Beurling and RVM primes, Franca-LeClair, DOIs) and
  `prueba-varpi-rvm-menor-1`.
* The conversation on the centroid of `exp(i gamma_k)` and the author's four texts: the derivation (1)-(8) of the
  residual `R_phi` (plain and LaTeX), the note "one cell / Hilbert", and the note "window, Q and HQ". Copies in
  `review/v24_notes/`.

## Front matter

* Date "14 October 2026 -- version 24"; PDF subject and keywords extended (exponential sums, Cramer function, RH).
* Abstract rewritten (p. 1): attribution of the clock and Lambert formula to Franca and LeClair; new paragraph
  "Exponential sums over the ordinates" with the new equivalent forms of RH; paragraph "Tables"; the not-proved list
  includes the imaginary-frequency, window and cell criteria.
* Notation table: new block "Exponential sums over the ordinates" (`rho_k`, `d_k`, `fhat`, `V_+`, `Z_gamma`, `Z_tau`,
  `Z_xi`, `X`, `g` and the pieces of the zero-free representation, `Y`, `Q_K`, `Q_infinity`, the centroids, `b_k`,
  `f(lambda)`, `lambda*`).

## Introduction

* New Subsection 1.2 "Known results on the Riemann-von Mangoldt law, the ordinates and the clock" (p. 10): the RvM
  formula, `S(T)` bounds, Landau's formula, Hlawka's theorem, Cramer's function, Gram points, verified computations,
  the Mertens literature, Franca-LeClair, Beurling systems satisfying RH; each stated as a known theorem with reference.
* Subsection 1.3: the Lambert paragraph now attributes the clock, the constant 11/8 and the inversion to Franca and
  LeClair (arXiv:1307.8395, Sec. III.A, Eqs. (24)-(25)).
* New Subsection 1.5 "Exponential sums over the ordinates and the Riemann hypothesis" (p. 15): items (a)-(g).
* Subsection 1.6: status table with thirteen new rows (clock centroid, zero-free representation, imaginary frequency,
  window, rung functional, one cell, finite set off the line, Frullani, Tauberian lemma, centroid under RH, crossing
  point, kappa family, first 1000 values); the not-proved list extended with the new equivalent forms.
* Subsection 1.7: organization updated for Section 5 and Appendix A.

## Section 2

* After the proof of Proposition 2.1: the Lambert equation and its solution are Eqs. (24)-(25) of Franca-LeClair;
  here they define the clock exactly.

## Section 4

* Corollary 4.2: the path centroid converges by a second summation by parts (Theorem 5.13).

## New Section 5 (pp. 23-31): exponential sums over the ordinates of zeta

* 5.1 The ordinate transform and Cramer's function: Proposition 5.1 (pair decomposition of the defect
  `X = -sum (cosh(w d_k) - 1) exp(i w gamma_k)`), Proposition 5.2 (RH at one imaginary frequency `y_0` in `(0, 4 pi]`),
  Proposition 5.3 (zero-free representation of `V_+` on `Omega_theta`, with `2 Re V_+(u) = e^u - (e^{2u}-1)^{-1}` on
  `(log 2, log 3)`; complete contour proof).
* 5.2 The window form of RH: Lemma 5.4 (vanishing boundary values, edge-of-wedge by repeated primitives and Schwarz
  reflection), Theorem 5.5 (window theorem with the exact residual over the zeros off the line, equivalence with the
  distributional convergence of the triangular centroids), Remark 5.6.
* 5.3 One window is one cell: Theorem 5.7 (`R_f(0) - (1/2) sum Lambda(n) n^{-1/2} f(log n) = <Y, f>`; equivalently
  `(log x)(dJ^M_Z1 - dJ)/dx = 2 x^{-1/2} Y(log x)`; the cosine difference `S_f(0) = R_f(1) - <Y, f>`), Corollary 5.8
  (real part of the window = cell (2,3); RH = cell (2,3) + sine identity), Remark 5.9 (the conjugate part is not local;
  Hilbert transform), Proposition 5.10 (finitely many zeros off the line imply that every cell fails), Theorem 5.11
  (Frullani form `Q_infinity = log L + log varpi_Z1`), Remark 5.12.
* 5.4 Centroids of the two spectra: Theorem 5.13 (the clock centroid converges, rate `O((log N)^2/N)`), Lemma 5.14
  (local Tauberian lemma, self-contained proof), Theorem 5.15 (under RH the ordinate centroid tends to
  `exp(-u/2) V_+(u)`; at `u = 1` the value `0.77689426079... + 0.76785566886... i`), Remark 5.16.

## Section 15

* New Subsection 15.5 "The crossing point of the family and what convexity can give" (p. 77): Proposition 15.13
  (crossing point, chord and tangent inequalities, `lambda* < 1.95e-11` with the verified zeros), Remark 15.14 (limits
  of convexity), Proposition 15.15 (a family with the same properties and `varpi_0 > 1`; rigorous bound
  `varpi_RVM > 0.7958` and `kappa_1 = 12.6` gives `varpi_0 > 1.056`).

## Section 19 (numerics)

* New Subsection 19.5 (p. 136): Experiment 19.7 (Cramer's function from the zero-free representation, `a = 1, 2`;
  centroids with 2,001,052 zeros; limit of the clock centroid), Experiment 19.8 (walks), Figures 10-11 (walks of
  `exp(i gamma_k)`, `exp(i tau_k)`, `exp(i (gamma_k + tau_k)/2)` in three dimensions, `k` vertical; projection).
* New Subsection 19.8 (p. 142): Experiment 19.13 (the first 1000 values), Figures 18-21.
* Experiment 19.14 (transport): the value `R_f(0) = -1.4e-11` is now identified, by Theorem 5.7, as the truncation at
  20000 ordinates, not the sum over the zeros off the line.

## Section 20 (conclusions)

* "New in this paper" rewritten with the attribution to Franca-LeClair and the new results of Sections 5 and 15.5.
* New items (41)-(50); (41) assumes RH explicitly, all others are unconditional.
* The list "Equivalent to (D) and not proved" and the dependence table extended.
* Three new open problems (direct proof of the window identity; convergence of the centroid without RH; a contracting
  Frullani kernel).

## Appendices

* New Appendix A "Tables of the first 1000 values" (pp. 155-180): Tables 12-15 (`tau_k` vs `gamma_k`, `p_j^RVM` vs
  `p_j`, `pi_RVM(n)` vs `pi(n)`, `M_RVM^crit(n)` vs `M(n)`).
* Appendix B: listings of `s15_tables_1000.py`, `s16_walks_3d_1000.py`, `s17_cramer_centroids.py` (B.16-B.18).
* Appendix C: their console outputs (C.13-C.15).

## Bibliography

* 28 new references with DOIs verified on publisher pages and OpenAlex (Cramer 1919, Landau 1912, Gonek 1993,
  Debruyne-Vindas 2019, Korevaar 2004, Franca-LeClair 2015, Hasanalizade-Shen-Wong 2022, Bellotti-Wong 2025,
  Trudgian 2011/2014, Littlewood 1924, Hutchinson 1925, Brent 1979, Platt 2017, Hlawka 1975 (no DOI),
  Ford-Zaharescu 2005, Guillera 2013, Hurst 2018, Kotnik-van de Lune 2004, Ng 2004, Zhang 2013,
  Broucke-Debruyne-Revesz 2025, Hilberdink-Lapidus 2006, Balazard-Saias-Yor 1999, Volchkov 1995,
  Sekatskii-Beltraminelli-Merlini 2012, Davenport-Heilbronn 1936 (two papers)).
* Platt-Trudgian 2021: journal DOI 10.1112/blms.12460 and pages 792-797.

## Code, data and tools

* New `code/s15_tables_1000.py` (needs `finufft`), `code/s16_walks_3d_1000.py`, `code/s17_cramer_centroids.py`;
  outputs in `output/s15_*`, `output/s16_*`, `output/s17_*`; figures `figures/fig20_*`-`fig25_*`.
* New `matlab/s15_tables_1000.m`, `matlab/s16_walks_3d_1000.m`; `.txt` copies in `code/txt/` and `matlab/txt/`.
* `tools/make_tips.py`: tooltips now render `\CGref`, `\CGeqref`, `\langle`, `\rangle`, `\iff`, `\Subset`, `\Upsilon`.
* `run_all_python.sh` runs `s01`-`s17`; `code/requirements.txt` adds `finufft`.
* `data/zeross.bin`, `data/zLamb.bin` and `output/s05_walks.csv` are not included (see `data/README.md`).
* The v23 manuscript is kept in part 2, `previous_versions/v23_manuscript/`.
