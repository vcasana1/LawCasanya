# V23 changelog (12 October 2026)

One substantive change: the inequality `varpi_RVM < 1`, Hypothesis 8.5 up to v22, is proved. Source: the external
review of v22 kept in `review/v22_reviews/review1_varpi_reduction.md` (R7), which observed that
`P_RVM^crit(1/2) < 1` reduces the inequality to `nu_3 + nu_4 <= 0`, and asked for the exact definitions of
`nu_3`, `nu_4` to finish it. Numbers and pages are those of the v23 PDF (198 pages).

## The theorem

Theorem 8.11 (`thm:varpi-less-one`, p. 32), placed after Theorem 8.10 (`halfplane-RVM`, which gives the closed
form `nu_4 = -2 int s_1(tau)/tau^2 dtau`):

* (a) `P_RVM^crit(1/2) = prod tau_k^2/(1/4 + tau_k^2)` lies in `(0,1)`; no value is used.
* (b) `nu_3 = nu_1 - nu_2 = 8 - (33/4) log 2 - 2 log pi = -0.0079240113...` (new `eq:nu3-closed`), from
  `int_0^{4 pi} log(tau/2 pi e) dtau = 4 pi log 2 - 8 pi`; the sign is `e^8 < 2^{33/4} pi^2`.
* (c) `nu_4 = -2 lim int_{tau_0}^X psi(N_RVM + 1/2) dtau/tau` (`eq:nu4-limit`). On `[tau_0, tau_1)` the sawtooth
  equals `N_RVM` (since `0 < N_RVM(tau_0) < 1/2`), giving the explicit piece `I_0(tau_1)` (`eq:nu4-I0`); on each
  later period the substitution `u = N_RVM + 1/2` gives `int_n^{n+1} (u - n - 1/2) W(u) du` with the clock weight
  `W(u) = 2 pi/(T log(T/2 pi))` (`eq:nu4-weight`), decreasing and convex. Euler-Maclaurin on each period with
  `max |B_3| = sqrt3/36` gives `nu_4 <= -2 M(tau_1)`, `M(t) = I_0(t) - pi/(6 t l) - (sqrt3/216) 4 pi^2 (l+1)/(t^2 l^3)`
  (`eq:nu4-bound`).
* (d) `tau_1` in `[14.52134, 14.52135]`; `M(tau_1)` in `[0.0063457, 0.0063526]`; `nu_4 <= -0.0126914`.
* (e) `log varpi_RVM < -0.0206154`, `varpi_RVM < 0.97960`.

The explicit inequalities of (b) and (d) are verified in interval arithmetic (mpmath.iv, 40 digits, outward
rounding) by the new program `code/s14_varpi_bound.py`; its console output is `output/s14_varpi_bound_console.txt`.
The margins also allow a five-decimal hand check. Remark 8.12 (`rem:varpi-values`) records the floating-point values
of Part B of the program (not part of the proof): `nu_4 = -0.0251569083`, `exp(nu_3 + nu_4) = 0.9674602699`,
`P(1/2) = 0.9942956924`, `varpi_RVM = 0.9619415789`, against the Richardson value 0.9619415807 obtained without
`nu_3`, `nu_4` (an independent check of `eq:varpi-def` and `eq:nu4-closed`).

Correction of v22: the paragraph "What a proof of the hypothesis would require" quoted `P(1/2) ~ 0.9940` and
`exp(nu_3 + nu_4) ~ 0.9676`; the values are `0.99430` and `0.96746`. That paragraph is removed with the hypothesis.

## Consequences in the text

| Place | Change |
|---|---|
| Abstract (p. 2) | "with one exception ... conditional" replaced: every statement is proved without hypothesis, including `varpi_RVM < 1`; it was a hypothesis up to v22. The sentence on "the single numerical hypothesis" removed. |
| Subsection 1.4 (p. 14) | `varpi_RVM < 1` removed from "what this paper does not prove"; the only computer-assisted element is the interval evaluation in Theorem 8.11. Status table: new row for Theorem 8.11; the open-path row is now a theorem. "Not proved" list: the open-path equivalence uses Theorem 8.11. |
| Notation (p. 5) | `varpi_RVM < 0.9796`; new row for `W`, `I_0`, `I_n`, `M`, `B_2`, `B_3` (names chosen free of collisions: `w`, `I_n`, `m` are taken); `nu_3` closed form referenced. |
| Section 8 | Hypothesis 8.5 and its two paragraphs removed; Theorem 8.11 and Remark 8.12 added after Theorem 8.10; the sentence after `eq:varpi-def` points to Theorem 8.11. |
| Proposition 13.16(ii) (`atomized-clock`) | `h_1(sigma) -> log L > 0` by Theorem 8.11. |
| Remark after Corollary 14.8 (`positivity`) | `varpi_RVM < 1` at the clock end by Theorem 8.11. |
| Proposition 14.10 (`one-number`) | `W(1) > 0` unconditionally. |
| Proposition 14.12 (`open-path-varpi`, p. 66) | No hypothesis in the statement; (i)=>(ii) uses Theorem 8.11 (the case `lambda = 1` of (ii)); proof cites it. |
| Corollary 14.35 (`ladder-pair`) | The first rung fails at the clock end, by Theorem 8.11. |
| Experiment 18.5 (`varpi-bound`, p. 123) | New: Part A (interval verification) and Part B (floating-point values). |
| Appendix A.15 / B.12 | Listing of `s14_varpi_bound.py` and of its console output. |
| Section 19 (p. 133) | "New in this paper" includes the closed form of `nu_3` and `varpi_RVM < 1`; "Conditional on the one hypothesis" replaced by "No unproved hypothesis" (the five former uses listed; the only hypotheses left are (D) where it is assumed explicitly and the existence of a solution in Proposition E.2); dependence table and list item (7) updated; "open" no longer lists `varpi_RVM < 1`. |
| Repository | `code/s14_varpi_bound.py`, `output/s14_varpi_bound_console.txt`, `run_all_python.sh`, README v23 section, `review/v22_reviews/`. |
