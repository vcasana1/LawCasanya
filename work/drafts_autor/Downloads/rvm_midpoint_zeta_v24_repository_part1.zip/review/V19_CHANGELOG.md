# V19 changelog (10 October 2026)

See README.md, section "v19: route B for finite sections". Summary of changes to the TeX:

1. New Section 17 "Route B for finite sections: compactness, prescribed masses, certificates, and a
   Kadec-Avdonin criterion with blocks of variable length" (from lemas_B_v4), inserted before the
   numerical illustration (now Section 18). 8 subsections, 2 figures, 3 tables, status table 17.8.
2. Abstract: one paragraph added; abstract moved after \maketitle so it can break across pages
   (in v18 the end of the abstract was cut off).
3. Introduction: status table rows for Section 17; Organization paragraph updated.
4. Notation: new block "Route B for finite sections" (all Section-17 symbols; no collision with the
   global table).
5. Bibliography: 17 entries added (Arias de Reyna 2024, Avdonin 1974, Avdonin-Ivanov 2002, Fujii 1974/1975/1975b,
   Garnett 2007, Gonek 2012, Guinand 1948, Hormander 1990, Kadec 1964, Lyubarskii-Seip 1997,
   Montgomery-Vaughan 1974, Selberg 1946, Weil 1952, Whittaker-Watson 1927, Zemanian 1965), with DOIs where they exist.
6. Appendices C and D: Python programs of Section 17 and their console outputs.
7. Tooltips regenerated; 0 overfull boxes, 0 undefined references; 179 pages.

Changes of lemas_B from v3 to v4 (all incorporated in Section 17):
- Hypothesis (L) replaced by two lemmas (Archimedean distribution; Laplace transform of the residual).
- Hypothesis E (extension lemma) replaced by the certificate theorem (Newton-Banach, frozen right inverse),
  the staged theorem, the graded extension and the monotone matching lemma.
- New subsection on Gonek's symmetrised Euler products and the tube lemma.
- New section of numerical certificates with two figures.
- Fujii's theorem used only as the upper bound it contains; Hadamard step of the obstruction theorem
  rewritten; tails of Step 3(b) written out; Selberg normalisation cited; Jensen endpoint argument;
  LF topology; matching lemma; upsilon < infinity; g_+/g_-; growth split; argument-principle multiplicities;
  Kadec L_0 indices; displacement of gamma cited from the main paper; remark on Arias de Reyna.
- Notation aligned with the main paper (all collisions renamed).
