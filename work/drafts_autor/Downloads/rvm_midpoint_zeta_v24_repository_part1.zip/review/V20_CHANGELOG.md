# V20 changelog (11 October 2026)

Correction release. Every change answers one point of the second audit of v19 (twenty points). Labels are
those of the TeX source; numbers are those of the v20 PDF.

| # | Audit point | Place changed | What was done |
|---|---|---|---|
| 1 | `prop:rb-graded` false with its hypotheses (`prod q_m = 0` does not give `prod_{j>=L} q_j -> 0`) | Proposition 17.23, new `eq:rb-graded-tail` | Hypothesis replaced by `prod_{j=L}^m q_j -> 0` for every `L`; sufficient conditions `q_m <= q < 1` eventually, or `sum (1-q_m) = inf`; proof rewritten; the counterexample `q_1 = 0`, `q_m = 1` recorded. |
| 2 | Gonek lemma: index shift of one unit in the wrong direction | Lemma 17.26, `eq:rb-aux-15`, `eq:rb-aux-17` | `j_X := j_0 + 1`; `Theta_X(kappa_k) = pi(k - 3/2)` for `k > j_X`; `N_RVM(kappa_k) = k - 1/2 - p_X/pi + r_theta`; the sentence "after replacing j_X by j_X - 1" removed. |
| 3 | `lem:rb-matching`: free variable `K` | Lemma 17.18 | `tau_K` -> `tau_{k*}` in statement and proof. |
| 4 | Lipschitz proof of `thm:unit-cell`: `alpha`/`eps` and `Psi`/`Phi` mixed | Theorem 6.1 proof; proof of Theorem 14.15 (clock density) | Abel parameter is `alpha` throughout; phases are `Psi_m^+-` throughout; the generic phase of the derivative tests is `varTheta`; the stationary-phase function `t log t - t` is renamed `varXi` to avoid `Psi`. |
| 5 | `thm:cell-form`: "the exponential ... is one" | Theorem 12.7 proof | "is again an absolutely convergent Dirichlet series". |
| 6 | `varpi_RVM < 1` used as proved | new Hypothesis 8.5 `hyp:varpi-less-one` (after the proof of Theorem 8.1); Proposition 13.15(ii) and its proof; Proposition 14.10 (`W(1) > 0`) and its proof; Proposition 14.12 statement and proof; intro status table; "Not proved" list; conclusions item | The inequality is an explicit hypothesis, numerically supported and not proved; its equivalent form as an ordered product (Theorem 12.1) is recorded; the three uses say so; Proposition 14.12 states which implications survive without it ((ii) contains the hypothesis as its case `lambda = 1`). |
| 7 | Appendix E: pairing an identity in `D'(0,inf)` with `e^{-(s-1/2)u}` | Proposition E.2 statement and proof; new `eq:rung-apriori-b-v18`, `eq:rung-laplace-S-v18`, `eq:rung-E-v18`, `eq:rung-laplace-identity-v18` | Each term extended to a distribution supported in `[0,inf)` as in Lemma 17.11; the difference is supported at `0`, its transform is a polynomial `p`; `p` is a constant `b` because the left side is `O(sigma^{eps_0})` on the real axis; factor `e^{2 b s}` carried through the growth and Jensen steps (`A_2 |b|` in the count bound). |
| 8 | Appendix E: mean-square bound on the masses asserted, not derived | Proposition E.2 hypothesis `eq:rung-apriori-mass-v18`; Remark E.3 | Made an explicit hypothesis; the remark says where it is a theorem (the lists `gamma_k(lambda)`, Theorem 13.10) and that it is not derived for general lists. |
| 9 | Appendix E: uniformity of `C*` and the "finitely many remaining indices" | Proposition E.2 statement; last paragraph of the proof | `C*` depends on the density and mass constants (one fixed `eps_0 < 1/4`), on `sum kappa_k^{-2}` and on `|b|`; the count bound holds for all `T >= 0`, so `kappa_k <= tau_{k_0} + C*_0` for `k < k_0` and the initial indices are absorbed uniformly. |
| 10 | "Certified" sections with floating point and no interval arithmetic | Section 17.7.1 set-up, 17.7.4 (retitled "Floating-point candidate certificates for exact square sections"), 17.7.5, 17.7.6(i), Figure 17.2 caption, status table 17.8, intro status table, abstract | Status changed to candidate certificates / floating-point evidence; "certified" no longer used for these results. |
| 11 | Gaussian tests are not in `C_c^inf(0,inf)` | Section 17.7.1 | Stated; the compactly supported alternative (`phi chi`) and the Schwartz extension named as what would be needed; neither done. |
| 12 | Right-inverse geometry (`t_m <= k*_m`) vs the overdetermined runs (`t_m >= k*_m`) | Section 17.7.2 (receding horizon), 17.7.4, Heuristic 17.25 | Overdetermined runs are least squares with a left inverse; the theorem applies to the square systems only; said at each place. |
| 13 | Kadec--Avdonin symbols (`J_m`, `N_m`, `V`, `d`, `L`, `g`) | Proposition 17.44, Corollary 17.45, Theorem 17.46 and proofs, Proposition 17.50 proof | `frak J_m`, `frak n_m`, `bb V`, `d_*`, `1 - 2 d_*`, `frak g_1`; the application of Proposition 17.44 inside the proof of Theorem 17.46 states its data. |
| 14 | `H(T) = 16 C_2 log T` needs `C_2 > 0` | Proposition 17.50 | Stated, with the remark that it is no restriction. |
| 15 | Transfer of results to all of `O` too compressed | new Theorem 15.1 `thm:transfer-O` (replaces the one-sentence claim after `eq:list-space`) | Result-by-result list of the inputs used (tube, ordering, threshold, third condition) and of the uniform constants; the `lambda`-derivative statements excluded. |
| 16 | Strict convexity needs `eta_k != 0` | Proposition 13.2 proof (`Upsilon' < 0`); Proposition 14.2 proof | `gamma_1 < 14.14` (rigorous classical location, Titchmarsh Ch. XV) and `N_RVM(14.14) = 0.4499... < 1/2 = N_RVM(tau_1)`, so `eta_1 > 0`; the formal version `>= 0`, strict iff `gamma != tau`, recorded. |
| 17 | Two-edge model: non-periodicity needs to exclude `e^{az+b}` | Proposition 16.2(i) proof | Hadamard gives `S(z+y) = e^{az+b} S(z)`; the dominant exponential as `Im z -> +inf` forces `a = 0`; then the coefficient comparison as before. |
| 18 | Exact Hadamard product: constant factor | Theorem 9.1 proof | The absence of a constant factor tied to `2 xi(0) = 1` (`q(0) = 0`, `Pi_zeta(0) = 1`). |
| 19 | `rem:hypothesis-X`: step function alone is not Hamburger's hypothesis | Remark 14.13 | The jump-growth condition `sum_{n<=X} |b_n| = O(X^{1+eps})` of Theorem 12.7 added. |
| 20 | "Three groups" vs four enumerated | Introduction | "Four groups". |

Other changes: the abstract no longer carries a version note ("A final section treats route B ..."); date line
"11 October 2026 -- version 20"; tooltips regenerated (886 labels); 0 overfull boxes, 0 undefined references;
182 pages. `build_pdf.sh`, `BUILD.md`, `REPOSITORY_CONTENTS.md` and `README.md` updated to v20. Code,
outputs and figures unchanged from v19.

Companion note: the corrections to Section 17 are made in the paper only. `supplementary/lemas_B_v4/` is kept as
the record of the material incorporated in v19 and is superseded by Section 17 of v20; no lemas_B_v5 is issued.
