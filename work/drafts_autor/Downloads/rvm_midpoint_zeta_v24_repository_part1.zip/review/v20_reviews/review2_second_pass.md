# Segunda revisión externa de v20 (recibida 2026-10-11) — material para v21

Texto literal. Comprobado sobre el fuente v20: los tres puntos A, B, C son reales.
- A: cor:rb-D-implies-B (línea ~4792) tiene \gamma_K, \tau_{K+1} y 'k^*_m,N_m can be chosen'; cambiar a \gamma_{k^*}, \tau_{k^*+1}, k^*_m,n^*_m.
- B: línea ~3632 (párrafo tras thm:positivity): 'At the clock end \varpi_RVM<1, and the density of dJ_RVM ...' -> condicionar a Hypothesis 8.5 (hyp:varpi-less-one) y separar la afirmación sobre la densidad, que no depende de la hipótesis.
- C: Apéndice E, Prop. E.2, paso 'Zero count': escribir el lema de conteo acumulativo N_kappa(T) = vartheta(T)/pi + 1 + O(log(2+T) + B_2 + |log C_theta| + |b|) con el rectángulo estándar (principio del argumento, como en lem:rb-argument / thm:rb-count de la Sección 17.4, que ya lo hace para cuasisoluciones), y restar el mismo resultado para RVM.

---

La v20 corrige casi todos los problemas importantes que señalé en v19. Tras revisarla otra vez sin internet y sin cálculos numéricos nuevos, **ya no veo ningún error estructural comparable al antiguo `rb-graded`**. Sí quedan dos errores concretos, una incoherencia y un punto demostrativo que conviene reforzar.

### 1. Sigue sin corregirse un error de variables en `cor:rb-D-implies-B`

En la prueba se define la truncación mediante \(k^*,n^*\), pero todavía aparece:

\[
\{\gamma_1,\dots,\gamma_K\}
\cup
\{\tau_{K+1},\tau_{K+2},\dots\}.
\]

Ese \(K\) no está definido ahí. Debe ser

\[
\boxed{
\{\gamma_1,\dots,\gamma_{k^*}\}
\cup
\{\tau_{k^*+1},\tau_{k^*+2},\dots\}.
}
\]

Y al final sigue apareciendo:

\[
k_m^*,N_m\ \text{can be chosen}.
\]

El segundo parámetro definido es \(n^*\), no \(N\). Debe ser

\[
\boxed{k_m^*,n_m^*}.
\]

Éste es el mismo residuo editorial de v19 que no se ha corregido.

---

### 2. Queda una afirmación incondicional de \(\varpi_{\rm RVM}<1\)

La corrección general de v20 está bien hecha: ahora existe explícitamente

\[
\text{Hypothesis 8.5:}\qquad \varpi_{\rm RVM}<1,
\]

y el texto explica correctamente que el valor \(0.9619415807\ldots\) es soporte numérico, **no una certificación rigurosa**.

También `prop:open-path-varpi` está correctamente condicionada.

Pero queda esta frase más adelante:

> “At the clock end \(\varpi_{\rm RVM}<1\), and the density of \(dJ_{\rm RVM}\)...”

Así escrita vuelve a afirmarlo como hecho.

Debe decir, por ejemplo,

\[
\boxed{\text{“Under Hypothesis 8.5, at the clock end }\varpi_{\rm RVM}<1\text{, ...”}}
\]

o separar la segunda afirmación, que no depende necesariamente de esa hipótesis.

---

### 3. Appendix E está ahora esencialmente reparado, pero el paso de conteo necesita desarrollarse

La nueva versión arregla correctamente el defecto serio anterior. Ahora construye

\[
\mathscr E
=
\mathscr S_{\boldsymbol\kappa}
-(1-\theta)\mathscr S_{\boldsymbol\tau}
-\theta\mathscr K+\mathscr A,
\]

observa que

\[
\operatorname{supp}\mathscr E\subset\{0\},
\]

y obtiene

\[
\mathcal L\mathscr E=p(s-\tfrac12).
\]

Luego demuestra que \(p\) es constante:

\[
p\equiv b,
\]

y conserva correctamente el término

\[
e^{2bs}
\]

en

\[
P_{\boldsymbol\kappa}(s)
=
C_\theta
G(s)\zeta_{\rm RVM}(s)^{1-\theta}
Y_\theta(s)e^{2bs}.
\]

Esto **sí corrige mi objeción principal a Appendix E de v19**.

También se ha corregido acertadamente otro problema: ahora

\[
\sum_{X<n\le2X}|a_n|^2\ll X^{1+\varepsilon}
\]

es una **hipótesis explícita** de la proposición y el remark dice que no se deriva de la mera densidad local.

Y también está arreglada la uniformidad de los índices iniciales.

Lo único que aún veo insuficientemente desarrollado es este salto:

> “Apply Backlund's form of Jensen's argument to \(P_{\boldsymbol\kappa}\) ... in a disc centred at \(2+iT\) with fixed radii ... [this] gives
> \[
> |N_{\boldsymbol\kappa}(T)-N_{\rm RVM}(T)|
> \le A^*\log(2+T)+\cdots.
> \]”

Un **disco de radio fijo alrededor de \(2+iT\)** controla el número local de ceros y/o la variación de argumento a altura \(T\). No cuenta directamente todos los ceros entre \(0\) y \(T\).

La conclusión

\[
N_{\boldsymbol\kappa}(T)
=
N_{\rm RVM}(T)+O(\log T)
\]

es perfectamente compatible con el argumento estándar de Riemann–von Mangoldt/Backlund, porque ya tienes:

- ecuación funcional;
- crecimiento de orden uno;
- control en \(\Re s=2\);
- control del argumento a altura \(T\).

Pero hay que escribir el **contorno acumulativo / principio del argumento** que convierte el control local del argumento en el conteo hasta \(T\).

Yo no retiraría la proposición por esto, pero sí añadiría un pequeño lema, algo del tipo:

\[
\boxed{
N_{\boldsymbol\kappa}(T)
=
\frac{\vartheta(T)}{\pi}+1
+O\!\left(
\log(2+T)+B_2+|\log C_\theta|+|b|
\right).
}
\]

Y demostrarlo con el rectángulo estándar. Entonces, restándolo del mismo resultado para RVM,

\[
N_{\boldsymbol\kappa}(T)-N_{\rm RVM}(T)=O(\log T)
\]

sale inmediatamente y Appendix E queda realmente cerrada.

---

## 4. `rb-graded`: corregido

Aquí v20 está bien.

Ahora se supone precisamente

\[
\boxed{
\prod_{j=L}^{m}q_j\longrightarrow0
\qquad\forall L,
}
\]

y además se explica explícitamente por qué

\[
\prod_{m\ge1}q_m=0
\]

no bastaría, incluso con el contraejemplo

\[
q_1=0,\qquad q_m=1\quad(m\ge2).
\]

La prueba de convolución

\[
s_m
\le
s_1\prod_{j<m}q_j
+
\sum_{\ell<m}h_\ell
\prod_{\ell<j<m}q_j
\]

está ahora bien.

**Éste era el único enunciado de v19 que había identificado como directamente falso, y está reparado.**

---

## 5. Gonek: corregido

También está bien arreglado.

Ahora se define

\[
j_X=j_0+1
\]

y se explica expresamente:

> “the choice \(j_X=j_0+1\), and not \(j_0\), is what makes the two counts agree”.

Entonces se obtiene correctamente

\[
N_{\rm RVM}(\kappa_k^{(X)})
=
k-\frac12
-\frac{p_X(\kappa_k^{(X)})}{\pi}
+r_\vartheta(\kappa_k^{(X)}),
\]

que se compara con

\[
N_{\rm RVM}(\tau_k)=k-\frac12.
\]

Corregido.

---

## 6. `lem:rb-matching`: corregido

Ahora aparece correctamente

\[
j
=
\#\{k>k^*:\tau_k\le\tau_{k^*}+C\}.
\]

Ya no existe el \(K\) libre que tenía v19.

La prueba posterior también utiliza \(\tau_{k^*}+C\).

---

## 7. Prueba Lipschitz de \(J_{\rm RVM}\): corregida

Ahora el amortiguador es consistentemente

\[
\alpha
\]

desde

\[
g(\tau)=e^{(iv-\alpha)\tau}
\]

hasta

\[
K_m^\pm
=
\int(iv-\alpha)e^{-\alpha\tau}
e^{i\Psi_m^\pm(\tau)}\,d\tau.
\]

Y la fase es consistentemente

\[
\Psi_m^\pm.
\]

Han desaparecido las mezclas \(\alpha/\varepsilon\) y \(\Psi/\Phi\).

No veo ya el error formal de v19.

---

## 8. `cell-form`: corregido

La frase falsa anterior se ha convertido correctamente en

> “The exponential of an absolutely convergent Dirichlet series is again an absolutely convergent Dirichlet series.”

Correcto.

---

## 9. Hadamard: corregido y mejor que antes

Ahora se explica expresamente que el factor constante desaparece porque

\[
2\xi(0)=1.
\]

Es decir,

\[
e^A=1.
\]

Y después la simetría elimina \(B'\).

Esta prueba está ahora mucho mejor cerrada.

---

## 10. Estricta convexidad: corregida

v20 también ha solucionado la objeción sobre

\[
\Upsilon'(\lambda)<0.
\]

Ya no se limita a observar que cada término es \(\le0\), sino que demuestra que el término \(k=1\) es estrictamente negativo porque

\[
\eta_1=\tau_1-\gamma_1>0.
\]

Además el propio texto distingue correctamente:

\[
\Upsilon'\le0
\]

por la fórmula sola, y estricta desigualdad cuando

\[
\boldsymbol\gamma\ne\boldsymbol\tau.
\]

Bien.

---

## 11. Certificados numéricos: corregidos de estatus

Ésta es otra mejora importante.

Ahora el texto dice expresamente:

> “A Gaussian is not compactly supported...”

y:

> “the computed quantities are not literally those of Theorem ...”

También:

> “what has been established is the floating-point inequality ... so these stages carry candidate certificates and not verified ones.”

Y el abstract los denomina:

\[
\boxed{\text{floating-point candidate Banach certificates}}
\]

“not verified by interval arithmetic”.

Eso es exactamente el estatus correcto.

Además ya se distingue correctamente:

\[
t_m\ge k_m^*
\]

para los diagnósticos sobredeterminados, frente a

\[
t_m\le k_m^*
\]

para el right inverse del teorema, reuniéndose ambas geometrías únicamente en el caso cuadrado.

Corregido.

---

## 12. `thm:nondegenerate`: lo mantengo como válido internamente

Mi primera crítica de v19 era incorrecta, como ya rectifiqué.

La v20 conserva la regularización:

\[
e^{-zu}
=
T_A(u)+R_A(u),
\]

con \(R_A\) anulándose hasta orden suficientemente alto antes de tomar la extensión par.

No veo ahora un error interno en esa parte.

---

## 13. Kadec–Avdonin: los errores principales parecen corregidos

La segunda revisión ya no encuentra los antiguos:

\[
1-2L,
\qquad
\frac{V\mathbb O}{\cdots},
\]

etc.

El teorema utiliza ahora consistentemente \(d_\star\) en la condición

\[
\|\mathrm A\|_\infty\le d_\star<\frac14.
\]

No he encontrado de nuevo el paquete de variables libres de v19.

---

## 14. Referencias internas: limpias

He comprobado estáticamente:

- **886 labels**;
- **0 labels duplicados**;
- **0 referencias a labels inexistentes** entre `\ref`, `\eqref`, `\CGref`, `\CGeqref`, etc.

Por ese lado v20 está limpia.

---

# Resultado de la revisión v20

La diferencia frente a v19 es grande.

### Errores objetivos que todavía corregiría

**A.** En `cor:rb-D-implies-B`:

\[
\gamma_K,\tau_{K+1}
\to
\gamma_{k^*},\tau_{k^*+1},
\]

y

\[
k_m^*,N_m
\to
k_m^*,n_m^*.
\]

**B.** Cambiar la frase incondicional

\[
\text{“At the clock end }\varpi_{\rm RVM}<1\text{”}
\]

por una frase condicionada a Hypothesis 8.5.

### Punto matemático que reforzaría antes de cerrar la versión

**C.** En Appendix E, escribir explícitamente el argumento de Backlund/argument principle que produce el **conteo acumulativo**

\[
N_{\boldsymbol\kappa}(T)-N_{\rm RVM}(T)=O(\log T).
\]

No basta con mencionar únicamente un disco fijo alrededor de \(2+iT\). La conclusión probablemente se salva mediante el argumento estándar, pero ése es ahora el punto demostrativo más débil que veo.

### Lo demás que había señalado en v19

Está corregido:

\[
\boxed{
\text{graded extension, Gonek, matching, Lipschitz, Hadamard,
strict convexity, }\varpi_{\rm RVM}\text{ status, certificates, Appendix E boundary term}.
}
\]

Mi diagnóstico ahora es bastante distinto del de v19:

\[
\boxed{\text{v20 ya no contiene, por lo que veo, un teorema central manifiestamente falso.}}
\]

La reparación más importante fue precisamente `rb-graded`. Appendix E también ha pasado de tener una laguna estructural clara a tener, a mi juicio, **un paso estándar pero insuficientemente desarrollado en el zero counting**.

No he modificado el archivo.

:chatgpt-content-reference{index="0"}[Ver rvm_zeta_pi_mertens_v20.tex](sandbox:/mnt/data/rvm_zeta_pi_mertens_v20.tex)