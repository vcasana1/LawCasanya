# Revisión externa de la ruta B′ en rvm_zeta_pi_mertens_v20 (recibida 2026-10-11) — material para v21

Texto literal de la revisión, guardado para revisiones futuras. Comprobaciones hechas sobre el fuente v20 al recibirla:

- Punto 10 (\Lambda(n)/(2n)): NO aparece en el fuente; el cuerpo tiene \Lambda(n)/(2\sqrt n) y M_* = log7/(2 sqrt7) en todas partes. Artefacto del resumen automático.
- Punto 11 (3 en vez de pi/3): el cuerpo de eq:sigma-two tiene \frac\pi3 correcto; SOLO el tooltip CGTip@eq:sigma-two muestra '>= 3' porque make_tips.py aplana mal \frac\pi3 sin llaves. Corregir en v21: escribir \frac{\pi}{3} en eq:sigma-two (y revisar otros \frac sin llaves en tooltips).

Pendiente de aplicar en v21: puntos 1 (orden local / Laplace-transformable en lem:rb-laplace), 2 (convención L(delta_0')(s)=z explícita), 3 (Q(1-s)-Q(s) in 2 pi i Z explícito en prop:rb-prescribed-uniqueness), 4 (métrica del producto o paso 4 explícito en cor:rb-Bprime), 5 (unicidad solo en Ran Q_m en thm:rb-certificate), 7 (escribir la serie y el supremo en (B)), 9 (comprobar constantes de lem:rb-archimedean), 11 (tooltip).

---

He revisado específicamente la nueva arquitectura de rvm_zeta_pi_mertens_v20.txt: extensión de Laplace, unicidad con masas prescritas, B′(C)B'(C), certificado por etapas y paso al límite. La versión 20 mejora de forma sustancial respecto a v18/v3 y elimina correctamente la antigua Hipótesis (L).

Veredicto
La ruta B′ de v20 estaˊ esencialmente bien cerrada como criterio condicional.\boxed{\text{La ruta }B'\text{ de v20 está esencialmente bien cerrada como criterio condicional.}}

En particular, considero correctos:

el lema de extensión de Laplace;
la unicidad con masas prescritas;
la equivalencia RH  ⟺  B′(C)\mathrm{RH}\iff B'(C) para algún tubo;
el certificado finito mediante Banach;
el teorema inductivo que convierte los certificados de todas las etapas en B′(C)B'(C).

No veo una demostración incondicional de los certificados para todas las etapas, y el propio texto no la reclama. Sí veo varias correcciones puntuales que conviene hacer antes de fijar la versión.

1. La antigua Hipótesis (L) ya está demostrada correctamente

El Lema 17.11 construye

Hκ(u)=∑kκk−2cos⁡(κku),\mathfrak H_{\boldsymbol\kappa}(u) = \sum_k\kappa_k^{-2}\cos(\kappa_ku),

que converge absoluta y uniformemente, y define

Sκ=−∂u2(Hκ1+)+Hκ(0)δ0′.\mathscr S_{\boldsymbol\kappa} = -\partial_u^2 \bigl(\mathfrak H_{\boldsymbol\kappa}\mathbf1_+\bigr) + \mathfrak H_{\boldsymbol\kappa}(0)\delta_0'.

La corrección

Hκ(0)δ0′\mathfrak H_{\boldsymbol\kappa}(0)\delta_0'

elimina exactamente el término de frontera introducido al derivar la extensión por cero. El manuscrito obtiene entonces

LSκ(s)=∑ks−12(s−12)2+κk2=12Pκ′Pκ(s).\mathcal L\mathscr S_{\boldsymbol\kappa}(s) = \sum_k \frac{s-\frac12} {(s-\frac12)^2+\kappa_k^2} = \frac12\frac{P_{\boldsymbol\kappa}'}{P_{\boldsymbol\kappa}}(s).

Junto con la distribución arquimediana K\mathscr K y la medida aritmética, esto produce

LEκ(s)=12(Pκ′Pκ−ξ′ξ)(s).\mathcal L\mathscr E_{\boldsymbol\kappa}(s) = \frac12 \left( \frac{P_{\boldsymbol\kappa}'}{P_{\boldsymbol\kappa}} - \frac{\xi'}{\xi} \right)(s).

Esto reemplaza realmente la convención (L) por un lema probado.

Ajuste terminológico

En el Lema 17.11 dices que Eκ\mathscr E_{\boldsymbol\kappa} es «de orden a lo sumo 22». Localmente eso está bien. Para evitar confusión con crecimiento global, escribiría:

distribución de orden local a lo sumo 22, soportada en [0,∞)[0,\infty), y Laplace-transformable en ℜs>1\Re s>1.

La medida

∑n≥2Λ(n)2nδlog⁡n\sum_{n\ge2} \frac{\Lambda(n)}{2\sqrt n}\delta_{\log n}

es localmente finita, pero su soporte no es compacto. Conviene distinguir «orden distribucional local» de «crecimiento en el infinito».

2. La normalización de la parte espectral debe revisarse una vez

En el texto aparece

LSκ(s)=−z2∑kzκk2(z2+κk2)+z∑k1κk2.\mathcal L\mathscr S_{\boldsymbol\kappa}(s) = -z^2\sum_k \frac{z}{\kappa_k^2(z^2+\kappa_k^2)} + z\sum_k\frac1{\kappa_k^2}.

Esto simplifica correctamente a

∑kzz2+κk2.\sum_k\frac{z}{z^2+\kappa_k^2}.

No obstante, conviene añadir explícitamente la convención

L(δ0′)(s)=z,z=s−12,\mathcal L(\delta_0')(s)=z, \qquad z=s-\frac12,

porque con la convención distribucional usual el signo depende de si se define la transformada mediante el emparejamiento con e−zue^{-zu} o mediante otra normalización. La fórmula resultante es coherente, pero una línea explícita evitaría objeciones.

3. La unicidad con masas prescritas está bien orientada

La Proposición 17.13 afirma que una lista a distancia acotada del reloj que resuelve exactamente el sistema con masas

anζ=Λ(n)2na_n^\zeta = \frac{\Lambda(n)}{2\sqrt n}

obliga a RH y coincide con la lista (γk)(\gamma_k).

El argumento correcto es:

R(κ,aζ)=0en (0,∞)\mathfrak R(\boldsymbol\kappa,\mathbf a^\zeta)=0 \quad\text{en }(0,\infty)

implica que la extensión está soportada en {0}\{0\}, luego

R^(s)=p(s−12)\widehat{\mathsf R}(s)=p(s-\tfrac12)

para algún polinomio pp. Así,

Pκ′Pκ−ξ′ξ=2p.\frac{P_{\boldsymbol\kappa}'}{P_{\boldsymbol\kappa}} - \frac{\xi'}{\xi} = 2p.

Integrando,

Pκ=c ξeQ.P_{\boldsymbol\kappa} = c\,\xi e^Q.

El orden uno da deg⁡Q≤1\deg Q\le1, y la simetría respecto de s↦1−ss\mapsto1-s fuerza que QQ sea constante. Por tanto, los divisores coinciden y todos los ceros de ξ\xi están en la recta.

Precisión que debe aparecer en la proposición

No basta decir únicamente «Hadamard y la ecuación funcional». Conviene incluir expresamente:

Q(1−s)−Q(s)∈2πiZ.Q(1-s)-Q(s)\in2\pi i\mathbb Z.

Como el miembro izquierdo es continuo, es constante. Si

Q(s)=as+b,Q(s)=as+b,

entonces

Q(1−s)−Q(s)=a(1−2s),Q(1-s)-Q(s)=a(1-2s),

y por tanto a=0a=0.

4. La equivalencia B′  ⟺  RHB'\iff\mathrm{RH} está bien formulada

La Definición 17.14 exige:

listas CC-admisibles;
cada lista igual al reloj más allá de un índice finito;
residuo tendiendo a cero sobre una familia exhaustiva;
masas de von Mangoldt prescritas.

La Proposición 17.5 proporciona compactación y paso al límite, mientras que la Proposición 17.13 identifica todo límite exacto. El Corolario 17.15 concluye correctamente que B′(C)B'(C) implica RH y que RH produce B′(C)B'(C) mediante truncaciones de la lista genuina.

La afirmación adicional de que converge toda secuencia de B′B', no solo una subsucesión, también es correcta:

toda subsucesión posee una subsucesión convergente;
todo punto límite resuelve el sistema exacto;
la unicidad obliga a que todo punto límite sea γ\boldsymbol\gamma;
un espacio producto numerable de intervalos compactos es metrizable;
una sucesión compacta con un único punto de acumulación converge.

Conviene incluir explícitamente el paso 4 o dar una métrica, por ejemplo

d(κ,λ)=∑k≥12−kmin⁡(1,∣κk−λk∣).d(\boldsymbol\kappa,\boldsymbol\lambda) = \sum_{k\ge1} 2^{-k} \min\left(1,|\kappa_k-\lambda_k|\right).
5. El certificado finito por Banach es correcto

La sección 17.3.2 usa un mapa residual finito Fm\mathbb F_m, su Jacobiano Jm\mathbb J_m, una inversa por la derecha Qm\mathbb Q_m, y las constantes

Lm=∥Qm∥∞→∞,\mathbb L_m=\|\mathbb Q_m\|_{\infty\to\infty}, Hm=km∗max⁡φ∈Tm∫∣φ(u)∣u2 du,\mathbb H_m = k_m^* \max_{\varphi\in\mathscr T_m} \int|\varphi(u)|u^2\,du, hm=∥Fm(0)∥∞.\mathsf h_m=\|\mathbb F_m(0)\|_\infty.

La condición

\tag{A_m} 2\mathbb L_m^2\mathbb H_m\mathsf h_m<1

produce una solución exacta con

∥x∗(m)∥∞≤2Lmhm.\|\mathsf x_*^{(m)}\|_\infty \le 2\mathbb L_m\mathsf h_m.

El argumento de contracción es válido porque, en las coordenadas yy,

DΨm(y)=(Jm−DFm(Qmy))Qm,D\Psi_m(y) = \bigl( \mathbb J_m- D\mathbb F_m(\mathbb Q_my) \bigr) \mathbb Q_m,

y en la bola ∥y∥∞≤2hm\|y\|_\infty\le2\mathsf h_m,

∥DΨm(y)∥≤2HmLm2hm<1.\|D\Psi_m(y)\| \le 2\mathbb H_m\mathbb L_m^2\mathsf h_m<1.

La inclusión de la bola en sí misma se obtiene mediante el resto cuadrático:

∥Ψm(y)∥∞≤hm+HmLm22∥y∥∞2<2hm.\|\Psi_m(y)\|_\infty \le \mathsf h_m+ \frac{\mathbb H_m\mathbb L_m^2}{2} \|y\|_\infty^2 < 2\mathsf h_m.
Corrección necesaria

La unicidad es únicamente la del punto fijo en la parametrización

x=Qmy.x=\mathbb Q_my.

Si km∗>dmk_m^*>d_m, el Jacobiano puede tener núcleo. Por tanto, evita cualquier frase que pueda leerse como unicidad de la raíz de Fm\mathbb F_m en toda la bola de Rkm∗\mathbb R^{k_m^*}.

La formulación segura es:

existe un único y∗y_* en la bola indicada y, en consecuencia, una solución certificada x∗=Qmy∗x_*=\mathbb Q_my_* en Ran⁡Qm\operatorname{Ran}\mathbb Q_m.

6. El teorema escalonado está correctamente reparado

El Teorema 17.21 ya incorpora las correcciones importantes:

sup⁡m∑j≤m2Ljhj≤C\sup_m\sum_{j\le m} 2\mathbb L_j\mathsf h_j \le C

y

C<τ1−2π.C<\tau_1-2\pi.

También afirma correctamente que la lista reordenada coincide con el reloj después de algún índice finito k~m∗\widetilde k_m^*, no necesariamente después del índice activo original.

El argumento inductivo es bueno:

Cm=∑j≤m2Ljhj,C_m= \sum_{j\le m}2\mathbb L_j\mathsf h_j, ∣κ~k(m)−τk∣≤Cm,|\widetilde\kappa_k^{(m)}-\tau_k| \le C_m,

y el lema de emparejamiento conserva el tubo después de ordenar. Como

Cm≤C<τ1−2π,C_m\le C<\tau_1-2\pi,

se obtiene

κ1(m)>2π.\kappa_1^{(m)}>2\pi.

Además, como se resuelve toda Tm\mathscr T_m,

sm=0,\mathsf s_m=0,

y en la etapa siguiente hm+1\mathsf h_{m+1} depende solo de los tests recién introducidos.

7. Hay una inconsistencia menor entre «supremo parcial» y «serie»

Escribes

sup⁡m≥1∑j≤m2Ljhj≤C.\sup_{m\ge1} \sum_{j\le m} 2\mathbb L_j\mathsf h_j \le C.

Dado que todos los términos son no negativos, esto equivale a

∑j≥12Ljhj≤C.\sum_{j\ge1} 2\mathbb L_j\mathsf h_j \le C.

La forma con supremo es correcta, pero la forma de serie comunica mejor la naturaleza del presupuesto global. Yo pondría ambas:

∑j≥12Ljhj=sup⁡m∑j≤m2Ljhj≤C.\sum_{j\ge1} 2\mathbb L_j\mathsf h_j = \sup_m \sum_{j\le m} 2\mathbb L_j\mathsf h_j \le C.
8. El lema graduado está correctamente corregido

La Proposición 17.23 usa

sm+1≤qmsm+hm,0≤qm≤1,∑hm<∞,s_{m+1}\le q_ms_m+h_m, \qquad 0\le q_m\le1, \qquad \sum h_m<\infty,

y la condición de cola

∏j=Lmqj→0\prod_{j=L}^m q_j\to0

para cada LL. Esa condición basta para concluir sm→0s_m\to0. También es correcto que

∑m(1−qm)=∞\sum_m(1-q_m)=\infty

sea una condición suficiente, porque

log⁡qm≤−(1−qm).\log q_m\le-(1-q_m).

Esta es la versión correcta, sin el peso exponencial excesivo del borrador anterior.

9. El Lema 17.10 arquimediano merece una comprobación adicional de constantes

El resumen recuperado muestra

cK=−14log⁡(2πeγE),c_{\mathscr K} = -\frac14\log(2\pi e^{\gamma_E}),

y la identidad

LK=12G′G.\mathcal L\mathscr K = \frac12\frac{G'}G.

La derivación mediante la parte finita de 1/u1/u parece coherente. El propio texto indica una comprobación numérica a 25 cifras, pero esa comprobación no sustituye la identidad simbólica.

Recomiendo verificar editorialmente las constantes en esta cadena:

−14log⁡π,−14(γE+log⁡2),cK.-\frac14\log\pi, \qquad -\frac14(\gamma_E+\log2), \qquad c_{\mathscr K}.

La suma debería dar exactamente

−14log⁡(2π)−γE4.-\frac14\log(2\pi)-\frac{\gamma_E}{4}.

Eso coincide con el cKc_{\mathscr K} mostrado.

10. Posible error tipográfico importante en el resumen de la caja canónica

El resultado recuperado muestra en algunos lugares

M∗=max⁡n≥2Λ(n)2n,M_*=\max_{n\ge2}\frac{\Lambda(n)}{2n},

pero simultáneamente da

M∗=log⁡727=0.367742…M_*=\frac{\log7}{2\sqrt7}=0.367742\ldots

y define en otros lugares

anζ=Λ(n)2n.a_n^\zeta=\frac{\Lambda(n)}{2\sqrt n}.

La fórmula correcta para esta normalización es

M∗=max⁡n≥2Λ(n)2n=log⁡727.\boxed{ M_*= \max_{n\ge2} \frac{\Lambda(n)}{2\sqrt n} = \frac{\log7}{2\sqrt7}. }

Revisa todas las apariciones de \Lambda(n)/(2n) en la sección 17.3. Si aparece realmente así en el fuente y no es un defecto del resumen automático, debe cambiarse a \Lambda(n)/(2\sqrt n).

11. Hay una discrepancia numérica en el teorema del eje real

En el resultado recuperado del Teorema 14.11 aparece aparentemente

∏k(1+214+γk2)≥3,\prod_k \left( 1+\frac2{\frac14+\gamma_k^2} \right) \ge 3,

mientras que la demostración incluida en el propio documento calcula

Pζ(2)=G(2)ζ(2)=π3.P_\zeta(2) = G(2)\zeta(2) = \frac\pi3.

La desigualdad correcta debería ser

∏k(1+214+γk2)≥π3.\boxed{ \prod_k \left( 1+\frac2{\frac14+\gamma_k^2} \right) \ge\frac\pi3. }

El mismo documento, en otra aparición recuperada, sí muestra π/3\pi/3. Esto parece una corrupción del tooltip o una definición asociada, no necesariamente del cuerpo principal. Revisa:

\CGTip@eq:sigma-two


y el enunciado real de eq:sigma-two.

12. La condición del primer punto puede flexibilizarse, pero está bien como está

La restricción

C<τ1−2πC<\tau_1-2\pi

solo garantiza que toda lista satisfaga κ1≥2π\kappa_1\ge2\pi. El propio texto lo explica correctamente y señala que puede eliminarse tratando la primera coordenada por separado.

No intentaría quitarla en v20. Es limpia y no afecta al núcleo del certificado.

13. Estado final de la sección 17

Mi valoración concreta es:

Resultado	EstadoExtensión arquimediana	Correcta, revisar constantes
Transformada del residuo	Correcta
Eliminación de (L)	Conseguida
Unicidad con masas prescritas	Correcta
B′(C)⇒RHB'(C)\Rightarrow\mathrm{RH}	Correcta
RH⇒B′(C)\mathrm{RH}\Rightarrow B'(C)	Correcta
Certificado finito de Banach	Correcto
Reordenación y tubo	Correctos
Cola después de un índice finito	Correcta
Teorema escalonado	Correcto
Certificados para todo mm	No demostrados, y el texto no afirma lo contrario
Convergencia de toda la sucesión	Correcta por unicidad de puntos límite
Conclusión

La versión 20 contiene un avance matemático real respecto de las versiones anteriores:

la ruta B′ ya no depende de una hipoˊtesis de unicidad ni de (L).\boxed{ \text{la ruta }B'\text{ ya no depende de una hipótesis de unicidad ni de (L).} }

La parte lógica queda reducida limpiamente a:

∀m,2Lm2Hmhm<1,∑m2Lmhm<C\boxed{ \forall m,\quad 2\mathbb L_m^2\mathbb H_m\mathsf h_m<1, \qquad \sum_m2\mathbb L_m\mathsf h_m<C }

para una construcción exhaustiva concreta.

Antes de cerrar v20, corregiría prioritariamente:

toda aparición dudosa de Λ(n)/(2n)\Lambda(n)/(2n);
el tooltip que muestra 33 en vez de π/3\pi/3;
la precisión de unicidad en Ran⁡Qm\operatorname{Ran}\mathbb Q_m;
una frase sobre orden local y Laplace-transformabilidad en el Lema 17.11.

Con esas correcciones, la sección 17 está coherente, rigurosa y mucho mejor delimitada que en v18.