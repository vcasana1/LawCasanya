# Cuarta revisión externa de v20 (reloj → modelos → numérica → apéndices, recibida 2026-10-11) — material para v21

Texto literal. Comprobado en el fuente v20:
- 1 (prop:lists-compact): real en parte. La prueba solo justifica la condición integral por X fijo; añadir: orden = ∩_k{κ_k≤κ_{k+1}} cerrado, umbral κ_1≥τ_0^+ cerrado, tercera condición = ∩_{X≥τ_0}{|F_X|≤C log X} con F_X continua en finitas coordenadas; producto numerable compacto y metrizable.
- 2 (F del modelo de dos aristas): real. Línea ~4566 define 'closed discrete set F⊂(0,∞) closed under addition'; con p/q∉Q el semigrupo {2(mp+m'q)} es localmente finito pero NO uniformemente discreto. Cambiar a 'closed, locally finite (F∩[0,R] finito ∀R), closed under addition' y revisar los usos de 'discrete' en thm:acceptance.
- 7 (λ=0 multiplicidades): NO procede; thm:path ya dice 'for 0<λ≤1 strictly increasing; at λ=0 the multiplicities...'.
- 11 (tooltip ζ_RVM = P·G): artefacto de make_tips.py al aplanar \frac{P}{G}; el cuerpo (eq:intro-zeta-rvm) tiene P/G. Mismo defecto que π/3.
- 12 (tooltips 'Eq. (), p. :'): real, 2 casos: eq:rb-Am y eq:rb-B (llevan \tag). Arreglar make_tips.py para \tag y para \frac sin llaves; regenerar.
- 13 (resonancia u·Δ_k≈2πr en thm de sumas exponenciales): YA está en el cuerpo (línea ~1569): k_0=k_0(u_2) con ℓ_{k_0}≥2u_2 ⇒ 0<Δ_k≤π para k≥k_0; bloque inicial aparte. No es laguna.
- 14 (prop:clock-defect-poisson, extensión par): real. La prueba invoca 'two integrations by parts' para O(m^{-2}) sobre la extensión par de g, pero g'(0)=c_f'(t_0)·T'(0) no es cero en general, así que la extensión par no es C^2 en 0. El O(m^{-2}) sigue siendo cierto escribiendo el término de borde explícito: ∫_0^∞ g cos(2πmv)dv = −g'(0)/(2πm)^2 − (2πm)^{-2}∫_0^∞ g'' cos(2πmv)dv (el término g'(0) no se cancela). Corregir en v21 con ese término explícito.
- 3 (Paley–Wiener–Schwartz en thm:acceptance), 4 (Phragmén–Lindelöf por subbandas en thm:finite-euler), 5-6 ('uncorrelated', 'independent' en la sección de Mertens), 8 (positividad factor a factor en thm:real-axis), 9 (ceros discretos en compacto en prop:exceptional-set), 10 (rama en el teorema de fase), 15 (producto ordenado vs absoluto en cada aparición), 16 (dos frases numéricas): correcciones de redacción/rigor a aplicar en v21; no comprobadas una a una aquí.

---

He revisado el resto de [rvm_zeta_pi_mertens_v20.txt](https://onedrive.live.com?cid=CAC62C6441984A26&id=CAC62C6441984A26!se998bc09e28e4a5ba5cbce8994618427&EntityRepresentationId=aec0533c-f17b-4e26-958d-4bdb7ec843c0), desde la construcción del reloj hasta los modelos, la parte numérica y los apéndices. El manuscrito tiene una arquitectura coherente, pero he encontrado **dos errores matemáticos claros**, varios pasos que necesitan reforzarse y un conjunto de inconsistencias editoriales importantes. 

# Veredicto general

La estructura central anterior a Route \(B\) es sólida en estas piezas:

- reloj de puntos medios y desplazamiento acotado;
- producto canónico sintético;
- sumas exponenciales del reloj;
- fórmula explícita sintética;
- construcción de \(\pi_{\mathrm{RVM}}\);
- familia \(\lambda\);
- reducción del endpoint mediante [Hans Hamburger](https://outlook.live.com/people/0/Hans+Hamburger?EntityRepresentationId=2aeb8cb3-5c69-820f-b932-c26e5e603c8a);
- criterios equivalentes del defecto;
- formulación compacta sobre listas;
- no degeneración condicional de una solución;
- modelos finitos.

Sin embargo:

\[
\boxed{\text{hay que corregir al menos dos enunciados antes de considerar v20 cerrada.}}
\]

Los dos problemas principales son:

1. el argumento de compacidad de \(\mathscr O\);
2. la afirmación de que \(\mathscr F\) del modelo de dos aristas es discreto.

Además, hay una afirmación numérica redactada como conclusión matemática que debe suavizarse.

---

# 1. Error principal: \(\mathscr O\) no queda demostrado compacto con el argumento dado

La Proposición «Compactness and continuity» afirma que \(\mathscr O\) es compacto porque es un subconjunto cerrado de

\[
\prod_k[\tau_k-C_\eta,\tau_k+C_\eta].
\]

Para la tercera condición se usa que, para cada \(X\),

\[
\int_{\tau_0}^{X}N_{\boldsymbol\kappa}(t)\,dt
=
\sum_k(X-\kappa_k)^+,
\]

depende continuamente de un número finito de coordenadas. 

El problema es que el manuscrito define la tercera condición mediante una cota para **todo** \(X\ge\tau_0\):

\[
\left|
\int_{\tau_0}^{X}
\bigl(N_{\boldsymbol\kappa}(t)-\mathcal N_{\mathrm{RVM}}(t)\bigr)\,dt
\right|
\le C\log X.
\]

Para demostrar que ese conjunto es cerrado, basta efectivamente comprobar cada \(X\) fijo, porque es una intersección arbitraria de conjuntos cerrados:

\[
\mathscr O
=
\bigcap_{X\ge\tau_0}
\left\{
\boldsymbol\kappa:
|F_X(\boldsymbol\kappa)|\le C\log X
\right\}.
\]

Así que la idea puede salvarse, pero hay un detalle adicional:

## El orden no es automáticamente cerrado si se permiten cruces fuera de los intervalos individuales

La condición

\[
\kappa_1\le\kappa_2\le\cdots
\]

sí es cerrada, porque es

\[
\bigcap_k\{\kappa_k\le\kappa_{k+1}\}.
\]

Esto debe añadirse explícitamente. Tal como está resumida la prueba, solo se justifican las condiciones de tubo y de integral, no el orden ni el umbral inferior.

### Redacción corregida

Sugiero reemplazar la prueba de compactitud por:

> El producto
> \[
> \mathcal K=\prod_{k\ge1}[\tau_k-C_\eta,\tau_k+C_\eta]
> \]
> es compacto por Tychonoff y metrizable por ser un producto numerable. La condición \(\kappa_1\ge\tau_0^+\) es cerrada, y la monotonía es la intersección de los cerrados \(\{\kappa_k\le\kappa_{k+1}\}\). Para cada \(X\), la función
> \[
> F_X(\boldsymbol\kappa)
> =
> \sum_k(X-\kappa_k)^+
> -
> \int_{\tau_0}^{X}\mathcal N_{\mathrm{RVM}}(t)\,dt
> \]
> depende de un número finito de coordenadas y es continua. La tercera condición es
> \[
> \bigcap_{X\ge\tau_0}\{|F_X|\le C\log X\},
> \]
> una intersección de cerrados. Por tanto \(\mathscr O\) es cerrado en \(\mathcal K\), luego compacto.

Con esto la Proposición queda reparada.

---

# 2. Error claro en el modelo de dos aristas: \(\mathscr F\) no es discreto

En el modelo se define

\[
\mathscr F
=
\{2(m\mathfrak p+m'\mathfrak q):
m,m'\ge0\}\setminus\{0\},
\]

con

\[
\frac{\mathfrak p}{\mathfrak q}\notin\mathbb Q.
\]

El texto anterior define la categoría discreta usando una frecuencia cerrada y discreta. Pero este semigrupo no es uniformemente discreto: por aproximación diofántica existen pares enteros distintos con

\[
|m\mathfrak p+m'\mathfrak q
-
(n\mathfrak p+n'\mathfrak q)|
\]

arbitrariamente pequeño.

Ahora bien, sí es **localmente finito** en \([0,\infty)\): para cada \(R\),

\[
m\mathfrak p+m'\mathfrak q\le R
\]

solo admite un número finito de pares \((m,m')\).

Por tanto, hay que distinguir:

- discreto en el sentido topológico local, que sí;
- uniformemente separado, que no;
- cerrado en \([0,\infty)\), que sí, porque todo compacto contiene solo un número finito de términos.

El problema está en que «closed discrete set» puede entenderse correctamente como subconjunto topológicamente discreto, pero después se usa la frase:

> la suma es finita porque \(\mathscr F^+\) es discreto.

Eso solo requiere finitud local, no separación uniforme.

## Corrección recomendada

Define desde el principio:

> Sea \(\mathscr F\subset(0,\infty)\) un conjunto cerrado y localmente finito, estable bajo suma.

Y sustituye «discrete» por «locally finite» en los puntos donde lo necesario sea:

\[
\mathscr F\cap[0,R]\quad\text{finito para todo }R.
\]

El modelo de dos aristas funcionará entonces sin conflicto. 

---

# 3. Problema en la aceptación: el paso Paley–Wiener necesita formularse con más precisión

En el criterio de aceptación se considera

\[
\mathsf N(z)
=
e^{i\mathfrak kz}\mathfrak C_{\boldsymbol\kappa}(z).
\]

Se afirma que \(\mathsf N\) es entera de tipo exponencial, tiene crecimiento polinómico en el eje real y queda acotada polinómicamente en el semiplano superior. A partir de ahí se concluye que la transformada de Fourier está soportada en

\[
[0,2\mathfrak k].
\]

La idea es correcta, pero el soporte unilateral no sale solo del tipo exponencial. Debe usarse conjuntamente:

- el tipo \(\mathfrak k\) de \(\mathfrak C\);
- el factor \(e^{i\mathfrak kz}\);
- crecimiento polinómico en \(\Im z\ge0\).

Conviene citar una versión exacta de Paley–Wiener–Schwartz:

> Si una función entera \(F\) satisface
> \[
> |F(z)|\le C(1+|z|)^N e^{B\max(0,-\Im z)}
> \]
> entonces es la transformada de Fourier de una distribución soportada en \([0,B]\).

Aquí debe verificarse explícitamente

\[
|\mathsf N(z)|
\le
C(1+|z|)^N
e^{2\mathfrak k\max(0,-\Im z)}.
\]

Sin esa línea, el intervalo \([0,2\mathfrak k]\) parece surgir demasiado deprisa.

---

# 4. El teorema del modelo finito necesita reforzar Phragmén–Lindelöf

En el «Hamburger theorem of the model» se supone que \(f\) es entera de orden finito, satisface

\[
f(-s)=6^sf(s)
\]

y es una serie de Dirichlet absolutamente convergente en un semiplano. Se afirma:

> \(f\) está acotada en ambos semiplanos extremos; por Phragmén–Lindelöf está acotada en toda banda vertical.

El argumento puede hacerse correcto, pero «orden finito» no basta sin explicar cómo se aplica Phragmén–Lindelöf, porque el ancho permitido depende del orden.

## Reparación

Si \(f\) tiene orden \(\rho<\infty\), divide cada banda vertical finita en subbandas de ancho menor que

\[
\frac{\pi}{\rho+\varepsilon}.
\]

Aplica Phragmén–Lindelöf sucesivamente en cada subbanda. Esto propaga la acotación desde las dos fronteras exteriores al interior.

Hay que escribir este paso. Si no, la posterior fórmula de extracción de coeficientes en cualquier recta vertical carece de una justificación explícita.

---

# 5. Un problema real en el manuscrito numérico: «uncorrelated» no está demostrado

En la sección de Mertens se afirma que las sucesiones de signos son «uncorrelated» porque, hasta \(10^6\),

\[
\frac{
\sum_{n\le10^6}\mu(n)\mu_h(n)
}{
\#\{n\le10^6:\mu(n)\ne0\}
}
=0.0007.
\]

Eso solo muestra una correlación empírica pequeña en esa muestra. No demuestra ausencia de correlación asintótica.

Sustituiría:

> the sign sequences are uncorrelated

por:

> the empirical normalized correlation is \(0.0007\) on this range.

Y en español conceptual:

\[
\boxed{\text{“no correlacionadas” debe ser “con correlación empírica próxima a cero”.}}
\]

El propio documento ya distingue bien experimentos y teoremas, así que esta frase desentona con esa disciplina. 

---

# 6. «Dos piezas independientes de información» también es demasiado fuerte

Se dice que los valores de \(\mu\) se dividen en dos piezas «independientes»:

1. el conjunto de no libres de cuadrados;
2. los signos sobre los libres de cuadrados.

Son dos componentes distintas de los datos, pero no se ha demostrado independencia estadística.

Mejor:

> Its values split into two components of information.

o

> Its values are specified by two pieces of data.

No usaría “independent” salvo que se defina en sentido puramente lógico, no probabilístico.

La densidad de cada signo

\[
\frac3{\pi^2}
\]

sí es correcta, porque

\[
\#\{\mu=1\}-\#\{\mu=-1\}
=
\sum_{n\le x}\mu(n)
=o(x)
\]

por el teorema de los números primos, mientras la densidad de los libres de cuadrados es \(6/\pi^2\).

---

# 7. La familia \(\lambda\): problema en \(\lambda=0\) con multiplicidades

La fórmula

\[
\gamma_{k+1}(\lambda)-\gamma_k(\lambda)
=
(1-\lambda)(\gamma_{k+1}-\gamma_k)
+
\lambda(\tau_{k+1}-\tau_k)
\ge
\lambda(\tau_{k+1}-\tau_k)>0
\]

solo prueba separación estricta para

\[
\lambda>0.
\]

En \(\lambda=0\), si \(\zeta\) tuviera ceros múltiples, podría ocurrir

\[
\gamma_{k+1}=\gamma_k.
\]

El manuscrito parece consciente de las multiplicidades en otros puntos, pero el Teorema 10.1 debe formular:

- para \(\lambda>0\), las ordenadas son estrictamente crecientes;
- para \(\lambda=0\), son no decrecientes y se cuentan con multiplicidad.

Si en el texto se afirma estrictamente creciente para todo \(\lambda\in[0,1]\), hay que corregirlo.

---

# 8. La prueba de que el endpoint domina a \(\zeta\) necesita una frase sobre el producto infinito

Para cada par de ceros fuera de la recta, el factor correspondiente es mayor que \(1\) para \(\sigma>1\), y tiende a una constante mayor que \(1\). De ahí se concluye

\[
\zeta_{Z1}(\sigma)\ge\zeta(\sigma).
\]

La conclusión es plausible y el cálculo de cada factor es correcto. Pero para afirmar que la igualdad del producto infinito implica que no hay ningún factor no trivial, conviene decir:

- todos los factores son \(\ge1\);
- todo factor asociado a \(d_\rho\ne0\) es estrictamente \(>1\);
- el producto converge;
- por tanto, si existe al menos uno de esos factores, el producto completo es estrictamente mayor que \(1\).

No basta simplemente con «equality only if the product is empty» sin recordar la positividad factor a factor.

El valor particular correcto es

\[
\prod_k
\left(
1+\frac{2}{\frac14+\gamma_k^2}
\right)
\ge\frac{\pi}{3},
\]

no \(3\). El cuerpo principal contiene \(\pi/3\), pero los tooltips todavía contienen \(3\). 

---

# 9. El conjunto excepcional: la finitud está bien, pero la prueba debe especificar “ceros reales en un compacto”

Se elige un compuesto \(n\) para el que

\[
\widetilde c_n(1)>0,
\]

y se observa que \(\widetilde c_n(\lambda)\) es entera y no idénticamente nula. Se concluye que tiene un número finito de ceros en \([0,1]\).

Esto es correcto, pero la formulación precisa es:

> Los ceros de una función holomorfa no idénticamente nula son discretos. Un subconjunto discreto de un compacto es finito.

No diría simplemente «an entire function has finitely many zeros in \([0,1]\)», porque una función entera puede tener infinitos ceros reales globalmente.

---

# 10. El teorema de la fase continua debe excluir también puntos donde intervenga una elección de rama

La fórmula

\[
\lim_{\sigma\to1/2^+}
\Im\log\zeta_\lambda(\sigma+it)
=
-\vartheta(t)+\pi(N_\lambda(t)-1)
\]

es correcta entre ordenadas, con una rama fijada desde el semiplano derecho.

Conviene especificar explícitamente que la igualdad se entiende:

\[
\pmod{2\pi}
\]

hasta que se fija la continuación concreta de la rama. El manuscrito sí menciona la rama real en \((1,\infty)\), pero sería mejor añadir:

> the continuation is taken along the connected component obtained after removing the horizontal cuts issued from the zeros.

Si no se indica el camino, “continued in \(\Re s>1/2,\Im s>0\)” puede resultar ambiguo porque ese dominio contiene ceros en su frontera, aunque no en el interior.

---

# 11. Problema de notación en la introducción: \(\zeta_{\mathrm{RVM}}\)

En el tooltip introductorio aparece aparentemente

\[
\zeta_{\mathrm{RVM}}=P_{\mathrm{RVM}}^{\mathrm{crit}}G,
\]

mientras la definición correcta del cuerpo es

\[
\boxed{
\zeta_{\mathrm{RVM}}(s)
=
\frac{P_{\mathrm{RVM}}^{\mathrm{crit}}(s)}{G(s)}.
}
\]

La misma definición correcta reaparece después en la familia:

\[
\zeta_\lambda=\frac{P_\lambda}{G}.
\]

Hay que revisar `CGTip@eq:intro-zeta-rvm`. Parece otro error de generación de tooltips, como el \(3\) frente a \(\pi/3\). 

---

# 12. Los tooltips están demasiado corruptos para una versión final

He encontrado varias expresiones dañadas:

- cocientes convertidos en productos;
- símbolos `\Re`, `\arg` o barras absolutas desaparecidos;
- \(\pi/3\) convertido en \(3\);
- subíndices duplicados;
- números de ecuación vacíos:
  \[
  \texttt{Eq. (), p. :}
  \]
  para \((A_m)\) y (B);
- títulos duplicados como `J_RVMJ_RVM`, `pipi`, `lambdalambda`;
- referencias con contenido matemático ilegible.

Esto no afecta necesariamente al PDF visible, pero sí al sistema de navegación que estás distribuyendo.

Mi recomendación es regenerar automáticamente los tooltips desde una representación de texto matemático simplificada, no mediante eliminación textual directa de comandos LaTeX.

---

# 13. El teorema de sumas exponenciales necesita revisar la uniformidad en \(u\)

Se afirma

\[
\sup_{u\in[u_1,u_2]}
\left|
\sum_{k\le N}e^{iu\tau_k}
\right|
\ll_{u_1,u_2}1+\log N.
\]

La prueba se basa en:

- monotonía y concavidad de la inversa del reloj;
- control de segundas diferencias;
- sumación por partes con
  \[
  b_k^{\mathrm{sbp}}
  =
  \frac1{e^{iu\Delta_k}-1}.
  \]

Aquí hay que garantizar uniformemente que

\[
|e^{iu\Delta_k}-1|
\]

no se aproxime arbitrariamente a cero por resonancia \(u\Delta_k\approx2\pi r\).

Como

\[
\Delta_k\to0,
\]

para \(k\) grande se tiene \(u\Delta_k<\pi\), uniformemente en \(u\le u_2\), y entonces

\[
|e^{iu\Delta_k}-1|
\asymp u\Delta_k.
\]

Para los finitos \(k\) iniciales puede haber valores de \(u\in[u_1,u_2]\) con resonancia exacta. En ese caso el denominador se anula.

La prueba debe separar:

1. una cola \(k\ge k_0(u_2)\), donde \(u\Delta_k<\pi\);
2. un bloque inicial finito, tratado trivialmente, sin usar \(b_k^{\mathrm{sbp}}\).

Si esa separación ya está en el cuerpo y no solo en el resumen, perfecto. Si no, es una laguna real en la uniformidad.

---

# 14. La fórmula de Poisson del defecto del reloj necesita una corrección en el extremo

Se define

\[
g(v)=c_f(\mathcal T(v)),\qquad v\ge0,
\]

y se aplica Poisson a una extensión par evaluada en semienteros.

Para que la extensión par sea \(C^2\), hace falta controlar \(g'(0)\). En general,

\[
g'(0)
=
c_f'(\mathfrak t_0)\mathcal T'(0)
\]

no tiene por qué ser cero.

La afirmación de que los coeficientes son

\[
O(m^{-2})
\]

por dos integraciones por partes necesita:

- o bien una extensión suave apropiada cerca de \(0\);
- o bien incluir el término de salto de la derivada;
- o simplemente usar \(O(m^{-1})\) si solo se dispone de continuidad.

Hay que revisar este punto con cuidado. La fórmula de Poisson puede seguir siendo válida distribucionalmente, pero el decaimiento \(O_f(m^{-2})\) no sale automáticamente de la extensión par indicada.

---

# 15. La convergencia de productos ordenados debe distinguirse de convergencia absoluta

En varias partes se usa un producto como

\[
\prod_k
\frac{\frac14+\tau_k^2}
{\frac14+\gamma_k^2}.
\]

Con desplazamiento acotado,

\[
\log
\frac{\frac14+\tau_k^2}
{\frac14+\gamma_k^2}
=
O\left(\frac{|\tau_k-\gamma_k|}{\tau_k}\right).
\]

Pero

\[
\sum_k\frac1{\tau_k}
\]

diverge. Así que el desplazamiento acotado por sí solo no da convergencia absoluta del logaritmo.

La convergencia depende de cancelaciones adicionales, por ejemplo de la primitiva del error de conteo. Cada aparición debe indicar claramente si el producto:

- converge absolutamente;
- converge condicionalmente en el orden natural;
- se define mediante una razón de productos canónicos.

En particular, «ordered product» debe mantenerse siempre que no se haya demostrado

\[
\sum_k
\left|
\log
\frac{\frac14+\tau_k^2}
{\frac14+\gamma_k^2}
\right|
<\infty.
\]

---

# 16. La parte numérica está bien separada, salvo dos frases

El manuscrito declara expresamente que:

- los certificados son candidatos en punto flotante;
- no están verificados por aritmética de intervalos;
- las simulaciones no forman parte de las pruebas. 

Eso está bien.

Cambiaría solamente:

### Frase actual

> the iteration converges at every stage

por:

> the implemented iteration reached the reported stopping tolerance at every tested stage.

### Frase actual

> resolving the masses up to \(N\) requires \(\Omega\) of the order of \(\pi N\)

El experimento solo muestra compatibilidad con esa escala. Mejor:

> the observed loss of resolution is consistent with a required band of order \(N\), as suggested by the stationary heights.

No declares una necesidad matemática general a partir de una única familia de discretizaciones.

---

# 17. Prioridades de corrección

## Críticas

1. Reparar la definición y uso de \(\mathscr F\) en el criterio de aceptación.
2. Completar rigurosamente la prueba de compactitud de \(\mathscr O\).
3. Revisar la extensión par y el \(O(m^{-2})\) en Poisson.
4. Separar la cola en la prueba uniforme de sumas exponenciales para evitar denominadores resonantes.
5. Distinguir productos naturales de productos absolutamente convergentes.

## Importantes

6. Corregir la familia en \(\lambda=0\) si hay multiplicidades.
7. Reforzar Phragmén–Lindelöf en el modelo finito.
8. Precisar Paley–Wiener–Schwartz en el criterio de aceptación.
9. Corregir “uncorrelated” e “independent”.
10. Suavizar las conclusiones numéricas sobre escalas necesarias.

## Editoriales

11. Regenerar todos los tooltips.
12. Corregir \(\zeta_{\mathrm{RVM}}=P/G\).
13. Corregir \(3\) por \(\pi/3\) en tooltips.
14. Reparar ecuaciones sin número y títulos duplicados.

# Conclusión

La revisión global no destruye el programa. La mayor parte de los teoremas principales puede mantenerse, pero no diría todavía que el manuscrito entero está listo para circulación formal.

Mi clasificación sería:

\[
\boxed{
\begin{array}{ll}
\text{Núcleo analítico:} & \text{coherente y mayoritariamente sólido},\\
\text{Route }B': & \text{bien cerrada como criterio},\\
\text{Modelos:} & \text{requieren dos reparaciones técnicas},\\
\text{Poisson y sumas uniformes:} & \text{requieren verificación puntual},\\
\text{Numerics:} & \text{bien delimitados, con lenguaje que ajustar},\\
\text{Edición/tooltips:} & \text{necesitan regeneración}.
\end{array}
}
\]

Los puntos más delicados matemáticamente son el número 13, sobre uniformidad en \(u\), y el número 14, sobre la extensión par en la fórmula de Poisson. Esos dos conviene resolver antes de producir v21.