# Tercera revisión externa de v20 (barrido del resto del paper, recibida 2026-10-11) — material para v21

Texto literal. Comprobado en el fuente v20: punto 1 real (abstract, línea ~1034: 'Every statement above is proved in this paper without any hypothesis'; y 'At the clock end varpi_RVM<1' tras thm:positivity); punto 3 real ('0<d\le C' y 'D(tau_k+d)' en cor:rb-displacement y remark, líneas ~5200-5204, la variable es q); punto 8/9 real (eq. ~4697 escribe e^{P(s)}/zeta(s) en Re s>1/2; debe restringirse a Re s>1 y tomar det_2 = exp(-sum_{m>=2} P(ms)/m) como objeto primario); punto 10 real (línea ~4686 'the same statements hold for prod_{p<=X}' sin corolario formal; thm:finite-euler se cita luego como si cubriera todo X).

Lista consolidada para v21 (junto con las dos revisiones anteriores): (i) abstract/intro: 'Every unconditional statement above is proved; statements invoking Hypothesis 8.5 are conditional'; marcar 'conditional on Hypothesis 8.5' en tablas donde la conclusión use varpi_RVM<1; (ii) cor:rb-D-implies-B K->k*, N_m->n*_m; (iii) cor:rb-displacement d->q; (iv) Apéndice E: reutilizar lem:rb-argument + thm:rb-count (principio del argumento + Backlund + vartheta) en vez del disco solo; (v) prop:lists-compact: exhibir la dominante L^2: |log zeta_kappa(sigma+it)| <= C_sigma(1+log(2+|t|)) uniforme en O, luego (1+log(2+|t|))^2/(1+|t|)^2 integrable; (vi) thm:transfer-O: escribir C=C(C_eta, sigma, eps, ...) explícito; (vii) operador primo: det_2 primario en Re s>1/2, e^{P}/zeta solo en Re s>1; 'zeta e^{-P} holomorphic without zeros' reescrito con D_2; 'contraction proves no zeros in sigma>1' = contraction + trace-class determinant identity; (viii) corolario formal para prod_{p<=X}(1-p^{-s}) en thm:finite-euler.

---

He revisado el resto de la v20, es decir, las partes que no eran simplemente correcciones de los defectos de v19. El resultado es bastante bueno: no encuentro otro teorema central manifiestamente falso. Sí aparecen varios puntos nuevos que conviene corregir o reforzar.

1. Hay todavía una contradicción en el abstract/estado inicial

Aunque v20 introduce correctamente Hypothesis 8.5
\varpi_{\rm RVM}<1
como hipótesis no demostrada, en la introducción sigue figurando:

“Every statement above is proved in this paper without any hypothesis.”

Eso ya no puede decirse literalmente, porque entre los statements anteriores hay conclusiones que se formulan usando \varpi_{\rm RVM}<1.

Hay que sustituirlo por algo como:

\boxed{\text{Every unconditional statement above is proved in this paper; statements invoking Hypothesis 8.5 are conditional on it.}}

Además queda, más adelante, la afirmación incondicional:

“At the clock end \varpi_{\rm RVM}<1…”

cuando ahora debería decir:

“Under Hypothesis 8.5, at the clock end \varpi_{\rm RVM}<1…”

Este punto es más importante de lo que parecía porque afecta al mensaje general del manuscrito, no solo a una prueba local.

⸻

2. cor:rb-D-implies-B: siguen dos variables incorrectas

Está sin corregir:

\{\gamma_1,\ldots,\gamma_K\}
\cup
\{\tau_{K+1},\tau_{K+2},\ldots\}.

Debe ser

\boxed{
\{\gamma_1,\ldots,\gamma_{k^*}\}
\cup
\{\tau_{k^*+1},\tau_{k^*+2},\ldots\}.
}

Y al final:

k_m^*,N_m

debe ser

\boxed{k_m^*,n_m^*.}

Aquí no hay duda.

⸻

3. cor:rb-displacement: queda otro error de variable

La prueba dice:

\kappa_k>\tau_k+\mathrm q
\qquad\text{with}\qquad
0<d\le C.

Debe ser

\boxed{0<\mathrm q\le C.}

Además el remark posterior dice:

\mathbb D(\tau_k+d)

cuando el argumento acaba de usar \mathrm q. También conviene cambiarlo a

\mathbb D(\tau_k+\mathrm q).

Es puramente formal, pero ahora mismo hay una variable d sin definición en esa prueba.

⸻

4. He revisado con más detalle el zero counting de Route B: aquí v20 está mejor de lo que parecía

Mi comentario anterior sobre que un disco de radio fijo no podía por sí solo producir el conteo acumulado era correcto respecto de Appendix E, pero en la Route B principal v20 sí tiene construida la cadena completa:

1. lem:rb-backlund controla la variación horizontal;
2. lem:rb-argument establece exactamente
    \pi N_{\boldsymbol\kappa}(T)
    =
    \Delta_{\mathbb G_T}\arg P_{\boldsymbol\kappa};
3. se descompone
    P_{\boldsymbol\kappa}=G\zeta_{\boldsymbol\kappa};
4. Stirling produce
    1+\frac{\vartheta(T)}{\pi}
    =
    N_{\rm RVM}(T)+O(1/T);
5. de ahí sale thm:rb-count.

Esa cadena está bien planteada.

Por tanto, no hay problema de conteo acumulativo en la Route B principal.

⸻

5. Appendix E debería reutilizar precisamente esa cadena, y ahora mismo no lo hace de forma suficiente

Éste sigue siendo el punto demostrativo más claro que reforzaría.

En Appendix E se dice:

“Apply Backlund’s form of Jensen’s argument to P_{\boldsymbol\kappa} … in a disc centred at 2+iT…”

y se salta rápidamente al bound para

N_{\boldsymbol\kappa}(T)-N_{\rm RVM}(T).

Pero la propia v20 ya contiene unas páginas antes el mecanismo exacto que hace falta:

\text{Backlund/Jensen}
+
\text{argument principle}
+
\vartheta(T)
\Longrightarrow
N_{\boldsymbol\kappa}(T).

Así que la reparación es sencilla y no requiere inventar nada nuevo: Appendix E debería citar/adaptar lem:rb-argument y thm:rb-count, o reproducir brevemente ese argumento.

Entonces desaparece la impresión de que el disco de Jensen está contando directamente todos los ceros hasta T.

No lo considero un contraejemplo al resultado, pero sí una laguna expositiva/demostrativa que debe cerrarse.

⸻

6. prop:lists-compact: continuidad en L^2(2,3) demasiado comprimida

Éste es un punto nuevo.

Para las celdas n=2^j se necesita continuidad de

\boldsymbol\kappa
\longmapsto
J_{\boldsymbol\kappa}
\in L^2(2,3).

La prueba dice que

J_{\boldsymbol\kappa}^{\rm M}

es la transformada Fourier–Plancherel de

\frac{\log\zeta_{\boldsymbol\kappa}(\sigma+it)}
{\sigma+it},

que converge puntualmente y está:

“dominated in L^2(\mathbb R) by the uniform bound of Proposition family-clock.”

Esto probablemente es correcto, pero debería mostrarse explícitamente qué dominante se está usando.

Por ejemplo, si la transferencia proporciona uniformemente

|\log\zeta_{\boldsymbol\kappa}(\sigma+it)|
\le
C_\sigma(1+\log(2+|t|)),

entonces

\left|
\frac{\log\zeta_{\boldsymbol\kappa}(\sigma+it)}
{\sigma+it}
\right|
\le
C_\sigma
\frac{1+\log(2+|t|)}{1+|t|},

y el cuadrado del miembro derecho es integrable:

\int_{\mathbb R}
\frac{(1+\log(2+|t|))^2}{(1+|t|)^2}\,dt<\infty.

Con una línea así queda cerrado.

Ahora mismo el texto cita una “uniform bound” sin exhibir que sea realmente una dominante de L^2.

Clasificación: prueba comprimida, fácilmente reparable; no veo un fallo del resultado.

⸻

7. La transferencia a todo \mathscr O sigue necesitando atención a la uniformidad

v20 ha mejorado este punto, pero hay una sutileza general.

Muchas pruebas originalmente establecidas para

\gamma_k(\lambda)

se transfieren después a cualquier

\boldsymbol\kappa\in\mathscr O

porque

|\kappa_k-\tau_k|\le C_\eta.

Para convergencia absoluta esto suele bastar. Para resultados que dicen uniformemente en \boldsymbol\kappa hace falta comprobar que las constantes dependen únicamente de los parámetros definitorios de \mathscr O.

Es particularmente relevante para:

\text{mean-square cells},
\qquad
L^2(2,3),
\qquad
\sum_n|k_n(\boldsymbol\kappa)|n^{-\sigma'}.

No he encontrado una contradicción concreta, pero recomiendo que el teorema de transferencia diga explícitamente:

C=C(C_\eta,\sigma,\varepsilon,\ldots),

y no simplemente «the proofs apply verbatim».

Eso evita que después la compactitud use accidentalmente una constante dependiente de la lista.

⸻

8. El modelo del determinante regularizado sobre los primos tiene una igualdad que debe escribirse con más precisión

Se define

\mathfrak P(s)=\sum_p p^{-s}

inicialmente para \Re s>1.

Después se escribe:

\det\nolimits_2(I-\mathsf X(s))
=
\prod_p(1-p^{-s})e^{p^{-s}}
=
\frac{e^{\mathfrak P(s)}}{\zeta(s)}
=
\exp\left(
-\sum_{m\ge2}\frac{\mathfrak P(ms)}m
\right)
\qquad
(\Re s>\tfrac12).

El último miembro sí tiene sentido directamente para

\Re s>\frac12,

porque m\sigma>1 para m\ge2.

Pero

\frac{e^{\mathfrak P(s)}}{\zeta(s)}

no está definido por las series/Euler products originales cuando

\frac12<\Re s\le1.

La formulación rigurosa debería ser:

\boxed{
\det_2(I-\mathsf X(s))
=
\frac{e^{\mathfrak P(s)}}{\zeta(s)}
\quad(\Re s>1),
}

y

\boxed{
\det_2(I-\mathsf X(s))
=
\exp\!\left(
-\sum_{m\ge2}\frac{\mathfrak P(ms)}m
\right)
\quad(\Re s>\tfrac12),
}

siendo la segunda expresión la prolongación holomorfa de la primera.

Esto es importante porque justo después el texto explica que en el strip 1/2<\sigma\le1 el problema se desplaza a la continuación de \mathfrak P. La ecuación actual parece utilizar ya \mathfrak P(s) allí.

⸻

9. La frase posterior sobre \zeta e^{-\mathfrak P} tiene el mismo problema semántico

Se dice:

“The contraction proves … that \zeta e^{-\mathfrak P} is holomorphic without zeros in \sigma>1/2.”

Más preciso sería definir primero

D_2(s)
:=
\det\nolimits_2(I-\mathsf X(s))
=
\exp\left(
-\sum_{m\ge2}\frac{\mathfrak P(ms)}m
\right),

y decir

D_2(s)

es holomorfa y sin ceros en \sigma>1/2, mientras que para \sigma>1,

D_2(s)=\frac{e^{\mathfrak P(s)}}{\zeta(s)}.

Es justo la distinción conceptual que la subsección intenta destacar.

⸻

10. La generalización del modelo Euler finito a todos los p\le X está solo esbozada

El teorema explícito se demuestra para

(1-2^{-s})(1-3^{-s}),

y después el texto afirma:

“The same statements hold for \prod_{p\le X}(1-p^{-s})…”

La generalización es natural y no veo obstáculo:

\prod_{p\le X}(1-p^{-s})
=
\sum_{n\mid X^\#}\mu(n)n^{-s},

con lista

\bigcup_{p\le X}
\frac{2\pi}{\log p}\mathbb N

y ecuación funcional correspondiente.

Pero en la conclusión se cita thm:finite-euler como si el teorema formal cubriera directamente todos los X.

Yo haría una de dos:

* extender el enunciado del teorema al conjunto finito arbitrario de primos; o
* añadir un corolario formal.

No es un error matemático aparente, sino una discordancia entre lo formalmente demostrado y lo que luego se cita como teorema.

⸻

11. prop:no-finite-rank está bien

He revisado expresamente este argumento.

Si f cumple las hipótesis de Hamburger y además tiene una serie de Dirichlet soportada solo en enteros X-smooth, Hamburger da

f=C_H\zeta.

Como \zeta tiene coeficiente 1 también en primos >X, la condición de soporte fuerza

C_H=0.

Y eso contradice f\not\equiv0.

No veo problema.

⸻

12. El modelo de dos aristas está ahora correctamente reparado

En v19 señalé que compartir ceros solo daba

S(z+y)=e^{az+b}S(z),

no proporcionalidad inmediata.

En v20 la prueba efectivamente pasa por ese factor y después usa el crecimiento/frecuencias para eliminar a.

Por tanto esa objeción desaparece.

⸻

13. El criterio de aceptación parece internamente correcto

No he detectado un intercambio ilegítimo entre «lista de ceros» y «frecuencias».

La estructura:

\text{window condition}
+
\text{frequency condition}
\iff
\text{accepted by both sides}

se mantiene en el marco abstracto definido allí.

Importante además: la sección no pretende que ese modelo abstracto resuelva la aceptación para \zeta; lo usa como modelo finito y después explica explícitamente dónde falla el paso al rango infinito.

Correcto.

⸻

14. El argumento de densidad del Jacobiano infinito parece sólido internamente

El paso clave es:

si H es ortogonal a todas las funciones de la familia, su transformada entera \widehat H de tipo exponencial tiene ceros en todos

\pm\tau_k.

Pero una función entera no nula de tipo exponencial tiene

O(r)

ceros en |z|\le r, mientras el reloj proporciona

2N_{\rm RVM}(r)+O(1)
\asymp r\log r.

Así que

\widehat H\equiv0.

No encuentro una laguna interna allí.

⸻

15. El criterio de positividad sigue pareciendo sólido

He revisado de nuevo la lógica:

\text{medida positiva}
\Longrightarrow
\varpi_{Z1}\le1,

mientras el producto de Hadamard da

\varpi_{Z1}\ge1.

Entonces

\varpi_{Z1}=1,

y por el teorema anterior,

(D).

No depende de \varpi_{\rm RVM}<1. Este punto es importante: la hipótesis nueva sobre el reloj no contamina el criterio de positividad para Z1.

⸻

16. El teorema de puente tampoco muestra un problema nuevo

La estructura reflexión → reconstrucción entera → simetría → control de crecimiento → constante/polinomio está internamente coherente.

No veo una utilización escondida de RH.

⸻

17. El criterio vertical \mathsf V_\sigma también parece bien separado del cierre

El manuscrito no afirma que

\mathsf V_\sigma=0

esté demostrado para el endpoint. Lo presenta como criterio.

La derivación de la derivada respecto a masas y ordinates usa primero truncaciones finitas y luego paso al límite con cotas ponderadas. No he localizado un fallo concreto.

⸻

18. La parte de densidad explícita del reloj no muestra un error lógico evidente

La expansión de

d\pi_{\rm RVM}

se obtiene mediante la fórmula explícita sintética y stationary phase. El manuscrito separa correctamente:

* parte absolutamente continua;
* átomos en 2^j;
* término oscilatorio principal;
* remainder.

No estoy verificando las constantes asintóticas mediante cálculo, conforme pediste, pero no veo una inconsistencia formal en la derivación escrita.

⸻

19. La parte de varpi_{Z1} sigue siendo uno de los núcleos más sólidos

Nada del resto de la revisión cambia:

\varpi_{Z1}
=
\varpi_{\rm RVM}
\prod_k
\frac{\frac14+\tau_k^2}
{\frac14+\gamma_k^2},

y al agrupar ceros fuera de la línea crítica se obtiene

\varpi_{Z1}\ge1,

con igualdad exactamente en el caso crítico.

Por tanto:

\boxed{
\varpi_{Z1}=1
\iff
\zeta_{Z1}=\zeta
\iff RH.
}

No encuentro que la nueva Route B haya introducido circularidad aquí.

⸻

20. La construcción de Z_1 permanece intacta tras el barrido completo

He vuelto a mirar también dependencias hacia atrás porque los nuevos resultados citan frecuentemente las secciones antiguas.

No encuentro un nuevo defecto en la cadena:

\tau_k
\to
P_{\rm RVM}
\to
\zeta_{\rm RVM}
\to
\gamma_k(\lambda)
\to
P_\lambda
\to
\zeta_\lambda
\to
\zeta_{Z1}.

Ni en:

Z_1=\zeta
\iff RH.

⸻

21. Route B con masas libres mantiene correctamente abierto el punto que debe quedar abierto

El texto ya no vende los finite sections como demostración.

Distingue:

\text{candidate numerical sections}

de

\text{existence of exact sections with residual }\to0.

Y además identifica correctamente la segunda cuestión:

* existencia;
* unicidad dentro del box sin toda la condición de \mathscr O.

Eso es conceptualmente limpio.

⸻

22. Route B′ sigue siendo una equivalencia, no un avance cerrado

La versión prescrita:

B'(C)
\iff RH

permanece coherente.

No he encontrado en el resto del documento una frase posterior que convierta accidentalmente esa equivalencia en «prueba de RH».

La conclusión vuelve a decir que no se ha demostrado (D), lo cual es correcto.

⸻

23. Hay una pequeña inconsistencia conceptual en el texto de la sección del operador primo

Después de observar las tres abscisas:

\sigma>0,
\qquad
\sigma>1,
\qquad
\sigma=\frac12,

se dice que:

“The contraction proves that \zeta has no zeros in \sigma>1”

La invertibilidad de

I-\mathsf X(s)

para \sigma>0 más la igualdad del determinante ordinario con 1/\zeta solo está disponible directamente cuando el operador es trace class:

\sigma>1.

Así que la frase es correcta, pero conviene dejar claro que utiliza contraction + trace-class determinant identity en \sigma>1, no únicamente contraction.

Es menor, pero encaja mejor con el propósito de la subsección.

⸻

24. El texto de estado necesita una actualización general después de introducir Hypothesis 8.5

No solo la frase “Every statement…”:

cualquier tabla o resumen que clasifique como “proved” un resultado cuya conclusión use

\varpi_{\rm RVM}<1

debe marcarlo como

\boxed{\text{conditional on Hypothesis 8.5}.}

El resto de resultados que únicamente usan:

\varpi_{\rm RVM}>0

no necesitan ningún cambio.

⸻

25. Qué NO he encontrado

Después de revisar el resto, no he encontrado:

* otra proposición falsa como la antigua rb-graded;
* una circularidad nueva que introduzca RH en una premisa;
* un uso oculto de \beta_k=\frac12 para los ceros verdaderos antes del endpoint;
* un intercambio ilegítimo general entre ordenadas RVM y ordenadas verdaderas;
* un nuevo fallo del producto canónico;
* un fallo del argumento de Hamburger central;
* un fallo del criterio \varpi_{Z1}=1;
* un fallo del modelo Euler finito;
* un fallo evidente en el teorema multiescala del Jacobiano;
* una reivindicación de que los cálculos floating point prueben el resultado infinito.

Balance completo de v20

Después de este segundo barrido, yo separaría lo pendiente así:

Correcciones obligatorias y objetivas:

\boxed{
K\to k^*,\quad
N_m\to n_m^*,\quad
d\to q
}

en Route B;

\boxed{
\text{condicionar todas las afirmaciones }\varpi_{\rm RVM}<1
\text{ a Hypothesis 8.5;}
}

y corregir:

“Every statement above is proved … without any hypothesis.”

Puntos de rigor que reforzaría:

\boxed{\text{Appendix E: escribir explícitamente argument principle + Backlund}}

y

\boxed{
\text{compactness: exhibir la dominante uniforme de }L^2.
}

Corrección técnica menor pero importante en el modelo primo:

para 1/2<\sigma\le1 no escribir sin explicación

e^{\mathfrak P(s)}/\zeta(s);

usar como objeto primario

\boxed{
\det_2(I-\mathsf X(s))
=
\exp\left[-\sum_{m\ge2}\frac{\mathfrak P(ms)}m\right].
}

Formalización recomendable:

convertir la generalización del modelo de 2,3 a todos los primos p\le X en un corolario explícito, y hacer explícita la uniformidad del teorema de transferencia a \mathscr O.

Con eso, mi diagnóstico sobre la v20 es bastante claro:

\boxed{\text{no veo ya un fallo central que obligue a desmontar la arquitectura.}}

Los defectos pendientes son principalmente dos huecos de exposición rigurosa, varios residuos de variables y una cuestión de estatus condicional. El núcleo {\rm RVM}\to Z_1, los criterios endpoint, la Route B′ como equivalencia y la mayor parte de la nueva maquinaria sobreviven al barrido completo.