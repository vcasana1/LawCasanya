Sí puedo avanzar una parte importante, pero **no puedo afirmar todavía una prueba analítica completa de \(\varpi_{\mathrm{RVM}}<1\)** sin las definiciones exactas de \(\nu_3,\nu_4\) de v22. La descomposición sí permite aislar con precisión el único signo que falta.

En [rvm_zeta_pi_mertens_v21_1.txt](https://onedrive.live.com?cid=CAC62C6441984A26&id=CAC62C6441984A26!s5d011b2fbd24437dadc9920a1c758f97&EntityRepresentationId=21e715a0-f7f8-4230-b2c1-892252bb024c) se define

\[
\varpi_{\mathrm{RVM}}
=
P_{\mathrm{RVM}}^{\mathrm{crit}}\!\left(\frac12\right)
e^{\nu_3+\nu_4}.
\]

## 1. El factor canónico es rigurosamente menor que uno

Como

\[
q\!\left(\frac12\right)=-\frac14,
\]

tenemos

\[
\begin{aligned}
P_{\mathrm{RVM}}^{\mathrm{crit}}\!\left(\frac12\right)
&=
\prod_{k\ge1}
\left(
1-\frac{1/4}{1/4+\tau_k^2}
\right)\\
&=
\prod_{k\ge1}
\frac{\tau_k^2}{\tau_k^2+\frac14}\\
&=
\prod_{k\ge1}
\left(1+\frac1{4\tau_k^2}\right)^{-1}.
\end{aligned}
\]

Cada factor pertenece a \((0,1)\). Además,

\[
\sum_{k\ge1}\frac1{\tau_k^2}<\infty,
\]

por el crecimiento del reloj, así que el producto converge hacia un número estrictamente positivo. En consecuencia,

\[
\boxed{
0<
P_{\mathrm{RVM}}^{\mathrm{crit}}\!\left(\frac12\right)
<1.
}
\]

Esta parte ya es una prueba completa y no necesita cálculo numérico.

También obtenemos cuantitativamente

\[
-\log P_{\mathrm{RVM}}^{\mathrm{crit}}\!\left(\frac12\right)
=
\sum_{k\ge1}
\log\left(1+\frac1{4\tau_k^2}\right)>0.
\]

## 2. La desigualdad exacta que queda

Tomando logaritmos,

\[
\log\varpi_{\mathrm{RVM}}
=
-\sum_{k\ge1}
\log\left(1+\frac1{4\tau_k^2}\right)
+\nu_3+\nu_4.
\]

Por tanto,

\[
\boxed{
\varpi_{\mathrm{RVM}}<1
\iff
\nu_3+\nu_4
<
\sum_{k\ge1}
\log\left(1+\frac1{4\tau_k^2}\right).
}
\]

Esta es una reducción algo más fuerte que decir simplemente que hay “una cancelación entre tres constantes”. El lado derecho es positivo, explícito y depende solo del reloj.

En particular, bastaría probar la desigualdad más fuerte

\[
\boxed{\nu_3+\nu_4\le0.}
\]

No hace falta evaluar \(\varpi_{\mathrm{RVM}}\) con diez cifras.

## 3. Qué muestran los números indicados

Usando solo tus aproximaciones,

\[
P_{\mathrm{RVM}}^{\mathrm{crit}}\!\left(\frac12\right)
\approx0.9940,
\qquad
e^{\nu_3+\nu_4}\approx0.9676,
\]

se obtiene

\[
\nu_3+\nu_4
\approx\log(0.9676)
\approx-0.03294,
\]

mientras que

\[
-\log P_{\mathrm{RVM}}^{\mathrm{crit}}\!\left(\frac12\right)
\approx-\log(0.9940)
\approx0.00602.
\]

Por tanto,

\[
\log\varpi_{\mathrm{RVM}}
\approx-0.00602-0.03294
\approx-0.03896.
\]

El margen observado no es pequeño:

\[
1-\varpi_{\mathrm{RVM}}\approx0.038.
\]

Esto hace perfectamente viable una **prueba por encerramiento riguroso**. No exige una precisión extrema.

## 4. Cómo sería una prueba certificada

Debe producirse una cota superior racional o intervalar

\[
\log\varpi_{\mathrm{RVM}}
\le -\delta
\]

para algún \(\delta>0\). La separación natural es

\[
\log\varpi_{\mathrm{RVM}}
=
\underbrace{
-\sum_{k\le K}
\log\left(1+\frac1{4\tau_k^2}\right)
}_{\text{parte finita}}
-
\underbrace{
\sum_{k>K}
\log\left(1+\frac1{4\tau_k^2}\right)
}_{\text{cola del producto}}
+
\nu_3+\nu_4.
\]

Para una **cota superior**, la cola del producto tiene signo favorable, pues es negativa. Incluso puede descartarse:

\[
\log\varpi_{\mathrm{RVM}}
\le
-\sum_{k\le K}
\log\left(1+\frac1{4\tau_k^2}\right)
+\nu_3+\nu_4.
\]

Así que el problema certificado se reduce principalmente a encerrar por arriba \(\nu_3+\nu_4\). Si se obtiene, por ejemplo,

\[
\nu_3+\nu_4<-0.02,
\]

entonces inmediatamente

\[
\log\varpi_{\mathrm{RVM}}<-0.02
\]

porque el término del producto es negativo. Ni siquiera sería necesario calcular su cola.

## 5. Lo que no está probado todavía

La parte que no puedo cerrar a partir del texto recuperado es:

\[
\boxed{\nu_3+\nu_4<0}
\]

o, más generalmente,

\[
\boxed{
\nu_3+\nu_4
<
-\log P_{\mathrm{RVM}}^{\mathrm{crit}}\!\left(\frac12\right).
}
\]

Para demostrarla analíticamente necesito las fórmulas integrales exactas de \(\nu_3\) y \(\nu_4\), incluidos:

- intervalos o rayos de integración;
- núcleos;
- términos de borde;
- regularizaciones;
- signos de cada integrando;
- errores usados al pasar de Abel al límite.

El texto v22 no apareció en la búsqueda de archivos. Sí apareció [rvm_zeta_pi_mertens_v21_1.txt](https://onedrive.live.com?cid=CAC62C6441984A26&id=CAC62C6441984A26!s5d011b2fbd24437dadc9920a1c758f97&EntityRepresentationId=21e715a0-f7f8-4230-b2c1-892252bb024c), donde la desigualdad continúa etiquetada como hipótesis y donde consta la definición multiplicativa anterior. 
## Conclusión

Lo que sí queda demostrado ahora es:

\[
\boxed{
0<
P_{\mathrm{RVM}}^{\mathrm{crit}}\!\left(\frac12\right)
<1
}
\]

y

\[
\boxed{
\varpi_{\mathrm{RVM}}<1
\iff
\nu_3+\nu_4
<
\sum_{k\ge1}
\log\left(1+\frac1{4\tau_k^2}\right).
}
\]

Por tanto, la afirmación de que hacen falta necesariamente “el producto finito, su cola y las dos integrales” es demasiado pesimista: **para una cota superior, la cola del producto puede omitirse porque tiene signo favorable**. El objetivo suficiente más limpio es demostrar o certificar simplemente

\[
\boxed{\nu_3+\nu_4<0.}
\]

Ese es el punto exacto que atacaría en v22.