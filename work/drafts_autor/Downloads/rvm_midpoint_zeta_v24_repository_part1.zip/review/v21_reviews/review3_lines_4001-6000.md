Primera pasada de auditoría: líneas 4001-6000

Este bloque es bastante distinto del 2000-4000.

Mi impresión general es que aquí el autor ya no intenta demostrar RH directamente, sino:

Reformula el paso final en varias formas equivalentes.
Construye criterios de existencia.
Desarrolla modelos abstractos.
Obtiene teoremas de unicidad y rigidez.
Añade resultados de análisis funcional tipo Kadec-Avdonin-Riesz.
Presenta experimentos numéricos.
Finalmente reconoce explícitamente qué NO está demostrado.

Paradójicamente, esta sección me parece intelectualmente más honesta que muchas partes previas.

1. La observación más importante

Al llegar a las conclusiones aparece:

Not proved. The identity ζZ1=ζ\zeta_{Z1}=\zeta is not proved.

y sigue:

The statements proved to be equivalent to it are listed... none of them evaluates the pairing ... on which every one of them depends at λ=0\lambda=0.

Esto cambia mucho la valoración global.

No estamos ante alguien que crea haber cerrado RH.

Está diciendo explícitamente:

He construido una red de equivalencias, pero el último paso sigue abierto.

Como referee, esto aumenta mucho la credibilidad del trabajo.

2. Corolario de existencia

Líneas 4013-4019.

El resultado esencial es:

(D)  ⟺  ∃ κ∈Otal queζ~Z,κ=ζ.(D) \iff \exists\,\boldsymbol{\kappa}\in\mathscr O \quad\text{tal que}\quad \tilde\zeta_{\mathbb Z,\boldsymbol\kappa} = \zeta .

La estructura es razonable:

compacidad de O\mathscr O,
continuidad del funcional,
rigidez previa.

No veo un fallo evidente.

Pero:

Importante

Esto es una reducción de existencia.

No construye el objeto.

Simplemente dice:

Si existe, entonces coincide con la lista real de ceros.

3. Sistema de escalones ("rung system")

Las líneas 4029-4050 contienen probablemente una de las reformulaciones más elegantes del trabajo.

Aparece el sistema:

∑kcos⁡(κku)+∑nanδ(u−log⁡n)=k(u).\sum_k\cos(\kappa_k u) + \sum_n a_n\delta(u-\log n) = k(u).

Luego se demuestra:

(D)  ⟺  el sistema tiene solucioˊn.(D) \iff \text{el sistema tiene solución}.

Y además:

an=log⁡p2na_n= \frac{\log p}{2\sqrt n}

para potencias primas.

Mi valoración

Matemáticamente esto parece correcto.

Pero hay que entender qué demuestra realmente.

No demuestra RH.

Demuestra que RH es equivalente a la existencia de una solución de cierta ecuación distribuciónal.

Eso es valioso.

No es una resolución.

4. Teorema de no degeneración

Líneas 4052-4078.

Este es uno de los mejores resultados del bloque.

La estrategia:

linealizar el sistema;
construir una función meromorfa H\mathsf H;
aplicarle Hamburger;
concluir que el núcleo es trivial.
Qué obtiene

Básicamente:

Si existe una solución, es aislada al primer orden.

Esto es un resultado serio.

No veo errores locales importantes.

Pero

El propio autor advierte:

The injectivity of the Jacobian ... and with it the existence of a solution, are not proved.

Eso es exactamente la dificultad que esperaría.

5. Gradiente del defecto vertical

Líneas 4080-4097.

Aquí aparece:

∂Vσ∂κk=2Qκ(κk).\frac{\partial V_\sigma}{\partial \kappa_k} = 2Q_{\boldsymbol\kappa}(\kappa_k).

Formalmente es bonito:

un solo objeto analítico,
todos los gradientes evaluados en los ceros.

El resultado parece sólido.

Punto delicado

El propio texto reconoce:

no se demuestra que los puntos críticos con Vσ>0V_\sigma>0 no existan.

Este comentario es muy importante.

Porque una estrategia de minimización necesitaría precisamente eso.

6. Sección "Acceptance criterion"

Desde 4100 aproximadamente.

Aquí cambia completamente el tema.

Construye un marco abstracto:

función continua,
frecuencias discretas,
criterio de aceptación.

La equivalencia:

densidad atoˊmica  ⟺  forma Euler  ⟺  ventana finita.\text{densidad atómica} \iff \text{forma Euler} \iff \text{ventana finita}.

es elegante.

Mi impresión

Esto parece un resultado independiente interesante.

No veo relación inmediata con un fallo lógico del programa RH.

Más bien parece teoría estructural.

7. Parte Kadec-Avdonin-Riesz

Aproximadamente líneas 4650-4750 y siguientes.

Aquí el nivel técnico es alto.

Se usan:

pesos A2A_2,
Helson-Szegő,
Pavlov,
Avdonin-Ivanov.

Todo esto pertenece a literatura estándar.

Lo bueno

Las constantes se calculan explícitamente:

d⋆<14.d_\star<\frac14.

No parece haber magia.

Lo malo

Aunque obtiene bases de Riesz, esto sigue siendo una herramienta funcional.

No cierra el paso final.

8. Experimentos numéricos

Líneas 5200-5300.

Especialmente interesante:

Experimento clock-to-zeros

Líneas 5215-5238.

Se resuelve una sección finita del sistema y aparecen:

ceros cercanos a γk\gamma_k
masas cercanas a von Mangoldt.

Resultado llamativo.

Mi valoración

Sugestivo.

No probatorio.

El propio texto lo dice:

computation and not a proof of existence.

Correcto.

9. Lo más importante de toda la sección

Las conclusiones 5274-5316.

Aquí el autor resume todo.

Y luego, en 5318-5319, declara abiertamente:

La identidad final no está demostrada.

Esto elimina prácticamente cualquier sospecha de pseudoprueba.

10. El problema abierto exacto

Las líneas 5321-5323 son probablemente las más relevantes.

El autor identifica el verdadero cuello de botella:

ζZ1=ζ\zeta_{Z1}=\zeta

equivalentemente:

(D),
identidad celular,
identidad de producto,
positividad,
existencia de lista de coincidencia.

Todo queda reducido a eso.

11. Códigos Python (5800-6000)

He revisado superficialmente los scripts.

Mi impresión:

no son decorativos;
implementan exactamente los experimentos descritos;
contienen aproximaciones explícitas;
no parecen introducir "trampas".

Sin embargo:

Advertencia

La validez matemática de los teoremas no depende de esos programas.

Sólo verifican ejemplos numéricos.

Veredicto global sobre 4001-6000

Si actuara como referee, diría:

Fortalezas
Muy buena honestidad matemática.
Reformulaciones profundas del problema.
Teoremas de rigidez y unicidad plausiblemente correctos.
Buena integración con Hamburger.
Buenos resultados de análisis funcional.
Reconocimiento explícito de qué falta.
Debilidades
El paso de existencia sigue sin resolverse.
El sistema de escalones se transforma pero no se resuelve.
Los criterios variacionales no excluyen mínimos espurios.
Los experimentos son sugestivos pero no demostrativos.
Conclusión

Mi valoración de las líneas 4001-6000 es más favorable que la del bloque 2000-4000.

No encuentro un error fatal inmediato.

Pero tampoco encuentro una demostración de RH.

Lo que sí encuentro es una formulación muy explícita de dónde está exactamente el problema restante: la existencia de una solución del sistema de escalones, equivalentes a (D) y a ζZ1=ζ\zeta_{Z1}=\zeta. El propio manuscrito admite que ese paso sigue abierto.