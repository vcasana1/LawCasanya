Voy ahora con la auditoría del tramo final de rvm_zeta_pi_mertens_v21_1.txt. El archivo termina en la línea 7771, así que el intervalo efectivo es 6001–7771, no llega a 8000.

Resumen ejecutivo

Este bloque final contiene tres tipos de material:

Código y salidas numéricas, aproximadamente hasta la línea 7573.
Un apéndice conceptual sobre interpolaciones y problemas aún abiertos, desde la línea 7574.
Una proposición analítica nueva de cota a priori para soluciones exactas del sistema de escalones, líneas 7641–7748.

Mi conclusión principal es:

El tramo final no cierra (D) ni RH.\boxed{\text{El tramo final no cierra (D) ni RH.}}

Además:

La parte numérica no es una prueba asistida por ordenador certificada.
Algunos cálculos etiquetados como “CERTIFIED” solo certifican ceros de sistemas finitos seleccionados, usando coma flotante ordinaria.
La interpolación aditiva es correctamente identificada como circular.
La nueva proposición de desplazamiento a priori tiene una idea fuerte, pero contiene al menos dos problemas técnicos importantes:
una afirmación incorrecta sobre el orden del producto canónico;
varias dificultades de ramas, Phragmén-Lindelöf y Jensen que necesitan una formulación más rigurosa.
El documento termina reconociendo correctamente que la existencia del sistema infinito sigue abierta.
1. Código de Mertens: líneas 6001–6217
1.1. Derivadas de ζRVM\zeta_{\mathrm{RVM}}

Para los primeros 10001000 ceros sintéticos se calcula el producto prácticamente de forma directa, y después se ajusta

ζRVM′(ρkRVM)≈ϖRVMlog⁡τk2π(1+cτk).\zeta_{\mathrm{RVM}}'(\rho_k^{\mathrm{RVM}}) \approx \varpi_{\mathrm{RVM}} \log\frac{\tau_k}{2\pi} \left(1+\frac{c}{\tau_k}\right).

El valor de ϖRVM\varpi_{\mathrm{RVM}} procede de una extrapolación de tres puntos, no de una evaluación certificada. Para k>1000k>1000, los residuos utilizados en la fórmula explícita dependen de ese ajuste empírico.

Veredicto

Esto sirve como aproximación numérica, pero no permite afirmar que la curva calculada sea exactamente MRVMcritM_{\mathrm{RVM}}^{\mathrm{crit}}. Es una combinación de:

cálculo truncado;
cola sintética;
ajuste asintótico;
extrapolación no certificada.
1.2. Derivadas de ζ\zeta en sus ceros

Para los primeros 10501050 valores se usa mpmath; después se aproxima Z′(t)Z'(t) mediante diferencias centradas con paso

h=10−5,h=10^{-5},

aplicadas a una versión truncada de Riemann-Siegel. Luego se reconstruye ζ′(ρ)\zeta'(\rho).

Problemas
No hay cota del error de truncación de Riemann-Siegel.
No hay análisis del error de la diferencia finita.
No hay estudio de cancelación para ceros donde ∣ζ′(ρ)∣|\zeta'(\rho)| sea pequeño.
La fórmula de residuos supone ceros simples.

El código compara 50 casos con mpmath, pero esa comparación no certifica el resto de los aproximadamente dos millones de derivadas.

Veredicto
aproximacioˊn diagnoˊstica, no caˊlculo riguroso\boxed{\text{aproximación diagnóstica, no cálculo riguroso}}
1.3. Fórmula explícita truncada de MM

Se usa

−2+2ℜ∑kx1/2+iγk(1/2+iγk)ζ′(1/2+iγk)+teˊrminos triviales.-2+2\Re\sum_k \frac{x^{1/2+i\gamma_k}} {(1/2+i\gamma_k)\zeta'(1/2+i\gamma_k)} +\text{términos triviales}.

El texto la presenta como fórmula explícita, pero computacionalmente:

la suma se corta;
los residuos altos son aproximados;
los términos triviales se cortan en seis;
no se regulariza explícitamente la suma de ceros;
no se aporta error uniforme en xx.

Por tanto, la comparación con M(x)M(x) es experimental.

1.4. Construcción del paseo ternario

El paseo μh\mu_h se define escogiendo el signo para seguir una función objetivo T[n]T[n]. Ese objetivo se obtiene mediante:

suma suavizada de ceros;
una malla no uniforme;
interpolación PCHIP;
residuos sintéticos aproximados.

La afirmación de que MhM_h sigue al objetivo dentro de un paso es esencialmente consecuencia del algoritmo de cuantización, siempre que el objetivo no varíe demasiado entre pasos admisibles. No señala una relación aritmética oculta con Möbius.

Punto conceptual importante

Que μh\mu_h tenga el mismo soporte cuadrado-libre que μ\mu no hace que sus signos contengan información sobre la factorización. Los signos se eligen usando el propio objetivo.

Veredicto

El experimento ilustra una cuantización tipo sigma-delta, no una transferencia demostrada entre MRVMM_{\mathrm{RVM}} y MM.

2. Códigos de ratios y producto: líneas 6218–6450
2.1. Ratios con πRVM\pi_{\mathrm{RVM}}

Estos cálculos reutilizan una aproximación previa de πRVM\pi_{\mathrm{RVM}}. Por tanto, no añaden precisión independiente. Los máximos normalizados sobre [8,1000][8,1000] son estadísticas de una cuadrícula, no cotas analíticas.

No hay error lógico si se mantienen como experimentos.

2.2. Producto ordenado

Se calcula

PK=∏k≤K1/4+γk21/4+τk2P_K= \prod_{k\le K} \frac{1/4+\gamma_k^2} {1/4+\tau_k^2}

en doble precisión, comparándolo con un valor fijo

VARPI=0.9619415807,\texttt{VARPI}=0.9619415807,

que procede de Richardson.

Problemas
El valor de comparación no es certificado.
El producto parcial no controla la cola.
La proximidad numérica entre PKP_K y ϖRVM\varpi_{\mathrm{RVM}} no demuestra la convergencia requerida.
Los propios desplazamientos tienen fuerte cancelación, por lo que una cola pequeña en promedio no implica una cota pequeña del resto ordenado.

El manuscrito ya había reconocido correctamente esta limitación.

3. Defecto de Poisson y transporte

El código s09 no calcula directamente

−2∑m≥1(−1)mIm.-2\sum_{m\ge1}(-1)^m I_m.

Lo obtiene como diferencia:

Rψ(1)−(kψ−I0).R_\psi(1)-(\mathsf k_\psi-I_0).

Esto comprueba una identidad aritmética entre cantidades obtenidas del mismo montaje, pero no verifica numéricamente los ImI_m individuales ni la convergencia de la serie de Poisson. El propio código lo declara.

Veredicto

El valor de la “parte oscilatoria” es residual, no una evaluación independiente de la serie que teóricamente representa.

4. Experimento reloj a ceros: líneas 6487–6574

Este experimento es interesante, pero necesita una lectura muy cuidadosa.

Se solucionan ecuaciones de prueba con:

60006000 ordenadas del reloj;
hasta 14 ordenadas libres;
masas libres solo entre 22 y 1111;
intervalo u∈(0,log⁡13.5)u\in(0,\log13.5);
eliminación de masas mediante ridge con parámetro 10−1010^{-10};
Levenberg-Marquardt;
varios cientos de ecuaciones de prueba correlacionadas.
4.1. “Eliminadas exactamente”

El comentario dice que las masas se eliminan “exactamente”, pero el código usa

(PTP+λI)−1PT(P^\mathsf TP+\lambda I)^{-1}P^\mathsf T

con λ=10−10\lambda=10^{-10}.

Eso es una regresión ridge, no la eliminación exacta por mínimos cuadrados sin regularización.

Corrección requerida

Debe decir:

Las masas se eliminan aproximadamente mediante una solución ridge lineal.

4.2. Métrica del residuo

Las salidas muestran la norma euclídea total del residuo, no la norma normalizada por el número de ecuaciones. Como el número de pruebas aumenta desde 361 hasta 1001, las normas de etapas distintas no son directamente comparables.

4.3. Dependencia de la cola

Las ordenadas no resueltas permanecen fijadas en el reloj. Por tanto, la solución finita compensa:

errores de la cola;
masas omitidas;
discretización de integrales;
regularización ridge;
la restricción de banda.

La proximidad de las primeras ordenadas a γk\gamma_k es sugestiva, pero no identifica una solución del sistema infinito.

4.4. Ordenación

El solver actualiza el vector gg, pero no impone explícitamente

g1≤g2≤⋯ .g_1\le g_2\le\cdots.

En esta ejecución concreta no parece haber cruce en las primeras posiciones mostradas, pero el sistema de optimización no preserva estructuralmente el orden.

Veredicto
experimento soˊlido como diagnoˊstico, no como certificado de existencia\boxed{\text{experimento sólido como diagnóstico, no como certificado de existencia}}
5. Salidas numéricas: líneas 6587–6978

Las salidas son consistentes con los códigos, pero no proporcionan una validación independiente. El texto muestra, entre otras cosas:

proximidad numérica de ζZ1\zeta_{Z1} con ζ\zeta;
comportamiento de transición de ζRVM\zeta_{\mathrm{RVM}};
resonancias de Landau;
masas celulares no positivas;
aproximación de las primeras ordenadas y masas.
Observación especialmente importante

La comparación de ζZ1\zeta_{Z1} con ζ\zeta reutiliza la lista de γk\gamma_k para construir PZ1P_{Z1}. Que sus productos coincidan bien a baja altura es esperable por la factorización de Hadamard truncada. No constituye una prueba nueva de (D).

El documento lo reconoce, lo cual es correcto.

6. Bibliografía: líneas 6979–7120

No hay argumento matemático nuevo aquí.

Observaciones editoriales
La bibliografía es amplia y relevante.
Incluye referencias a Hamburger, Hadamard, Ingham, Kadec, Avdonin, Pavlov/Helson-Szegő y fórmulas explícitas.
Varias afirmaciones de novedad son prudentemente evitadas.

Una auditoría bibliográfica completa requeriría comprobar las versiones exactas de los teoremas citados, especialmente:

la forma de Hamburger utilizada;
Pavlov para bases completas interpolantes;
Avdonin-Ivanov para diferencias divididas;
la versión de Phragmén-Lindelöf empleada.
7. Código de Route B: líneas 7135–7423
7.1. Funciones gaussianas no compactamente soportadas

La teoría de las etapas había sido formulada con funciones de prueba compactamente soportadas en (0,∞)(0,\infty). El código utiliza gaussianas en toda R\mathbb R:

ϕ(u)=e−(u−c)2/(2s2).\phi(u)= e^{-(u-c)^2/(2s^2)}.

Luego integra la parte arquimediana solo desde c−9sc-9s hasta c+9sc+9s, mientras que la transformada coseno Fphi usa la integral exacta sobre R\mathbb R.

Problema

El código no implementa exactamente el espacio de pruebas de la teoría:

las gaussianas tienen una cola negativa;
Fphi integra sobre toda la recta;
kpair corta en el semieje positivo;
la contribución de las colas fuera de 9s9s se desprecia.

Como c≥9sc\ge9s, la cola negativa es pequeña, pero no se acota rigurosamente.

Consecuencia

Los “certificados” son para el sistema numérico discretizado y truncado que ejecuta el código, no literalmente para el sistema distribuciónal original.

7.2. Cola espectral finita

core.residual suma sobre la lista kap que se le entrega. Aunque esa lista puede tener 60 000 elementos, sigue siendo finita. No hay una cota explícita del resto infinito del reloj.

Para gaussianas, esa cola debería ser extremadamente pequeña por

e−s2κ2/2,e^{-s^2\kappa^2/2},

pero debe ser acotada si se pretende una prueba asistida por ordenador.

7.3. Lista de Gonek

El localizador de raíces:

muestrea con paso 0.0050.005;
detecta cambios del entero ⌊v(t)⌋\lfloor v(t)\rfloor;
aplica Brent solo si observa cambio de signo.

Esto puede omitir raíces si:

la fase no es monótona;
hay más de un cruce dentro de una celda;
hay contacto sin cambio de signo;
el nivel cambia en más de una unidad.

No aparece una prueba de monotonía de la fase aproximada ni un certificado de todas las raíces.

Veredicto

Las listas de Gonek son aproximaciones numéricas plausibles, no listas exhaustivamente certificadas.

8. “Certificados” de secciones finitas
8.1. Qué se certifica realmente

cert7.py selecciona mediante QR un subconjunto cuadrado de ecuaciones y realiza Newton sobre ese sistema. Después aplica una desigualdad de Banach/Kantorovich a la matriz y derivadas computadas.

Eso podría proporcionar una prueba de existencia para el sistema cuadrado finito seleccionado, si todas las cantidades estuvieran acotadas con aritmética rigurosa.

No certifica simultáneamente todas las ecuaciones acumuladas. De hecho, la columna

ρ(all tests≤m)\rho(\text{all tests}\le m)

es distinta de cero y aumenta en etapas altas, llegando aproximadamente a 3.3×10−33.3\times10^{-3} en la etapa 15.

Conclusión
cero exacto del subsistema seleccionado≠cero exacto de todas las pruebas\boxed{ \text{cero exacto del subsistema seleccionado} \neq \text{cero exacto de todas las pruebas} }
8.2. Uso incorrecto de “CERTIFIED”

Los cálculos usan:

numpy.linalg.inv;
numpy.linalg.solve;
QR en doble precisión;
cuadratura SciPy;
datos binarios;
sin aritmética de intervalos;
sin redondeo dirigido.

Por tanto, “CERTIFIED” significa que las desigualdades calculadas en coma flotante satisfacen el criterio, no que exista un certificado matemático riguroso.

Corrección terminológica recomendada

Usar:

“numerically certified under floating-point evaluation”, o
“passes the computed Banach test”.

No “computer-assisted proof” ni “certified” sin matización.

8.3. Radios microscópicos

Los radios obtenidos están cerca de

10−15 a 10−13.10^{-15}\text{ a }10^{-13}.

Son del orden de la precisión de doble coma flotante. Eso hace especialmente problemática la ausencia de intervalos: el error de redondeo puede ser comparable al radio certificado.

8.4. No hay construcción anidada

Cada etapa se pule independientemente sobre un subsistema cuadrado nuevo. Las soluciones no se demuestran compatibles ni anidadas.

Además:

la etapa 16 falla por Jacobiano singular;
los tests de entrada de bloques dejan de superar el criterio desde etapas bastante bajas;
el criterio completo falla antes que el de banda.

Las propias salidas muestran que esta ruta computacional no produce una cadena infinita certificada.

9. Apéndice de interpolaciones: líneas 7574–7638
9.1. Interpolación aditiva

La identidad

Gε=(1−ε)ζRVM+εζ=ζRVM((1−ε)+εQRVM)\mathcal G_\varepsilon = (1-\varepsilon)\zeta_{\mathrm{RVM}} +\varepsilon\zeta = \zeta_{\mathrm{RVM}} \bigl((1-\varepsilon)+\varepsilon\mathcal Q_{\mathrm{RVM}}\bigr)

es trivial y correcta. Sus ceros adicionales satisfacen

QRVM=−1−εε.\mathcal Q_{\mathrm{RVM}} = -\frac{1-\varepsilon}{\varepsilon}.

El manuscrito reconoce correctamente que esto es una reformulación por conjuntos de nivel y no una herramienta nueva para RH.

Veredicto

Correcto y bien delimitado.

9.2. Aproximación por 1+χ1+\chi

La identidad sobre la línea crítica

eiϑ(t)(1+χ(1/2+it))=2cos⁡ϑ(t)e^{i\vartheta(t)} (1+\chi(1/2+it)) = 2\cos\vartheta(t)

es correcta.

Decir que el reloj es “asintóticamente el conjunto de ceros seleccionado por el término n=1n=1” es una interpretación, no un teorema de correspondencia exacta. El propio texto lo matiza.

9.3. Polinomios de Dirichlet completados

Se define

Rε,M(s)=Pε,M(s)+χ(s)Pε,M(1−s).R_{\varepsilon,M}(s) = P_{\varepsilon,M}(s) +\chi(s)P_{\varepsilon,M}(1-s).

La ecuación funcional es exacta por construcción.

En puntos de Gram, si

ε∑2≤n≤Mn−1/2<1,\varepsilon\sum_{2\le n\le M}n^{-1/2}<1,

el término n=1n=1 domina y determina el signo. Entre puntos de Gram consecutivos, si ϑ\vartheta es monótona, hay un cero por el teorema del valor intermedio.

Veredicto

La afirmación suficiente es correcta. No cuenta todos los ceros y el texto no pretende que lo haga.

10. Problema autónomo de inyectividad del reloj

La ecuación propuesta es:

H(z)=ν8+∑kκ˙k(τkz2+τk2−1τk)=∑n≥2a˙nlog⁡nn−z.H(z) = \nu_8+ \sum_k\dot\kappa_k \left( \frac{\tau_k}{z^2+\tau_k^2} -\frac1{\tau_k} \right) = \sum_{n\ge2} \frac{\dot a_n}{\log n}n^{-z}.

Se pregunta si implica H≡0H\equiv0.

Veredicto

Es una formulación genuinamente autónoma y no contiene las ordenadas reales como datos. Sin embargo:

no está resuelta;
incluso si se resolviera, solo daría inyectividad lineal;
no proporcionaría existencia del sistema no lineal;
no demostraría automáticamente (D).

El manuscrito lo indica correctamente.

11. Proposición de desplazamiento a priori

Este es el principal resultado analítico nuevo del tramo final.

11.1. Paso inicial: crecimiento del conteo

De

Nκ(T+1)−Nκ(T)≪ε(1+T)εN_{\boldsymbol\kappa}(T+1) - N_{\boldsymbol\kappa}(T) \ll_\varepsilon(1+T)^\varepsilon

se obtiene

Nκ(T)=O(T1+ε).N_{\boldsymbol\kappa}(T) = O(T^{1+\varepsilon}).

También se obtiene

∑kκk−2<∞.\sum_k\kappa_k^{-2}<\infty.

Esto es correcto.

11.2. Error: orden del producto canónico

El texto afirma:

el producto tiene orden a lo sumo 1 porque su exponente de convergencia es a lo sumo 1.

Pero la hipótesis local solo da, para cada ε>0\varepsilon>0,

N(T)=Oε(T1+ε).N(T)=O_\varepsilon(T^{1+\varepsilon}).

Eso implica que el exponente de convergencia es a lo sumo 1, sí. Sin embargo, para el producto en la variable ss,

Pκ(s)=∏k(1+(s−1/2)2κk2)×constante,P_{\boldsymbol\kappa}(s) = \prod_k \left( 1+ \frac{(s-1/2)^2}{\kappa_k^2} \right) \times\text{constante},

los ceros son ±iκk\pm i\kappa_k, y un producto de género adecuado puede tener orden 1. El producto emparejado converge por ∑κk−2\sum\kappa_k^{-2}.

El problema no es la conclusión de orden 1, que es plausible, sino que “exponente de convergencia ≤1\le1” no se desprende inmediatamente de una única cota O(T1+ε0)O(T^{1+\varepsilon_0}). Se necesita usar que la hipótesis vale para todo ε0>0\varepsilon_0>0, y después demostrar que el crecimiento máximo del producto es de orden ≤1\le1, no solo que su divisor tiene exponente ≤1\le1.

Reparación

Debe añadirse una estimación directa:

log⁡∣P(s)∣≤∫0∞log⁡(1+C∣s∣2t2)dN(t)=Oε(∣s∣1+ε),\log |P(s)| \le \int_0^\infty \log\left(1+\frac{C|s|^2}{t^2}\right)dN(t) = O_\varepsilon(|s|^{1+\varepsilon}),

para todo ε>0\varepsilon>0, de donde el orden es ≤1\le1.

Clasificación
conclusioˊn reparable, justificacioˊn actual insuficiente\boxed{\text{conclusión reparable, justificación actual insuficiente}}
11.3. Extensión desde (0,∞)(0,\infty)

La regularización mediante

Sκ=−∂u2(Hκ1+)+Hκ(0)δ0′\mathscr S_{\boldsymbol\kappa} = -\partial_u^2 (\mathfrak H_{\boldsymbol\kappa}\mathbf1_+) + \mathfrak H_{\boldsymbol\kappa}(0)\delta_0'

es coherente y recupera la transformada logarítmica del producto. La diferencia de dos extensiones que coinciden en el semieje abierto queda soportada en el origen, por lo que su transformada de Laplace es un polinomio.

Veredicto

Este paso es esencialmente correcto.

11.4. El polinomio es constante

El lado izquierdo se acota por

O(σε0),ε0<1/4.O(\sigma^{\varepsilon_0}), \qquad \varepsilon_0<1/4.

Un polinomio con ese crecimiento en el eje real positivo debe tener grado cero. Correcto.

Detalle menor

En la integración por partes contra NκN_{\boldsymbol\kappa} falta explicitar que el término de borde desaparece tanto en cero como en infinito. La cota de conteo lo garantiza.

11.5. Integración y potencias fraccionarias

Se obtiene formalmente

Pκ(s)=Cθ(PRVMcrit(s))1−θG(s)θYθ(s)e2bs.P_{\boldsymbol\kappa}(s) = C_\theta (P_{\mathrm{RVM}}^{\mathrm{crit}}(s))^{1-\theta} G(s)^\theta Y_\theta(s) e^{2bs}.

Esto se escribe en el semiplano ℜs>3/2\Re s>3/2, donde los factores relevantes pueden elegirse sin ceros y con ramas holomorfas.

Observación

Debe decirse explícitamente que:

PRVMcritP_{\mathrm{RVM}}^{\mathrm{crit}} no se anula allí;
GG no se anula allí;
el semiplano es simplemente conexo;
las ramas se fijan por valores positivos sobre el eje real.

La frase “continuada a lo largo del camino” es demasiado ambigua, porque distintos caminos podrían importar si hubiera ceros. En este semiplano concreto puede hacerse bien.

11.6. Convergencia de YθY_\theta

De

∑X<n≤2X∣an∣2≪X1+ε\sum_{X<n\le2X}|a_n|^2 \ll X^{1+\varepsilon}

se obtiene por Cauchy-Schwarz

∑X<n≤2X∣an∣n1/2−σ≪X3/2−σ+ε/2.\sum_{X<n\le2X} |a_n|n^{1/2-\sigma} \ll X^{3/2-\sigma+\varepsilon/2}.

La serie diádica converge si

σ>32+ε2.\sigma> \frac32+\frac{\varepsilon}{2}.

Al tomar σ=2\sigma=2, ε<1/4\varepsilon<1/4, la convergencia uniforme en ℜs≥2\Re s\ge2 es correcta.

11.7. Problema con Phragmén-Lindelöf

Se define

u(s)=log⁡∣Zκ(s)s+2∣.u(s)= \log\left| \frac{\mathcal Z_{\boldsymbol\kappa}(s)} {s+2} \right|.

Pero s=−2s=-2 está fuera del strip −1≤ℜs≤2-1\le\Re s\le2, así que no introduce singularidad dentro del strip. Bien.

La aplicación de Phragmén-Lindelöf requiere una condición de crecimiento subcrítico respecto de la anchura del strip. Decir solo “es de orden uno” puede no bastar en el caso crítico. El texto remite a un lema anterior, pero para auditar esta prueba habría que comprobar que dicho lema admite exactamente orden uno y esas cotas.

Veredicto
dependencia crıˊtica del lema Phragmeˊn-Lindelo¨f anterior\boxed{\text{dependencia crítica del lema Phragmén-Lindelöf anterior}}
11.8. Jensen en el disco

El disco centrado en 2+iT2+iT y radio 22 llega hasta ℜs=0\Re s=0, no hasta ℜs=4\Re s=4 exclusivamente. El texto divide correctamente el control entre:

el strip hasta ℜs=2\Re s=2;
el semiplano ℜs≥2\Re s\ge2.

Pero Jensen exige comparar el valor en el centro con el promedio sobre el círculo, no simplemente con el máximo. Usar el máximo da una cota válida más débil:

n(r)log⁡(R/r)≤max⁡∣z−z0∣=Rlog⁡∣f(z)∣−log⁡∣f(z0)∣.n(r)\log(R/r) \le \max_{|z-z_0|=R}\log|f(z)| -\log|f(z_0)|.

Eso es correcto.

Punto delicado

Si Pκ(2+iT)P_{\boldsymbol\kappa}(2+iT) pudiera acercarse mucho a cero, la cota inferior sería problemática. La identidad de tres factores y las cotas sobre YθY_\theta proporcionan una cota inferior uniforme relativa a GG, siempre que las ramas y la igualdad estén fijadas correctamente.

11.9. Variación vertical del argumento

El término

e2bse^{2bs}

produce variación 2bT2bT, lo que conduce a la deriva del conteo:

Nκ(T)−NRVM(T)=2bπT+O(log⁡T).N_{\boldsymbol\kappa}(T) - N_{\mathrm{RVM}}(T) = \frac{2b}{\pi}T+O(\log T).

La idea es correcta.

Pero la frase “la variación es 2bT+O(⋯ )2bT+O(\cdots)” debería distinguir:

variación neta del argumento;
variación total.

Para el principio del argumento interesa la variación neta continua a lo largo del camino. Las partes acotadas contribuyen una diferencia acotada entre extremos, así que la estimación funciona.

11.10. De conteo a cuantiles

De la cota de conteo se obtiene

NRVM(κk)=k−2bπκk+O(log⁡κk),\mathcal N_{\mathrm{RVM}}(\kappa_k) = k-\frac{2b}{\pi}\kappa_k +O(\log\kappa_k),

con atención a multiplicidades. Después, el teorema del valor medio produce

κk−τk∼−4b κklog⁡(κk/2π).\kappa_k-\tau_k \sim -\frac{4b\,\kappa_k} {\log(\kappa_k/2\pi)}.

Esto es coherente.

“Si y solo si b=0b=0”
Si b=0b=0, la cota da desplazamiento acotado.
Si b≠0b\neq0, el término principal tiene magnitud aproximadamente κ/log⁡κ\kappa/\log\kappa, por lo que el desplazamiento no puede ser acotado.

Correcto, después de establecer κk≍τk\kappa_k\asymp\tau_k.

11.11. Veredicto de la proposición

La proposición es interesante y probablemente reparable, pero no la consideraría lista para publicación sin:

una demostración explícita del orden del producto;
una comprobación precisa del lema de Phragmén-Lindelöf usado;
una fijación global de ramas en ℜs>3/2\Re s>3/2;
una exposición más clara de variación neta frente a variación total;
una revisión de la uniformidad declarada en θ\theta, porque CθC_\theta depende de la normalización y debe acotarse con cuidado.

Además, como el propio texto dice, es una cota a priori: supone que la solución exacta existe y que satisface las hipótesis de densidad y media cuadrática. No prueba existencia.

12. Diagnósticos finales de secciones acotadas

Las secciones imponen numéricamente

∣κk−τk∣≤1.2,∣an∣≤0.5.|\kappa_k-\tau_k|\le1.2, \qquad |a_n|\le0.5.

Estas cotas son regularizadores del solver, no consecuencias del teorema ni hipótesis del sistema infinito. La cola no resuelta queda fijada en el reloj.

Los residuos pequeños y la validación cruzada muestran estabilidad local del problema discretizado. No demuestran:

convergencia de las listas;
consistencia entre todas las etapas;
que el residuo distribuciónal tienda a cero;
compacidad de las masas;
que el límite satisfaga todas las pruebas;
que las restricciones permanezcan inactivas;
existencia de una solución infinita.

El manuscrito lo declara correctamente.

13. Veredicto global de 6001–7771
Sólido o esencialmente sólido
La interpretación de la interpolación aditiva como conjunto de nivel.
La identidad exacta con 1+χ1+\chi.
El criterio suficiente de dominación en puntos de Gram.
La formulación autónoma del problema de inyectividad del reloj.
La extensión distribuciónal regularizada del sistema.
La aparición de un polinomio soportado en u=0u=0.
La reducción de ese polinomio a una constante.
La derivación formal del término de deriva 2bT/π2bT/\pi.
La traducción del conteo a desplazamiento, una vez aceptadas las cotas analíticas previas.
Requiere reparación o ampliación
Orden del producto canónico en la proposición a priori.
Aplicación crítica de Phragmén-Lindelöf.
Elección y continuidad de ramas fraccionarias.
Uniformidad de constantes.
Certificación de las listas de Gonek.
Correspondencia exacta entre gaussianas numéricas y pruebas de soporte compacto.
Control de las colas espectrales y aritméticas.
Numéricamente no riguroso
Valores de ζ′\zeta' y residuos altos.
Extrapolación de ϖRVM\varpi_{\mathrm{RVM}}.
Fórmulas explícitas de Mertens.
Producto ordenado truncado.
Solvers Levenberg-Marquardt.
“Certificados” en coma flotante.
Radios de Banach del orden de 10−1510^{-15}.
Cuadraturas y truncamientos sin intervalos.
Certificación solo de subconjuntos cuadrados de ecuaciones.
Resultado definitivamente no obtenido
(D),ζZ1=ζ,RH\boxed{ (D),\qquad \zeta_{Z1}=\zeta,\qquad \mathrm{RH} }

El cierre del documento es correcto y explícito: la interpolación atómica interior no está establecida, las secciones finitas no producen una solución infinita y el problema principal permanece abierto.