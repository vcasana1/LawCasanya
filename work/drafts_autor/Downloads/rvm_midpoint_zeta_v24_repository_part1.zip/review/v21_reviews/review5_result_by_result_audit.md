He auditado la **v21.1 completa como documento nuevo**, sin heredar la validación de v20, sin internet y sin hacer cálculos numéricos nuevos. He releído los **160 resultados formales** —teoremas, proposiciones, lemas y corolarios— con sus pruebas y dependencias.

El resultado global es mejor de lo que parecía durante la revisión parcial: **no he encontrado un teorema central cuya conclusión haya demostrado ser falsa**. Sí he encontrado **una laguna estructural importante**, **una sobreafirmación falsa dentro de un lema**, **dos reparaciones locales**, y una gran familia de resultados que queda provisionalmente dependiente de la laguna estructural.

Uso estas marcas:

- **OK**: prueba internamente coherente.
- **OK-ext**: internamente coherente, pero usa un teorema externo citado que no he verificado en internet.
- **DEP56**: su prueba propia puede estar bien, pero depende de `thm:mellin-counts`, cuya prueba tiene una laguna.
- **GAP**: laguna demostrativa real.
- **FIX**: resultado aparentemente correcto, pero hay que corregir un paso.
- **ERROR-L**: sobreafirmación falsa localizada; el núcleo del lema se salva.

## Auditoría resultado por resultado

| # | Resultado | Estado |
|---:|---|---|
| 1 | `prop:lambert` | **OK** |
| 2 | `lem:bounded-displacement` | **OK** |
| 3 | `thm:canonical` | **OK** |
| 4 | `thm:exp-sum` | **OK** |
| 5 | `cor:point-centroid` | **OK** |
| 6 | `cor:MH-decay` | **OK** |
| 7 | `lem:Ei` | **OK** |
| 8 | `thm:J-exists` | **OK** |
| 9 | `prop:finite-inversion` | **OK** |
| 10 | `lem:A-RVM` | **OK** |
| 11 | `thm:Lambert-estimate` | **OK** |
| 12 | `cor:three-limits` | **OK-ext** (PNT) |
| 13 | `thm:unit-cell` | **OK** |
| 14 | `cor:cn-bounded` | **OK** |
| 15 | `cor:ZRVM-Dirichlet` | **OK** |
| 16 | `thm:MS` | **DEP56** |
| 17 | `cor:weighted-factorization` | **DEP56** |
| 18 | `lem:cell-cancel` | **OK** |
| 19 | `prop:eventual-positive` | **OK** |
| 20 | `prop:Mcrit-poles` | **OK** |
| 21 | `prop:Gaussian` | **OK**, bajo su hipótesis explícita |
| 22 | `thm:transition` | **OK** |
| 23 | `lem:TR-smooth` | **OK** |
| 24 | `lem:TR-clock` | **OK** |
| 25 | `lem:TR-harmonic` | **OK** |
| 26 | `lem:TR-boundary` | **OK** |
| 27 | `cor:derivative-zeros` | **OK** |
| 28 | `cor:vertical-limit` | **OK** |
| 29 | `lem:saw-primitive` | **OK** |
| 30 | `thm:halfplane-RVM` | **OK** |
| 31 | `thm:no-Dirichlet-RVM` | **OK** |
| 32 | `thm:unsmoothed-RVM` | **OK** |
| 33 | `thm:Hadamard` | **OK** |
| 34 | `prop:M-transform-relation` | **OK**, segunda parte correctamente condicional |
| 35 | `cor:Q-control` | **OK-ext** |
| 36 | `thm:path` | **OK** |
| 37 | `thm:generator` | **OK** |
| 38 | `prop:integrated-multiplier` | **OK** |
| 39 | `cor:endpoint-expansion` | **OK** |
| 40 | `prop:residues` | **OK** |
| 41 | `prop:Z1-class` | **OK** |
| 42 | `thm:Hamburger-Z1` | **OK-ext** |
| 43 | `thm:D-multiplier` | **OK** |
| 44 | `lem:zeta-growth` | **OK** |
| 45 | `lem:log-zeta` | **OK** |
| 46 | `lem:perron-kernel` | **OK-ext** |
| 47 | `thm:step3` | **OK** |
| 48 | `thm:transfer` | **OK** |
| 49 | `cor:step3-D` | **OK** |
| 50 | `prop:finite-Perron` | **OK** |
| 51 | `thm:coefficient-criterion` | **OK** |
| 52 | `thm:Z1-clock` | **OK** |
| 53 | `thm:varpi-Z1` | **OK** |
| 54 | `cor:product-identity` | **OK** |
| 55 | `prop:Z1-bounded` | **OK** |
| **56** | **`thm:mellin-counts`** | **GAP** |
| 57 | `thm:distributional-EF` | **DEP56** |
| 58 | `thm:cell-form` | **DEP56** |
| 59 | `prop:family-clock` | **OK** |
| 60 | `prop:family-flow` | **OK** |
| 61 | `prop:varpi-verified` | **OK-ext**; input de verificación externa |
| 62 | `prop:first-cell` | **DEP56** |
| **63** | **`lem:L2-partial-sums`** | **ERROR-L** |
| 64 | `thm:joining-factor` | **DEP56** |
| 65 | `prop:cell-explicit` | **DEP56** |
| 66 | `prop:cell-limit` | **DEP56** |
| 67 | `lem:mean-value-ordinates` | **OK** |
| 68 | `thm:mean-square-cells` | **DEP56** parcialmente, por celdas \(2^j\) |
| 69 | `cor:abscissa-one` | **DEP56** |
| 70 | `thm:atomized-continuation` | **DEP56** |
| 71 | `thm:closing` | **DEP56** |
| 72 | `prop:atomized-clock` | **DEP56** |
| 73 | `prop:Mellin-Mertens` | **DEP56** |
| 74 | `prop:nonconstant` | **DEP56** por la construcción atomizada |
| 75 | `prop:convexity` | **OK** |
| 76 | `thm:pair-criterion` | **DEP56**, con una frase a suprimir |
| 77 | `thm:double-hamburger` | **DEP56** |
| 78 | `prop:clock-asymmetry` | **DEP56** |
| 79 | `lem:summation-positive` | **OK** |
| 80 | `thm:positivity` | **OK** |
| 81 | `cor:positivity` | **DEP56** |
| 82 | `lem:summation-all` | **DEP56** |
| 83 | `prop:one-number` | **DEP56** |
| 84 | `thm:real-axis` | **OK** |
| 85 | `prop:open-path-varpi` | **DEP56** solo por \(\mathsf W\); resto OK bajo Hyp. 8.5 |
| 86 | `lem:stationary-U` | **OK** |
| 87 | `thm:clock-density` | **OK** |
| 88 | `cor:clock-cells` | **OK** |
| 89 | `prop:height-kernels` | **OK** |
| 90 | `prop:flow-count` | **OK** |
| 91 | `prop:defect-kernel` | **OK** |
| 92 | `lem:vertical-growth` | **DEP56** |
| 93 | `prop:gaussian-defect` | **DEP56** |
| 94 | `cor:residue-condition` | **DEP56** |
| 95 | `prop:entire-lambda` | **OK** |
| **96** | `prop:exceptional-set` | **FIX** |
| 97 | `cor:cell-mass-form` | **DEP56** |
| 98 | `prop:witness` | **DEP56** |
| 99 | `prop:per-cell` | **OK** |
| 100 | `prop:dichotomy` | **OK**, justificar mejor Hadamard |
| 101 | `thm:ladder` | **OK** |
| 102 | `thm:halfline-hamburger` | **OK-ext** |
| 103 | `cor:ladder-pair` | **DEP56** |
| 104 | `thm:bridge` | **OK-ext** |
| 105 | `cor:bridge-family` | **DEP56** |
| 106 | `prop:continuous-phase` | **OK** |
| 107 | `prop:one-ordinate` | **OK** |
| 108 | `prop:rung-functional` | **OK** |
| 109 | `thm:transport-band` | **OK** |
| 110 | `prop:clock-defect-poisson` | **OK** |
| 111 | `thm:clock-jacobian` | **OK-ext** (Ingham) |
| 112 | `thm:transfer-O` | **DEP56** |
| 113 | `thm:rigidity` | **DEP56** |
| **114** | `prop:lists-compact` | **DEP56 + FIX** |
| 115 | `cor:existence-form` | **DEP56** |
| 116 | `thm:free-masses` | **DEP56** |
| 117 | `thm:nondegenerate` | **DEP56**; argumento propio OK |
| 118 | `prop:critical-points` | **DEP56**; diferencial propio OK |
| 119 | `thm:acceptance` | **OK** |
| 120 | `prop:graph-model` | **OK** |
| 121 | `thm:finite-euler` | **OK** |
| 122 | `prop:no-finite-rank` | **OK-ext** |
| 123 | `lem:rb-canonical-box` | **OK** |
| 124 | `cor:rb-D-implies-B` | **DEP56** |
| 125 | `prop:rb-compactness` | **OK** |
| 126 | `cor:rb-selection` | **OK**, condicional como declara |
| 127 | `lem:rb-archimedean` | **OK** |
| 128 | `lem:rb-laplace` | **OK** |
| 129 | `prop:rb-prescribed-uniqueness` | **OK**, Hadamard puede explicitarse |
| 130 | `cor:rb-Bprime` | **DEP56** en dirección RH\(\Rightarrow B'\) |
| 131 | `lem:rb-matching` | **OK** |
| 132 | `lem:rb-lipschitz` | **OK** |
| 133 | `thm:rb-certificate` | **OK** |
| 134 | `thm:rb-staged` | **OK** |
| 135 | `prop:rb-graded` | **OK** — corregida respecto v19 |
| 136 | `lem:rb-gonek-tube` | **OK-ext** |
| 137 | `lem:rb-upsilon-infinite` | **OK** |
| 138 | `lem:rb-PL` | **OK-ext** |
| 139 | `lem:rb-factor` | **OK** |
| 140 | `lem:rb-halfplane` | **OK** |
| 141 | `lem:rb-strip` | **OK** |
| 142 | `lem:rb-backlund` | **OK** |
| 143 | `lem:rb-argument` | **OK** |
| 144 | `thm:rb-count` | **OK** |
| 145 | `cor:rb-displacement` | **OK** |
| 146 | `lem:rb-generating` | **OK** |
| 147 | `thm:rb-criterion` | **OK-ext** |
| 148 | `cor:rb-riesz` | **OK-ext** |
| 149 | `prop:rb-variable-blocks` | **OK** |
| 150 | `cor:rb-kadec-avdonin` | **OK-ext** |
| 151 | `thm:rb-variable-N` | **OK** |
| 152 | `lem:rb-psi-bound` | **OK** |
| 153 | `prop:rb-O-blocks` | **OK** |
| 154 | `cor:rb-one-condition` | **OK** |
| 155 | `prop:rb-weight` | **OK** |
| 156 | `thm:rb-obstruction` | **OK-ext** |
| 157 | `lem:rb-smoothing` | **OK-ext** |
| 158 | `cor:rb-obstruction` | **OK-ext** |
| 159 | `prop:additive-level-v18` | **OK** |
| **160** | `prop:rung-apriori-v18` | **FIX** |

---

# 1. El problema principal: Teorema 12.5 / resultado 56

Éste es el defecto más importante de toda la v21.1.

El teorema construye \(J_X^{\rm M}\) en cada línea \(\Re s=\sigma\) como inversa Fourier–Plancherel de

\[
F_\sigma(t)
=
\frac{\log\zeta_X(\sigma+it)}{\sigma+it}.
\]

Hasta ahí, bien.

El problema aparece al intentar demostrar que la función recuperada **no depende de \(\sigma\)**. La prueba toma un test con \(\widehat\psi\in C_c^\infty\) y afirma que cierta integral con factor \(\widehat\psi(t)\) es independiente de \(\sigma\) «by Cauchy's theorem». rvm_zeta_pi_mertens_v21_1

Eso no funciona tal como está:

\[
\widehat\psi(t)
\]

es una función arbitraria de la variable real \(t\). **No es una función holomorfa de**

\[
s=\sigma+it.
\]

Por tanto no se puede desplazar el contorno de

\[
\frac{\log\zeta_X(s)}s\,\widehat\psi(\Im s)
\]

mediante Cauchy.

Ésta es una laguna real, no una errata.

### Pero es muy reparable

La conclusión pretendida es exactamente un resultado estándar de Hardy/Paley–Wiener para el semiplano. Tienes

\[
F(s)=\frac{\log\zeta_X(s)}s
\]

holomorfa para \(\Re s>1\), y

\[
\sup_{\sigma\ge c}
\int_{\mathbb R}|F(\sigma+it)|^2\,dt<\infty.
\]

Entonces el teorema \(H^2\) del semiplano proporciona **una única**

\[
j(u)\in L^2(0,\infty)
\]

tal que

\[
F(s)=\int_0^\infty j(u)e^{-su}\,du.
\]

Eso da directamente la independencia de \(\sigma\) y el soporte \(u\ge0\).

También podrías evitar la maquinaria Hardy definiendo primero \(J_X\) desde la fórmula explícita y recuperando posteriormente la transformada de Mellin desde \(-\zeta'_X/\zeta_X\). La v21.1 ya tiene casi todo lo necesario en el Teorema 12.6. rvm_zeta_pi_mertens_v21_1

**Conclusión:** no veo motivo para abandonar `mellin-counts`, pero **la prueba presente no vale**.

---

# 2. Esto no destruye treinta teoremas: crea una dependencia pendiente

Es importante distinguirlo.

Resultados como `cell-form`, `joining-factor`, `closing`, `summation-all`, etc., no contienen necesariamente un nuevo error. Su problema es que utilizan el \(J_X^{\rm M}\) cuya construcción aún no ha quedado demostrada.

Por ejemplo, `cell-form` utiliza explícitamente la unicidad de `mellin-counts` para identificar

\[
J_{Z1}^{\rm M}=J
\]

cuando \(\zeta_{Z1}=\zeta\). rvm_zeta_pi_mertens_v21_1

Por eso los he marcado **DEP56**, no «erróneos».

Si arreglas 12.5 mediante Paley–Wiener/Hardy, una gran fracción de las marcas DEP56 desaparece de golpe.

---

# 3. Lema 13.6: una afirmación es falsa con la regularidad declarada

El núcleo \(L^2\) del lema está bien:

\[
S_K\to S,\qquad E_K\to E
\quad\text{en }L^2(I).
\]

El problema es la consecuencia (a). El enunciado dice que **para toda \(\psi\) Lipschitz compactamente soportada** la serie integrada converge absolutamente. rvm_zeta_pi_mertens_v21_1

Pero la propia prueba reconoce después:

> absolute convergence follows ... when \(\psi\) is Lipschitz with \(\psi'\) of bounded variation

es decir, impone una hipótesis adicional. rvm_zeta_pi_mertens_v21_1

Lipschitz solo implica

\[
\psi'\in L^\infty
\]

a.e.; no implica

\[
\psi'\in BV.
\]

Por tanto conviene separar:

\[
\boxed{
\psi\text{ Lipschitz}
\Rightarrow
\text{convergencia de los emparejamientos}
}
\]

de

\[
\boxed{
\psi'\in BV
\Rightarrow
\text{convergencia absoluta término a término}.
}
\]

Esto es especialmente benigno porque las funciones concretas que utilizas después son suaves o tienen la regularidad adicional necesaria. No afecta al corazón del bound \(L^2\).

---

# 4. `prop:exceptional-set`: conclusión buena, argumento topológico incorrecto

La prueba dice:

> “its zeros are discrete, and a discrete subset of the compact interval \([0,1]\) is finite”.

Eso es falso como afirmación topológica general: por ejemplo,

\[
\{1/n:n\ge1\}
\]

es infinito y discreto como subespacio de \([0,1]\).

Pero en tu caso la función es **entera no idénticamente nula**, y eso sí da inmediatamente el resultado correcto: sus ceros no tienen punto de acumulación finito. Una sucesión infinita de ceros en el compacto \([0,1]\) tendría una subsucesión convergente dentro de \([0,1]\), contradiciendo el teorema de identidad. rvm_zeta_pi_mertens_v21_1

Así que basta cambiar una frase. La proposición se salva íntegra.

---

# 5. Appendix E / resultado 160: queda un error local en el Jensen bound

La v21.1 ha reparado muy bien casi todos los problemas antiguos de este apéndice:

- trata correctamente la distribución soportada en \(u=0\);
- obtiene el polinomio de borde;
- prueba que es constante \(\mathrm b\);
- conserva el factor
  \[
  e^{2\mathrm bs};
  \]
- introduce la hipótesis cuadrática sobre las masas;
- hace el conteo acumulativo mediante Backlund + principio del argumento;
- identifica correctamente el drift
  \[
  \frac{2\mathrm b}{\pi}T.
  \]

Todo eso está ahora mucho mejor. rvm_zeta_pi_mertens_v21_1

Pero al aplicar Jensen en el disco centrado en \(2+iT\), la prueba afirma en \(\Re s\ge2\)

\[
\log|P_{\boldsymbol\kappa}(s)|
\le
\log|G(s)|+\mathbb K.
\]

El factor exacto contiene

\[
e^{2\mathrm bs}.
\]

Por tanto

\[
|e^{2\mathrm bs}|=e^{2\mathrm b\Re s},
\]

y la constante \(\mathbb K\), construida en la línea \(\Re s=2\), solo incorpora \(4|\mathrm b|\). rvm_zeta_pi_mertens_v21_1

No puedes extender esa misma constante a todo \(\Re s\ge2\).

### Reparación

No necesitas todo el semiplano. El disco Jensen tiene radio \(2\) y centro \(2+iT\), así que

\[
0\le\Re s\le4.
\]

Luego basta sustituir el término \(4|\mathrm b|\) por, por ejemplo,

\[
8|\mathrm b|.
\]

Con esa modificación la estimación vuelve a ser uniforme en el disco y el resto del conteo no cambia.

Por tanto:

\[
\boxed{\text{resultado 160 aparentemente correcto; prueba local a corregir.}}
\]

---

# 6. `prop:lists-compact`: escribir la dominante \(L^2\)

Aquí no veo una laguna comparable a 12.5, pero sí una justificación demasiado implícita.

Para usar convergencia dominada en

\[
\frac{\log\zeta_{\boldsymbol\kappa}(\sigma+it)}
     {\sigma+it}
\]

deberías escribir explícitamente la dominante uniforme. Basta algo como

\[
\left|
\frac{\log\zeta_{\boldsymbol\kappa}(\sigma+it)}
{\sigma+it}
\right|
\le
C_\sigma
\frac{1+\log(2+|t|)}{1+|t|},
\]

porque

\[
\int_{\mathbb R}
\frac{(1+\log(2+|t|))^2}{(1+|t|)^2}\,dt<\infty.
\]

Entonces el paso es inmediato.

Éste es **FIX**, no GAP.

---

# 7. `pair-criterion`: eliminar una frase, no el teorema

La prueba obtiene por Hamburger

\[
\tilde\zeta_{\mathbb Z,\lambda}=\zeta.
\]

También obtiene que no puede haber zeros de \(\zeta\) fuera de la línea porque el lado continuo y la simetría excluyen zeros en los dos semiplanos.

Pero después dice que esos zeros:

> “are the points \(\frac12\pm i\gamma_k\)”.

Eso es más fuerte de lo que se ha justificado para \(\lambda\) general: la prolongación meromorfa del joining factor podría tener zeros o polos exactamente sobre la línea crítica y alterar finitamente el divisor allí.

No necesitas esa frase.

Lo que necesitas es simplemente:

\[
\text{todos los zeros no triviales de }\zeta
\text{ están en }\Re s=\frac12,
\]

es decir RH. Para \(\lambda=0\),

\[
RH\Rightarrow\zeta_{Z1}=\zeta
\]

por tu Teorema 11.2.

Así que el teorema se salva quitando la identificación innecesaria del conjunto exacto de ordenadas.

---

# 8. Los pasos de Hadamard en 100 y 129 son aceptables, pero los haría explícitos

En `prop:dichotomy` aparece la frase de que un cociente entero de funciones de orden \(\le1\) tiene orden \(\le1\). La formulación es demasiado rápida, aunque aquí la conclusión se puede justificar correctamente mediante comparación de factorizaciones/Nevanlinna.

En Route B′ ocurre:

\[
P_{\boldsymbol\kappa}
=
c\,\xi\,e^Q.
\]

Como \(Q\) ya es polinómico y los dos lados relevantes tienen orden \(1\), se obtiene

\[
\deg Q\le1,
\]

y la simetría fuerza finalmente \(Q\) constante. rvm_zeta_pi_mertens_v21_1

No considero ya esto una laguna, pero escribiría:

> “Comparing the Hadamard factorizations of the two order-one entire functions…”

en vez de la formulación abreviada del cociente.

Route B′ sigue en pie.

---

# 9. Route B ha salido especialmente bien de esta auditoría

Esto merece resaltarse porque era la zona más problemática de v19.

En v21.1:

\[
\boxed{\text{`rb-graded` está correctamente reparada.}}
\]

La hipótesis ahora es la correcta sobre todos los productos de cola, no el antiguo

\[
\prod q_m=0.
\]

También están reparados:

- el índice Gonek;
- `rb-matching`;
- las variables \(K/k^*\);
- \(d/q\);
- la separación entre right-inverse certificate y mínimos cuadrados;
- el estado de los cálculos floating point;
- el término de borde \(u=0\);
- el drift lineal de Appendix E.

No he encontrado en los resultados 123–158 una nueva contradicción interna.

Las partes `Gonek`, `Pavlov`, `Kadec–Avdonin`, `Fujii`, etc. quedan **OK-ext** porque, conforme pediste, no he ido a verificar las fuentes externas.

---

# 10. El núcleo endpoint tampoco ha sufrido daños

Después de rehacer la auditoría desde cero, siguen sólidos internamente:

\[
\boxed{
\zeta_{Z1}=\zeta
\iff
RH
}
\]

mediante Hamburger/Hadamard;

\[
\boxed{
\varpi_{Z1}\ge1,
\qquad
\varpi_{Z1}=1
\iff
\zeta_{Z1}=\zeta
}
\]

y

\[
\boxed{
\zeta_{Z1}(\sigma)\ge\zeta(\sigma)
\quad(\sigma>1),
}
\]

con igualdad en un solo \(\sigma>1\) si y solo si hay cierre.

He vuelto a revisar específicamente el producto por parejas fuera de la línea en `varpi-Z1` y la monotonicidad del factor en `real-axis`; no encuentro el fallo que destruiría esos criterios.

---

# 11. También sobreviven las piezas RVM iniciales

Tras releerlas, no estoy heredando aquí la auditoría anterior. En **esta v21.1** encuentro internamente coherentes:

\[
\text{Lambert clock}
\to
P_{\rm RVM}
\to
\zeta_{\rm RVM},
\]

el bound de sumas exponenciales,

\[
S_{\rm RVM}(N;u)=O(\log N),
\]

la existencia del zero sum, el bound de \(J_{\rm RVM}\), el control Lipschitz, el teorema de transición,

\[
\zeta_{\rm RVM}
=
\varpi_{\rm RVM}(1+w)(1+O(1/t)),
\]

el límite vertical,

\[
\zeta_{\rm RVM}(\sigma+it)\to\varpi_{\rm RVM},
\]

la ausencia de series de Dirichlet y el Mertens sintético

\[
M_{\rm RVM}^{\rm crit}(x)
=
L+O_\varepsilon(x^{1/2+\varepsilon}).
\]

La hipótesis

\[
\varpi_{\rm RVM}<1
\]

está ahora correctamente separada y declarada como **Hypothesis 8.5**, no como un teorema.

---

# 12. Diagnóstico matemático de v21.1

La prioridad de corrección es ahora muy clara:

\[
\boxed{\textbf{PRIORIDAD 1: reparar `thm:mellin-counts`.}}
\]

Eso eliminaría de una vez la incertidumbre sobre aproximadamente treinta resultados marcados `DEP56`.

Después:

\[
\boxed{\textbf{PRIORIDAD 2: corregir el enunciado de `L2-partial-sums`.}}
\]

Separar Lipschitz de \(\psi'\in BV\).

Después:

\[
\boxed{\textbf{PRIORIDAD 3: dos reparaciones locales.}}
\]

- `exceptional-set`: usar «zeros of a nonzero entire function cannot accumulate».
- Appendix E: controlar \(e^{2bs}\) en \(0\le\Re s\le4\), no con la constante exclusiva de \(\Re s=2\).

Y por último:

\[
\boxed{\textbf{PRIORIDAD 4: reforzar dos justificaciones.}}
\]

- dominante \(L^2\) explícita en `lists-compact`;
- comparación de Hadamard explícita en `dichotomy` y B′.

## Veredicto global

No encuentro en v21.1 el equivalente del antiguo `rb-graded` falso.

El estado real que veo es:

\[
\boxed{
\text{159/160 resultados no presentan una conclusión que haya podido refutar;}
}
\]

pero eso **no** significa «159 demostrados», porque existe una dependencia común importante. El mapa correcto es:

\[
\boxed{
\text{1 GAP estructural}
+
\text{1 sobreafirmación local falsa}
+
\text{2 FIX claros}
+
\text{muchos DEP56}.
}
\]

Y la buena noticia matemática es que la única laguna estructural detectada, `mellin-counts`, parece muy probablemente **reparable con una herramienta estándar sobre tu objeto nuevo** —Hardy \(H^2\)/Paley–Wiener para el semiplano—, sin cambiar la arquitectura del manuscrito ni recurrir a una vía clásica equivalente a RH.

No he modificado la v21.1.