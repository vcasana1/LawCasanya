A continuación tienes una lista maestra numerada de todos los cambios que propondría a partir de la auditoría realizada sobre las líneas 2000–7771 de rvm_zeta_pi_mertens_v21_1.txt. Incluyo errores, lagunas, demostraciones incompletas, dependencias que deben hacerse explícitas, mejoras de precisión expositiva y cambios opcionales que facilitarían la lectura.

Clave de prioridad
[Crítico]: afecta a la validez de un teorema o conclusión.
[Mayor]: la afirmación parece reparable, pero la demostración actual no es suficiente.
[Moderado]: falta una justificación local o una hipótesis explícita.
[Claridad]: no es imprescindible para la validez, pero mejora mucho la comprensión.
[Numérico]: afecta a la interpretación, reproducibilidad o certificación de los experimentos.
A. Estado lógico general del manuscrito

[Crítico] Declarar desde la introducción que la identidad final no está demostrada. No debe esperarse hasta las conclusiones para indicar que (D)(D), ζZ1=ζ\zeta_{Z1}=\zeta y RH permanecen abiertos. El manuscrito sí lo reconoce expresamente al final, pero esta advertencia debería aparecer también en el resumen, introducción y programa principal.

[Claridad] Separar visualmente “teoremas demostrados”, “equivalencias”, “hipótesis”, “heurísticas” y “experimentos”. El texto suele etiquetarlos correctamente, pero la cantidad de criterios equivalentes puede producir la impresión de que la existencia ya se ha probado.

[Claridad] Incluir una tabla de dependencias lógicas. Cada resultado debería indicar si depende de:

ϖRVM<1\varpi_{\mathrm{RVM}}<1;
la hipótesis del resto celular;
el crecimiento de saltos;
la pertenencia a O\mathscr O;
la condición (D)(D);
RH;
datos de ceros verificados.

[Claridad] Distinguir siempre entre “reducción a” y “resolución de”. Por ejemplo, “(D)(D) es equivalente a la existencia de una lista” no prueba que esa lista exista.

[Claridad] Introducir una notación tipográfica uniforme para resultados condicionales. Las conclusiones que dependen de hipótesis numéricas o estructurales podrían llevar el prefijo “Condicional”.

[Claridad] Añadir al principio una lista corta de los únicos puntos realmente abiertos. El propio manuscrito termina identificando:

el problema de endpoint (D)(D);
la existencia del sistema infinito;
la inyectividad lineal autónoma del reloj;
la posibilidad de pasar al límite desde secciones finitas.

[Claridad] Evitar llamar “final step” a una equivalencia si no existe un mecanismo para verificarla. Sería más preciso hablar de “final unresolved equivalence” o “endpoint criterion”.

[Moderado] Indicar explícitamente qué resultados han sido comprobados solo en las líneas auditadas y cuáles dependen de resultados previos no reprobados dentro del mismo tramo.

[Claridad] Eliminar cualquier frase que pueda sugerir que la cercanía numérica de ζZ1\zeta_{Z1} y ζ\zeta es evidencia de (D)(D). El propio texto finalmente dice que no lo es; esa advertencia debe acompañar cada gráfica pertinente.

[Claridad] Añadir una sección breve titulada “Qué no demuestra este trabajo”. Sería útil incluir:

no demuestra RH;
no demuestra (D)(D);
no demuestra una trayectoria atómica interior;
no demuestra convergencia de las secciones finitas;
no proporciona una prueba asistida por ordenador.
B. Constantes ϖRVM\varpi_{\mathrm{RVM}} y ϖZ1\varpi_{Z1}

[Crítico] Mantener ϖRVM<1\varpi_{\mathrm{RVM}}<1 como hipótesis y nunca reutilizarla implícitamente como teorema. El texto reconoce que no proporciona un encerramiento riguroso. Todos los resultados que dependen de ella deben marcarse expresamente como condicionales.

[Mayor] Proporcionar, si se desea convertirla en resultado, un encerramiento riguroso de ϖRVM\varpi_{\mathrm{RVM}}. Haría falta:

cota explícita del producto finito;
cota de la cola;
aritmética de intervalos;
control de todas las aproximaciones asintóticas.

[Moderado] Distinguir el valor matemático de ϖRVM\varpi_{\mathrm{RVM}} de su estimación por Richardson. La cifra 0.9619415807 no debe aparecer como valor certificado.

[Numérico] No presentar diez cifras de ϖRVM\varpi_{\mathrm{RVM}} sin una cota de error. El teorema proporciona un error O(1/T)O(1/T), pero el ajuste numérico presupone una expansión con términos 1/T1/T y 1/T21/T^2.

[Mayor] Desarrollar completamente el paso

lim⁡σ→∞ζZ1(σ)=ϖRVM∏k1/4+τk21/4+γk2.\lim_{\sigma\to\infty}\zeta_{Z1}(\sigma) = \varpi_{\mathrm{RVM}} \prod_k \frac{1/4+\tau_k^2}{1/4+\gamma_k^2}.

Debe justificarse el intercambio entre límite y producto ordenado.

[Moderado] Precisar si el producto que define ϖZ1\varpi_{Z1} converge absoluta o condicionalmente.

[Moderado] Explicar por qué el valor del producto es independiente de cualquier agrupación permitida o, si no lo es, declarar que el orden por altura forma parte de la definición.

[Numérico] Añadir cotas rigurosas de la cola del producto PKP_K antes de compararlo con ϖRVM\varpi_{\mathrm{RVM}}.

[Numérico] No interpretar la estabilidad visual de los productos parciales como convergencia demostrada.

[Claridad] Separar tres cantidades actualmente muy próximas en la exposición:

el producto parcial;
su límite supuesto;
la estimación numérica de ϖRVM\varpi_{\mathrm{RVM}}.
C. Paso de Abel, transición y límites uniformes

[Mayor] Escribir una cota dominante explícita para el paso r↑1r\uparrow1 en las series de Abel.

[Mayor] Precisar el dominio exacto en que la dominación es uniforme, especialmente respecto de:

r,σ′,t.r,\quad \sigma',\quad t.

[Moderado] Separar los pasos de convergencia puntual, compacta y uniforme. En varios lugares se usan casi indistintamente.

[Moderado] Justificar por separado la integración término a término y el cierre de contornos.

[Moderado] Dar cotas explícitas de los arcos de cierre, en vez de referirse genéricamente a Stirling.

[Claridad] Indicar en cada transición si el error O(1/∣t∣)O(1/|t|) es uniforme en bandas cerradas o depende de la banda.

[Claridad] Evitar presentar la extrapolación numérica del teorema de transición como confirmación independiente del propio esquema usado para construir la función.

D. Productos de Hadamard y funciones enteras

[Moderado] Indicar expresamente por qué el emparejamiento ρ↔1−ρ\rho\leftrightarrow1-\rho conserva la convergencia requerida.

[Moderado] Explicar con detalle la eliminación del factor exponencial eB′se^{B's} mediante la simetría.

[Claridad] Separar el producto sobre ceros de ξ\xi del producto construido con una lista sintética.

[Mayor] Cuando se concluye que un cociente sin ceros es eQe^Q, justificar primero que el cociente es entero. No debe formularse como una propiedad previa del cociente si resulta de la identidad analítica.

[Mayor] Añadir una estimación directa del orden de cada producto canónico usado en las secciones finales.

[Error reparable] Corregir la frase de la proposición a priori según la cual el producto tiene orden a lo sumo uno “porque su exponente de convergencia es a lo sumo uno”. La conclusión es plausible, pero debe obtenerse usando que la hipótesis local vale para todo ε>0\varepsilon>0 y mediante una cota directa de log⁡∣P(s)∣\log|P(s)|.

[Mayor] Incluir explícitamente una estimación como

log⁡∣P(s)∣=Oε(∣s∣1+ε)\log|P(s)|=O_\varepsilon(|s|^{1+\varepsilon})

para todo ε>0\varepsilon>0, antes de afirmar orden ≤1\le1.

E. Uso del teorema de Hamburger

[Mayor] Enunciar una sola versión precisa del teorema de Hamburger utilizada en el manuscrito.

[Mayor] Enumerar cada una de sus hipótesis y verificarla localmente cada vez que se aplica:

función entera o polo permitido;
orden;
ecuación funcional;
serie de Dirichlet;
abscisa de convergencia;
función dual;
crecimiento en bandas.

[Claridad] Evitar expresiones como “Hamburger gives” sin recordar qué versión se está usando.

[Mayor] Revisar las aplicaciones a productos con factores auxiliares meromorfos. Debe especificarse si se aplica Hamburger a la función original, a una función con el polo despejado o a un par.

[Crítico] Reparar la prueba del “Hamburger del modelo Euler finito”. La fórmula

an=lim⁡T→∞12T∫−TTf(σ+it)nσ+it dta_n=\lim_{T\to\infty}\frac1{2T} \int_{-T}^T f(\sigma+it)n^{\sigma+it}\,dt

no puede desplazarse automáticamente a rectas negativas cuando la serie de Dirichlet solo converge absolutamente en un semiplano derecho.

[Crítico] Justificar el desplazamiento de la fórmula de extracción de coeficientes usando, por ejemplo:

integración suavizada;
un teorema de inversión aplicable;
un teorema converso;
control explícito de los segmentos horizontales.

[Mayor] No concluir que an=0a_n=0 para n>6n>6 hasta reparar el punto anterior.

[Mayor] Marcar la parte (iii) del modelo Euler finito como dependiente de la reparación de la parte (ii).

[Moderado] En la prueba de no degeneración, verificar con detalle que Z\mathsf Z satisface exactamente la ecuación funcional exigida por Hamburger.

[Mayor] Cerrar primero la cuestión de orden finito de Z\mathsf Z antes de aplicar Hamburger en el teorema de no degeneración.

F. Compacidad, continuidad y convexidad en O\mathscr O

[Claridad] Mantener la prueba de compacidad, que es correcta, pero indicar explícitamente que la intersección sobre todos los XX sigue siendo cerrada.

[Claridad] Se puede sustituir la intersección sobre todos los reales por una intersección sobre racionales más continuidad en XX, aunque no es necesario.

[Mayor] Reescribir la continuidad de

κ↦Jκ∈L2(2,3).\boldsymbol\kappa\mapsto J_{\boldsymbol\kappa} \in L^2(2,3).

[Mayor] No usar la expresión ambigua “dominated in L2L^2”. Debe proporcionarse una función dominante puntual H(t)∈L2H(t)\in L^2.

[Mayor] Identificar los dos emparejamientos que determinan la constante JκM−JκJ^{\rm M}_{\boldsymbol\kappa}-J_{\boldsymbol\kappa}.

[Moderado] Demostrar la continuidad de esos emparejamientos en la topología producto de O\mathscr O.

[Mayor] Tratar por separado las celdas n=2jn=2^j en lugar de integrarlas en la afirmación general de continuidad.

[Moderado] Explicar que la estricta convexidad es coordenada, no una convexidad funcional global en un abierto de Banach.

[Claridad] Mantener la advertencia de que O\mathscr O tiene interior vacío y que hacen falta condiciones KKT o variaciones unilaterales.

[Claridad] No sugerir que compacidad, continuidad y convexidad bastan para demostrar que el mínimo es cero.

[Claridad] Indicar expresamente que

min⁡OVσ=0\min_{\mathscr O}\mathsf V_\sigma=0

es equivalente al problema final, no una consecuencia de la compactación.

G. Sistema de escalones y masas libres

[Claridad] Mostrar explícitamente el desarrollo

eν72−s=∑r≥0ν7rr!2−rs,e^{\nu_7 2^{-s}} = \sum_{r\ge0}\frac{\nu_7^r}{r!}2^{-rs},

para justificar que el factor es una serie de Dirichlet absoluta.

[Claridad] Corregir “both factors are absolutely convergent Dirichlet series” identificando exactamente cuáles son los dos factores.

[Mayor] Indicar con precisión qué resultados previos garantizan que ζκ\zeta_{\boldsymbol\kappa} satisface las hipótesis de Hamburger para una lista arbitraria de O\mathscr O.

[Moderado] Desarrollar el argumento según el cual soporte entero de dJMdJ^{\rm M} implica anulación de todos los defectos celulares.

[Moderado] Explicar con detalle por qué la truncación en 22 y la inversión de Möbius no crean soporte fuera de los enteros.

[Claridad] Recalcar después del teorema de masas libres que la existencia de la solución continúa sin demostrarse.

[Claridad] Diferenciar la unicidad de una solución, que sí se demuestra, de su existencia.

[Claridad] No describir el sistema finito numérico como una aproximación automáticamente convergente al sistema distribuciónal infinito.

H. Teorema de no degeneración

[Moderado] Formalizar la convergencia de

∑kκ˙kusin⁡(κku)\sum_k\dot\kappa_k u\sin(\kappa_ku)

en S′(R)\mathcal S'(\mathbb R), indicando las integraciones por partes utilizadas.

[Moderado] Justificar el paso desde la identidad en D′(0,∞)\mathcal D'(0,\infty) a una distribución par en un entorno del origen.

[Mayor] Tratar mediante un lema independiente la afirmación de que una distribución soportada en {0}\{0\} depende de un jet finito.

[Mayor] Reescribir con ese lema la demostración de que y(z)\mathsf y(z) es un polinomio.

[Moderado] No mezclar en el mismo párrafo el argumento de soporte puntual con las cotas O(κ−3)O(\kappa^{-3}) de los coeficientes de Fourier.

[Moderado] Justificar que H1(σ)→0\mathsf H_1(\sigma)\to0 mediante dominación de la serie de Dirichlet.

[Moderado] Demostrar explícitamente

∑kκ˙k2κkσ(σ2+κk2)2=O(σ−1log⁡σ).\sum_k \dot\kappa_k \frac{2\kappa_k\sigma} {(\sigma^2+\kappa_k^2)^2} = O(\sigma^{-1}\log\sigma).

[Mayor] Completar la prueba de que H\mathsf H tiene crecimiento controlado en círculos alejados de los polos.

[Mayor] Explicar cómo una sucesión de cotas sobre círculos implica un crecimiento global de orden finito.

[Mayor] Escoger radii rjr_j con razón controlada y aplicar explícitamente el máximo módulo en cada disco.

[Moderado] Tratar las multiplicidades en los intervalos que se excluyen alrededor de los polos.

[Claridad] Mantener la advertencia de que la inyectividad del Jacobiano en una solución no equivale a un teorema de la función implícita.

[Claridad] Mantener la advertencia de que la inyectividad en el reloj no se demuestra.

[Claridad] No presentar la no degeneración como evidencia de existencia.

I. Gradiente del defecto vertical

[Moderado] Especificar la topología funcional en la que se aplica la regla de la cadena.

[Moderado] Detallar el paso de productos de Euler finitos al límite en el espacio ℓ1\ell^1 ponderado.

[Mayor] Demostrar la existencia y la cota uniforme de

∂κJκ\partial_\kappa J_{\boldsymbol\kappa}

en (2,3)(2,3), utilizada para las potencias de 2.

[Mayor] Separar la prueba de la cota de um(t)\mathsf u_m(t) para m≠2jm\neq2^j de la prueba para m=2jm=2^j.

[Moderado] Precisar por qué la convergencia de Qκ(t)\mathsf Q_{\boldsymbol\kappa}(t) es uniforme en todo tt, no solo en compactos.

[Claridad] Mantener la observación de que contar ceros de Qκ\mathsf Q_{\boldsymbol\kappa} no excluye puntos críticos con defecto positivo.

[Claridad] Formular explícitamente como problema abierto si las condiciones KKT fuerzan Vσ=0\mathsf V_\sigma=0.

J. Criterio de aceptación y modelos abstractos

[Moderado] En la equivalencia densidad atómica-forma de Euler, indicar que la diferencia soportada en cero produce un polinomio.

[Moderado] Añadir la frase lógica completa: como ese polinomio tiene un límite finito en el eje imaginario, debe ser constante.

[Moderado] En el paso de la forma de Euler a la ventana finita, indicar la versión exacta de Paley-Wiener-Schwartz empleada.

[Moderado] Precisar las convenciones de transformada de Fourier, para evitar signos opuestos en el soporte [0,2k][0,2\mathfrak k].

[Moderado] En el paso de suma finita a forma de Euler, mostrar la desigualdad que hace converger el logaritmo.

[Claridad] Explicar que el criterio abstracto no prueba que la lista zeta pertenezca a esa intersección de categorías.

[Moderado] En el modelo de dos aristas, justificar formalmente el movimiento antihorario de los autovalores o sustituirlo por un principio del argumento.

[Claridad] Mantener separado el modelo finito, donde el cierre funciona, del caso de zeta, donde la unicidad de la categoría discreta es mucho más rígida.

[Claridad] Subrayar que el modelo finito con dos primos no se extiende automáticamente a más primos.

[Claridad] Mantener la discusión dimensional que muestra por qué falla la unicidad cuando aumenta el número de primos.

[Claridad] No sugerir que el operador diagonal sobre primos proporciona un determinante ordinario en la franja crítica.

[Moderado] Recordar que el determinante ordinario exige clase traza, mientras que el regularizado tiene otro dominio y otra interpretación.

K. Ruta B, distribuciones y masas prescritas

[Claridad] Mantener el término corrector H(0)δ0′\mathfrak H(0)\delta_0' y destacarlo en un lema, porque es esencial.

[Moderado] Especificar la convención del signo para la transformada de δ0′\delta_0'.

[Moderado] Dar una referencia exacta para la transformada de Laplace de distribuciones soportadas en el semieje.

[Claridad] Explicar que dos extensiones que coinciden en (0,∞)(0,\infty) pueden diferir por una distribución soportada en cero.

[Claridad] Mostrar por qué esa diferencia produce un polinomio en s−12s-\frac12.

[Moderado] En la prueba de unicidad con masas prescritas, invertir el orden de la exposición: primero obtener la identidad analítica y después concluir que el cociente es entero y sin ceros.

[Claridad] Mantener la observación de que B′ es equivalente a RH y no un resultado intermedio más débil.

[Claridad] Evitar presentar las secciones finitas de B′ como “más fáciles” sin recordar que demostrar su convergencia sería ya demostrar la existencia global.

[Moderado] En la compactación de cuasisoluciones, indicar con precisión la topología de convergencia de las distribuciones residuales.

[Moderado] Justificar la continuidad del residuo frente a convergencia coordenada de las listas.

L. Certificados abstractos de etapas

[Claridad] Mantener el teorema abstracto de contracción, que está correctamente formulado.

[Claridad] Indicar desde el enunciado que la unicidad solo se obtiene dentro de Ran⁡Qm\operatorname{Ran}Q_m.

[Claridad] No denominar “Newton” sin matización al método con inversa derecha congelada; es una iteración de Newton modificada.

[Moderado] Añadir una versión del teorema con errores de evaluación, necesaria para una aplicación computacional rigurosa.

[Moderado] Añadir condiciones que garanticen preservación del orden de las ordenadas después de una corrección.

[Claridad] Señalar que certificar cada etapa por separado no proporciona compatibilidad entre etapas.

[Claridad] Formular qué estimaciones uniformes serían necesarias para pasar a una sucesión infinita.

M. Teoría A2A_2, bases de Riesz y bloques variables

[Moderado] Verificar en las referencias originales que la versión de Pavlov utilizada admite exactamente el tipo de función generadora construido.

[Moderado] Verificar las hipótesis exactas de Avdonin-Ivanov para puntos múltiples y diferencias divididas.

[Moderado] Precisar si la uniformidad discreta se supone o se deduce en cada corolario.

[Claridad] Mantener separadas las conclusiones para bases ordinarias y para bases de subespacios.

[Moderado] Añadir detalles sobre la normalización del peso A2A_2, aunque una constante multiplicativa no afecte a la propiedad.

[Moderado] Explicar con más detalle la representación de Herglotz y la ausencia o irrelevancia del término lineal.

[Claridad] Señalar que el criterio A2A_2 es suficiente para la aplicación prevista, no necesariamente necesario en la formulación por bloques presentada.

[Moderado] Repasar las constantes del teorema de bloques variables. Parecen holgadas, pero deben verificarse línea por línea si se pretenden explícitas.

[Claridad] Mantener la advertencia de que no se reivindica novedad para la variante de bloques variables.

[Claridad] Recalcar que la condición media sobre bloques ≍log⁡2T\asymp\log^2T no implica la condición integral original.

[Claridad] Mantener la corrección explícita de la formulación anterior, pues evita una equivalencia falsa.

N. Proposición final de desplazamiento a priori

[Mayor] Añadir una demostración directa del orden de PκP_{\boldsymbol\kappa}, como se indicó en los puntos 32–34.

[Moderado] Verificar que los términos de borde desaparecen al integrar por partes contra NκN_{\boldsymbol\kappa}.

[Moderado] Justificar con detalle la convergencia absoluta de la parte de masas en ℜs>3/2\Re s>3/2.

[Claridad] Explicar que el polinomio pp representa la libertad de añadir masas y derivadas de delta en el origen.

[Moderado] Precisar que la cota O(σε0)O(\sigma^{\varepsilon_0}) se obtiene con un ε0<1\varepsilon_0<1, y por eso fuerza grado cero.

[Mayor] Fijar de forma global las ramas de

(P\_{\mathrm{RVM}}^{\mathrm{crit}})^{1-\theta} \quad\text{y}\quad G^\theta ] en el semiplano $$\Re s>3/2$$.

[Mayor] Sustituir “continuadas a lo largo del camino” por una construcción de logaritmos holomorfos en un dominio simplemente conexo y sin ceros.

[Moderado] Indicar expresamente que los factores son positivos sobre el eje real utilizado para normalizar las ramas.

[Mayor] Comprobar que el lema de Phragmén-Lindelöf admite el caso de orden uno utilizado en el strip.

[Mayor] Si el lema exige tipo suficientemente pequeño, proporcionar una estimación de tipo, no solo de orden.

[Moderado] Explicar por qué dividir por s+2s+2 da las cotas de borde reclamadas sin introducir singularidades en el strip.

[Moderado] Separar la cota en el strip −1≤ℜs≤2-1\le\Re s\le2 de la cota en ℜs≥2\Re s\ge2.

[Moderado] En Jensen, escribir la fórmula completa con radios 3/23/2 y 22.

[Moderado] Aclarar que se sustituye la media del círculo por su máximo, obteniendo una cota más débil pero válida.

[Moderado] Distinguir la variación neta del argumento de la variación total en el segmento vertical.

[Moderado] Justificar que las ramas del argumento se eligen continuamente desde t=0t=0.

[Moderado] Tratar con más detalle el caso de una ordenada múltiple al pasar del conteo al cuantil.

[Claridad] Mantener la observación de que bb es una masa en el origen no determinada por una identidad planteada solo en (0,∞)(0,\infty).

[Claridad] Explicar intuitivamente por qué b≠0b\neq0 produce una deriva de tamaño κ/log⁡κ\kappa/\log\kappa.

[Claridad] Formular el corolario separado: para soluciones con extensión sin masa en cero, el desplazamiento es uniformemente acotado.

[Claridad] No presentar la proposición a priori como teorema de existencia.

[Mayor] Recordar en el enunciado que la cota media cuadrática de las masas es una hipótesis independiente para listas generales.

[Moderado] Revisar la afirmación de uniformidad en θ\theta y señalar exactamente de qué cantidades uniformes depende C∗C^\ast.

O. Parte numérica general

[Numérico] Añadir hashes y procedencia de zeross.bin y zLamb.bin.

[Numérico] Especificar la precisión certificada de cada ordenada almacenada.

[Numérico] Separar resultados reproducibles en doble precisión de resultados matemáticamente certificados.

[Numérico] Incluir una tabla de fuentes de error para cada experimento: - truncación; - cola; - discretización; - interpolación; - redondeo; - ajuste asintótico.

[Numérico] Usar aritmética de intervalos si se mantiene la palabra “certificado”.

[Numérico] No llamar “exacta” a una suma calculada con producto truncado, cola asintótica o coma flotante.

[Numérico] No llamar “all zeros” a una suma que utiliza una lista finita de 2 001 0522\,001\,052 ordenadas. Debe decir “all zeros in the supplied file”.

[Numérico] Proporcionar una cota del error de la cola del producto después de la última ordenada.

[Numérico] En Product(gam), declarar de forma visible que la cola desconocida se reemplaza por la cola del reloj.

[Numérico] No interpretar el error 10−910^{-9} en ζZ1/ζ\zeta_{Z1}/\zeta sin contabilizar esa sustitución de cola.

[Numérico] Añadir términos y cota de resto al desarrollo cúbico de la cola.

[Numérico] Validar la aproximación de Ei⁡\operatorname{Ei} con una cota uniforme del resto.

[Numérico] Propagar el error de Ei⁡\operatorname{Ei} a JJ, πRVM\pi_{\mathrm{RVM}} y las masas celulares.

[Numérico] Cuantificar el error de la interpolación lineal en la inversión de Möbius.

[Numérico] No interpretar máximos tomados sobre una cuadrícula como supremos continuos.

[Numérico] Para las derivadas de Riemann-Siegel, estudiar conjuntamente el error de truncación y el de diferencia finita.

[Numérico] Adaptar el paso hh a la altura o demostrar que h=10−5h=10^{-5} es adecuado en todo el intervalo.

[Numérico] Verificar numéricamente la simplicidad y separación de los ceros utilizados para residuos.

[Numérico] No presentar las sumas espectrales de residuos como cantidades exactas.

[Numérico] Añadir una prueba de estabilidad frente al número de ceros, ventana de suavizado y parámetros de corte.

[Numérico] Proporcionar experimentos con varias precisiones para detectar cancelación catastrófica.

[Numérico] Separar visualmente datos de entrada, cantidades ajustadas y cantidades de salida.

P. Código de Mertens y paseo ternario

[Numérico] Etiquetar MRVMcritM_{\mathrm{RVM}}^{\mathrm{crit}} como aproximación numérica cuando se construye con residuos ajustados.

[Numérico] No llamar “explicit formula” a la evaluación sin indicar el esquema de suma y truncación.

[Numérico] Añadir el error por truncar los términos triviales en seis términos.

[Numérico] Justificar la suma sin regularización explícita de los términos de los ceros.

[Claridad] Explicar que el paseo ternario sigue el objetivo por diseño.

[Claridad] Evitar sugerir que la coincidencia parcial de signos de μh\mu_h y μ\mu tenga contenido teórico sin un análisis estadístico independiente.

[Numérico] Cuantificar el error introducido por PCHIP al construir el objetivo entero.

[Numérico] Comparar el paseo con objetivos perturbados dentro del error numérico estimado.

[Claridad] Separar el experimento de cuantización de cualquier afirmación sobre transferencia a la función de Mertens real.

Q. Solver reloj a ceros

[Error terminológico] Cambiar “las masas se eliminan exactamente” por “se resuelven mediante regresión ridge”. El código añade RIDGE*I.

[Numérico] Informar del número de condición de PnTPnP_n^\mathsf TP_n.

[Numérico] Repetir el experimento para varios valores de RIDGE.

[Numérico] Normalizar el residuo por la raíz del número de ecuaciones cuando se comparan etapas.

[Numérico] Imponer o comprobar explícitamente el orden de las ordenadas durante la optimización.

[Numérico] Cuantificar el efecto de mantener la cola en el reloj.

[Numérico] Variar KT, MARGIN, WMIN, NU y la banda máxima.

[Numérico] No usar la proximidad a γk\gamma_k como criterio de convergencia interna del solver. Debe mantenerse, como ahora, solo como diagnóstico posterior.

[Numérico] Indicar que las masas en 1212 y 1313 se excluyen por umbral numérico, aunque sus posiciones estén dentro de la ventana.

[Claridad] Explicar por qué las ordenadas por encima de la banda no se determinan, como muestran los errores grandes en k=12,13,14k=12,13,14.

[Claridad] No extrapolar la buena recuperación de las primeras once ordenadas a una solución infinita.

R. Gaussianas y Route B computacional

[Mayor/Numérico] Alinear las funciones de prueba del código con las funciones de prueba compactamente soportadas de la teoría.

[Numérico] Si se mantienen gaussianas, desarrollar una versión teórica para funciones de Schwartz, no para Cc∞C_c^\infty.

[Numérico] Acotar rigurosamente la cola negativa de cada gaussiana.

[Numérico] Acotar la cola omitida más allá de 9s9s en kpair.

[Numérico] Alinear los dominios de Fphi, kpair y masspair; actualmente no representan exactamente el mismo emparejamiento.

[Numérico] Proporcionar una cota explícita de la cola espectral posterior a la lista kap finita.

[Numérico] Proporcionar una cota de la cola de masas posterior a LAM=vonmangoldt(200000).

[Numérico] Demostrar o verificar rigurosamente que la lista Gonek contiene todos los cruces relevantes.

[Numérico] No detectar raíces únicamente mediante cambios de ⌊v(t)⌋\lfloor v(t)\rfloor.

[Numérico] Demostrar monotonía de la fase aproximada o usar aislamiento por intervalos con aritmética de intervalos.

[Numérico] Evitar que el algoritmo pueda omitir cruces múltiples dentro de una malla de paso 0.0050.005.

S. “Certificados” finitos

[Crítico terminológico] No usar “CERTIFIED” sin aritmética de intervalos o una cota rigurosa de redondeo.

[Numérico] Sustituir np.linalg.inv por resolución lineal con estimación certificada del error.

[Numérico] Certificar el rango y la no singularidad de los Jacobianos.

[Numérico] Incluir errores de cuadratura, truncación y datos en las desigualdades de Banach.

[Numérico] Evitar radios de certificación 10−1510^{-15} en doble precisión sin análisis de redondeo.

[Claridad] Indicar que el certificado concierne solo al subsistema cuadrado seleccionado por QR.

[Claridad] No sugerir que todas las pruebas acumuladas se anulan. El propio rho_all_levels es distinto de cero.

[Numérico] Proporcionar una cota que conecte el subsistema seleccionado con el conjunto completo de ecuaciones.

[Claridad] Destacar que las etapas no forman una sucesión anidada de soluciones exactas.

[Claridad] Mantener visible que la etapa 16 falla por singularidad.

[Claridad] Mantener visible que los tests de entrada de banda dejan de certificarse en etapas posteriores.

[Claridad] Interpretar el crecimiento de ∥Qm∥\|Q_m\|, ∥QmBm∥\|Q_mB_m\| y el deterioro del margen como dificultad, no como evidencia de estabilidad.

[Numérico] Repetir los certificados con precisión arbitraria y comparar los radios.

[Numérico] Publicar los archivos de intervalos o certificados verificables si se pretende una prueba asistida por ordenador.

T. Secciones acotadas y anidadas

[Claridad] Mantener la frase de que las cotas

∣κ_k−τ_k∣≤1.2,∣a_n∣≤0.5]sonregularizadoresnumeˊricos,noteoremas.|\kappa\_k-\tau\_k|\le1.2,\qquad |a\_n|\le0.5 ] son regularizadores numéricos, no teoremas.

[Numérico] Informar de qué restricciones están activas en cada solución.

[Numérico] Demostrar que los parámetros interiores no dependen fuertemente de los límites impuestos.

[Numérico] Repetir las secciones con tubos y cotas de masas diferentes.

[Numérico] Explicar cómo se seleccionan los bloques permanentes.

[Numérico] Incluir las pruebas cruzadas dentro de una cota global, no solo como RMS.

[Claridad] No interpretar residuos pequeños en bloques antiguos como convergencia monótona.

[Mayor] Formular el teorema de compactación que faltaría para pasar a un límite distribuciónal.

[Mayor] Indicar qué cotas uniformes sobre listas y masas serían suficientes para aplicar esa compactación.

[Mayor] Demostrar que la unión de las familias de pruebas es densa en la topología adecuada.

[Mayor] Probar que residual cero en esa familia densa implica identidad en D′(0,∞)\mathcal D'(0,\infty).

[Claridad] Señalar que lograr los puntos 222–225 equivaldría esencialmente a resolver la existencia final, no sería un detalle técnico menor.

U. Presentación, notación y organización

[Claridad] Reducir el número de formulaciones equivalentes presentadas como resultados centrales. Algunas podrían trasladarse a un apéndice.

[Claridad] Crear un índice de símbolos global.

[Claridad] Unificar NRVMN_{\mathrm{RVM}}, nRVMn_{\mathrm{RVM}} y NRVM\mathcal N_{\mathrm{RVM}}, explicando claramente qué es continuo, qué es entero y qué es redondeado.

[Claridad] Unificar la notación de las listas τk\tau_k, γk\gamma_k, κk\kappa_k y las familias interpoladas.

[Claridad] No reutilizar letras como KK, NN, TT, LL y CC para conceptos muy distintos en secciones cercanas.

[Claridad] Añadir al comienzo de cada sección una frase sobre su función lógica dentro del programa.

[Claridad] Añadir al final de cada sección un bloque breve: “Resultado obtenido / Resultado no obtenido”.

[Claridad] Separar con más fuerza los apéndices de versiones anteriores, añadidos posteriores y cuerpo principal.

[Claridad] Evitar que un añadido v18 o posterior parezca modificar retroactivamente teoremas anteriores sin una declaración formal.

[Claridad] Marcar las correcciones de formulaciones previas en un historial de cambios, no solo dentro del texto matemático.

[Claridad] Distinguir “ordenada verificada”, “ordenada almacenada” y “ordenada calculada con mpmath”.

[Claridad] Usar “masa de von Mangoldt escalada” cuando se habla de Λ(n)/(2n)\Lambda(n)/(2\sqrt n), no simplemente “masa de von Mangoldt”.

[Claridad] Explicar en cada fórmula distribuciónal si la igualdad vale en D′(0,∞)\mathcal D'(0,\infty), S′(R)\mathcal S'(\mathbb R) o para distribuciones soportadas en [0,∞)[0,\infty).

[Claridad] Señalar siempre si el origen está incluido. Varias constantes y el término bb dependen precisamente de esta diferencia.

[Claridad] Evitar “harmless polynomial” sin indicar por qué es inofensivo en el argumento concreto.

[Claridad] Explicar cuándo un término polinómico cambia una normalización, un conteo o una ecuación funcional.

[Claridad] No usar “exact” para una identidad teórica y para una evaluación en coma flotante dentro de la misma sección.

[Claridad] Sustituir “observed” por “floating-point output” en las tablas que puedan parecer rigurosas.

[Claridad] Añadir versiones de los gráficos con bandas de error cuando se disponga de estimaciones.

[Claridad] Mostrar los parámetros computacionales relevantes en los pies de figura.

[Claridad] Incluir una tabla final de afirmaciones con columnas: demostrada, condicional, equivalente a RH, heurística, numérica.

V. Cambios prioritarios antes de una posible publicación

[Prioridad 1] Reparar la extracción de coeficientes en el modelo Euler finito.

[Prioridad 1] Completar el crecimiento de orden finito en el teorema de no degeneración.

[Prioridad 1] Corregir y completar la demostración del orden del producto en la proposición a priori.

[Prioridad 1] Verificar la aplicación de Phragmén-Lindelöf en la proposición final.

[Prioridad 1] Demostrar rigurosamente la continuidad L2L^2 y las celdas 2j2^j.

[Prioridad 1] Demostrar la existencia y uniformidad de ∂κJκ\partial_\kappa J_{\boldsymbol\kappa}.

[Prioridad 1] Renombrar los certificados numéricos o convertirlos en certificados rigurosos con intervalos.

[Prioridad 1] Hacer explícito en resumen e introducción que RH no está demostrada.

[Prioridad 2] Añadir un mapa completo de dependencias y resultados condicionales.

[Prioridad 2] Aislar las afirmaciones numéricas de las teóricas.

[Prioridad 2] Añadir cotas de truncación y cola a los experimentos principales.

[Prioridad 2] Alinear las gaussianas computacionales con el espacio teórico de funciones de prueba.

[Prioridad 2] Especificar una versión única y precisa de Hamburger.

[Prioridad 2] Reorganizar la teoría de Route B para que unicidad, existencia y estabilidad no aparezcan mezcladas.

[Prioridad 3] Simplificar la proliferación de equivalencias y trasladar formulaciones secundarias a apéndices.

[Prioridad 3] Normalizar notación, terminología y leyendas de figuras.

[Prioridad 3] Añadir un protocolo completo de reproducibilidad computacional.

Conclusión consolidada de la auditoría

El manuscrito contiene matemática seria y varias construcciones plausiblemente correctas.

No parece una pseudodemostración típica, porque identifica explícitamente el paso no resuelto y limita el alcance de sus experimentos.

La mayor aportación del manuscrito es una red de equivalencias, criterios de rigidez, formulaciones distribucionales y herramientas de existencia potencial.

La principal carencia matemática continúa siendo la existencia de una solución del sistema infinito, equivalente a (D)(D).

Hay una laguna seria identificable en el modelo Euler finito, concretamente en el desplazamiento de la fórmula de extracción de coeficientes.

La prueba de no degeneración todavía necesita completar el control de crecimiento entero.

La continuidad de las celdas especiales 2j2^j y la derivada respecto de una ordenada necesitan lemas independientes.

La proposición a priori final es interesante, pero su prueba debe reforzarse en orden, ramas y Phragmén-Lindelöf.

Los cálculos numéricos son ilustrativos, no certificados.

Las secciones finitas no demuestran la existencia de un límite distribuciónal.

Los certificados de Banach en doble precisión no constituyen una prueba asistida por ordenador.

La cercanía de ζZ1\zeta_{Z1} y ζ\zeta en los experimentos no prueba la identidad global.

El resultado final permanece exactamente como lo declara el propio documento:

(D),ζZ1=ζ,RH(D),\qquad \zeta_{Z1}=\zeta,\qquad \mathrm{RH}

siguen sin demostrarse.

Mi recomendación editorial global sería “revisión mayor”. No rechazaría el proyecto por falta de contenido matemático, pero exigiría reparar las lagunas señaladas, rebajar la terminología numérica, clarificar las dependencias y presentar el trabajo como un programa de reducción y rigidez, no como una resolución del problema.