Tienes razón. Lo anterior no fue una auditoría, sino un inventario superficial. Voy a corregirlo revisando el bloque 0–2000 línea por línea y resultado por resultado, con veredicto, comprobación de la prueba y cualquier laguna concreta.Tienes razón. Perdona: antes te di un índice cuando pedías una auditoría matemática. Esta es la auditoría efectiva del bloque 0–2000 de rvm_zeta_pi_mertens_v21_1.txt, resultado por resultado, comprobando enunciado, prueba y dependencias.

Auditoría del bloque 0–2000
Proposición 2.1. Inversión de Lambert
Veredicto: correcta

La sustitución

y=τ2π,v=log⁡y−1y=\frac{\tau}{2\pi},\qquad v=\log y-1

transforma

y(log⁡y−1)=k−118y(\log y-1)=k-\frac{11}{8}

en

vev=k−11/8e.ve^v=\frac{k-11/8}{e}.

De aquí se obtiene correctamente

τk=2π(k−11/8)W0((k−11/8)/e).\tau_k= \frac{2\pi(k-11/8)} {W_0((k-11/8)/e)}.

Para k=1k=1, argumento y valor de W0W_0 son negativos, por lo que el cociente es positivo. La elección de W0W_0 corresponde a la solución situada en la rama creciente [2π,∞)[2\pi,\infty).

Mejora menor

Conviene añadir que, cuando k=1k=1, la rama W−1W_{-1} produce la otra solución positiva inferior a 2π2\pi, que el texto ya comenta antes del enunciado. No es una laguna.

Lema 2.2. Desplazamiento acotado
Veredicto: esencialmente correcto, pero la prueba contiene una justificación abreviada

La prueba establece

∣NRVM(γk)−NRVM(τk)∣=O(log⁡γk).\left| \mathcal N_{\mathrm{RVM}}(\gamma_k) - \mathcal N_{\mathrm{RVM}}(\tau_k) \right| =O(\log\gamma_k).

Como

NRVM′(T)=12πlog⁡T2π,\mathcal N_{\mathrm{RVM}}'(T) = \frac{1}{2\pi}\log\frac{T}{2\pi},

el teorema del valor medio da

∣γk−τk∣≪log⁡γkinf⁡T entre γk,τklog⁡(T/2π).|\gamma_k-\tau_k| \ll \frac{\log\gamma_k} {\inf_{T\text{ entre }\gamma_k,\tau_k}\log(T/2\pi)}.

El resultado es O(1)O(1) una vez demostrado que ambos extremos, y por tanto todo el intervalo intermedio, tienen logaritmos comparables a log⁡k\log k.

Punto que debe explicitarse

El texto afirma:

“\eqrefeq:clock−discrepancy\eqref{eq:clock-discrepancy} gives
 log⁡γk≍log⁡τk≍log⁡k\log\gamma_k\asymp\log\tau_k\asymp\log k.”

La conclusión es correcta, pero no es inmediata de la desigualdad tal como está escrita. Sugiero insertar:

NRVM(γk)=k+O(log⁡γk),\mathcal N_{\mathrm{RVM}}(\gamma_k) = k+O(\log\gamma_k),

y, como

NRVM(T)≍Tlog⁡T,\mathcal N_{\mathrm{RVM}}(T)\asymp T\log T,

deducir primero

γk≍klog⁡k,τk≍klog⁡k.\gamma_k\asymp \frac{k}{\log k}, \qquad \tau_k\asymp \frac{k}{\log k}.

Entonces el denominador del teorema del valor medio es ≍log⁡k\asymp\log k.

Clasificación

No veo un error matemático, pero sí una inferencia que debería desarrollarse para evitar una apariencia de circularidad.

Teorema 3.1. Caracterización canónica de ζRVM\zeta_{\mathrm{RVM}}
Veredicto: correcto

La convergencia normal se apoya en

∑kτk−2<∞,\sum_k \tau_k^{-2}<\infty,

que se sigue de τk≍k/log⁡k\tau_k\asymp k/\log k. En compactos,

∣q(s)14+τk2∣≪Kτk−2.\left| \frac{q(s)}{\frac14+\tau_k^2} \right| \ll_K\tau_k^{-2}.

Esto prueba convergencia absoluta y localmente uniforme del producto. Las simetrías salen factor por factor de

q(1−s)=q(s),q(sˉ)=q(s)‾.q(1-s)=q(s),\qquad q(\bar s)=\overline{q(s)}.

Los ceros de cada factor satisfacen

(s−12)2+τk2=0,\left(s-\frac12\right)^2+\tau_k^2=0,

y son simples porque los τk\tau_k son distintos y 2s−1≠02s-1\neq0 en esos puntos. La descripción del polo en s=1s=1, los ceros triviales y la regularidad en s=0s=0 también es correcta.

Corrección editorial recomendable

En

G(0)≠0,G(0)\ne0,

puede escribirse el valor exacto:

G(0)=−2.G(0)=-2.

Esto aclara inmediatamente por qué s=0s=0 no es cero de ζRVM\zeta_{\mathrm{RVM}}.

Teorema 4.1. Cota logarítmica uniforme de sumas exponenciales
Veredicto: correcto; la objeción de resonancia de v20 está reparada

La versión actual separa correctamente un bloque inicial y elige k0=k0(u2)k_0=k_0(u_2) de forma que

0<Δk=u(τk+1−τk)≤π0<\Delta_k=u(\tau_{k+1}-\tau_k)\le\pi

para k≥k0k\ge k_0. Esto evita que

eiΔk−1e^{i\Delta_k}-1

se anule o se aproxime a una resonancia 2πm2\pi m en la cola. La identidad de sumación por partes es exacta, y las cotas

∣bksbp∣≪ℓk+1,∣bk−1sbp−bksbp∣≪1k|\mathfrak b_k^{\mathrm{sbp}}| \ll\ell_{k+1}, \qquad |\mathfrak b_{k-1}^{\mathrm{sbp}}-\mathfrak b_k^{\mathrm{sbp}}| \ll\frac1k

producen

SRVM(N;u)=Ou1,u2(1+log⁡N).S_{\mathrm{RVM}}(N;u)=O_{u_1,u_2}(1+\log N).

El bloque inicial tiene longitud fija dependiente solo de u2u_2.

Comprobación puntual

La afirmación de que ∣T′′∣|\mathcal T''| decrece es válida en el intervalo utilizado:

∣T′′(y)∣=4π2T(y)log⁡3(T(y)/2π),|\mathcal T''(y)| = \frac{4\pi^2} {\mathcal T(y)\log^3(\mathcal T(y)/2\pi)},

y tanto T\mathcal T como el logaritmo crecen.

Mejora menor

En la última cota aparece

ℓN+1=O(log⁡N),\ell_{N+1}=O(\log N),

aunque realmente es O(log⁡N)O(\log N) de forma muy holgada y vale ≍log⁡N\asymp\log N. No hay problema.

Corolario 4.2. Centroide puntual
Veredicto: correcto

Dividir la cota del teorema por NN da directamente

CRVMpts(N;u)=O(1+log⁡NN).C_{\mathrm{RVM}}^{\mathrm{pts}}(N;u) = O\left(\frac{1+\log N}{N}\right).

También es correcta la advertencia sobre el centroide de camino: de S(n)=O(log⁡n)S(n)=O(\log n) solo resulta

1N∑n≤NS(n)=O(log⁡N),\frac1N\sum_{n\le N}S(n)=O(\log N),

no convergencia a cero.

Corolario 4.3. Decaimiento de la transformada de altura
Veredicto: correcto

Para u=log⁡x>0u=\log x>0,

MHRVM(x)=SRVM(N;u)N,N=nRVM(H).M_H^{\mathrm{RVM}}(x) = \frac{S_{\mathrm{RVM}}(N;u)}{N}, \qquad N=n_{\mathrm{RVM}}(H).

Es una aplicación directa del Teorema 4.1.

Lema 5.1. Asintótica de Ei⁡\operatorname{Ei}
Veredicto: correcto

La integración por partes proporciona

Ei⁡(w)=eww+∫−∞aev+ib(v+ib)2 dv,\operatorname{Ei}(w) = \frac{e^w}{w} + \int_{-\infty}^{a} \frac{e^{v+ib}}{(v+ib)^2}\,dv,

y

∣∫−∞aev+ib(v+ib)2 dv∣≤eab2.\left| \int_{-\infty}^{a} \frac{e^{v+ib}}{(v+ib)^2}\,dv \right| \le \frac{e^a}{b^2}.

La rama queda bien definida mediante la trayectoria horizontal.

Teorema 5.2. Existencia compacta-uniforme de la suma sobre ceros
Veredicto: correcto

La expansión real debería contener también el término

eu/2u12cos⁡(uτk)14+τk2,\frac{e^{u/2}}u \frac{\frac12\cos(u\tau_k)} {\frac14+\tau_k^2},

pero este es O(τk−2)O(\tau_k^{-2}), por lo que queda correctamente absorbido en el error del texto:

ℜEi⁡((12+iτk)u)=eu/2usin⁡(uτk)τk+O(τk−2).\Re\operatorname{Ei}\left( \left(\frac12+i\tau_k\right)u \right) = \frac{e^{u/2}}u \frac{\sin(u\tau_k)}{\tau_k} + O(\tau_k^{-2}).

La sumación de Abel está bien aplicada:

SRVM(K;u)=O(log⁡K),S_{\mathrm{RVM}}(K;u)=O(\log K),

y

1τK−1τK+1≪log⁡KK2.\frac1{\tau_K}-\frac1{\tau_{K+1}} \ll\frac{\log K}{K^2}.

Así, la serie de diferencias queda dominada por

∑K(log⁡K)2K2<∞.\sum_K\frac{(\log K)^2}{K^2}<\infty.

La convergencia es uniforme en intervalos compactos de u>0u>0.

Proposición 5.3. Inversión finita de potencias primas
Veredicto: correcta

La sustitución de la definición de πRVM\pi_{\mathrm{RVM}} produce para el término con exponente total rr el coeficiente

1r∑d∣rμ(d),\frac1r\sum_{d\mid r}\mu(d),

que vale uno para r=1r=1 y cero para r>1r>1. Como las sumas son finitas, no hay problemas de intercambio.

Lema 5.4. Suma ponderada del reloj
Veredicto: plausiblemente correcto, pero requiere una corrección de exposición

La descomposición diádica y el test de la segunda derivada muestran que la cola ponderada por 1/τk1/\tau_k es sumable. La estimación de cada bloque toma la forma

PjYj≪(j+2)3/22−j/2,\frac{\mathcal P_j}{Y_j} \ll (j+2)^{3/2}2^{-j/2},

que es sumable uniformemente en u≥log⁡2u\ge\log2. Esto prueba la convergencia de

ARVM(u)=∑keiuτkτk.\mathcal A_{\mathrm{RVM}}(u) = \sum_k\frac{e^{iu\tau_k}}{\tau_k}.

La lógica del test de Van der Corput y la posterior suma diádica es consistente.

Problema de redacción

El texto dice:

“the terms with k>Kk>K form a run of BJ\mathcal B_J followed by the full blocks…”

Para demostrar Cauchy debe considerarse una suma finita

∑K′<k≤K′′,\sum_{K'<k\le K''},

que contiene:

un tramo final del primer bloque;
bloques completos;
posiblemente un tramo inicial del último bloque.

La última parte no se menciona, aunque queda dominada por la misma cota Pj/Yj\mathcal P_j/Y_j.

Corrección propuesta

Cambiar por:

Any finite tail consists of at most two partial runs and the complete intervening blocks; Abel’s inequality bounds each partial run by the same block majorant.

No afecta al resultado, pero completa la prueba.

Teorema 5.5. Estimación de escala raíz cuadrada
Veredicto: correcto

La descomposición

1ρkRVM=−iτk+rk,rk=O(τk−2),\frac1{\rho_k^{\mathrm{RVM}}} = -\frac{i}{\tau_k}+r_k, \qquad r_k=O(\tau_k^{-2}),

y el Lema 5.4 dan

∑kEi⁡(ρkRVMu)=eu/2u(−iARVM(u)+O(1)).\sum_k \operatorname{Ei}(\rho_k^{\mathrm{RVM}}u) = \frac{e^{u/2}}u \left(-i\mathcal A_{\mathrm{RVM}}(u)+O(1)\right).

Como

ARVM(u)=O(log⁡2u),\mathcal A_{\mathrm{RVM}}(u)=O(\log^2u),

resulta

JRVM(x)−li⁡(x)=O(x(log⁡log⁡x)2log⁡x).J_{\mathrm{RVM}}(x)-\operatorname{li}(x) = O\left( \frac{\sqrt x(\log\log x)^2}{\log x} \right).

La inversión de Möbius añade términos m≥2m\ge2 menores que esa escala.

Error menor en una estimación intermedia

El texto afirma que el término m=2m=2 es

O(xlog⁡x).O\left(\frac{\sqrt x}{\log x}\right).

Esto es correcto después de incluir el factor 1/21/2. Para verlo:

12JRVM(x)≪12xlog⁡x=xlog⁡x.\frac12J_{\mathrm{RVM}}(\sqrt x) \ll \frac12\frac{\sqrt x}{\log\sqrt x} = \frac{\sqrt x}{\log x}.

No hay error final.

Estimación deliberadamente holgada

Para m≥3m\ge3, el texto da O(x1/3log⁡x)O(x^{1/3}\log x). Puede mejorarse, pero queda absorbida por la escala principal. No requiere corrección.

Corolario 5.6. Los tres límites
Veredicto: correcto

La primera razón se deduce del Teorema 5.5. La segunda es el teorema de los números primos. Para la diferencia,

π−πRVM=(π−li⁡)−(πRVM−li⁡),\pi-\pi_{\mathrm{RVM}} = (\pi-\operatorname{li}) - (\pi_{\mathrm{RVM}}-\operatorname{li}),

y el error clásico

xe−clog⁡xxe^{-c\sqrt{\log x}}

domina asintóticamente a

x (log⁡log⁡x)2log⁡x.\sqrt x\,\frac{(\log\log x)^2}{\log x}.

Por tanto, tras reducir cc si fuera necesario,

π(x)−πRVM(x)=O(xe−c0log⁡x).\pi(x)-\pi_{\mathrm{RVM}}(x) = O\left(xe^{-c_0\sqrt{\log x}}\right).

La tercera razón sigue al dividir por πRVM(x)∼x/log⁡x\pi_{\mathrm{RVM}}(x)\sim x/\log x.

Teorema 6.1. Control Lipschitz de JRVMJ_{\mathrm{RVM}}
Veredicto: hay una laguna concreta en la justificación de la expansión del diente de sierra

La estrategia es:

regularizar con e−ατke^{-\alpha\tau_k};
expresar la suma mediante la medida de conteo del reloj;
expandir el diente de sierra en armónicos;
estimar las fases mediante tests de primera y segunda derivada;
pasar a α↓0\alpha\downarrow0.

La estimación resultante

∣Sα(v)∣≤C(v+1)ev/2|S_\alpha(v)| \le C(v+1)e^{v/2}

sí conduce a

∣JRVM(x+θ)−JRVM(x)∣≪θ.|J_{\mathrm{RVM}}(x+\theta)-J_{\mathrm{RVM}}(x)| \ll\theta.

Pero esta frase no es suficiente:

“The partial sums of ψ(y+12)\psi(y+\frac12) are uniformly bounded and converge off a null set, and g′∈L1g'\in L^1, so termwise integration is allowed.”

El problema es que las sumas parciales

−∑m≤M(−1)msin⁡(2πmy)πm-\sum_{m\le M}\frac{(-1)^m\sin(2\pi my)}{\pi m}

son uniformemente acotadas en yy, lo cual es cierto, pero debe citarse o demostrarse. Además, la composición y=NRVM(τ)y=\mathcal N_{\mathrm{RVM}}(\tau) conserva como conjunto nulo los puntos de discontinuidad porque el reloj es estrictamente monótono y suave en el intervalo utilizado.

Reparación necesaria

Añadir:

sup⁡M≥1sup⁡y∈R∣∑m≤Msin⁡(2πmy)m∣<∞,\sup_{M\ge1}\sup_{y\in\mathbb R} \left| \sum_{m\le M}\frac{\sin(2\pi my)}m \right| <\infty,

por Dirichlet, y señalar que los puntos donde NRVM(τ)+1/2∈Z\mathcal N_{\mathrm{RVM}}(\tau)+1/2\in\mathbb Z forman un conjunto discreto. Entonces el teorema de convergencia dominada con ∣g′∣∈L1|g'|\in L^1 justifica el paso.

Segundo detalle

El segundo teorema del valor medio se aplica a

e−ατ∫eiΨ(τ) dτ,e^{-\alpha\tau} \int e^{i\Psi(\tau)}\,d\tau,

mientras el factor constante iv−αiv-\alpha se estima por v+1v+1. Esto es correcto, pero debería exponerse en esa forma para evitar que parezca que se aplica a un peso complejo.

Clasificación
resultado probablemente correcto, prueba incompleta en un paso justificativo\boxed{\text{resultado probablemente correcto, prueba incompleta en un paso justificativo}}
Corolario 6.2. Masas celulares acotadas
Veredicto: correcto

La aportación m=1m=1 se controla por el teorema Lipschitz. Para m≥2m\ge2,

n1/m−(n−1)1/m≤n1/m−1≤n−1/2.n^{1/m}-(n-1)^{1/m} \le n^{1/m-1}\le n^{-1/2}.

La suma de O(log⁡n)O(\log n) términos sigue siendo acotada, y los saltos causados por JRVM∗J_{\mathrm{RVM}}^\ast en 22 solo aparecen cuando n=2mn=2^m, con peso 1/m1/m.

Corolario 6.3. La zeta de pesos enteros es una serie de Dirichlet
Veredicto: correcto

De cnRVM=O(1)c_n^{\mathrm{RVM}}=O(1) se obtiene convergencia absoluta de

∑ncnRVM∑m≥1n−msm\sum_n c_n^{\mathrm{RVM}} \sum_{m\ge1}\frac{n^{-ms}}m

para ℜs>1\Re s>1. La exponencial de una serie de Dirichlet absolutamente convergente sigue siendo una serie de Dirichlet absolutamente convergente; lo mismo vale para la exponencial del negativo.

Observación de notación

Los coeficientes del inverso se denotan aˉNZ\bar a_N^{\mathbb Z}. Esa barra puede confundirse con conjugación. Sería mejor usar, por ejemplo,

aNZ,−1obNZ.a_N^{\mathbb Z,-1} \quad\text{o}\quad b_N^{\mathbb Z}.

No es un error.

Teorema 6.4. Identificación de Mellin–Stieltjes
Veredicto: no puede considerarse auditado dentro de este bloque

El texto no incluye aquí la prueba, sino que la remite a teoremas posteriores:

teorema de conteos de Mellin;
fórmula explícita distribucional;
cota del semiplano completo.

Por tanto, en este punto solo puede comprobarse que el enunciado es compatible con las consecuencias usadas, no que esté demostrado.

Estado de auditoría
pendiente hasta revisar las lıˊneas donde aparecen los teoremas remitidos\boxed{\text{pendiente hasta revisar las líneas donde aparecen los teoremas remitidos}}

No debe marcarse todavía como “correcto”.

Corolario 6.5. Factorización ponderada
Veredicto: correcto condicionado al Teorema 6.4

La diferencia

JZ,RVM(x)−JRVM∗(x)J_{\mathbb Z,\mathrm{RVM}}(x) - J_{\mathrm{RVM}}^\ast(x)

es O(1+log⁡log⁡x)O(1+\log\log x), porque el error del término mm es O(1/m)O(1/m) y

∑m≤log⁡2x1m=O(log⁡log⁡x).\sum_{m\le\log_2x}\frac1m = O(\log\log x).

La integral que define hRVMh_{\mathrm{RVM}} converge para ℜs>0\Re s>0, y la exponencial no introduce ceros.

Dependencia

La igualdad con JRVMMJ_{\mathrm{RVM}}^{\mathrm M} depende enteramente del Teorema 6.4, que aún está pendiente.

Lema 6.6. Cancelación del primer armónico
Veredicto: correcto y trivial
∫n−1n2cos⁡(2πx) dx=0.\int_{n-1}^n2\cos(2\pi x)\,dx=0.
Hipótesis 6.7 y Proposición 6.8
Veredicto de la proposición: correcto

El texto aclara que la “hipótesis” se demuestra más adelante en el conjunto indicado. Si

cnRVM−∫n−1n(1log⁡x+2cos⁡2πx)dx=o(1/log⁡n),c_n^{\mathrm{RVM}} - \int_{n-1}^n \left(\frac1{\log x}+2\cos 2\pi x\right)dx = o(1/\log n),

la cancelación del coseno y

∫n−1ndxlog⁡x=1log⁡n+O(1nlog⁡2n)\int_{n-1}^n\frac{dx}{\log x} = \frac1{\log n} + O\left(\frac1{n\log^2n}\right)

dan

cnRVM∼1log⁡n.c_n^{\mathrm{RVM}}\sim\frac1{\log n}.

De ahí resulta eventualmente 0<cnRVM<10<c_n^{\mathrm{RVM}}<1.

Observación editorial

Llamarla “Hypothesis” cuando después se prueba puede inducir a error. Sería más claro:

Temporary hypothesis, proved later as Corollary 14.16.

Proposición 7.1. Abscisa sintética de polos
Veredicto: el enunciado contiene una formulación contradictoria

Afirma primero:

FRVM es holomorfa en ℜs>12.F_{\mathrm{RVM}}\text{ es holomorfa en }\Re s>\frac12.

Inmediatamente después afirma que tiene polos en

12±iτk.\frac12\pm i\tau_k.

Esos polos están en la frontera, no dentro de ℜs>1/2\Re s>1/2, así que ambas frases son compatibles. Pero la frase:

“Its poles are … 12±iτk\frac12\pm i\tau_k and −2,−4,…-2,-4,\dots”

describe polos globales, mientras la primera frase describe solo un semiplano.

Matemáticamente la descripción es correcta:

polos en los ceros de PRVMcritP_{\mathrm{RVM}}^{\mathrm{crit}};
polos en los polos de GG, es decir, enteros pares negativos;
cero simple en s=1s=1.
Mejora necesaria

Escribir:

FRVMF_{\mathrm{RVM}} is holomorphic in ℜs>12\Re s>\frac12. Its meromorphic continuation to C\mathbb C has simple poles at…

Esto elimina la ambigüedad.

Proposición 7.2. Cota gaussiana bajo crecimiento vertical
Veredicto: correcta

El factor

∣es2∣=eσ2−t2|e^{s^2}|=e^{\sigma^2-t^2}

domina cualquier crecimiento exp⁡(o(t2))\exp(o(t^2)). No hay polos en la banda de desplazamiento, y mover la recta a ℜs=1/2+ε\Re s=1/2+\varepsilon produce el factor x1/2+εx^{1/2+\varepsilon}.

Mejora menor

Para obtener una constante OεO_\varepsilon también hay dependencia inicial de cc, aunque esta desaparece tras mover la recta. Puede dejarse como está.

Resultado provisional del bloque 0–2000
Correctos
Proposición 2.1
Teorema 3.1
Teorema 4.1
Corolarios 4.2 y 4.3
Lema 5.1
Teorema 5.2
Proposición 5.3
Teorema 5.5
Corolario 5.6
Corolarios 6.2 y 6.3
Lema 6.6
Proposición 6.8
Proposiciones 7.1 y 7.2, con una aclaración editorial en 7.1
Correctos, pero con prueba que debe completarse o aclararse
Lema 2.2: justificar explícitamente la comparabilidad de γk\gamma_k, τk\tau_k y k/log⁡kk/\log k.
Lema 5.4: incluir el tramo parcial del último bloque en el argumento de Cauchy.
Teorema 6.1: justificar formalmente la convergencia dominada de las sumas parciales de Fourier del diente de sierra.
Pendiente por dependencia posterior
Teorema 6.4, y por tanto parte de la auditoría del Corolario 6.5.
Error grave encontrado hasta ahora

En las líneas efectivamente inspeccionadas de este bloque no encuentro todavía una contradicción que invalide un teorema principal. El defecto más serio es la justificación incompleta del paso armónico en el Teorema 6.1. El resto son reparaciones locales y dependencias aún no inspeccionadas.