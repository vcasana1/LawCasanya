# V22 changelog (12 October 2026)

Correction release. Every change answers one point of the six reviews of v21 collected in `review/v21_reviews/`
(R1 lines 1-2000, R2 lines 2000-4000, R3 lines 4001-6000, R4 lines 6001-7771, R5 result-by-result audit,
R6 master numbered list, sections A-V). Labels are those of the TeX source; numbers and pages are those of the
v22 PDF. The numerical sections (R6 part O and the related P-T) were handled as instructed: no new experiments
were run; wording that was wrong or dubious was corrected. Points of the reviews that were checked and found
not to apply, or that ask for new computations, are listed at the end.

## The hypothesis varpi_RVM < 1

An attempt was made to prove Hypothesis 8.5 (p. 30) before writing. It cannot be proved with the tools of the
paper: `varpi_RVM = P_RVM^crit(1/2) e^{nu_3 + nu_4}` is a product of three clock constants, numerically
`0.9940... x 0.9676...`, and the sign of `log varpi_RVM` is a cancellation between them that nothing in
Sections 3-8 controls; a proof would be a certified enclosure (interval arithmetic of the finite product, of
its tail, and of the two ray integrals `nu_3`, `nu_4`, with a margin of about 0.038). This is now stated in the
paragraph after Hypothesis 8.5 ("What a proof of the hypothesis would require"), and the hypothesis is kept.
The Richardson value is declared to carry no error bound (R6-B).

## Errors and gaps repaired (proofs)

| Source | Place | Change |
|---|---|---|
| R5 GAP, R6-E | Theorem 12.5 (`mellin-counts`, p. 45) | The sigma-independence of `J^M_X` was argued by Cauchy's theorem against a cut-off `hat psi(Im s)`, which is not holomorphic in `s`: not a proof. Replaced by the Paley-Wiener theorem for `H^2` of a half-plane (Rudin, RCA Thm. 19.2): `log zeta_X(s)/s` is in `H^2(Re s > c)`, hence a Laplace transform `int_0^infty j(u) e^{-su} du` with `e^{-cu} j` in `L^2`, independent of `c` by injectivity; new `eq:mellin-count-laplace`. |
| R6-E (Priority 1) | Theorem 16.3(ii) (`finite-euler`, p. 90) | The coefficient-extraction formula was displaced to lines `Re s < 0` where the Dirichlet series does not converge. New proof: boundedness in the closed strip (Phragmen-Lindelof), the means `A_{lambda,T}(sigma)` of `f e^{i lambda t}`, the identity `d/dsigma (e^{lambda sigma} A_{lambda,T}) = O(M/T)` by one integration by parts (`eq:finite-euler-coefficients`), hence equality of the spectra on the two boundary lines (`eq:finite-euler-spectrum`), which gives `n | 6` and `a_n = a_{6/n}`. Bohr (Acta Math. 47, 1926, doi:10.1007/BF02543846) cited as the general theorem. Part (iii) now rests on a repaired (ii). |
| R6-H (Priority 1) | Theorem 15.7 (`nondegenerate`, p. 84) | Step 1: convergence in `S'` with the three integrations by parts written; point-support lemma (Hormander 2.3.4) stated and used. Step 2 rewritten: Taylor remainder of order `A+1`, polynomial part with the coefficients `O(kappa^{-3})` proved, remainder part shown to vanish by mollification and the point-support lemma; `H_1(sigma) -> 0` by domination `sum |a_n|/n < infinity`; `sum kappa_dot 2 kappa sigma/(sigma^2+kappa^2)^2 = O(sigma^{-1} log sigma)` proved by splitting at `kappa = sigma` and partial summation. Step 4 rewritten: holomorphy of `Z` at the poles with multiplicities; admissible radii `r_j` with `r_{j+1} <= 4 r_j`; the bound `|H| <= C log^2 r` on admissible circles by three shells with `|z -+ i kappa| >= |r - kappa|`; maximum principle on the discs (`eq:nondeg-order`) gives order at most one. |
| R5 ERROR-L, R6-F | Lemma 13.6(a) (`L2-partial-sums`, p. 50) | Lipschitz tests give convergence of the pairing; absolute convergence only when `psi'` has bounded variation (one integration by parts gains `1/kappa`). Statement and proof corrected. |
| R5 FIX, R6-F (Priority 1) | Proposition 15.3(ii) (`lists-compact`, p. 82) | "Dominated in L^2" replaced by an explicit pointwise majorant `H(t) = C(1+log(2+|t|))/(1+|t|)` in `L^2` (`eq:lists-compact-dominant`), pointwise continuity of `log zeta_kappa` on `O` (uniformly convergent series), dominated convergence, Plancherel; the two pairings determining `J^M - J` identified and shown continuous (tails uniform on `O` by `eq:L2-partial-sums`); the cells `n = 2^j` treated separately. |
| R6-I (Priority 1) | Proposition 15.9 (`critical-points`, p. 86) | Existence and uniform bound of `d/dkappa_k J_kappa` on `(2,3)`: only the k-th term of the series depends on `kappa_k`, derivative `-2 Re(i y^{1/2+i kappa}/(1/2+i kappa))`, bounded by `2 sqrt3 / tau_0^+`; the bound for `u_m` on powers of 2 follows; the chain-rule topology named (`ell^1(n^{-sigma'})`); uniformity of `Q_kappa` in all `t`. |
| R5, R6-N (Priority 1) | Appendix E, Proposition E.2 (p. 188) | (a) Order of `P_kappa` proved directly: `log|P_kappa(s)| = O_eps(|s|^{1+eps})` from `N_kappa(t) << t^{1+eps_0}` by Stieltjes integration, instead of "because its convergence exponent is at most 1". (b) The constant `K_E` now carries `8|b|` (the Jensen disc lies in `0 <= Re s <= 4`, where `e^{2bs}` contributes up to `8|b|`; on the line `Re s = 2` it is `4b`); `eq:rung-line-v18` stated for `2 <= Re s <= 4`. (c) Branches of `(P^crit)^{1-t}` and `G^t` defined globally on the simply connected zero-free half-plane `Re s > 3/2` with logarithms real on the axis, not "continued along the path". (d) Phragmen-Lindelof: the order-one function satisfies `u <= |s|^2 <= e^{|Im s|/2}`, admissible since `1/2 < pi/3`; the division by `s+2` explained. (e) Jensen's formula written with its radii `3/2` and `2`, and the replacement of the mean by the maximum made explicit. (f) Net versus total variation of the argument on the vertical segment; branches continuous from `t = 0`. (g) Boundary terms of the partial summation written; `eps_0 < 1` forces degree zero. (h) New Corollary E.3: `b = 0` gives bounded displacement; the mechanism of the drift explained; the mean-square hypothesis on the masses declared independent. |
| R5, R6-D | Proposition 14.31 (`dichotomy`, p. 73) and Proposition 17.13 (`rb-prescribed-uniqueness`, p. 97) | "An entire quotient of two order-one functions has order one" replaced by the comparison of the Hadamard factorizations (same zeros with multiplicities, same canonical product, so the quotient is `e^{linear}`); in 17.13 the analytic identity is derived first and the quotient discussed only afterwards. |
| R5 | Theorem 14.3 (`pair-criterion`, p. 61) and Corollary 15.4 (`existence-form`, p. 82) | "they are the points 1/2 +- i gamma_k" deleted; the conclusion is RH, and then Theorem 11.2 gives `zeta_Z1 = zeta`. |
| R5, R6-F | Proposition 14.25 (`exceptional-set`, p. 71) | "A discrete subset of a compact interval is finite" replaced by: the zeros of a nonzero entire function have no finite accumulation point. |
| R2, R6-B | Theorem 12.2 (`varpi-Z1`, p. 44); paragraph after Theorem 12.1 | Dominated convergence for series written with the majorant `17 d_rho^2/gamma^2`; the ordered product `eq:varpi-Z1-product` declared ordered (absolute convergence not asserted; the order by height is part of the definition). |
| R1 | Lemma 2.2 (`bounded-displacement`, p. 18) | Comparability `gamma_k ~ tau_k ~ k/log k` derived from `N(gamma_k) = k + O(log gamma_k)` before the mean-value step. |
| R1 | Theorem 6.1 (`unit-cell`, p. 23) | Uniform bound of the partial sums of `sum sin(2 pi m y)/m` proved in one line (split at `floor(1/y)` plus Abel summation); the exceptional set declared discrete, hence null; second mean-value theorem stated in Bonnet's form for real and imaginary parts, with `|iv - alpha| <= v + 1`. |
| R1 | Lemma 5.4 (`A-RVM`, p. 21) | A finite index range consists of at most two partial runs and complete blocks; the Cauchy criterion written uniformly in the upper index. |
| R2, R6-C | Lemma 8.4 (`TR-harmonic`, p. 29) | Paragraph "Uniformity": the three limits `r -> 1` have r-independent majorants, so `O(t^{-2})` is uniform in `0 < sigma' <= B`, `t >= t_0(B)`. |
| R6-G | Theorem 15.6 (`free-masses`, p. 83) | `e^{nu_7 2^{-s}} = sum nu_7^r/r! 2^{-rs}` written; the two factors identified; why the support stays in the integers after truncation and Mobius inversion explained; the hypotheses (H0)-(H3) traced to Theorem 15.1 (transfer to `O`); paragraph after the theorem: uniqueness is proved, existence is (D) and is not. |
| R6-J | Theorem 16.1 (`acceptance`, p. 87) | (i)<=>(ii): the difference supported at `0` is a polynomial, which has a finite limit along `z = iy`, hence is the constant `-ik`; Paley-Wiener-Schwartz cited as Hormander 7.3.1 with the transform convention of `eq:model-logder` and the support `[0, 2k]`; (iii)=>(ii): the inequality `|w| <= 1/2` that makes the logarithm converge. The criterion is declared silent on whether the zeta list belongs to the intersection. |
| R6-J | Proposition 16.2 (`graph-model`, p. 88) | The counterclockwise motion of the eigenvalues proved: `M' = 2i M D`, eigenphase derivative `theta_j' = 2(p|v_1|^2 + q|v_2|^2) >= 2 min(p,q)` (`eq:graph-eigenphase`), `M(t)` never scalar, `1` never a double eigenvalue, zeros simple, count `kT/pi + O(1)`. |
| R1 | Theorem 3.1, Proposition 7.1, Hypothesis 6.7 | `G(0) = -2`; `F_RVM` meromorphic on `C`, holomorphic in `Re s > 1/2`, "poles of its meromorphic continuation"; Hypothesis 6.7 retitled "proved in Corollary 14.16". |
| R6-L | Theorem 17.20 (`rb-certificate`, p. 98) and new Remark 17.21 | Uniqueness only in `Ran Q_m` stated in the theorem; "modified Newton iteration" (frozen right inverse); remark on evaluation errors (residual error `eps_m`, inexact right inverse `delta_m`), order of the ordinates after a correction, no compatibility between stages, and what uniform estimates an infinite sequence would need; `CERTIFIED` in the console output explained as a floating-point test. |

## Wording, status and notation (R6-A, B, O, P, Q, U)

| Source | Place | Change |
|---|---|---|
| R6-A (Priority 1) | Abstract (p. 2), Subsection 1.4 (p. 13) | Abstract: the paper proves neither RH nor (D). Subsection 1.4 opens with "What this paper does not prove" (RH, (D), existence of the rung solution, interior atomic path, convergence of finite sections, `varpi_RVM < 1`, computer-assisted proof) and the list of the only open points. |
| R6-A, U | Section 19 (p. 131) | New opening: "New in this paper" (one paragraph listing the contributions, with the classical substance of B' acknowledged); "Proved without hypotheses" (the forty items plus the secondary lemmas that carry them); "Conditional on the one hypothesis" (the five uses of 8.5; 6.7 is proved; the jump-growth condition is part of an equivalence); "Equivalent to (D) and not proved"; "Open and not claimed"; a dependence table (results versus what they depend on: clock only, membership in `O`, Hypothesis 8.5, (D), existence of a solution, verified zeros, floating point). "Not proved" paragraph names RH. |
| R6-U | Notation (p. 2) | Paragraph "The three counts": `N_RVM` (continuous clock), `n_RVM = floor(N_RVM + 1/2)` (integer count of the clock), `N_kappa` (count of a list); scaled von Mangoldt mass; the three distribution spaces and whether the origin is included. Appendix E used `N_RVM(T)` for the integer count: replaced by `n_RVM(T)` (6 places). |
| R6-U, user | Collision check (p. 2); Appendix E | Variable collisions removed: the interpolation parameter of Appendix E was `theta` (the unit-cell step) and is now `sf t`; its constants `K`, `K'` collided with the box `K(C, M)` of Section 17 and are now `K_E`, `K_E'`; `B_2` and `C^*` noted; "Vall'ee" typo fixed. |
| R6-B | After Hypothesis 8.5 (p. 30) | Richardson value declared without error bound and not certified; the agreement with the ordered product is a consistency check between two floating-point computations. |
| R6-O | Section 18 preamble (p. 119) | "the first 10^5 factors exactly" -> "in double precision, one by one"; the clock tail replaces the unknown tail of the zeta ordinates in every product over the `gamma_k`, and all agreements of `zeta_Z1` with `zeta` include that substitution; "all zeros" means all zeros in the supplied file; no quantity of the section is certified. |
| R6-O | Experiment 18.2 (`Z1`), 18.4 (`transition`) | The `10^-9` figure measures file truncation and tail substitution, not (D); Richardson extrapolation presupposes a `1/T`, `1/T^2` expansion finer than the proved `O(1/T)`, values without error bound. |
| R6-Q | Experiment 18.12 (`clock-to-zeros`, p. 128) | "the masses being eliminated linearly" -> solved by ridge regression (`10^-10 I` in the code), not eliminated exactly; proximity to `gamma_k` used only as a diagnostic. |
| R6-P | Section 18, ternary walk | The walk follows its target by design; sign coincidences with `mu` reported without statistical content. |
| R6-S | Section 17.7 and Remark 17.21 | `CERTIFIED` = floating-point value of `l_m` below 1; the enclosures a rigorous application would need are listed and declared absent. |

## References added

Bohr 1926 (doi:10.1007/BF02543846), Rudin 1987 (no DOI).

## Checked and not changed

- R3 (lines 4001-6000) found no local error; its remarks on "reduction versus resolution" are now in Subsection 1.4 and Section 19.
- R6-O/P/Q/R/S/T items that ask for new computations (hashes of the data files, interval arithmetic, condition numbers, multiple RIDGE values, stability tests, several precisions, perturbed targets, Schwartz-test versions, certified rounding) were not carried out, as instructed; the text now says exactly what the computations are and are not.
- R6-K: the correction term `H(0) delta_0'` is already isolated in Lemma 17.11 (`rb-laplace`) and the sign convention is stated there; the topology of the residual convergence is that of Proposition 17.5 (`rb-compactness`).
- R6-M: the hypotheses of Pavlov and Avdonin-Ivanov are quoted in Section 17.6 as in v21; no change.
- R6-U "move secondary equivalences to an appendix", "index of symbols": the notation table already serves as the index; the equivalences were left in place, their status being now fixed by the dependence table.
- R6-D "elimination of e^{B's} by the symmetry": already in the proof of Theorem 9.1 (`Hadamard`).
