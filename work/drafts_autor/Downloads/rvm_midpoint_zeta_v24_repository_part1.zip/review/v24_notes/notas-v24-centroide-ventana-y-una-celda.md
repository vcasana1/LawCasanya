# Notas para v24 — sumas exponenciales sobre las ordenadas: centroide, Cramér, ventana (log2,log3) y una sola celda (14 oct 2026)

Fuentes: chat «Centroide de exp(gamma k*i)» (claude.ai/chat/57c07f01-97b5-42c1-87f1-e02c1dec2f85, 110 turnos) y dos adjuntos de Doktor del 14 oct (derivación (1)–(8) y nota «una sola celda / Hilbert»), copiados literalmente al final. Doktor pide que en v24 el estudio de las sumas exponenciales y las nuevas equivalencias con RH vayan DESTACADOS.

## A. Objetos

- $\gamma_k>0$ ordenadas con multiplicidad; $\rho=\tfrac12+\delta+i\gamma$; $w_{k,N}=1-\frac{k-1}{N}$.
- Centroide de ordenadas $C_N^\zeta(u)=\sum_{k\le N}w_{k,N}e^{iu\gamma_k}$ (en $u=1$: $0.7769\ldots+0.7678\ldots i$ medido con $2\,001\,052$ ceros).
- Centroide de ceros completos $C_N^\xi(u)=\sum_{k\le N}w_{k,N}e^{u(\rho_k-1/2)}$.
- $A(w)=\sum_{\gamma_k>0}e^{iw\gamma_k}$, $\Im w>0$; $B(w)=e^{-w/2}V_+(w)$, $V_+(z)=\sum_{\Im\rho>0}e^{\rho z}$ (Cramér 1919: continuación meromorfa, polos simples en $\pm\log p^m$).
- $\mathcal D(w)=A(w)-B(w)=\sum_{\beta>1/2}2\bigl(1-\cosh(w\delta)\bigr)e^{iw\gamma}$ (suma por órbitas $\tfrac12\pm\delta+i\gamma$).

## B. Resultados establecidos en el chat

1. **Bajo RH** (Landau en $x=e$, Cramér, tauberiano local de Debruyne–Vindas, Level 1): $\lim_N C_N^\zeta=e^{-1/2}V_+(1)=0.77689426079325\ldots+0.76785566886455\ldots i$, con $\Re=\frac1{2\sqrt e}\bigl(e-\frac1{e^2-1}\bigr)$ (fórmula explícita: $\psi(e^u)$ constante en $(\log2,\log3)$). La parte imaginaria $0.76785\ldots$ no aparece en la literatura consultada (Cramér, Guillera 2013 arXiv:1307.5723 Cor. 4.3/4.4/Conj. 4.5, Landau–Gonek).
2. **Sin RH**: no está demostrado ni que $C_N^\zeta$ converja ni su valor; criterio tauberiano exacto: converge sii $\int_s^\infty G(\sigma)\sigma^{-2}d\sigma-b/s$ es pseudofunción local en $s=0$, $G(s)=\sum_ke^{i\gamma_k}e^{-s\gamma_k}$.
3. **Equivalencia en un punto imaginario**: para un $y_0\in(0,4\pi]$, $\sum_k e^{-y_0\gamma_k}=e^{-iy_0/2}V_+(iy_0)\iff$ RH; el defecto es $\sum_{\beta>1/2}2(1-\cos(y_0\delta))e^{-y_0\gamma}\ge0$.
4. **Equivalencia en la ventana** $I=(\log2,\log3)$: RH $\iff\lim_N\sum_{k\le N}w_{k,N}e^{iu\gamma_k}=e^{-u/2}V_+(u)$ en $\mathcal D'(I)$; prueba: borde de la cuña + identidad + positividad en el eje imaginario. Forma con funciones test: $\sum_k\widehat\varphi(\gamma_k)=\int_I\varphi(u)e^{-u/2}V_+(u)du$ para toda $\varphi\in C_c^\infty(I)$ (fórmula explícita de Weil escrita solo para la medida de ordenadas en un hueco entre potencias de primos). Hace falta la forma unilateral (la simétrica solo da $\Re\mathcal D=0$) y un abierto (un punto o finitos puntos no bastan).
5. Vecino más próximo: Arias de Reyna, arXiv:2402.10604 (global, simétrico, mecanismo en el lado de primos: medida temperada). Diferencias: local, unilateral, mecanismo cuña+positividad. Revisar Lev–Olevskii, Kurasov–Sarnak antes de afirmar novedad.
6. Escala $\delta^2$: $-u^2\delta^2e^{iu\gamma}$ (real) frente a $+y^2\delta^2e^{-y\gamma}$ (imaginario): continuación en $w$ de $\sum_{\beta>1/2}\delta^2e^{iw\gamma}$ (transformada de $A_2$).
7. Qué basta: intervalo abierto sí; finitos puntos no; conjunto con acumulación solo si $\mathcal D$ se extiende analíticamente; un punto imaginario decide pero no se mide ($|\mathcal D(iy_0)|\ll T_V\log T_V e^{-y_0T_V}$).
8. Familia $\lambda$: $C(1)=0.04157\ldots+1.75754\ldots i$ (reloj, incondicional); pendiente medida en $\lambda=1$: $-i\sum w\varepsilon e^{i\tau}=0.271+10.398i$, cuerda $C(0)-C(1)=0.7353-0.9897i$; el camino no es lineal. En el interior no se sabe que $C(\lambda)$ exista (segundo orden $\int S^2e^{it}/\log t$). Participación por prefijo: $C_N(\lambda)=\lambda c_M+(1-\lambda)c-(1-\lambda)R_{\lambda N}+o(1)$, $R_K=\sum_{k\le K}(e^{i\gamma_k}-e^{i\tau_k})$, $\max|R_k|=3.0068$. Conteo: $N_\lambda=\lambda N_{\rm RVM}+(1-\lambda)N_\zeta+o(1)$, por eso $\pi_\lambda$ queda a mitad de camino (núcleo $1/\rho$) y el centroide no (núcleo $1$).
9. Centroides con 1000 ceros (en el chat con mpmath; en v24 rehacer con zeross.bin): $C_\gamma=0.7720742641+0.7626754146i$, $C_\tau=0.0401443298+1.7565288414i$, $C_\theta=0.6133423126+1.3939939477i$ ($\theta_k=(\gamma_k+\tau_k)/2$); $(C_\gamma+C_\tau)/2=0.4061+1.2596i$; diferencia $0.2072+0.1344i$.
10. Hamburger: $\zeta_{Z1}$ serie de Dirichlet $\Rightarrow\zeta_{Z1}=\zeta\Rightarrow$ RH; en la ventana es la identidad del punto 4.

## C. Adjunto 1 (derivación (1)–(8)): residuo exacto $R_\varphi$
Ver copia literal abajo. Resultado: $\langle{\rm bv}\mathcal D,\varphi\rangle=\sum_{\beta>1/2}[2\Phi_\varphi(\gamma)-\Phi_\varphi(\gamma-i\delta)-\Phi_\varphi(\gamma+i\delta)]$, absolutamente convergente; RH $\iff R_\varphi=0$ para toda $\varphi\in C_c^\infty(I)$; la ausencia de átomos primos en $I$ no elimina las colas unilaterales $1/(u-\log n)$.

## D. Adjunto 2 (una sola celda): $Q=0$ y $\mathcal HQ=0$ solo en $I$
$Q\propto dJ^{\rm M}_{Z1}/dx-dJ/dx$ en $x=e^u$; en $(2,3)$, $dJ=0$, luego $Q=0$ en $I\iff dJ^{\rm M}_{Z1}=0$ en $(2,3)\iff\mathsf R_{\mathsf f}(0)=0$ para toda $\mathsf f\in C_c^\infty(I)$ (identidad coseno (7)). La parte de Hilbert (identidad seno (8)) no se sigue localmente: en $I$, $\mathcal HQ$ es la transformada de lo que hay fuera ($\delta_{\log2}$ deja $1/(\pi(u-\log2))$). Coseno + seno en esa única banda bastan (unicidad holomorfa). Paso siguiente propuesto: derivar el funcional seno unilateral explícito con términos arquimedianos y colas $1/(u-\log n)$.

## E. Adjunto 3 (ventana, $Q$ y $\mathcal HQ$): compresión de A7 a un solo hueco espectral
Con (1) $(\log x)\,dJ^{\rm M}_{Z1}/dx=1-\frac{2}{\sqrt x}\Re A(\log x)-\frac1{x(x^2-1)}$ (Thm 12.6 de v23 para $Z_1$) y (2) lo mismo para $J$ con $B$ (fórmula explícita clásica, incondicional), y $dJ=0$ en $(2,3)$: $\Re\,{\rm bv}\mathcal D(u)=-\tfrac12e^{u/2}u\,(dJ^{\rm M}_{Z1}/dx)(e^u)$ en $(\log2,\log3)$. Luego $\Re\,{\rm bv}\mathcal D=0$ en la ventana $\iff J^{\rm M}_{Z1}$ constante en $(2,3)$ (condición de celda, Thm 12.7). Con $Q(u)=e^{u/2}u[dJ^{\rm M}_{Z1}/dx-dJ/dx]_{x=e^u}$: ${\rm bv}\mathcal D=-\tfrac12(Q+i\mathcal HQ)$; $\mathcal H$ no local (colas $1/(u-\log n)$ de Cramér). Cadena: ${\rm bv}\mathcal D=0$ en $(\log2,\log3)\iff\mathcal D\equiv0\iff\zeta_{Z1}=\zeta\iff$ (D) $\iff$ RH. Resultado: A7 para todas las celdas $\iff{\rm bv}\mathcal D=0$ solo en $(\log2,\log3)$; lo que habría que probar: $Q=0$ y $\mathcal HQ=0$ en la ventana usando solo ordenadas y Cramér.

---
## Copia literal adjunto 1 (derivación (1)–(8))

Tienes razón en el punto lógico: **si conseguimos demostrar la coincidencia usando solo \(N(T)\), Cramér y propiedades incondicionales de \(\zeta\), no se ha introducido RH**. Eso constituiría una demostración de RH.

He hecho la comparación exacta. El resultado es que la coincidencia **no sale automáticamente del hueco \((\log2,\log3)\)**. Aparece un término adicional muy preciso. Éste es el cálculo.

Sea
\[
I=(\log2,\log3),\qquad
A(w)=\sum_{\gamma_k>0}e^{iw\gamma_k},
\qquad
B(w)=e^{-w/2}V_+(w).
\]
Para
\[
\varphi\in C_c^\infty(I)
\]
definimos
\[
\Phi_\varphi(z)
=
\int_I\varphi(u)e^{iuz}\,du.
\]
Como \(\varphi\) es \(C^\infty\) y compactamente soportada, \(\Phi_\varphi\) decrece más rápido que cualquier potencia sobre cada banda
\[
|\Im z|\le \frac12.
\]

Por tanto los valores frontera pueden evaluarse término a término en sentido distribucional. Para la suma de ordenadas,
\[
\boxed{
\left\langle\operatorname{bv}A,\varphi\right\rangle
=
\sum_{\gamma_k>0}\Phi_\varphi(\gamma_k).
}
\tag{1}
\]

Esto depende exclusivamente de las ordenadas. Equivalentemente,
\[
\left\langle\operatorname{bv}A,\varphi\right\rangle
=
\int_0^\infty \Phi_\varphi(t)\,dN(t).
\tag{2}
\]
Y aquí \(N\) satisface incondicionalmente
\[
dN=dH+dS.
\]
Ésta es precisamente la descomposición de Stieltjes que ya tienes. zeta_rvm_exponential_centroids\_…

Para el lado de Cramér, escribiendo
\[
\rho=\frac12+\delta_\rho+i\gamma_\rho,
\]
tenemos
\[
B(w)
=
\sum_{\gamma_\rho>0}
e^{w(\delta_\rho+i\gamma_\rho)}.
\]
Luego
\[
\boxed{
\left\langle\operatorname{bv}B,\varphi\right\rangle
=
\sum_{\gamma_\rho>0}
\Phi_\varphi(\gamma_\rho-i\delta_\rho).
}
\tag{3}
\]

Ahora agrupamos los ceros mediante
\[
\frac12+\delta+i\gamma
\longleftrightarrow
\frac12-\delta+i\gamma .
\]
Una órbita fuera de la recta aporta a (1)
\[
2\Phi_\varphi(\gamma),
\]
y a (3)
\[
\Phi_\varphi(\gamma-i\delta)
+
\Phi_\varphi(\gamma+i\delta).
\]

Por tanto obtenemos la identidad exacta

\[
\boxed{
\begin{aligned}
\left\langle\operatorname{bv}\mathcal D,\varphi\right\rangle
={}&
\left\langle\operatorname{bv}(A-B),\varphi\right\rangle\\
={}&
\sum_{\substack{\beta>1/2\\\gamma>0}}
\left[
2\Phi_\varphi(\gamma)
-\Phi_\varphi(\gamma-i\delta)
-\Phi_\varphi(\gamma+i\delta)
\right].
\end{aligned}}
\tag{4}
\]

La serie de (4) converge absolutamente. Así que no hay aquí ningún problema de regularización.

El objetivo queda reducido exactamente a demostrar

\[
\boxed{
\int_0^\infty\Phi_\varphi(t)\,dN(t)
=
\left\langle
\operatorname{bv}\bigl(e^{-w/2}V_+(w)\bigr),
\varphi
\right\rangle
\quad
\forall\varphi\in C_c^\infty(I).
}
\tag{5}
\]

Y, como querías, **los dos miembros de (5) pueden formularse sin conocer ningún \(\beta\)**:

\[
\text{izquierda: }N(T)\text{ y las ordenadas};
\qquad
\text{derecha: Cramér/}\xi'/\xi.
\]

Hasta aquí todo es incondicional.

El intento natural es ahora usar que no existe ninguna potencia prima \(n\) con
\[
\log2<\log n<\log3.
\]
Pero aquí aparece el detalle decisivo. La fórmula unilateral de Cramér utiliza, en \(\Re s=c>1\),
\[
-\frac{\zeta'}{\zeta}(s)
=
\sum_{n\ge2}\frac{\Lambda(n)}{n^s},
\]
y la integración vertical produce

\[
\int_0^\infty e^{it(w-\log n)}dt
=
\frac{i}{w-\log n}.
\]
Esto está explícitamente en la representación que ya tenías. Pasted text(20260813-133910)

Por tanto, para \(u\in I\), aunque
\[
u\ne\log n
\]
para todo entero \(n\), queda

\[
\frac{1}{u-\log n},
\]
no cero.

Es decir,

\[
\boxed{
\text{ausencia de átomos primos en }I
\quad\not\Rightarrow\quad
\text{ausencia de la contribución unilateral prima en }I.
}
\tag{6}
\]

La propia formulación anterior de tu manuscrito detectaba exactamente esto: la proyección unilateral conserva contribuciones no locales con denominadores \(1\pm\log n\); que la frecuencia no sea una potencia prima elimina la resonancia, pero no toda la contribución aritmética. zeta_rvm_exponential_centroids\_…

Se puede intentar evitar (6) pasando a la fórmula **bilateral** de Weil, donde las contribuciones primas sí son verdaderos átomos
\[
\delta(u-\log n),\qquad
\delta(u+\log n).
\]
Entonces, efectivamente, sobre \(I\) desaparecen.

Pero al hacerlo aparece exactamente otro término: la fórmula holomorfa ve
\[
\rho=\frac12+\delta+i\gamma
\]
mediante
\[
\Phi_\varphi(\gamma-i\delta),
\]
mientras que la proyección de ordenadas quiere
\[
\Phi_\varphi(\gamma).
\]

No existe una sustitución holomorfa gratuita de una por otra. Tu propio análisis anterior aislaba este hecho: una fórmula explícita holomorfa ve \(e^{\rho-1/2}\), mientras que una función que dependa únicamente de \(\Im\rho\) no es holomorfa en el cero completo. zeta_rvm_exponential_centroids\_…

Y cuando se hace rigurosamente el desplazamiento del contorno desde \(\Re s>1\) hasta la recta crítica, cada cero con
\[
\beta>\frac12
\]
que se atraviesa deja precisamente

\[
2\Phi_\varphi(\gamma)
-\Phi_\varphi(\gamma-i\delta)
-\Phi_\varphi(\gamma+i\delta).
\]

Es decir, el residuo que impide cerrar el argumento es **exactamente (4)**.

Por tanto hemos llegado a una reducción muy precisa:

\[
\boxed{
\begin{array}{c}
\text{Cramér + hueco }(\log2,\log3)\\[2mm]
\text{elimina las singularidades primas locales,}\\[2mm]
\text{pero al proyectar los ceros sobre sus ordenadas queda}\\[2mm]
R_\varphi=
\displaystyle
\sum_{\beta>1/2,\gamma>0}
\bigl[
2\Phi_\varphi(\gamma)
-\Phi_\varphi(\gamma-i\delta)
-\Phi_\varphi(\gamma+i\delta)
\bigr].
\end{array}}
\tag{7}
\]

La prueba de RH quedaría cerrada si se demuestra, **sin usar los \(\beta\)**,

\[
\boxed{R_\varphi=0
\qquad
\forall\varphi\in C_c^\infty((\log2,\log3)).}
\tag{8}
\]

No hay RH escondida en (8). Pero Cramér y el mero hueco entre \(2\) y \(3\) no demuestran (8): el cálculo exacto deja precisamente ese residuo.

Así que la puerta correcta es ahora más estrecha de lo que parecía: **hay que demostrar (5) directamente desde \(dN=dH+dS\) y la representación cero-libre de Cramér, sin desplazar el contorno de una forma que vuelva a introducir los residuos laterales**. Ése sería un argumento genuinamente nuevo y, si se logra, sí cierra RH.
---
## Copia literal adjunto 2 (una sola celda / Hilbert)

Sí en una cosa importante: **no hace falta demostrar nada “para todo \(n\)”**. Si consigues
\[
Q=0,\qquad \mathcal H Q=0
\]
solo en
\[
I=(\log2,\log3),
\]
ya está. La unicidad holomorfa propaga desde ese único intervalo y da \(\mathcal D\equiv0\), por tanto RH.

Pero hay que distinguir dos dificultades. Para el \(Q\) que definimos,
\[
Q(u)\propto 
\left(\frac{dJ^{\rm M}_{Z1}}{dx}-\frac{dJ}{dx}\right)_{x=e^u},
\]
y en \(2<x<3\)
\[
dJ=0.
\]
Por tanto
\[
Q=0\quad\text{en }I
\]
equivale exactamente a
\[
\boxed{dJ^{\rm M}_{Z1}=0\quad\text{en }(2,3).}
\]
Eso es una **sola celda** del problema de atomización, no todas. La v23 permite formularla puramente con las ordenadas mediante el funcional
\[
\mathsf R_{\mathsf f}(0)
=
\mathsf k_{\mathsf f}-\sum_k\mathsf c_{\mathsf f}(\gamma_k),
\qquad
\supp\mathsf f\Subset(\log2,\log3),
\]
y \(Q=0\) en esa celda es precisamente
\[
\mathsf R_{\mathsf f}(0)=0
\quad\forall\,\mathsf f\in C_c^\infty(I).
\]
La proposición de las rungs establece esta formulación exactamente. rvm_zeta_pi_mertens_v23_1

Así que aquí estoy de acuerdo contigo: **atacar una sola celda puede ser muchísimo más fácil que atomizar todas las celdas**. Y si además recuperamos la parte conjugada, no necesitamos las demás.

El problema es que \(\mathcal H Q=0\) no se sigue localmente de \(Q=0\). Éste es el punto que hay que tratar con cuidado. Si \(Q=0\) en \(I\), entonces para \(u\in I\)
\[
\mathcal H Q(u)
=
\frac1\pi\operatorname{pv}
\int_{\mathbb R\setminus I}
\frac{Q(v)}{u-v}\,dv.
\tag{1}
\]
Es decir: **en el hueco, \(\mathcal H Q\) está formado exclusivamente por lo que ocurre fuera del hueco**.

El ejemplo elemental que muestra el problema es precisamente el que nos interesa. Si
\[
Q=\delta_{\log2},
\]
entonces ciertamente
\[
Q=0\qquad\text{en }(\log2,\log3),
\]
pero
\[
\mathcal H Q(u)
=
\frac{1}{\pi(u-\log2)}
\ne0
\qquad(\log2<u<\log3).
\tag{2}
\]
Una masa en el extremo izquierdo deja una cola en todo el intervalo. Lo mismo hacen \(\log3,\log4,\ldots\).

Por eso los denominadores de Cramér
\[
\frac1{u-\log n}
\]
eran exactamente esta transformada de Hilbert: los átomos desaparecen **como soporte local**, pero sus partes conjugadas no desaparecen.

Ahora bien, esto también muestra exactamente qué habría que probar, y es mucho más pequeño que “todos los \(n\)”.

Si \(Q=0\) en \(I\), define
\[
F(z)
:=
\frac1\pi
\left\langle Q(v),\frac1{z-v}\right\rangle .
\tag{3}
\]
Como no hay soporte de \(Q\) dentro de \(I\), \(F\) es analítica a través de \(I\), y
\[
F(u)=\mathcal H Q(u),\qquad u\in I.
\tag{4}
\]
Por tanto basta demostrar
\[
F(u_0)=0
\]
no en todos los puntos mediante cálculo independiente, sino —si además conseguimos alguna estructura rígida de \(F\)— hacer que ese dato fuerce
\[
F\equiv0\quad\text{en }I.
\]

Más directamente, si podemos obtener de Cramér que la contribución externa satisface
\[
\boxed{
\operatorname{pv}
\int_{\mathbb R\setminus I}
\frac{Q(v)}{u-v}\,dv=0,
\qquad \log2<u<\log3,
}
\tag{5}
\]
entonces se termina inmediatamente:
\[
Q=\mathcal HQ=0\quad\text{en }I
\Longrightarrow
\operatorname{bv}\mathcal D=0\quad\text{en }I
\Longrightarrow
\mathcal D\equiv0
\Longrightarrow\mathrm{RH}.
\]

Y aquí la v23 tiene una pieza que puede ser útil: para cualquier \(\mathsf f\) soportada dentro de ese hueco, el funcional de rung es una **serie absolutamente convergente únicamente en las ordenadas**
\[
\mathsf R_{\mathsf f}(0)
=
\mathsf k_{\mathsf f}
-\sum_{k\ge1}\mathsf c_{\mathsf f}(\gamma_k),
\tag{6}
\]
mientras que el transporte desde el reloj también es una función entera de \(\lambda\) y admite la expansión exacta en momentos. rvm_zeta_pi_mertens_v23_1

Eso permite reformular nuestro único objetivo como

\[
\boxed{
\mathsf k_{\mathsf f}
=
\sum_{k\ge1}
\int_{\log2}^{\log3}
\mathsf f(u)\cos(\gamma_k u)\,du
\quad
\forall\mathsf f\in C_c^\infty(I).
}
\tag{7}
\]

Ésta es solo la parte \(Q=0\). La parte de Hilbert correspondiente sería la identidad seno

\[
\boxed{
\mathsf k^{\,\mathrm{odd}}_{\mathsf f}
=
\sum_{k\ge1}
\int_I
\mathsf f(u)\sin(\gamma_k u)\,du ,
}
\tag{8}
\]
con el término explícito \(\mathsf k^{\rm odd}_{\mathsf f}\) obtenido del valor frontera unilateral de Cramér.

Si conseguimos (7) y (8) **para esta única banda**, no hay que estudiar ninguna otra celda.

Por tanto modificaría lo que dije antes: el proyecto correcto no es atomizar \(J_{Z1}^{\rm M}\) para todos los enteros. Es mucho más agresivo:

\[
\boxed{
\text{demostrar únicamente la identidad compleja de Cramér–ordenadas en }
(\log2,\log3).
}
\]

La v23 ya proporciona el lado coseno de la formulación exacta y la convergencia absoluta del funcional. rvm_zeta_pi_mertens_v23_1 La siguiente operación que haría es **derivar explícitamente el funcional seno unilateral análogo a (6), con todos los términos arquimedianos y las colas \(1/(u-\log n)\), y comprobar si en esta primera banda coseno+seno se cancelan por la ecuación funcional**. Ahí sí hay una posibilidad concreta de cierre que no exige recorrer todas las celdas.
---
## Copia literal adjunto 3 (ventana, Q y HQ)

Con la v23 se puede llevar el argumento bastante más lejos y aislar exactamente el punto de cierre. Pero el último “\(=0\)” no se deduce de Cramér + el hueco \((\log2,\log3)\); escribirlo sería precisamente asumir el paso A7/(D) de la v23. El cálculo exacto es éste.

Pon
\[
A(w):=\sum_{\gamma_k>0}e^{iw\gamma_k},
\qquad
B(w):=e^{-w/2}V_+(w),
\qquad
\mathcal D(w):=A(w)-B(w).
\]

Para \(x=e^u\), el Teorema 12.6 de la v23 da, para \(Z_1\),

\[
(\log x)\frac{dJ^{\rm M}_{Z1}}{dx}
=
1-\frac{2}{\sqrt x}\Re A(\log x)
-\frac1{x(x^2-1)}.
\tag{1}
\]

Por otro lado, la fórmula explícita clásica de \(\zeta\) da

\[
(\log x)\frac{dJ}{dx}
=
1-\frac{2}{\sqrt x}\Re B(\log x)
-\frac1{x(x^2-1)}.
\tag{2}
\]

Aquí (2) es completamente incondicional: \(B\) lleva los ceros completos, no se ha sustituido \(\beta\) por \(1/2\).

Ahora viene la ventaja especial del intervalo. Si

\[
2<x<3,
\]

no existe ninguna potencia prima, luego

\[
\frac{dJ}{dx}=0
\qquad(2<x<3).
\]

Restando (2) de (1),

\[
(\log x)\frac{dJ^{\rm M}_{Z1}}{dx}
=
-\frac2{\sqrt x}\Re\mathcal D(\log x).
\]

Es decir, con \(u=\log x\),

\[
\boxed{
\Re\operatorname{bv}\mathcal D(u)
=
-\frac12\,e^{u/2}u\,
\frac{dJ^{\rm M}_{Z1}}{dx}(e^u),
\qquad
\log2<u<\log3 .
}
\tag{3}
\]

Esto es importante: **Cramér elimina completamente el lado de \(\zeta\) en el hueco y deja exactamente el defecto continuo de \(Z_1\).**

Por tanto,

\[
\boxed{
\Re\operatorname{bv}\mathcal D=0
\text{ en }(\log2,\log3)
\iff
J^{\rm M}_{Z1}\text{ es constante en }(2,3).
}
\tag{4}
\]

Y aquí la v23 nos dice exactamente dónde estamos: la constancia de \(J^{\rm M}_{Z1}\) entre enteros es la condición de celda del Teorema 12.7. La v23 no demuestra siquiera automáticamente

\[
J^{\rm M}_{Z1}{}'=0\quad\text{en }(2,3);
\]

la distribución \(J^{\rm M}_{Z1}\) es la “medida prima generalizada” construida a partir de las ordenadas, y demostrar que pierde su parte continua es precisamente la atomización final.

Pero todavía queda una observación más fuerte. Aunque consiguiéramos (4), eso solo anula la **parte real** de \(\mathcal D\). El objetivo que tú has propuesto es

\[
\operatorname{bv}\mathcal D(u)=0
\qquad(\log2<u<\log3),
\tag{5}
\]

que contiene además la parte conjugada/Hilbert del defecto de todas las demás celdas.

De hecho, por ser \(\mathcal D\) holomorfa en \(\Im w>0\) y tener valor frontera distribucional, su parte imaginaria es, tras la regularización usual, la transformada de Hilbert de su parte real. Así, (3) permite escribir esquemáticamente

\[
\mathcal D_{\rm bv}
=
-\frac12
\left(
Q+i\,\mathcal H Q
\right),
\tag{6}
\]

donde

\[
Q(u)
=
e^{u/2}u
\left[
\frac{dJ^{\rm M}_{Z1}}{dx}
-
\frac{dJ}{dx}
\right]_{x=e^u}.
\tag{7}
\]

Sobre nuestro hueco \(dJ/dx=0\), pero la transformada de Hilbert es **no local**:

\[
(\mathcal H Q)(u)
=
\frac1\pi\operatorname{pv}
\int_{\mathbb R}\frac{Q(v)}{u-v}\,dv.
\tag{8}
\]

Éstos son exactamente los términos \(1/(u-\log n)\) que aparecían en Cramér. Que no haya un átomo en \(u\) elimina la delta local, pero no elimina las colas procedentes de todas las demás frecuencias.

Por eso

\[
dJ=0\text{ en }(2,3)
\]

no implica

\[
\mathcal D=0\text{ en }(\log2,\log3).
\]

Lo que sí obtenemos es un resultado bastante limpio:

\[
\boxed{
\begin{aligned}
\operatorname{bv}\mathcal D=0
\text{ en }(\log2,\log3)
&\iff \mathcal D\equiv0\quad(\Im w>0)\\
&\iff \zeta_{Z1}=\zeta\\
&\iff (D)\\
&\iff \mathrm{RH}.
\end{aligned}}
\tag{9}
\]

La primera implicación es unicidad de valores frontera holomorfos. La última también puede verse directamente poniendo \(w=iy\):

\[
\mathcal D(iy)
=
2\sum_{\beta>1/2}
\left(1-\cos(y\delta)\right)e^{-y\gamma}\ge0,
\]

y para \(0<y\le4\pi\) la igualdad obliga a \(\delta=0\).

Así que tu idea **sí comprime todo el paso final a un único hueco espectral**. Ésa es la mejora real:

\[
\boxed{
\text{A7 para todas las celdas}
\quad\Longleftrightarrow\quad
\operatorname{bv}\mathcal D=0
\text{ solo en }(\log2,\log3).
}
\]

Pero la igualdad no sale solo de que entre \(2\) y \(3\) no haya primos. La parte que habría que demostrar de verdad es

\[
\boxed{
Q=0\ \text{y}\ \mathcal H Q=0
\qquad\text{en }(\log2,\log3),
}
\tag{10}
\]

con \(Q\) dado por (7), **usando únicamente las ordenadas y la fórmula de Cramér**. Eso sería una prueba de RH sin haberla introducido.

La v23 confirma además que éste no es un paso ya disponible bajo otro nombre: su sección de problemas abiertos identifica precisamente \(\zeta_{Z1}=\zeta\), la atomización de \(J^{\rm M}_{Z1}\), como el endpoint todavía abierto.

:chatgpt-content-reference{index="0"}[Archivo v23 usado](sandbox:/mnt/data/rvm_zeta_pi_mertens_v23_1.tex)