# V21 changelog (12 October 2026)

Correction release. Every change answers one point of the five reviews of v20 collected in `review/v20_reviews/`
(R1 route B', R2 second pass, R3 rest of the paper, R4 models and numerics, R5 internal full review). Labels are
those of the TeX source; numbers and pages are those of the v21 PDF. Points of the reviews that were checked and
found not to apply are listed at the end.

## Errors repaired

| Source | Place | Change |
|---|---|---|
| R5-A1, R2-C, R3-5 | Appendix E, Proposition E.2 (p. 181) | The factor `e^{2bs}` of the v20 factorization has an argument `2bt` on `Re s = 2`, so the count is `N_kappa(T) - N_RVM(T) = 2bT/pi + O(log T)` (new `eq:rung-apriori-count-v18`) and the displacement is `kappa_k - tau_k = -4b kappa_k/log(kappa_k/2pi) + O(1)` (`eq:rung-apriori-bound-v18`), bounded iff `b = 0`. Statement rewritten accordingly; proof rewritten: strip bound by Phragmen-Lindelof on `Z_kappa/(s+2)` with the reflected line, Backlund-Jensen on the horizontal segment (`eq:rung-nT-v18`), vertical variation of the argument with the linear term, argument principle via Lemma 17.36 (`rb-argument`), `T < T_0` absorbed; Remark E.3 updated. |
| R5-A2 | Section 17.4, new Lemma 17.29 (`rb-upsilon-infinite`) and Remark 17.30 (`rb-count-scope`), p. 98; status table 17.8; intro table | For a finite section, `upsilon < infinity` iff all masses vanish: `E(T) = int |D| + O(log T)` with `D` the Dirichlet polynomial of the masses, and `int_{-T}^T |D| >> T` if `D != 0`. Theorem 17.37 and Corollary 17.38 are therefore stated as a template (they are void for sections with primes); the tables say so. |
| R5-A4 | Theorem 17.37, Corollary 17.38 (p. 101) | Additive constant `c_4 := 3/2 + c_6/pi + 1/T_0 + 2c_5/log(4/3)` defined; `+c_5` replaced by `+c_4`; the final insertion written out. |
| R5-A3 | Corollary 12.3 (`product-identity`, p. 43) | `lim Pi_tr(sigma) = L` is a fourth equivalent condition; unconditionally the limit is `varpi_Z1 L >= L`. |
| R3-1, R5-B1, R5-B2, R2-B | Abstract/intro "without any hypothesis"; Corollary 14.35 (`ladder-pair`); remark after Corollary 14.8 (`positivity`); list of uses after Hypothesis 8.5 (p. 30) | Conditioned on Hypothesis 8.5; the list now names five uses. |
| R2-A, R3-2 | Corollary 17.4 (`rb-D-implies-B`, p. 89) | `gamma_K, tau_{K+1}` -> `gamma_{k*}, tau_{k*+1}`; `k*_m, N_m` -> `k*_m, n*_m`. |
| R3-3, R5-E | Corollary 17.38 proof and Remark 17.39 (`rb-tube`) | `d` -> `q`. |
| R4-2 | Section 16, definition of the discrete side (p. 84) and proof of Theorem 16.1 | `F` is closed and locally finite (not uniformly discrete; the two-edge semigroup is not); the finiteness of the sum uses `F ∩ [0, 2k]` finite. |
| R3-10, R5 (dimension count) | After Theorem 16.3 (`finite-euler`, p. 86); conclusions; intro and status tables | For `prod_{p<=X}(1-p^{-s})` only part (i) extends; (ii) is false as stated for `pi(X) >= 3` (coefficient conditions `a_{X#/n} = -a_n` leave a space of dimension `>= 2`), and (iii) was proved through (ii); claims restricted to the primes 2, 3. |
| R3-8, R3-9, R3-23 | `eq:prime-det2` and the paragraph after `eq:three-abscissas` (p. 87-88) | `D_2 = det_2(I - X_P)` is the primary object on `Re s > 1/2`; `e^P/zeta` only on `Re s > 1`; "contraction proves no zeros in `sigma > 1`" now says contraction + trace-class determinant identity; `zeta e^{-P}` replaced by `D_2`. |

## Gaps closed

| Source | Place | Change |
|---|---|---|
| R5-C2, C3, C4 | New Lemma 13.6 (`L2-partial-sums`, p. 48); Theorem 13.7 proof; Proposition 13.8 proof; Theorem 13.11 proof | Mean-square convergence of the ordinate series on compact intervals (`eq:L2-partial-sums`), termwise integration against Lipschitz tests, continuity of `J_lambda`, `d/dlambda J_lambda` and `C_lambda` in `lambda`, `sup |C_lambda| < infinity`; the `V_lambda` bound on vertical lines replaces the wrong citation of Lemma 13.10. |
| R5-C1 | Theorem 12.1 proof (`Z1-clock`, p. 42); inherited by Proposition 13.2 | "Analytic continuation" of an `O`-estimate replaced by the exact formula `eq:smooth-exact` on `Re z > 0`, the bound on `[0, tau_0]`, uniform Stirling and the branch of `Log(z^2 - 1/4)`. |
| R5-C5 | Line after `eq:height-kernel` at `Omega = 0` (p. 73) | Pointwise `O(n^{1/4} log n)` justified through the `j = 1` kernel and `eq:J-prime-exact`/Theorem 14.15, not through `c_n(1)`. |
| R5-C6 | Theorem 12.5 proof (`mellin-counts`) | `sigma`-independence of `J^M_X` shown on test functions with `hat psi` in `C_c^infinity`. |
| R5-C7 | Theorem 13.13(i) proof | Substitution `y = x^{1/j}` written out. |
| R5-C8 | Theorem 12.6 proof (`distributional-EF`) | Trivial-zero sum kept as one tempered distribution; the split made only on `(1, infinity)`. |
| R5-C9 | Lemma 5.4 proof (`A-RVM`) | Second-derivative ratio `16` -> `256` on the whole summation interval; `eq:block-vdc` updated. |
| R5-C10 | Theorem 8.11 proof (`halfplane-RVM`) | Remark that the expansions only use `|arg z| < pi/2`. |
| R5-C11 | Lemma 17.26 (`rb-gonek-tube`) and Section 17.7.2 | Lemma stated for the list with rearranged prefix; the numerical list (`X = 8`, from `t ≈ 14`) declared outside the lemma (`t_8 ≈ 2 pi e^{16}`). |
| R4-1 | Proposition 15.3(i) proof (`lists-compact`, p. 80) | Tychonoff, metrizability, ordering and threshold closed, third condition as an intersection over `X`. |
| R4-3 | Theorem 16.1 proof | Paley-Wiener-Schwartz bound `|N(z)| <= C(1+|z|)^N e^{2k max(0, -Im z)}` written. |
| R4-4 | Theorem 16.3(ii) proof | Phragmen-Lindelof growth condition for finite order written (any finite width). |
| R4-8 | Theorem 14.11 proof (`real-axis`) | Positivity factor by factor; equality iff the product is empty. |
| R4-9 | Proposition 14.25 proof (`exceptional-set`) | Zeros discrete, hence finite in the compact `[0,1]`. |
| R4-10 | Proposition 14.38 (`continuous-phase`) | Branch continued along any path in the open quadrant; zeros and pole on its boundary. |
| R4-14, R5 | Proposition 14.43 proof (`clock-defect-poisson`) | Even extension has a corner at `0`; boundary term `-g'(0+)/(2 pi m)^2` written; `O(m^{-2})` not improvable. |
| R1-1, R1-2 | Lemma 17.11 (`rb-laplace`) | Local order vs. support; Laplace transform convention `L(delta_0')(s) = z` written. |
| R1-3 | Proposition 17.13 proof | `Q(1-s) - Q(s) in 2 pi i Z`, continuous hence constant. |
| R1-4 | Corollary 17.15 proof | Product metric `d(kappa, kappa') = sum 2^{-k} min(1, |kappa_k - kappa'_k|)` and the compact-metric argument for convergence of the whole sequence. |
| R1-5 | Theorem 17.20 proof | Uniqueness only of `y_*` in the ball, i.e. of `x_*` in `Ran Q_m`. |
| R1-7 | Condition (B) | Series and supremum both written. |
| R3-6 | Proposition 15.3 (via Lemma 13.6 and Theorem 15.1) | Uniform `L^2` dominant made explicit through the uniform bound `|log zeta_kappa(sigma+it)| <= C_sigma(1+log(2+|t|))` and the new lemma. |
| R3-7 | Theorem 15.1 (`transfer-O`, p. 79) | Constants `C = C(tau_0^+, C_eta, C; sigma, eps, ...)` stated explicitly. |

## Values, wording, symbols

| Source | Place | Change |
|---|---|---|
| R5-D1 | Remark 17.27 (`rb-gonek-status`) | `m_3 = 1.81` by hand; the printed `1.42, 3.02, 5.98` are the observed suprema of `|p_X|`; `m_X ≍ sqrt(X)/log^2 X`, `n_X ≍ sqrt(X)`. |
| R5-D2 | Theorem 5.5 proof (`Lambert-estimate`) | `(log_2 x)^2`, `O(x^{1/3} log x)`. |
| R5-D3, R1-9 | Lemma 17.10 (`rb-archimedean`) | `g(u) = -1/(2u) + O(e^{-5u/2})`; constants checked and correct. |
| R5-D4 | Proposition 17.52 proof | `+1` -> `+2`. |
| R5-D5 | Lemma 17.3 | `0.361500`. |
| R5-E1 | Proposition 14.31 (`dichotomy`) | Hypothesis `g != 0` added. |
| R5-E2 | After Theorem 14.36 (`bridge`) | Relation to Theorem 14.3 reworded. |
| R5-E3 | Hypothesis 6.7, Proposition 6.8, Corollary 14.16 | Hypothesis marked as proved by Corollary 14.16; "Conditional" removed. |
| R5-E4 | Lemma 8.4 proof | `U^±` -> `H^±`. |
| R5-E5 | Proposition 13.17 proof | `A_end` -> `A`. |
| R5-E6 | Lemma 8.6 | `t_0 = t_0(1/4)`. |
| R5-E9 | Notation section; Section 16 | Local symbols listed; prime diagonal operator renamed `X_P`. |
| R5-E10 | Four integrals | `int_{0^+}^1` -> `int_0^1`. |
| R5-E11 | Theorem 14.42 | Redundant "if" removed. |
| R5-E12 | Section 17.7.6(i) | Marked heuristic. |
| R5-E13 | Corollary 6.5 | Pole at `s = 1` inherited. |
| R4-5, R4-6 | Section 18, Mertens experiment | "two pieces of data"; "empirical normalized correlation 0.0007 on this range". |
| R1-11, R4-11, R4-12 | `eq:sigma-two`; `tools/make_tips.py` | `\frac{\pi}{3}` with braces; generator fixed for `\tag` labels (page and tag now shown) and for `\frac` with unbraced or nested arguments (`pi/3`, `P/G` now correct); tooltips regenerated (897). |

## Review points checked and not applied

* R4-7 (multiplicities at `lambda = 0`): Theorem 10.1 already distinguishes `lambda > 0` (strictly increasing) from `lambda = 0` (multiplicities).
* R4-13 (resonance `u Delta_k ≈ 2 pi r` in the exponential-sum theorem): the proof already separates `k >= k_0(u_2)`, where `0 < Delta_k <= pi`, from the finite initial block.
* R4-16 (two numerical phrases "converges at every stage", "requires Omega of order pi N"): not found in the source.
* R4-15 (ordered vs. absolutely convergent products): every appearance already says "ordered product"; no change.
* R1-10 (`Lambda(n)/(2n)`): not in the source; artefact of the reviewer's summary.
* R5-E7, R5-E8 (symbols in Heuristic 17.25 and Lemma 17.31(b)): left as they are, being inside a heuristic and a lemma whose proof is correct; listed for a later pass.

Build: pdflatex x2, `tools/make_tips.py` + `tools/replace_tips.py`, pdflatex x3; 185 pages, 0 overfull boxes, 0 undefined references. Code, outputs and figures unchanged from v19.
