import math,csv
import numpy as np
from scipy.optimize import least_squares
TAU=np.fromfile('/mnt/data/zLamb(2).bin',dtype='<f8')[:12000]
GAM=np.fromfile('/mnt/data/zeross(3).bin',dtype='<f8')
N=16; Om=58.6; DOM=.2; NU=4001; MARGIN=14.; KT=len(TAU)
U=math.log(N+.5); grid=np.linspace(0,U,NU); u=grid[1:-1]; du=U/(NU-1)
v=(u-U/2)/(U/2); w=np.exp(-1/(1-v*v)); w/=w.sum()*du
smooth=.5*(np.exp(u/2)-np.exp(-u/2)/(np.exp(2*u)-1))
ns=np.arange(2,N+1,dtype=int)
omega=np.arange(0,Om+1e-12,DOM)
Psi=np.vstack([w*np.cos(o*u) for o in omega]+[w*np.sin(o*u) for o in omega[1:]])*du
Wj=Psi@smooth
Pn=np.vstack([np.interp(np.log(ns),u,Psi[j]/du) for j in range(Psi.shape[0])])
Uq,sing,Vh=np.linalg.svd(Pn,full_matrices=False); inv=np.where(sing>sing[0]*1e-13,1/sing,0); Q=(Vh.T*inv)@Uq.T; Proj=Pn@Q
clock=np.zeros_like(u)
for a in range(0,KT,400): clock += np.cos(np.outer(u,TAU[a:a+400])).sum(axis=1)
K=int((TAU<=Om+MARGIN).sum()); tail=clock-np.cos(np.outer(u,TAU[:K])).sum(axis=1); fixed=Psi@tail-Wj

def res(x):
 r=Psi@np.cos(np.outer(u,x)).sum(axis=1)+fixed; return r-Proj@r

def jac(x):
 J=Psi@(-u[:,None]*np.sin(np.outer(u,x))); return J-Proj@J

rng=np.random.default_rng(42)
starts=[('clock',TAU[:K]),('mid',.5*(TAU[:K]+GAM[:K])),('zeta',GAM[:K])]
for j in range(10): starts.append((f'random{j}',TAU[:K]+rng.normal(0,.8,K)))
rows=[]
for name,x0 in starts:
 sol=least_squares(res,x0,jac=jac,method='lm',max_nfev=1200,ftol=1e-13,xtol=1e-13,gtol=1e-13)
 nr=np.linalg.norm(sol.fun)/math.sqrt(Psi.shape[0]); err=np.sqrt(np.mean((sol.x[:10]-GAM[:10])**2)); shift=np.max(np.abs(sol.x-TAU[:K]))
 print(name, 'NRMS',nr,'rms10',err,'shift',shift,'nfev',sol.nfev)
 rows.append([name,nr,err,shift,sol.nfev])
with open('/mnt/data/N16_start_diagnostic.csv','w',newline='') as f:
 csv.writer(f).writerows([['start','nrms','rms10_gamma_diagnostic','max_abs_shift','nfev']]+rows)
