import os, math, csv, time
import numpy as np
from scipy.optimize import least_squares

ZLAMB='/mnt/data/zLamb(2).bin'
ZEROS='/mnt/data/zeross(3).bin'
tau=np.fromfile(ZLAMB,dtype='<f8')
gam=np.fromfile(ZEROS,dtype='<f8')
KT=12000
TAU=tau[:KT]
DOM=0.15
NU=5001
MARGIN=14.0
RIDGE=1e-11
WMIN=0.015
stages=[(5,20.0),(8,30.0),(13,50.0),(20,70.0),(27,90.0),(34,110.0)]

prev=None
rows=[]
ordrows=[]

for N,Omega in stages:
    U=math.log(N+0.5)
    grid=np.linspace(0,U,NU)
    u=grid[1:-1]; du=U/(NU-1)
    v=(u-U/2)/(U/2)
    w=np.exp(-1/(1-v*v)); w/=w.sum()*du
    smooth=.5*(np.exp(u/2)-np.exp(-u/2)/(np.exp(2*u)-1))
    ns=np.array([n for n in range(2,N+1) if np.interp(math.log(n),u,w)/w.max()>=WMIN],dtype=int)
    omega=np.arange(0,Omega+1e-12,DOM)
    Psi=np.vstack([w*np.cos(o*u) for o in omega]+[w*np.sin(o*u) for o in omega[1:]])*du
    smooth_j=Psi@smooth
    Pn=np.vstack([np.interp(np.log(ns),u,Psi[j]/du) for j in range(Psi.shape[0])]) if len(ns) else np.zeros((Psi.shape[0],0))
    if len(ns):
        Uq,sing,Vh=np.linalg.svd(Pn,full_matrices=False)
        inv=np.where(sing>sing[0]*1e-12,1/sing,0)
        Q=(Vh.T*inv)@Uq.T
        Proj=Pn@Q
        rank=int(np.sum(sing>sing[0]*1e-12))
        cond=sing[0]/sing[rank-1] if rank else np.inf
    else:
        Proj=np.zeros((Psi.shape[0],Psi.shape[0])); Q=np.zeros((0,Psi.shape[0])); rank=0; cond=np.nan
    clock=np.zeros_like(u)
    for a in range(0,KT,400):
        clock += np.cos(np.outer(u,TAU[a:a+400])).sum(axis=1)
    K=int((TAU<=Omega+MARGIN).sum())
    low_clock=np.cos(np.outer(u,TAU[:K])).sum(axis=1)
    fixed=Psi@(clock-low_clock)-smooth_j
    def raw(x): return Psi@np.cos(np.outer(u,x)).sum(axis=1)+fixed
    def res(x):
        r=raw(x)
        return r-Proj@r
    def jac(x):
        J=Psi@(-u[:,None]*np.sin(np.outer(u,x)))
        return J-Proj@J
    if prev is None:
        x0=TAU[:K].copy()
    else:
        x0=TAU[:K].copy()
        m=min(len(prev),K)
        x0[:m]=prev[:m]
    n0=np.linalg.norm(res(x0)); t0=time.time()
    sol=least_squares(res,x0,jac=jac,method='lm',max_nfev=1200,ftol=1e-12,xtol=1e-12,gtol=1e-12)
    elapsed=time.time()-t0
    prev=sol.x.copy()
    rf=np.linalg.norm(sol.fun); nr=rf/math.sqrt(Psi.shape[0])
    rr=raw(sol.x); masses=-(Q@rr) if len(ns) else np.array([])
    maxshift=float(np.max(np.abs(sol.x-TAU[:K])))
    zerr=np.abs(sol.x-gam[:K]); low=min(10,K)
    rms10=float(np.sqrt(np.mean(zerr[:low]**2)))
    max10=float(np.max(zerr[:low]))
    # stability compared with prior stage not directly available after overwrite; tracked via errors to genuine only diagnostic
    rows.append([N,U,Omega,K,len(ns),Psi.shape[0],rank,cond,n0,rf,nr,sol.nfev,maxshift,rms10,max10,elapsed])
    for k in range(K):
        ordrows.append([N,k+1,TAU[k],sol.x[k],gam[k],sol.x[k]-gam[k],sol.x[k]-TAU[k]])
    print(f'N={N:2d} U={U:.3f} Om={Omega:5.1f} K={K:2d} masses={len(ns):2d} rank={rank:2d} tests={Psi.shape[0]:4d} NRMS={nr:.4e} maxshift={maxshift:.3f} rms10={rms10:.3e} nfev={sol.nfev} time={elapsed:.1f}s')

out='/mnt/data/rung_growth_test.csv'
with open(out,'w',newline='') as f:
    wr=csv.writer(f); wr.writerow(['N','U','Omega','K','num_masses','num_tests','mass_rank','mass_cond','initial_norm','final_norm','normalized_rms','nfev','max_abs_shift','rms_error_first10','max_error_first10','seconds']); wr.writerows(rows)
with open('/mnt/data/rung_growth_ordinates.csv','w',newline='') as f:
    wr=csv.writer(f); wr.writerow(['N','k','tau','solved','gamma_diagnostic','solved_minus_gamma','solved_minus_tau']); wr.writerows(ordrows)
