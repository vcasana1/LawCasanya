import math,csv,time
import numpy as np
TAU=np.fromfile('/mnt/data/zLamb(2).bin',dtype='<f8')[:16000]
GAM=np.fromfile('/mnt/data/zeross(3).bin',dtype='<f8')
KT=len(TAU); DOM=.2; NU=3001; MARGIN=14.; WMIN=.015; STEP=.15; ITER=420; RIDGE=1e-10
# First establish the N=13 branch by height continuation, then move diagonally.
stages=[(13,18),(13,26),(13,34),(13,42),(13,50)] + [(n,50+(70-50)*(n-13)/7) for n in range(14,21)]
rows=[]; ordrows=[]; prev=None

def setup(N,Om):
    U=math.log(N+.5); ug=np.linspace(0,U,NU); u=ug[1:-1]; du=U/(NU-1)
    v=(u-U/2)/(U/2); w=np.exp(-1/(1-v*v)); w/=w.sum()*du
    smooth=.5*(np.exp(u/2)-np.exp(-u/2)/(np.exp(2*u)-1))
    ns=np.array([n for n in range(2,N+1) if np.interp(math.log(n),u,w)/w.max()>=WMIN],dtype=int)
    om=np.arange(0,Om+1e-12,DOM)
    Psi=np.vstack([w*np.cos(o*u) for o in om]+[w*np.sin(o*u) for o in om[1:]])*du
    Wj=Psi@smooth
    Pn=np.vstack([np.interp(np.log(ns),u,Psi[j]/du) for j in range(Psi.shape[0])])
    Q=np.linalg.solve(Pn.T@Pn+RIDGE*np.eye(len(ns)),Pn.T)
    clock=np.zeros_like(u)
    for a in range(0,KT,400): clock+=np.cos(np.outer(u,TAU[a:a+400])).sum(axis=1)
    K=int((TAU<=Om+MARGIN).sum())
    tail=clock-np.cos(np.outer(u,TAU[:K])).sum(axis=1)
    fixed=Psi@tail-Wj
    def res(x):
        raw=Psi@np.cos(np.outer(u,x)).sum(axis=1)+fixed
        m=-Q@raw
        return raw+Pn@m,m
    def jac(x):
        J=Psi@(-u[:,None]*np.sin(np.outer(u,x)))
        return J-Pn@(Q@J)
    return U,ns,Psi,K,res,jac

def optimize(x,res,jac):
    r,m=res(x); n0=np.linalg.norm(r); best=(n0,x.copy(),m.copy()); damp=1e-3
    for it in range(1,ITER+1):
        J=jac(x); A=J.T@J; b=-J.T@r; diag=np.diag(A)+1e-14
        accepted=False
        for _ in range(40):
            try:d=np.linalg.solve(A+damp*np.diag(diag),b)
            except np.linalg.LinAlgError:damp*=10;continue
            md=np.max(np.abs(d));
            if md>STEP:d*=STEP/md
            r2,m2=res(x+d)
            if np.linalg.norm(r2)<np.linalg.norm(r): accepted=True; break
            damp*=4
        if not accepted: break
        x=x+d; r,m=r2,m2; nr=np.linalg.norm(r)
        if nr<best[0]:best=(nr,x.copy(),m.copy())
        damp=max(damp/3,1e-14)
        if np.max(np.abs(d))<1e-11:break
    return n0,best,it

for si,(N,Om) in enumerate(stages):
    U,ns,Psi,K,res,jac=setup(N,Om)
    x=TAU[:K].copy()
    if prev is not None:
        m=min(len(prev),K); x[:m]=prev[:m]
    t=time.time(); n0,best,it=optimize(x,res,jac); sec=time.time()-t
    rf,prev,mass=best; nr=rf/math.sqrt(Psi.shape[0]); err=np.abs(prev-GAM[:K]); low=min(10,K)
    rms10=float(np.sqrt(np.mean(err[:low]**2))); max10=float(np.max(err[:low])); maxshift=float(np.max(np.abs(prev-TAU[:K])))
    rows.append([si,N,U,Om,K,len(ns),Psi.shape[0],n0,rf,nr,it,maxshift,rms10,max10,sec])
    print(f'stage={si:2d} N={N:2d} Om={Om:5.1f} K={K:2d} masses={len(ns):2d} NRMS={nr:.3e} maxshift={maxshift:.3f} rms10={rms10:.3e} it={it}')

for k in range(len(prev)): ordrows.append([k+1,TAU[k],prev[k],GAM[k],prev[k]-GAM[k],prev[k]-TAU[k]])
with open('/mnt/data/diagonal_rung_height.csv','w',newline='') as f:
    w=csv.writer(f); w.writerow(['stage','N','U','Omega','K','num_masses','num_tests','initial_norm','final_norm','normalized_rms','iterations','max_abs_shift','rms_error_first10','max_error_first10','seconds']); w.writerows(rows)
with open('/mnt/data/diagonal_rung_height_ordinates.csv','w',newline='') as f:
    w=csv.writer(f); w.writerow(['k','tau','solved','gamma_diagnostic','solved_minus_gamma','solved_minus_tau']); w.writerows(ordrows)
