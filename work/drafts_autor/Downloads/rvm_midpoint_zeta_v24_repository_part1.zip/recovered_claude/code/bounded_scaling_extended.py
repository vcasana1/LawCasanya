import math,csv,time
import numpy as np
from scipy.optimize import least_squares

TAU=np.fromfile('/mnt/data/zLamb(2).bin',dtype='<f8')[:14000]
GAM=np.fromfile('/mnt/data/zeross(3).bin',dtype='<f8')
KT=len(TAU); DOM=.25; NU=2201; MARGIN=14.; B=1.2
cases=[(13,50.0),(16,58.6),(20,70.0),(27,90.0),(34,110.0),(50,150.0),(70,210.0),(100,300.0)]
rows=[]; ordrows=[]; massrows=[]
for N,Om in cases:
    tstart=time.time(); U=math.log(N+.5); grid=np.linspace(0,U,NU); u=grid[1:-1]; du=U/(NU-1)
    v=(u-U/2)/(U/2); w=np.exp(-1/(1-v*v)); w/=w.sum()*du
    smooth=.5*(np.exp(u/2)-np.exp(-u/2)/(np.exp(2*u)-1))
    ns=np.arange(2,N+1,dtype=int)
    omega=np.arange(0,Om+1e-12,DOM)
    Psi=np.vstack([w*np.cos(o*u) for o in omega]+[w*np.sin(o*u) for o in omega[1:]])*du
    Wj=Psi@smooth
    Pn=np.vstack([np.interp(np.log(ns),u,Psi[j]/du) for j in range(Psi.shape[0])])
    Uq,sing,Vh=np.linalg.svd(Pn,full_matrices=False); inv=np.where(sing>sing[0]*1e-12,1/sing,0); Q=(Vh.T*inv)@Uq.T; Proj=Pn@Q
    clock=np.zeros_like(u)
    for a in range(0,KT,400): clock += np.cos(np.outer(u,TAU[a:a+400])).sum(axis=1)
    K=int((TAU<=Om+MARGIN).sum()); tail=clock-np.cos(np.outer(u,TAU[:K])).sum(axis=1); fixed=Psi@tail-Wj
    def raw(x): return Psi@np.cos(np.outer(u,x)).sum(axis=1)+fixed
    def res(x):
        r=raw(x); return r-Proj@r
    def jac(x):
        J=Psi@(-u[:,None]*np.sin(np.outer(u,x))); return J-Proj@J
    sol=least_squares(res,TAU[:K].copy(),jac=jac,method='trf',bounds=(TAU[:K]-B,TAU[:K]+B),max_nfev=2500,ftol=1e-12,xtol=1e-12,gtol=1e-12,x_scale='jac')
    rr=raw(sol.x); masses=-(Q@rr)
    nr=np.linalg.norm(sol.fun)/math.sqrt(Psi.shape[0]); e=sol.x-GAM[:K]; rms10=np.sqrt(np.mean(e[:min(10,K)]**2)); rmsall=np.sqrt(np.mean(e**2)); maxall=np.max(np.abs(e)); mx=np.max(np.abs(sol.x-TAU[:K])); active=np.sum((np.abs(sol.x-(TAU[:K]-B))<1e-5)|(np.abs(sol.x-(TAU[:K]+B))<1e-5)); sec=time.time()-tstart
    mass_energy=float(np.sum(masses*masses)); mass_max=float(np.max(np.abs(masses)))
    rows.append([N,U,Om,K,len(ns),Psi.shape[0],nr,rms10,rmsall,maxall,mx,active,sol.nfev,sec,mass_energy,mass_max])
    for k in range(K): ordrows.append([N,Om,k+1,TAU[k],sol.x[k],GAM[k],sol.x[k]-GAM[k],sol.x[k]-TAU[k]])
    # diagnostic von Mangoldt masses
    for n,a in zip(ns,masses):
        # compute Lambda(n)
        lam=0.0
        m=n
        # prime power detection
        for p in range(2,int(math.sqrt(n))+2):
            if n%p==0:
                q=n; exp=0
                while q%p==0:
                    q//=p; exp+=1
                if q==1:
                    # p must be prime
                    isprime=all(p%d for d in range(2,int(math.sqrt(p))+1))
                    if isprime: lam=math.log(p)
                break
        else:
            if n>=2: lam=math.log(n) # n prime
        expected=lam/(2*math.sqrt(n))
        massrows.append([N,n,a,expected,a-expected])
    print(f'N={N:3d} K={K:3d} NRMS={nr:.3e} rms10={rms10:.3e} massE={mass_energy:.3e} massMax={mass_max:.3e} maxshift={mx:.3f} active={active} nfev={sol.nfev} sec={sec:.1f}', flush=True)

with open('/mnt/data/bounded_scaling_extended.csv','w',newline='') as f:
    csv.writer(f).writerows([['N','U','Omega','K','num_masses','num_tests','nrms','rms10_gamma_diagnostic','rmsall_gamma_diagnostic','maxerr_gamma_diagnostic','max_abs_shift','active_bounds','nfev','seconds','mass_energy','mass_max']]+rows)
with open('/mnt/data/bounded_scaling_extended_ordinates.csv','w',newline='') as f:
    csv.writer(f).writerows([['N','Omega','k','tau','solved','gamma_diagnostic','solved_minus_gamma','solved_minus_tau']]+ordrows)
with open('/mnt/data/bounded_scaling_extended_masses.csv','w',newline='') as f:
    csv.writer(f).writerows([['N','n','solved_mass','von_mangoldt_diagnostic','difference']]+massrows)
