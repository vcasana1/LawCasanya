import math,csv,time
import numpy as np
from scipy.optimize import least_squares
TAU=np.fromfile('/mnt/data/zLamb(2).bin',dtype='<f8')[:14000]
GAM=np.fromfile('/mnt/data/zeross(3).bin',dtype='<f8')
KT=len(TAU); DOM=.25; NU=2201; MARGIN=14.; B=1.2; M=0.5
cases=[(13,50.0),(20,70.0),(34,110.0),(50,150.0)]
prev_x=None; prev_m=None; prev_ns=None
rows=[]; ordrows=[]; massrows=[]
for N,Om in cases:
    U=math.log(N+.5); grid=np.linspace(0,U,NU); u=grid[1:-1]; du=U/(NU-1)
    v=(u-U/2)/(U/2); w=np.exp(-1/(1-v*v)); w/=w.sum()*du
    smooth=.5*(np.exp(u/2)-np.exp(-u/2)/(np.exp(2*u)-1))
    ns=np.arange(2,N+1,dtype=int); omega=np.arange(0,Om+1e-12,DOM)
    Psi=np.vstack([w*np.cos(o*u) for o in omega]+[w*np.sin(o*u) for o in omega[1:]])*du
    Wj=Psi@smooth
    Pn=np.vstack([np.interp(np.log(ns),u,Psi[j]/du) for j in range(Psi.shape[0])])
    clock=np.zeros_like(u)
    for a in range(0,KT,400): clock += np.cos(np.outer(u,TAU[a:a+400])).sum(axis=1)
    K=int((TAU<=Om+MARGIN).sum()); tail=clock-np.cos(np.outer(u,TAU[:K])).sum(axis=1); fixed=Psi@tail-Wj
    def fun(z):
        x=z[:K]; masses=z[K:]
        return Psi@np.cos(np.outer(u,x)).sum(axis=1)+fixed+Pn@masses
    def jac(z):
        x=z[:K]; Jk=Psi@(-u[:,None]*np.sin(np.outer(u,x)))
        return np.hstack([Jk,Pn])
    x0=TAU[:K].copy(); m0=np.zeros(len(ns))
    if prev_x is not None:
        q=min(K,len(prev_x)); x0[:q]=prev_x[:q]
        qn=min(len(m0),len(prev_m)); m0[:qn]=prev_m[:qn]
    z0=np.r_[x0,m0]
    lo=np.r_[TAU[:K]-B,-M*np.ones(len(ns))]; hi=np.r_[TAU[:K]+B,M*np.ones(len(ns))]
    z0=np.minimum(np.maximum(z0,lo+1e-10),hi-1e-10)
    t=time.time(); sol=least_squares(fun,z0,jac=jac,method='trf',bounds=(lo,hi),max_nfev=1800,ftol=1e-12,xtol=1e-12,gtol=1e-12,x_scale='jac')
    x=sol.x[:K]; masses=sol.x[K:]; prev_x=x.copy(); prev_m=masses.copy(); prev_ns=ns.copy()
    nr=np.linalg.norm(sol.fun)/math.sqrt(Psi.shape[0]); rms10=np.sqrt(np.mean((x[:10]-GAM[:10])**2)); dr=np.nan
    rows.append([N,Om,K,nr,rms10,np.sum(masses*masses),np.max(np.abs(masses)),np.max(np.abs(x-TAU[:K])),sol.nfev,time.time()-t])
    for k in range(K): ordrows.append([N,k+1,TAU[k],x[k],GAM[k],x[k]-GAM[k],x[k]-TAU[k]])
    for n,a in zip(ns,masses): massrows.append([N,n,a])
    print(f'N={N:2d} K={K:2d} nrms={nr:.3e} rms10={rms10:.3e} massE={np.sum(masses*masses):.3e} maxM={np.max(np.abs(masses)):.3f} maxshift={np.max(np.abs(x-TAU[:K])):.3f} nfev={sol.nfev}',flush=True)
with open('/mnt/data/bounded_mass_continuation_summary.csv','w',newline='') as f: csv.writer(f).writerows([['N','Omega','K','nrms','rms10_gamma_diagnostic','mass_energy','mass_max','max_abs_shift','nfev','seconds']]+rows)
with open('/mnt/data/bounded_mass_continuation_ordinates.csv','w',newline='') as f: csv.writer(f).writerows([['N','k','tau','solved','gamma_diagnostic','solved_minus_gamma','solved_minus_tau']]+ordrows)
with open('/mnt/data/bounded_mass_continuation_masses.csv','w',newline='') as f: csv.writer(f).writerows([['N','n','solved_mass']]+massrows)
