import math,csv,time
import numpy as np
from scipy.optimize import least_squares
TAU=np.fromfile('/mnt/data/zLamb(2).bin',dtype='<f8')[:14000]
GAM=np.fromfile('/mnt/data/zeross(3).bin',dtype='<f8')
KT=len(TAU); DOM=.25; NU=2201; MARGIN=14.; B=1.2
cases=[(13,50.0),(16,58.6),(20,70.0),(27,90.0),(34,110.0)]
rows=[]
ords=[]
for N,Om in cases:
 tstart=time.time(); U=math.log(N+.5); grid=np.linspace(0,U,NU); u=grid[1:-1]; du=U/(NU-1)
 v=(u-U/2)/(U/2); w=np.exp(-1/(1-v*v)); w/=w.sum()*du
 smooth=.5*(np.exp(u/2)-np.exp(-u/2)/(np.exp(2*u)-1))
 ns=np.arange(2,N+1,dtype=int)
 omega=np.arange(0,Om+1e-12,DOM)
 Psi=np.vstack([w*np.cos(o*u) for o in omega]+[w*np.sin(o*u) for o in omega[1:]])*du
 Wj=Psi@smooth
 Pn=np.vstack([np.interp(np.log(ns),u,Psi[j]/du) for j in range(Psi.shape[0])])
 Uq,sing,Vh=np.linalg.svd(Pn,full_matrices=False); inv=np.where(sing>sing[0]*1e-12,1/sing,0); Q=(Vh.T*inv)@Uq.T; Proj=Pn@Q
 clock=np.zeros_like(u)
 for a in range(0,KT,400): clock += np.cos(np.outer(u,TAU[a:a+400])).sum(axis=1)
 K=int((TAU<=Om+MARGIN).sum()); tail=clock-np.cos(np.outer(u,TAU[:K])).sum(axis=1); fixed=Psi@tail-Wj
 def res(x):
  r=Psi@np.cos(np.outer(u,x)).sum(axis=1)+fixed; return r-Proj@r
 def jac(x):
  J=Psi@(-u[:,None]*np.sin(np.outer(u,x))); return J-Proj@J
 sol=least_squares(res,TAU[:K].copy(),jac=jac,method='trf',bounds=(TAU[:K]-B,TAU[:K]+B),max_nfev=1400,ftol=1e-12,xtol=1e-12,gtol=1e-12,x_scale='jac')
 nr=np.linalg.norm(sol.fun)/math.sqrt(Psi.shape[0]); e=sol.x-GAM[:K]; rms10=np.sqrt(np.mean(e[:min(10,K)]**2)); rmsall=np.sqrt(np.mean(e**2)); maxall=np.max(np.abs(e)); mx=np.max(np.abs(sol.x-TAU[:K])); active=np.sum((np.abs(sol.x-(TAU[:K]-B))<1e-5)|(np.abs(sol.x-(TAU[:K]+B))<1e-5)); sec=time.time()-tstart
 rows.append([N,U,Om,K,len(ns),Psi.shape[0],nr,rms10,rmsall,maxall,mx,active,sol.nfev,sec])
 for kk in range(K): ords.append([N,Om,kk+1,TAU[kk],sol.x[kk],GAM[kk],sol.x[kk]-GAM[kk],sol.x[kk]-TAU[kk]])
 print(f'N={N:2d} K={K:2d} NRMS={nr:.3e} rms10={rms10:.3e} rmsall={rmsall:.3e} maxerr={maxall:.3e} maxshift={mx:.3f} active={active} nfev={sol.nfev} sec={sec:.1f}')
with open('/mnt/data/bounded_scaling_uniform.csv','w',newline='') as f:
 csv.writer(f).writerows([['N','U','Omega','K','num_masses','num_tests','nrms','rms10_gamma_diagnostic','rmsall_gamma_diagnostic','maxerr_gamma_diagnostic','max_abs_shift','active_bounds','nfev','seconds']]+rows)
with open('/mnt/data/bounded_scaling_uniform_ordinates.csv','w',newline='') as f:
 csv.writer(f).writerows([['N','Omega','k','tau','solved','gamma_diagnostic','solved_minus_gamma','solved_minus_tau']]+ords)
