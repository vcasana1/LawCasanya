import math,csv
import numpy as np
from scipy.optimize import least_squares
TAU=np.fromfile('/mnt/data/zLamb(2).bin',dtype='<f8')[:14000]
GAM=np.fromfile('/mnt/data/zeross(3).bin',dtype='<f8')
KT=len(TAU); DOM=.25; NU=2201; MARGIN=14.
rows=[]
for N,Om in [(100,300.0)]:
 U=math.log(N+.5); grid=np.linspace(0,U,NU); u=grid[1:-1]; du=U/(NU-1)
 v=(u-U/2)/(U/2); w=np.exp(-1/(1-v*v)); w/=w.sum()*du
 smooth=.5*(np.exp(u/2)-np.exp(-u/2)/(np.exp(2*u)-1))
 # all masses n=2..N; SVD projection to eliminate them
 ns=np.arange(2,N+1,dtype=int)
 omega=np.arange(0,Om+1e-12,DOM)
 Psi=np.vstack([w*np.cos(o*u) for o in omega]+[w*np.sin(o*u) for o in omega[1:]])*du
 Wj=Psi@smooth
 Pn=np.vstack([np.interp(np.log(ns),u,Psi[j]/du) for j in range(Psi.shape[0])])
 Uq,sing,Vh=np.linalg.svd(Pn,full_matrices=False); inv=np.where(sing>sing[0]*1e-12,1/sing,0); Q=(Vh.T*inv)@Uq.T; Proj=Pn@Q
 clock=np.zeros_like(u)
 for a in range(0,KT,400): clock += np.cos(np.outer(u,TAU[a:a+400])).sum(axis=1)
 K=int((TAU<=Om+MARGIN).sum()); tail=clock-np.cos(np.outer(u,TAU[:K])).sum(axis=1); fixed=Psi@tail-Wj
 def res(x):
  r=Psi@np.cos(np.outer(u,x)).sum(axis=1)+fixed; return r-Proj@r
 def jac(x):
  J=Psi@(-u[:,None]*np.sin(np.outer(u,x))); return J-Proj@J
 for B in [1.2]:
  lo=TAU[:K]-B; hi=TAU[:K]+B
  sol=least_squares(res,TAU[:K].copy(),jac=jac,method='trf',bounds=(lo,hi),max_nfev=2500,ftol=1e-12,xtol=1e-12,gtol=1e-12,x_scale='jac')
  nr=np.linalg.norm(sol.fun)/math.sqrt(Psi.shape[0]); rms10=np.sqrt(np.mean((sol.x[:min(10,K)]-GAM[:min(10,K)])**2)); mx=np.max(np.abs(sol.x-TAU[:K])); active=np.sum((np.abs(sol.x-lo)<1e-5)|(np.abs(sol.x-hi)<1e-5))
  print(f'N={N:2d} B={B:.1f} K={K:2d} NRMS={nr:.3e} rms10={rms10:.3e} maxshift={mx:.3f} active={active} nfev={sol.nfev}')
  rows.append([N,Om,K,B,nr,rms10,mx,active,sol.nfev])
with open('/mnt/data/bounded_branch_test.csv','w',newline='') as f:
 csv.writer(f).writerows([['N','Omega','K','bound','nrms','rms10_gamma_diagnostic','max_abs_shift','active_bounds','nfev']]+rows)
