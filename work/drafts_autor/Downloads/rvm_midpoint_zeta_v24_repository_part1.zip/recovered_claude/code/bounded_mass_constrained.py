import math,time,csv
import numpy as np
from scipy.optimize import least_squares
TAU=np.fromfile('/mnt/data/zLamb(2).bin',dtype='<f8')[:14000]
GAM=np.fromfile('/mnt/data/zeross(3).bin',dtype='<f8')
KT=len(TAU); DOM=.25; NU=2201; MARGIN=14.; B=1.2
cases=[(13,50.0),(20,70.0),(34,110.0),(50,150.0)]
Mbounds=[0.5,1.0,2.0]
rows=[]
for N,Om in cases:
  U=math.log(N+.5); grid=np.linspace(0,U,NU); u=grid[1:-1]; du=U/(NU-1)
  v=(u-U/2)/(U/2); w=np.exp(-1/(1-v*v)); w/=w.sum()*du
  smooth=.5*(np.exp(u/2)-np.exp(-u/2)/(np.exp(2*u)-1))
  ns=np.arange(2,N+1,dtype=int); omega=np.arange(0,Om+1e-12,DOM)
  Psi=np.vstack([w*np.cos(o*u) for o in omega]+[w*np.sin(o*u) for o in omega[1:]])*du
  Wj=Psi@smooth
  Pn=np.vstack([np.interp(np.log(ns),u,Psi[j]/du) for j in range(Psi.shape[0])])
  clock=np.zeros_like(u)
  for a in range(0,KT,400): clock += np.cos(np.outer(u,TAU[a:a+400])).sum(axis=1)
  K=int((TAU<=Om+MARGIN).sum()); tail=clock-np.cos(np.outer(u,TAU[:K])).sum(axis=1); fixed=Psi@tail-Wj
  def fun(z):
    x=z[:K]; masses=z[K:]
    return Psi@np.cos(np.outer(u,x)).sum(axis=1)+fixed+Pn@masses
  def jac(z):
    x=z[:K]
    Jk=Psi@(-u[:,None]*np.sin(np.outer(u,x)))
    return np.hstack([Jk,Pn])
  for M in Mbounds:
    z0=np.r_[TAU[:K],np.zeros(len(ns))]
    lo=np.r_[TAU[:K]-B,-M*np.ones(len(ns))]; hi=np.r_[TAU[:K]+B,M*np.ones(len(ns))]
    t=time.time()
    sol=least_squares(fun,z0,jac=jac,method='trf',bounds=(lo,hi),max_nfev=1500,ftol=1e-11,xtol=1e-11,gtol=1e-11,x_scale='jac')
    x=sol.x[:K]; masses=sol.x[K:]; nr=np.linalg.norm(sol.fun)/math.sqrt(Psi.shape[0]); rms10=np.sqrt(np.mean((x[:min(10,K)]-GAM[:min(10,K)])**2)); mx=np.max(np.abs(x-TAU[:K])); am=np.sum(np.abs(np.abs(masses)-M)<1e-5); ak=np.sum((np.abs(x-(TAU[:K]-B))<1e-5)|(np.abs(x-(TAU[:K]+B))<1e-5)); E=np.sum(masses*masses)
    print(f'N={N:2d} M={M:3.1f} K={K:2d} nrms={nr:.3e} rms10={rms10:.3e} massE={E:.3e} massMax={np.max(np.abs(masses)):.3e} activeM={am} activeK={ak} nfev={sol.nfev} sec={time.time()-t:.1f}',flush=True)
    rows.append([N,Om,K,M,nr,rms10,E,np.max(np.abs(masses)),am,ak,sol.nfev,time.time()-t])
    with open('/mnt/data/bounded_mass_constrained.csv','w',newline='') as f:
      csv.writer(f).writerows([['N','Omega','K','mass_bound','nrms','rms10_gamma_diagnostic','mass_energy','mass_max','active_mass_bounds','active_kappa_bounds','nfev','seconds']]+rows)
