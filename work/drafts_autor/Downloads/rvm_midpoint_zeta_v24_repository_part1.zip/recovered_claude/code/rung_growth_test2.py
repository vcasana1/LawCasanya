import math,csv,time
import numpy as np

TAU=np.fromfile('/mnt/data/zLamb(2).bin',dtype='<f8')[:12000]
GAM=np.fromfile('/mnt/data/zeross(3).bin',dtype='<f8')
KT=len(TAU); DOM=.15; NU=5001; MARGIN=14.; WMIN=.015
STEP=.20; ITER=500; RIDGE=1e-10
stages=[(5,20.),(8,30.),(13,50.),(20,70.),(27,90.),(34,110.)]
prev=None; prevK=0; rows=[]; ordrows=[]

def solve(N,Omega,prev=None):
    U=math.log(N+.5); ug=np.linspace(0,U,NU); u=ug[1:-1]; du=U/(NU-1)
    v=(u-U/2)/(U/2); w=np.exp(-1/(1-v*v)); w/=w.sum()*du
    smooth=.5*(np.exp(u/2)-np.exp(-u/2)/(np.exp(2*u)-1))
    ns=np.array([n for n in range(2,N+1) if np.interp(math.log(n),u,w)/w.max()>=WMIN],dtype=int)
    om=np.arange(0,Omega+1e-12,DOM)
    Psi=np.vstack([w*np.cos(o*u) for o in om]+[w*np.sin(o*u) for o in om[1:]])*du
    Wj=Psi@smooth
    Pn=np.vstack([np.interp(np.log(ns),u,Psi[j]/du) for j in range(Psi.shape[0])])
    Q=np.linalg.solve(Pn.T@Pn+RIDGE*np.eye(len(ns)),Pn.T)
    clock=np.zeros_like(u)
    for a in range(0,KT,400): clock += np.cos(np.outer(u,TAU[a:a+400])).sum(axis=1)
    K=int((TAU<=Omega+MARGIN).sum())
    x=TAU[:K].copy()
    if prev is not None:
        m=min(len(prev),K); x[:m]=prev[:m]
    tail=clock-np.cos(np.outer(u,TAU[:K])).sum(axis=1)
    fixed=Psi@tail-Wj
    def res(xx):
        raw=Psi@np.cos(np.outer(u,xx)).sum(axis=1)+fixed
        masses=-Q@raw
        return raw+Pn@masses,masses
    r,m=res(x); n0=np.linalg.norm(r); damp=1e-3
    best=(np.linalg.norm(r),x.copy(),m.copy())
    for it in range(1,ITER+1):
        J=Psi@(-u[:,None]*np.sin(np.outer(u,x))); J=J-Pn@(Q@J)
        A=J.T@J; b=-J.T@r; diag=np.diag(A)+1e-14
        accepted=False
        for _ in range(40):
            try: d=np.linalg.solve(A+damp*np.diag(diag),b)
            except np.linalg.LinAlgError: damp*=10; continue
            md=np.max(np.abs(d))
            if md>STEP: d*=STEP/md
            r2,m2=res(x+d)
            if np.linalg.norm(r2)<np.linalg.norm(r): accepted=True; break
            damp*=4
        if not accepted: break
        x=x+d
        r,m=r2,m2
        nr=np.linalg.norm(r)
        if nr<best[0]: best=(nr,x.copy(),m.copy())
        damp=max(damp/3,1e-14)
        if np.max(np.abs(d))<1e-11: break
    rf,bx,bm=best; x=bx; m=bm
    return dict(N=N,U=U,Omega=Omega,K=K,ns=ns,tests=Psi.shape[0],x=x,m=m,n0=n0,rf=rf,nrms=rf/math.sqrt(Psi.shape[0]),it=it)

for N,Om in stages:
    t=time.time(); z=solve(N,Om,prev); prev=z['x']; elapsed=time.time()-t
    K=z['K']; err=np.abs(z['x']-GAM[:K]); low=min(10,K)
    rms10=float(np.sqrt(np.mean(err[:low]**2))); max10=float(np.max(err[:low])); maxshift=float(np.max(np.abs(z['x']-TAU[:K])))
    rows.append([N,z['U'],Om,K,len(z['ns']),z['tests'],z['n0'],z['rf'],z['nrms'],z['it'],maxshift,rms10,max10,elapsed])
    for k in range(K): ordrows.append([N,k+1,TAU[k],z['x'][k],GAM[k],z['x'][k]-GAM[k],z['x'][k]-TAU[k]])
    print(f'N={N:2d} Om={Om:5.1f} K={K:2d} masses={len(z["ns"]):2d} tests={z["tests"]:4d} |r| {z["n0"]:.3e}->{z["rf"]:.3e} NRMS={z["nrms"]:.3e} maxshift={maxshift:.3f} rms10={rms10:.3e} it={z["it"]} time={elapsed:.1f}s')

with open('/mnt/data/rung_growth_test2.csv','w',newline='') as f:
    wr=csv.writer(f); wr.writerow(['N','U','Omega','K','num_masses','num_tests','initial_norm','final_norm','normalized_rms','iterations','max_abs_shift','rms_error_first10','max_error_first10','seconds']); wr.writerows(rows)
with open('/mnt/data/rung_growth_ordinates2.csv','w',newline='') as f:
    wr=csv.writer(f); wr.writerow(['N','k','tau','solved','gamma_diagnostic','solved_minus_gamma','solved_minus_tau']); wr.writerows(ordrows)
