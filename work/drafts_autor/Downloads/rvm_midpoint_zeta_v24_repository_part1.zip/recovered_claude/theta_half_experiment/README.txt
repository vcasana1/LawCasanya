Theta = 1/2 rung-homotopy finite-section experiment

Purpose
-------
Test the interior target

  sum_k cos(kappa_k u) + sum_n a_n delta(u-log n)
    = 0.5 sum_k cos(tau_k u) + 0.5 k(u)

with the same finite-section machinery as s10.

Important status
----------------
This is numerical evidence, not a proof of nonexistence of an infinite
interior solution. Genuine zeta ordinates are used only in explicitly labelled
diagnostic initializations. The autonomous random multistarts use only the RVM
clock.

Main observations
-----------------
1. At N=13, Omega=50, the best normalized residual is essentially zero at
   theta=0, about 5.2e-5 at theta=1, but about 1.38e-2 at theta=1/2.
2. The theta scan has a clear interior residual arch rather than a low-residual
   continuation between the two endpoints.
3. At theta=1/2 the best normalized residual is about 1.42e-2 (N=13),
   1.84e-2 (N=20), and 2.05e-2 (N=34) under the same finite-section scheme.
   It does not decrease as the resolved window grows.
4. Thirty autonomous random starts at N=13 do not find a residual below the
   same order of magnitude; the best is recorded in
   theta_half_random_multistart.csv.

Interpretation
--------------
The computation strongly disfavors the specific linear target homotopy as an
exact interior path at the tested resolutions. It does not rule out an infinite
solution: finite truncation, tail locking, and nonlinear conditioning remain
possible explanations. The endpoint theta=1 is recovered much more accurately
with the same machinery, which makes a purely numerical-resolution explanation
less plausible for the N=13 test.
