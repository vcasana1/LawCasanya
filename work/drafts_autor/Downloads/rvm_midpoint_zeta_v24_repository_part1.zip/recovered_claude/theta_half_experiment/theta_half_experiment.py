#!/usr/bin/env python3
"""Finite-section test of the autonomous theta-homotopy.

The target distribution is

    sum_k cos(kappa_k u) + sum_n a_n delta(u-log n)
      = (1-theta) sum_k cos(tau_k u) + theta k(u).

The atomic masses are eliminated linearly at every nonlinear step. The
nonlinear variables are the free ordinates kappa_k; ordinates above the free
height are kept on the RVM clock. Genuine zeta ordinates are used only for
explicitly labelled diagnostic initializations after the autonomous problem
has been assembled.
"""
import os
import math
import csv
import numpy as np
from scipy.optimize import least_squares
import matplotlib.pyplot as plt

ROOT = os.path.dirname(os.path.abspath(__file__))
ZLAMB = os.path.join('/mnt/data', 'zLamb(2).bin')
ZEROS = os.path.join('/mnt/data', 'zeross(3).bin')

KT = 8000
NU = 4001
DOM = 0.2
MARGIN = 12.0
RIDGE = 1e-10
WMIN = 0.05

tau_master = np.fromfile(ZLAMB, dtype='<f8')[:KT]
gamma_master = np.fromfile(ZEROS, dtype='<f8')


def setup_problem(N, omega_max, theta, include_all_masses=False):
    U = math.log(N + 0.5)
    grid = np.linspace(0.0, U, NU)
    u = grid[1:-1]
    du = U / (NU - 1)
    v = (u - U / 2.0) / (U / 2.0)
    w = np.exp(-1.0 / (1.0 - v * v))
    w /= w.sum() * du
    smooth = 0.5 * (np.exp(u / 2.0) - np.exp(-u / 2.0) / (np.exp(2.0 * u) - 1.0))

    if include_all_masses:
        ns = np.arange(2, N + 1, dtype=int)
    else:
        ns = np.array([
            n for n in range(2, N + 1)
            if np.interp(math.log(n), u, w) / w.max() >= WMIN
        ], dtype=int)

    omega = np.arange(0.0, omega_max + 1e-12, DOM)
    psi = np.vstack(
        [w * np.cos(o * u) for o in omega] +
        [w * np.sin(o * u) for o in omega[1:]]
    ) * du
    smooth_j = psi @ smooth

    mass_matrix = np.vstack([
        np.interp(np.log(ns), u, psi[j] / du)
        for j in range(psi.shape[0])
    ])

    if include_all_masses:
        Uq, sing, Vh = np.linalg.svd(mass_matrix, full_matrices=False)
        inv = np.where(sing > sing[0] * 1e-13, 1.0 / sing, 0.0)
        Q = (Vh.T * inv) @ Uq.T
    else:
        Q = np.linalg.solve(
            mass_matrix.T @ mass_matrix + RIDGE * np.eye(len(ns)),
            mass_matrix.T,
        )
    projector = mass_matrix @ Q

    clock_signal = np.zeros_like(u)
    for a in range(0, KT, 400):
        clock_signal += np.cos(np.outer(u, tau_master[a:a + 400])).sum(axis=1)
    clock_j = psi @ clock_signal

    K = int((tau_master <= omega_max + MARGIN).sum())
    low_clock = np.cos(np.outer(u, tau_master[:K])).sum(axis=1)
    tail_clock = clock_signal - low_clock
    fixed = psi @ tail_clock - (1.0 - theta) * clock_j - theta * smooth_j

    def residual(x):
        raw = psi @ np.cos(np.outer(u, x)).sum(axis=1) + fixed
        return raw - projector @ raw

    def jacobian(x):
        J = psi @ (-u[:, None] * np.sin(np.outer(u, x)))
        return J - projector @ J

    return {
        'N': N,
        'U': U,
        'Omega': omega_max,
        'theta': theta,
        'K': K,
        'num_tests': psi.shape[0],
        'num_masses': len(ns),
        'residual': residual,
        'jacobian': jacobian,
    }


def solve(problem, x0, max_nfev=800):
    sol = least_squares(
        problem['residual'], x0.copy(), jac=problem['jacobian'], method='lm',
        max_nfev=max_nfev, ftol=1e-12, xtol=1e-12, gtol=1e-12,
    )
    norm = float(np.linalg.norm(sol.fun))
    return sol, norm, norm / math.sqrt(problem['num_tests'])


# Experiment A: scan theta at fixed numerical resolution.
theta_rows = []
N = 13
Omega = 50.0
for theta in [0.0, 0.10, 0.25, 0.50, 0.75, 0.90, 1.0]:
    p = setup_problem(N, Omega, theta, include_all_masses=True)
    K = p['K']
    starts = [
        ('clock', tau_master[:K]),
        ('diagnostic_interpolation', (1.0 - theta) * tau_master[:K] + theta * gamma_master[:K]),
        ('diagnostic_zeta', gamma_master[:K]),
    ]
    best = None
    for name, x0 in starts:
        sol, norm, nrms = solve(p, x0)
        row = [theta, name, norm, nrms, sol.nfev, np.max(np.abs(sol.x - tau_master[:K]))]
        theta_rows.append(row)
        if best is None or norm < best[0]:
            best = (norm, nrms, name)
    print(f'theta={theta:.2f}: best={best[2]}, residual={best[0]:.9e}, NRMS={best[1]:.9e}')

with open(os.path.join(ROOT, 'theta_scan_N13.csv'), 'w', newline='') as f:
    wr = csv.writer(f)
    wr.writerow(['theta', 'start', 'residual_norm', 'normalized_rms', 'nfev', 'max_abs_shift'])
    wr.writerows(theta_rows)

# Experiment B: theta=1/2 versus the endpoint theta=1 on growing windows.
scale_rows = []
for N, Omega in [(13, 50.0), (20, 70.0), (34, 110.0)]:
    for theta in [0.5, 1.0]:
        p = setup_problem(N, Omega, theta, include_all_masses=False)
        K = p['K']
        if theta == 0.5:
            starts = [
                ('clock', tau_master[:K]),
                ('diagnostic_interpolation', 0.5 * (tau_master[:K] + gamma_master[:K])),
            ]
        else:
            starts = [('diagnostic_zeta', gamma_master[:K])]
        best = None
        for name, x0 in starts:
            sol, norm, nrms = solve(p, x0, max_nfev=300)
            if best is None or norm < best[0]:
                best = (norm, nrms, name, sol.nfev, np.max(np.abs(sol.x - tau_master[:K])))
        scale_rows.append([N, p['U'], Omega, K, p['num_masses'], p['num_tests'], theta, *best])
        print(f'N={N}, theta={theta:.1f}: best={best[2]}, residual={best[0]:.9e}, NRMS={best[1]:.9e}')

with open(os.path.join(ROOT, 'theta_half_scaling.csv'), 'w', newline='') as f:
    wr = csv.writer(f)
    wr.writerow([
        'N', 'U', 'Omega', 'K', 'num_masses', 'num_tests', 'theta',
        'residual_norm', 'normalized_rms', 'best_start', 'nfev', 'max_abs_shift'
    ])
    wr.writerows(scale_rows)

# Experiment C: autonomous random multistart at theta=1/2, N=13.
p = setup_problem(13, 50.0, 0.5, include_all_masses=False)
K = p['K']
rng = np.random.default_rng(777)
random_rows = []
for j in range(30):
    scale = [0.1, 0.25, 0.5, 1.0, 2.0][j % 5]
    x0 = tau_master[:K] + rng.normal(0.0, scale, K)
    sol, norm, nrms = solve(p, x0, max_nfev=400)
    random_rows.append([j, scale, norm, nrms, sol.nfev, np.max(np.abs(sol.x - tau_master[:K]))])

with open(os.path.join(ROOT, 'theta_half_random_multistart.csv'), 'w', newline='') as f:
    wr = csv.writer(f)
    wr.writerow(['run', 'start_sigma', 'residual_norm', 'normalized_rms', 'nfev', 'max_abs_shift'])
    wr.writerows(random_rows)

# Figure 1: best residual versus theta.
best_by_theta = []
for theta in sorted(set(r[0] for r in theta_rows)):
    vals = [r for r in theta_rows if r[0] == theta]
    best_by_theta.append((theta, min(v[3] for v in vals)))
arr = np.asarray(best_by_theta)
plt.figure(figsize=(7.2, 4.7))
plt.plot(arr[:, 0], arr[:, 1], marker='o')
plt.xlabel('Theta')
plt.ylabel('Best normalized residual RMS')
plt.title('Finite rung target: residual across the theta homotopy')
plt.tight_layout()
plt.savefig(os.path.join(ROOT, 'theta_scan_residual.png'), dpi=180)
plt.close()

# Figure 2: theta=1/2 compared with theta=1 as resolution grows.
scale = np.asarray([[float(r[0]), float(r[6]), float(r[8])] for r in scale_rows])
plt.figure(figsize=(7.2, 4.7))
for theta in [0.5, 1.0]:
    z = scale[scale[:, 1] == theta]
    plt.plot(z[:, 0], z[:, 2], marker='o', label=f'theta={theta:g}')
plt.xlabel('Mass window N')
plt.ylabel('Best normalized residual RMS')
plt.title('Interior target versus the endpoint under growing resolution')
plt.legend()
plt.tight_layout()
plt.savefig(os.path.join(ROOT, 'theta_half_scaling.png'), dpi=180)
plt.close()

print('Finished.')
