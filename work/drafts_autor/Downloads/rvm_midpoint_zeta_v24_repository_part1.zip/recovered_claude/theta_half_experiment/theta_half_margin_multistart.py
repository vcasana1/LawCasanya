#!/usr/bin/env python3
"""Multistart diagnostic for the theta=1/2 rung target.
All program text is English. Genuine zeros are used only for labelled diagnostic starts.
"""
import os, math
import numpy as np
HERE=os.path.dirname(os.path.abspath(__file__)); ROOT=os.path.abspath(os.path.join(HERE,'..'))
DATA=os.path.join(ROOT,'data'); OUT=os.path.join(ROOT,'output')
THETA=0.5; KT=8000; N=13; OM=50.; DOM=.2; NU=4001; RIDGE=1e-10; STEP=.2; ITER=180; WMIN=.05
MARGINS=[12.,50.]
tau=np.fromfile(os.path.join(DATA,'zLamb.bin'),dtype='<f8')[:KT]
gam=np.fromfile(os.path.join(DATA,'zeross.bin'),dtype='<f8')
U=math.log(N+.5); ug=np.linspace(0,U,NU); u=ug[1:-1]; du=U/(NU-1)
v=(u-U/2)/(U/2); w=np.exp(-1/(1-v*v)); w/=w.sum()*du
Wfun=.5*(np.exp(u/2)-np.exp(-u/2)/(np.exp(2*u)-1))
ns=np.array([n for n in range(2,N+1) if np.interp(math.log(n),u,w)/w.max()>=WMIN])
om=np.arange(0,OM+1e-12,DOM)
Psi=np.vstack([w*np.cos(o*u) for o in om]+[w*np.sin(o*u) for o in om[1:]])*du
Wj=Psi@Wfun
Pn=np.vstack([np.interp(np.log(ns),u,Psi[j]/du) for j in range(Psi.shape[0])])
Q=np.linalg.solve(Pn.T@Pn+RIDGE*np.eye(len(ns)),Pn.T)
COS=np.zeros_like(u)
for a in range(0,KT,400): COS += np.cos(np.outer(u,tau[a:a+400])).sum(axis=1)
clockj=Psi@COS

def solve(K,x0,fixed):
    g=x0.copy()
    def res(x):
        raw=Psi@np.cos(np.outer(u,x)).sum(axis=1)+fixed
        masses=-Q@raw
        return raw+Pn@masses,masses
    r,masses=res(g); r0=np.linalg.norm(r); damp=1e-3
    for it in range(1,ITER+1):
        J=Psi@(-u[:,None]*np.sin(np.outer(u,g))); J=J-Pn@(Q@J)
        A=J.T@J; b=-J.T@r; diag=np.diag(A)+1e-14
        accepted=False
        for _ in range(30):
            try: d=np.linalg.solve(A+damp*np.diag(diag),b)
            except np.linalg.LinAlgError:
                damp*=10; continue
            md=np.max(np.abs(d));
            if md>STEP: d*=STEP/md
            r2,m2=res(g+d)
            if np.linalg.norm(r2)<np.linalg.norm(r): accepted=True; break
            damp*=4
        if not accepted: break
        g+=d; r,masses=r2,m2; damp=max(damp/3,1e-14)
        if np.max(np.abs(d))<1e-11: break
    return g,masses,r0,np.linalg.norm(r),it

rows=[]
print('s13c: theta=1/2 multistart diagnostic')
for margin in MARGINS:
    K=int((tau<=OM+margin).sum())
    tail=COS-np.cos(np.outer(u,tau[:K])).sum(axis=1)
    fixed=Psi@tail-(1-THETA)*clockj-THETA*Wj
    rng=np.random.default_rng(20261009+K)
    starts=[
        ('clock',tau[:K].copy(),1),
        ('random_0p5',tau[:K]+rng.normal(0,.5,K),1),
        ('true_midpoint',.5*(tau[:K]+gam[:K]),0),
        ('true_zeta',gam[:K].copy(),0),
    ]
    for name,x0,aut in starts:
        g,m,r0,rf,it=solve(K,x0,fixed)
        nr=rf/math.sqrt(Psi.shape[0]); ms=np.max(np.abs(g-tau[:K]))
        print(f'margin={margin:4.0f} K={K:3d} start={name:13s} autonomous={aut} '
              f'|r| {r0:.3e}->{rf:.3e} NRMS={nr:.3e} maxshift={ms:.3f} it={it}')
        rows.append((margin,K,name,aut,r0,rf,nr,ms,it))
with open(os.path.join(OUT,'s13c_theta_half_multistart.csv'),'w') as f:
    f.write('margin,K,start,autonomous,initial_residual,final_residual,normalized_rms,max_abs_shift,iterations\n')
    for r in rows:
        f.write(f'{r[0]},{r[1]},{r[2]},{r[3]},{r[4]:.12g},{r[5]:.12g},{r[6]:.12g},{r[7]:.12g},{r[8]}\n')
