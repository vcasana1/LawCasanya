function s16_walks_3d_1000
% S16_WALKS_3D_1000  The three exponential walks of the first 1000 ordinates in 3D (k on
% the vertical axis) and their triangular centroids.
%   S_k(x) = sum_{j<=k} exp(i x_j),  x = gamma (zeros of zeta), tau (midpoint clock),
%   theta = (gamma + tau)/2;   C_N = (1/N) sum_{k<=N} S_k = sum_k (1 - (k-1)/N) exp(i x_k).
% Data: zeross.bin and zLamb.bin (little-endian doubles) in ../data or in the current folder.
% MATLAB version of s16_walks_3d_1000.py.  Figures are saved as PNG and left open.
clc;
clear;

DATA = '../data';
if ~exist(fullfile(DATA, 'zeross.bin'), 'file'), DATA = '.'; end
gam = readbin(fullfile(DATA, 'zeross.bin'));
tau = readbin(fullfile(DATA, 'zLamb.bin'));
Nz  = min(numel(gam), numel(tau));
gam = gam(1:Nz); tau = tau(1:Nz);
if abs(gam(1) - 14.134725141734693) > 1e-6, error('zeross.bin: first value is not gamma_1'); end
N  = 1000;
k  = (1:N).';
g  = gam(1:N); t = tau(1:N); th = (g + t)/2;
w  = 1 - (k - 1)/N;
Sg = cumsum(exp(1i*g)); St = cumsum(exp(1i*t)); Sm = cumsum(exp(1i*th));
Cg = sum(w .* exp(1i*g)); Ct = sum(w .* exp(1i*t)); Cm = sum(w .* exp(1i*th));
ch = (Cg + Ct)/2;
wall = 1 - (0:Nz-1).'/Nz;
CgAll = sum(wall .* exp(1i*gam)); CtAll = sum(wall .* exp(1i*tau));
eps = g - t;

out = fopen('s16_walks_3d_1000_console.txt', 'w');
say = @(varargin) cellfun(@(f) fprintf(f, '%s\n', sprintf(varargin{:})), {1, out});
say('C_gamma  = %+.10f %+.10f i   (|S_N| = %.4f, max_k |S_k| = %.4f, check mean(S_k) - C = %.1e)', ...
    real(Cg), imag(Cg), abs(Sg(N)), max(abs(Sg)), abs(mean(Sg) - Cg));
say('C_tau    = %+.10f %+.10f i   (|S_N| = %.4f, max_k |S_k| = %.4f, check mean(S_k) - C = %.1e)', ...
    real(Ct), imag(Ct), abs(St(N)), max(abs(St)), abs(mean(St) - Ct));
say('C_theta  = %+.10f %+.10f i   (|S_N| = %.4f, max_k |S_k| = %.4f, check mean(S_k) - C = %.1e)', ...
    real(Cm), imag(Cm), abs(Sm(N)), max(abs(Sm)), abs(mean(Sm) - Cm));
say('(C_gamma + C_tau)/2 = %+.10f %+.10f i;  C_theta - chord midpoint = %+.6f %+.6f i, modulus %.6f', ...
    real(ch), imag(ch), real(Cm - ch), imag(Cm - ch), abs(Cm - ch));
say('gamma_k - tau_k, k <= %d: mean %+.6f, std %.6f, max |.| %.6f', N, mean(eps), std(eps, 1), max(abs(eps)));
say('reference values with all %d ordinates: C_gamma = %+.10f %+.10f i, C_tau = %+.10f %+.10f i', Nz, ...
    real(CgAll), imag(CgAll), real(CtAll), imag(CtAll));
fclose(out);
writetable(table(k, g, t, th, real(Sg), imag(Sg), real(St), imag(St), real(Sm), imag(Sm), 'VariableNames', ...
    {'k','gamma','tau','theta','ReS_gamma','ImS_gamma','ReS_tau','ImS_tau','ReS_theta','ImS_theta'}), ...
    's16_walks_1000.csv');
save('s16_results.mat', 'k', 'g', 't', 'th', 'Sg', 'St', 'Sm', 'Cg', 'Ct', 'Cm');

cG = [0.12 0.37 0.66]; cT = [0.82 0.35 0.16]; cM = [0.24 0.60 0.24];
zc = (N + 1)/2;
labG = '\gamma_k (zeros of \zeta)'; labT = '\tau_k (midpoint clock)'; labM = '\theta_k = (\gamma_k+\tau_k)/2';

%% one 3D panel per walk
f1 = figure('Color', 'w', 'Position', [40 40 1600 600]);
S3 = {Sg, St, Sm}; C3 = {Cg, Ct, Cm}; col = {cG, cT, cM}; mk = {'o', 's', 'd'}; lab = {labG, labT, labM};
for i = 1:3
    subplot(1,3,i);
    plot3(real(S3{i}), imag(S3{i}), k, '-', 'Color', col{i}, 'LineWidth', 0.6); hold on;
    plot3(real(C3{i}), imag(C3{i}), zc, mk{i}, 'MarkerSize', 9, 'MarkerFaceColor', col{i}, 'MarkerEdgeColor', 'k');
    grid on; box on; view(-35, 22);
    xlabel('Re S_k'); ylabel('Im S_k'); zlabel('k');
    title(sprintf('%s,  C = %.4f %+.4f i', lab{i}, real(C3{i}), imag(C3{i})));
end
print(f1, 'fig24_walks_3d_1000.png', '-dpng', '-r150');

%% the three walks together and the projection on the complex plane
f2 = figure('Color', 'w', 'Position', [60 60 1500 650]);
subplot(1,2,1);
plot3(real(Sg), imag(Sg), k, '-', 'Color', cG, 'LineWidth', 0.6); hold on;
plot3(real(St), imag(St), k, '-', 'Color', cT, 'LineWidth', 0.6);
plot3(real(Sm), imag(Sm), k, '-', 'Color', cM, 'LineWidth', 0.6);
plot3(real(Cg), imag(Cg), zc, 'o', 'MarkerSize', 9, 'MarkerFaceColor', cG, 'MarkerEdgeColor', 'k');
plot3(real(Ct), imag(Ct), zc, 's', 'MarkerSize', 9, 'MarkerFaceColor', cT, 'MarkerEdgeColor', 'k');
plot3(real(Cm), imag(Cm), zc, 'd', 'MarkerSize', 9, 'MarkerFaceColor', cM, 'MarkerEdgeColor', 'k');
grid on; box on; view(-35, 22); xlabel('Re S_k'); ylabel('Im S_k'); zlabel('k');
title(sprintf('The three walks, N = %d (centroids at height (N+1)/2)', N));
legend({labG, labT, labM}, 'Location', 'northwest');
subplot(1,2,2);
plot(real(Sg), imag(Sg), '-', 'Color', cG, 'LineWidth', 0.4); hold on;
plot(real(St), imag(St), '-', 'Color', cT, 'LineWidth', 0.4);
plot(real(Sm), imag(Sm), '-', 'Color', cM, 'LineWidth', 0.4);
plot(real(Cg), imag(Cg), 'o', 'MarkerSize', 10, 'MarkerFaceColor', cG, 'MarkerEdgeColor', 'k');
plot(real(Ct), imag(Ct), 's', 'MarkerSize', 10, 'MarkerFaceColor', cT, 'MarkerEdgeColor', 'k');
plot(real(Cm), imag(Cm), 'd', 'MarkerSize', 10, 'MarkerFaceColor', cM, 'MarkerEdgeColor', 'k');
plot(real(ch), imag(ch), 'kx', 'MarkerSize', 12, 'LineWidth', 1.6);
axis equal; grid on; box on; xlabel('Re S_k'); ylabel('Im S_k');
title('Projection on the complex plane');
legend({labG, labT, labM, sprintf('C_\\gamma = %.4f %+.4f i', real(Cg), imag(Cg)), ...
        sprintf('C_\\tau = %.4f %+.4f i', real(Ct), imag(Ct)), sprintf('C_\\theta = %.4f %+.4f i', real(Cm), imag(Cm)), ...
        '(C_\gamma+C_\tau)/2'}, 'Location', 'northwest');
print(f2, 'fig25_walks_projection_1000.png', '-dpng', '-r150');
end

function x = readbin(name)
fid = fopen(name, 'r', 'ieee-le');
if fid < 0, error('cannot open %s', name); end
x = fread(fid, inf, 'double');
fclose(fid);
x = x(:);
end
