set -e
run () { echo "=== $1 ==="; python3 "$1" 2>&1 | tee "output/$2"; }
run zeros.py     01_zeros.txt
run refine2.py   02_refine.txt
run carrier.py   03_carrier.txt
run saddle.py    04_saddle.txt
run spikes.py    05_spikes.txt
run residual.py  06_residual.txt
run scan.py      07_scan.txt
run conv.py      08_convergence.txt
run law.py       09_law.txt
python3 fig.py  >/dev/null; python3 fig2.py >/dev/null
