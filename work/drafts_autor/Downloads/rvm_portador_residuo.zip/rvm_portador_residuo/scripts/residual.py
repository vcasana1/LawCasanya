import numpy as np
from scipy.special import lambertw, loggamma
TWOPI=2*np.pi
g=np.load("gammas.npy"); N=len(g); T=g[-1]; sN=np.sqrt(N); L=np.log(T/TWOPI)
k=np.arange(1,N+1,dtype=np.float64); A=(k-11/8)/np.e
tau=np.where(A>0,TWOPI*(k-11/8)/np.real(lambertw(A,0)),14.0).astype(np.longdouble)
kl=k.astype(np.longdouble); TP=np.longdouble(2)*np.longdouble(np.pi)
for _ in range(4):
    f=(tau/TP)*np.log(tau/(TP*np.e))+np.longdouble(7)/8-(kl-np.longdouble(.5)); tau-=f/(np.log(tau/TP)/TP)
eps=(g.astype(np.longdouble)-tau).astype(np.float64)
H=1+(np.imag(loggamma(0.25+0.5j*g))-0.5*g*np.log(np.pi))/np.pi
Sstar=k-0.5-H
dens=np.log(g/TWOPI)/TWOPI                      # M'(gamma)
print(f"N={N}  T={T:.0f}  log(T/2pi)={L:.3f}  mean spacing={1/dens[-1]:.4f}")
print(f"\nrms(eps)                       = {eps.std():.5f}   (= {eps.std()*dens[-1]:.3f} mean spacings)")
print(f"rms(S_*)                       = {Sstar.std():.5f}")
print(f"rms(-2pi S_*/log(g/2pi)) check = {(-Sstar/dens).std():.5f}   <- your identity, vs rms(eps) above")
print(f"max |eps + S_*/M'(gamma)|      = {np.abs(eps+Sstar/dens).max():.4f}  (2nd-order term)")

print("\n--- Is 'remove the RVM carrier' a reduction?  Phase spread of the residual e^{i t eps_k} ---")
print("  alpha |  t=a*logT' |  rms(t*eps) rad |  |mean e^{i t eps}| |  mean|e^{i t eps}-1|")
print("-"*84)
for a,lab in [(1/L,"  <- x=e, the paper's frequency"),(0.1,""),(0.25,""),(0.5,""),(1.0,"  <- Montgomery plateau starts"),(1.5,""),(2.0,"")]:
    t=a*L; ph=t*eps
    print(f"  {a:6.3f} | {t:10.4f} | {ph.std():15.3f} | {abs(np.mean(np.exp(1j*ph))):18.4f} | {np.mean(np.abs(np.exp(1j*ph)-1)):19.4f}{lab}")
print("\n(uniform-phase reference: |mean|=0, mean|e^{i.}-1| = 4/pi = 1.2732)")
