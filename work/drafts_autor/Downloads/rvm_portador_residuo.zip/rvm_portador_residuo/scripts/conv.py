import numpy as np
g=np.load("g_hp.npy"); L=0.77689426079325358+0.767855668864547j
e=np.exp(1j*g)
# C_N = sum_{k<=N} (1-(k-1)/N) e^{i g_k}  -> use prefix sums of e and of (k-1)e
A=np.concatenate([[0],np.cumsum(e)]); Bp=np.concatenate([[0],np.cumsum(np.arange(len(g))*e)])
def CN(N): return A[N]-Bp[N]/N
Ns=np.unique(np.round(np.logspace(np.log10(200),np.log10(len(g)),40)).astype(int))
print(f"L = {L.real:.15f} {L.imag:+.15f}i     (paper: Re=0.77689426079325358, Im=0.76785566886455)")
print(f"\n     N |        Re C_N |        Im C_N |   |C_N - L| |  x sqrt(N) |  x N/logN")
print("-"*80)
for N in Ns[::3]:
    c=CN(N); d=abs(c-L)
    print(f"{N:6d} | {c.real:13.8f} | {c.imag:13.8f} | {d:10.6f} | {d*np.sqrt(N):10.4f} | {d*N/np.log(N):9.3f}")
c=CN(len(g)); print(f"\nN={len(g)}: C_N = {c.real:.9f} {c.imag:+.9f}i,  |C_N-L| = {abs(c-L):.6f}")
print(f"  Re err = {c.real-L.real:+.6f}   Im err = {c.imag-L.imag:+.6f}")
# fit power law on the tail
m=Ns>=1000; d=np.array([abs(CN(N)-L) for N in Ns[m]])
p=np.polyfit(np.log(Ns[m]),np.log(d),1)
print(f"\nfit |C_N - L| ~ C * N^b  on N in [1000,{len(g)}]:  b = {p[0]:+.3f}   (C={np.exp(p[1]):.3f})")
print(f"   sqrt-cancellation would give b=-0.5 ;  1/log N would give b~0 ;  logN/N gives b~-1")
