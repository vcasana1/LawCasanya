import numpy as np
from scipy.special import lambertw
TWOPI=2*np.pi
g=np.load("gammas.npy"); N=len(g); T=g[-1]; sN=np.sqrt(N)
# matched RVM carrier: same ordinal count
k=np.arange(1,N+1,dtype=np.float64); A=(k-11/8)/np.e
tau=np.where(A>0,TWOPI*(k-11/8)/np.real(lambertw(A,0)),14.0).astype(np.longdouble)
kl=k.astype(np.longdouble); TP=np.longdouble(2)*np.longdouble(np.pi)
for _ in range(4):
    f=(tau/TP)*np.log(tau/(TP*np.e))+np.longdouble(7)/8-(kl-np.longdouble(.5)); tau-=f/(np.log(tau/TP)/TP)
gl=g.astype(np.longdouble)
def amp(x,seq):
    ph=np.longdouble(x)*seq; ph-=TP*np.floor(ph/TP); return abs(np.sum(np.exp(1j*ph.astype(np.float64))))
print(f"N={N}  T={T:.1f}  sqrt(N)={sN:.1f}  log(T/2pi)={np.log(T/TWOPI):.3f}")
print("\nLandau resonances: at x=p^m the zeta sum must spike by ~(T/2pi)*Lambda(x)/sqrt(x).")
print("The RVM carrier is evaluated at the SAME t. Ratios are to sqrt(N).\n")
print("   x     t=log x |  |S_zeta|/sqrt(N) | |S_tau|/sqrt(N) | Landau pred/sqrt(N)")
print("-"*80)
def lam(x):
    for p in [2,3,5,7,11,13,17,19,23,29,31]:
        n=x
        while n%p==0: n//=p
        if n==1: return np.log(p)
    return 0.0
for x in [2,3,4,5,6,7,8,9,10,11,12,13,16,17,19,23,25,27,29,31,32]:
    t=np.log(x); L=lam(x); pred=(T/TWOPI)*L/np.sqrt(x)/sN
    tag="  <-- prime power" if L>0 else ""
    print(f"  {x:3d}  {t:9.5f} | {amp(t,gl)/sN:16.3f} | {amp(t,tau)/sN:15.3f} | {pred:18.3f}{tag}")
