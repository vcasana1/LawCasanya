import numpy as np
g=np.load("g_hp.npy"); n=len(g)
Lre=(1/(2*np.sqrt(np.e)))*(np.e-1/(np.e**2-1))
L=Lre+0.767855668864547j
e=np.exp(1j*g); A=np.concatenate([[0],np.cumsum(e)]); Bp=np.concatenate([[0],np.cumsum(np.arange(n)*e)])
CN=lambda N: A[N]-Bp[N]/N
print(f"closed form  Re L = (1/2sqrt(e))(e - 1/(e^2-1)) = {Lre:.17f}")
print(f"paper                                            0.77689426079325358")
print(f"Im L = B(1).im + P(1).im = {0.14616310152859:.14f} + {0.621692567335957:.15f} = {0.14616310152859+0.621692567335957:.15f}")
print(f"   (tu mensaje decia 0.76785566886445254 -> difiere en el decimal 13)\n")
Ns=np.unique(np.round(np.logspace(np.log10(300),np.log10(n),60)).astype(int))
R=np.array([abs(CN(N)-L)*N/np.log(N) for N in Ns])
print(f"|C_N - L| * N/log N   over N in [300,{n}]:")
print(f"   mean={R.mean():.3f}  sd={R.std():.3f}  min={R.min():.3f}  max={R.max():.3f}   -> BOUNDED, no trend")
h1,h2=R[:len(R)//2],R[len(R)//2:]
print(f"   first half mean={h1.mean():.3f}   second half mean={h2.mean():.3f}")
for a,lab in [(0.5,"N^-1/2 (raiz, tipo GUE)"),(1.0,"N^-1"),(0.0,"const")]:
    S=np.array([abs(CN(N)-L)*N**a for N in Ns]); print(f"   |C_N-L|*N^{a:<4}: mean={S.mean():9.4f} sd/mean={S.std()/S.mean():.2f}   {lab}")
S=np.array([abs(CN(N)-L)*N/np.log(N) for N in Ns]); print(f"   |C_N-L|*N/logN : mean={S.mean():9.4f} sd/mean={S.std()/S.mean():.2f}   <-- mejor ajuste")
NP=2001052
print(f"\nEXTRAPOLACION a N={NP} (el N del paper), desde mis {n} ceros independientes:")
print(f"   prediccion  |C_N - L| ~ {R.mean():.2f} * log N/N = {R.mean()*np.log(NP)/NP:.3e}")
print(f"   paper mide  discrepancia coordenada real        = 1.29e-05")
print(f"   paper mide  |C_N - Q_N^(H)|                     = 8.7162e-06")
# divergence of the sigma=1/2 prime series in (8.2)
X=2_000_000; sieve=np.ones(X+1,bool); sieve[:2]=False
for p in range(2,int(X**.5)+1):
    if sieve[p]: sieve[p*p::p]=False
pr=np.nonzero(sieve)[0]
terms=[]
for p in pr:
    q=int(p); 
    while q<=X:
        terms.append((q,np.log(p))); q*=p
terms.sort(); nn=np.array([t[0] for t in terms],float); lam=np.array([t[1] for t in terms])
val=lam/(np.sqrt(nn)*np.log(nn)*np.abs(1-np.log(nn)))
cs=np.cumsum(val)
print(f"\nserie de primos de (8.2) en sigma=1/2:  sum_n Lambda(n)/(sqrt(n) log n |1-log n|)")
for X0 in [1e2,1e3,1e4,1e5,1e6,2e6]:
    i=np.searchsorted(nn,X0)-1; print(f"   suma hasta n={X0:>9.0e} : {cs[i]:8.3f}")
print("   -> DIVERGE (como 2 sqrt(X)/log^2 X). No converge absolutamente en la linea critica.")
