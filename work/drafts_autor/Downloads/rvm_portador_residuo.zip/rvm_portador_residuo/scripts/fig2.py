import numpy as np, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
g=np.load("g_hp.npy"); n=len(g)
L=(1/(2*np.sqrt(np.e)))*(np.e-1/(np.e**2-1))+0.767855668864547j
e=np.exp(1j*g); A=np.concatenate([[0],np.cumsum(e)]); Bp=np.concatenate([[0],np.cumsum(np.arange(n)*e)])
CN=lambda N: A[N]-Bp[N]/N
Ns=np.unique(np.round(np.logspace(np.log10(300),np.log10(n),300)).astype(int))
d=np.array([abs(CN(N)-L) for N in Ns])
INK="#1a1a1a";MUT="#8a8a8a";C1="#0b6fa4";C2="#c8681c";C3="#4a7c59"
fig,(a1,a2)=plt.subplots(1,2,figsize=(11.5,4.5),dpi=170)
a1.loglog(Ns,d,color=C1,lw=1.3,label=r"$|C_N-L|$  (22 491 ceros)")
a1.loglog(Ns,1.145*np.log(Ns)/Ns,color=C2,lw=1.6,ls="--",label=r"$1.145\,\log N/N$")
a1.loglog(Ns,0.194/np.sqrt(Ns),color=C3,lw=1.4,ls=":",label=r"$0.194\,N^{-1/2}$  (tipo GUE)")
a1.set_xlabel("N",fontsize=10);a1.set_ylabel(r"$|C_N-L|$",fontsize=10)
a1.legend(frameon=False,fontsize=8.5);a1.set_title("La tasa observada no es de raíz",fontsize=11,loc="left")
a2.semilogx(Ns,d*Ns/np.log(Ns),color=C2,lw=1.2,label=r"$|C_N-L|\cdot N/\log N$   (acotado)")
a2.semilogx(Ns,d*np.sqrt(Ns),color=C3,lw=1.2,label=r"$|C_N-L|\cdot\sqrt{N}$   (decae)")
a2.axhline(1.145,color=MUT,lw=.8,ls="--")
a2.set_xlabel("N",fontsize=10);a2.set_ylim(0,2.1)
a2.legend(frameon=False,fontsize=8.5);a2.set_title("Normalizaciones compensadas",fontsize=11,loc="left")
for ax in (a1,a2):
    ax.tick_params(labelsize=8.5);ax.spines["top"].set_visible(False);ax.spines["right"].set_visible(False)
    [s.set_color(MUT) for s in ax.spines.values()]
fig.suptitle(r"El centroide converge a ritmo $\log N/N$ — el mismo orden que el modelo liso RVM (Thm 6.4: $\log^2\!N/N$)",
             fontsize=12,x=0.012,ha="left",y=1.02,color=INK)
plt.tight_layout();plt.savefig("rate.png",bbox_inches="tight",facecolor="white");print("ok")
