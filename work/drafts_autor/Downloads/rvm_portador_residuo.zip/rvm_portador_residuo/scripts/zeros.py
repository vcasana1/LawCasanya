import numpy as np
from scipy.special import loggamma
TWOPI=2*np.pi
def theta(t):
    return np.imag(loggamma(0.25+0.5j*t))-0.5*t*np.log(np.pi)
def Zfun(t):
    t=np.atleast_1d(np.asarray(t,dtype=np.float64))
    th=theta(t); a=np.sqrt(t/TWOPI); nu=np.floor(a).astype(int); p=a-nu
    out=np.zeros_like(t); nmax=int(nu.max())
    for n in range(1,nmax+1):
        m=nu>=n
        out[m]+=np.cos(th[m]-t[m]*np.log(n))/np.sqrt(n)
    out*=2.0
    C0=np.cos(TWOPI*(p*p-p-1/16))/np.cos(TWOPI*p)
    out+=np.where(nu%2==1,1.0,-1.0)*(t/TWOPI)**-0.25*C0
    return out
T=20000.0; step=0.02
grid=np.arange(10.0,T,step)
Z=np.empty_like(grid)
for i in range(0,len(grid),200000):
    Z[i:i+200000]=Zfun(grid[i:i+200000])
s=np.signbit(Z); idx=np.nonzero(s[:-1]!=s[1:])[0]
lo=grid[idx].copy(); hi=grid[idx+1].copy(); flo=Z[idx].copy()
for _ in range(60):
    mid=0.5*(lo+hi); fm=Zfun(mid)
    same=np.signbit(fm)==np.signbit(flo)
    lo=np.where(same,mid,lo); hi=np.where(same,hi,mid); flo=np.where(same,fm,flo)
g=0.5*(lo+hi)
Ncount=(T/TWOPI)*np.log(T/(TWOPI*np.e))+7/8
print(f"zeros found = {len(g)},  Riemann-von Mangoldt N(T) = {Ncount:.1f},  diff = {len(g)-Ncount:+.1f}")
print("first 6:", np.round(g[:6],6))
print("known   : [14.134725 21.02204  25.010858 30.424876 32.935062 37.586178]")
np.save("gammas.npy",g)
