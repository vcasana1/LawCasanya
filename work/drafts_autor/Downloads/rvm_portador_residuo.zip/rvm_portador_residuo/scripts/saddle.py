import numpy as np
from scipy.special import lambertw
TWOPI=2*np.pi; N=2_001_052
k=np.arange(1,N+1,dtype=np.float64); A=(k-11/8)/np.e
tau=np.where(A>0,TWOPI*(k-11/8)/np.real(lambertw(A,0)),14.0)
tau=tau.astype(np.longdouble); kl=k.astype(np.longdouble); TP=np.longdouble(2)*np.longdouble(np.pi)
for _ in range(4):
    f=(tau/TP)*np.log(tau/(TP*np.e))+np.longdouble(7)/8-(kl-np.longdouble(.5)); tau-=f/(np.log(tau/TP)/TP)
T=float(tau[-1]); L=np.longdouble(np.log(T/TWOPI)); sN=np.sqrt(N)
def S(a):
    ph=(np.longdouble(a)*L)*tau; ph-=TP*np.floor(ph/TP); return abs(np.sum(np.exp(1j*ph.astype(np.float64))))
print("Saddle law:  |S_tau(t)| ~ t*exp(t/(2n))/n^{3/2},  n=ceil(alpha), t=alpha*log(T/2pi)")
print(f"log(T/2pi)={float(L):.4f}  sqrt(N)={sN:.1f}\n")
print(" alpha |  measured |predicted |  ratio | measured/sqrt(N)")
print("-"*60)
for a in [0.3,0.5,0.7,0.8,0.9,0.95,1.05,1.2,1.4,1.6,1.8,1.95,2.2,2.6,2.9]:
    t=float(a*L); n=int(np.ceil(a)); pred=t*np.exp(t/(2*n))/n**1.5; m=S(a)
    print(f" {a:5.2f} | {m:9.1f} | {pred:8.1f} | {m/pred:6.3f} | {m/sN:8.3f}")
