import numpy as np, time
from scipy.special import loggamma
TWOPI=2*np.pi
B=np.array([1/6,-1/30,1/42,-1/30,5/66,-691/2730,7/6,-3617/510,43867/798,-174611/330,854513/138,-236364091/2730])
FAC=np.array([np.prod(np.arange(1,2*k+1,dtype=float)) for k in range(1,13)])
def zeta_half(t,M):
    s=0.5+1j*t; ln=np.log(np.arange(1,M,dtype=np.float64))
    out=np.zeros(len(t),dtype=np.complex128)
    for a in range(0,M-1,8192):
        out+=np.exp(-np.outer(s,ln[a:a+8192])).sum(axis=1)
    lM=np.log(M); out+=np.exp(-s*lM)/2+np.exp((1-s)*lM)/(s-1)
    prod=np.ones(len(t),dtype=np.complex128); j=0
    for kk in range(1,13):
        while j<=2*kk-2: prod=prod*(s+j); j+=1
        out+=(B[kk-1]/FAC[kk-1])*prod*np.exp(-(s+2*kk-1)*lM)
    return out
def theta(t): return np.imag(loggamma(0.25+0.5j*t))-0.5*t*np.log(np.pi)
def Z(t):
    t=np.atleast_1d(np.asarray(t,float)); o=np.argsort(t); ts=t[o]; out=np.empty(len(ts))
    ed=np.unique(np.searchsorted(ts,np.linspace(0,ts[-1]*1.001,80)))
    ed=np.unique(np.concatenate([[0],ed,[len(ts)]]))
    for a,b in zip(ed[:-1],ed[1:]):
        if b<=a: continue
        M=max(50,int(np.ceil(0.75*ts[b-1]))+3)
        out[a:b]=np.real(np.exp(1j*theta(ts[a:b]))*zeta_half(ts[a:b],M))
    r=np.empty(len(t)); r[o]=out; return r
g=np.load("gammas.npy"); CUT=1e9; sel=g<CUT; x=g[sel].copy()
known=np.array([14.134725141734693790,21.022039638771554993,25.010857580145688763,30.424876125859513210,
 32.935061587739189691,37.586178158825671257,40.918719012147495187,43.327073280914999519,
 48.005150881167159727,49.773832477672302182])
t0=time.time(); h=1e-6
for it in range(3):
    f=Z(x); x=x-f/((Z(x+h)-Z(x-h))/(2*h))
print(f"refined {len(x)} zeros below T={CUT} in {time.time()-t0:.1f}s")
print("max |EM - known| on first 10 :", np.format_float_scientific(np.abs(x[:10]-known).max(),3))
print("max |RS - known| on first 10 :", np.format_float_scientific(np.abs(g[:10]-known).max(),3))
d=x-g[sel]
print(f"RS-vs-EM shift: rms={d.std():.3e}  mean={d.mean():+.3e}  max={np.abs(d).max():.3e}")
np.save("g_hp.npy",x)
# effect on the centroid over this range
def CN(gam):
    n=len(gam); w=1-np.arange(n)/n
    return np.sum(w*np.exp(1j*gam))/1.0/n*n  # = sum w e^{i gamma}
n=len(x); w=1-np.arange(n)/n
c_rs=np.sum(w*np.exp(1j*g[sel]))/n*n/n; c_em=np.sum(w*np.exp(1j*x))/n*n/n
c_rs=np.sum(w*np.exp(1j*g[sel]))/n; c_em=np.sum(w*np.exp(1j*x))/n
print(f"\nC_N (RS zeros) = {c_rs.real:.9f} {c_rs.imag:+.9f}i")
print(f"C_N (EM zeros) = {c_em.real:.9f} {c_em.imag:+.9f}i")
print(f"|difference|   = {abs(c_rs-c_em):.3e}   <-- contamination from RS truncation")
L=0.77689426079325358+0.767855668864547j
print(f"|C_N - L|      = {abs(c_em-L):.5f}     at N={n}")
