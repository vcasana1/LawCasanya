import numpy as np
from scipy.special import lambertw

TWOPI = 2.0*np.pi
N = 2_001_052

# --- RVM Lambert levels: M(tau_k) = k - 1/2,  M(x) = (x/2pi) log(x/2pi e) + 7/8
k = np.arange(1, N+1, dtype=np.float64)
A = (k - 11.0/8.0)/np.e
tau = np.where(A > 0, TWOPI*(k-11.0/8.0)/np.real(lambertw(A, 0)), np.nan)
# k=1 gives A<0 slightly? A=(1-1.375)/e <0 -> handle first few by Newton from a seed
bad = ~np.isfinite(tau) | (tau <= 0)
tau[bad] = 14.0 + 2.0*np.arange(bad.sum())

# Newton-refine in long double so that M(tau_k) = k-1/2 to full precision
tau = tau.astype(np.longdouble)
kl  = k.astype(np.longdouble)
TP  = np.longdouble(2)*np.longdouble(np.pi)
for _ in range(4):
    f  = (tau/TP)*np.log(tau/(TP*np.e)) + np.longdouble(7)/8 - (kl - np.longdouble(0.5))
    fp = np.log(tau/TP)/TP
    tau = tau - f/fp
resid = float(np.max(np.abs((tau/TP)*np.log(tau/(TP*np.e)) + np.longdouble(7)/8 - (kl-np.longdouble(0.5)))))
T = float(tau[-1])
print(f"N = {N},  tau_N = {T:.6f},  max |M(tau_k)-(k-1/2)| = {resid:.3e}")
print(f"log(T/2pi) = {np.log(T/TWOPI):.6f}   sqrt(N) = {np.sqrt(N):.3f}")

# --- carrier exponential sum  Sigma_k exp(i t tau_k),  t = alpha * log(T/2pi)
L = np.longdouble(np.log(T/TWOPI))
def carrier(alpha):
    t = np.longdouble(alpha)*L
    ph = t*tau
    ph = ph - TP*np.floor(ph/TP)          # exact-ish reduction in long double
    ph = ph.astype(np.float64)
    return abs(np.sum(np.exp(1j*ph)))

print("\n alpha |   t=a*log(T/2pi) |   |S_tau(t)|    | ratio to sqrt(N)")
print("-"*66)
for a in [0.05,0.1,0.2,0.3,0.5,0.7,0.9,1.0,1.1,1.25,1.5,1.75,2.0,2.5,3.0]:
    S = carrier(a)
    print(f" {a:5.2f} | {float(a*L):15.4f} | {S:13.2f}  |  {S/np.sqrt(N):10.3f}")
