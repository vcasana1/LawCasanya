import numpy as np
from scipy.special import lambertw
TWOPI=2*np.pi
g=np.load("gammas.npy"); N=len(g); T=g[-1]; sN=np.sqrt(N)
k=np.arange(1,N+1,dtype=np.float64); A=(k-11/8)/np.e
tau=np.where(A>0,TWOPI*(k-11/8)/np.real(lambertw(A,0)),14.0).astype(np.longdouble)
kl=k.astype(np.longdouble); TP=np.longdouble(2)*np.longdouble(np.pi)
for _ in range(4):
    f=(tau/TP)*np.log(tau/(TP*np.e))+np.longdouble(7)/8-(kl-np.longdouble(.5)); tau-=f/(np.log(tau/TP)/TP)
gl=g.astype(np.longdouble)
ts=np.arange(0.30,4.001,0.0025)
def scan(seq):
    out=np.empty(len(ts))
    for i,t in enumerate(ts):
        ph=np.longdouble(t)*seq; ph-=TP*np.floor(ph/TP)
        out[i]=abs(np.sum(np.exp(1j*ph.astype(np.float64))))
    return out/sN
Sz=scan(gl); St=scan(tau)
np.savez("scan.npz",ts=ts,Sz=Sz,St=St,N=N,T=T)
print(f"N={N} T={T:.0f} sqrt(N)={sN:.1f}")
print(f"zeta : max={Sz.max():.2f} at t={ts[Sz.argmax()]:.4f} (log5={np.log(5):.4f}) | median={np.median(Sz):.4f}")
print(f"carrier: max={St.max():.3f} | median={np.median(St):.4f}")
print(f"ratio of medians (zeta/carrier) = {np.median(Sz)/np.median(St):.2f}")
