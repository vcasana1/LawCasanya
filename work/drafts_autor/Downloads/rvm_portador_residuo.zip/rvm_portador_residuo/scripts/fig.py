import numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
d=np.load("scan.npz"); ts,Sz,St,N,T=d["ts"],d["Sz"],d["St"],int(d["N"]),float(d["T"])
L=np.log(T/(2*np.pi))
INK="#1a1a1a"; MUT="#8a8a8a"; C1="#0b6fa4"; C2="#c8681c"; GRID="#e6e6e6"
fig,ax=plt.subplots(figsize=(11,5.4),dpi=170)
pp={2:2,3:3,4:2,5:5,7:7,8:2,9:3,11:11,13:13,16:2,17:17,19:19,23:23,25:5,27:3,29:29,31:31,32:2,37:37,41:41,43:43,47:47,49:7}
for x in pp:
    t=np.log(x)
    if ts[0]<=t<=ts[-1]: ax.axvline(t,color=GRID,lw=0.9,zorder=0)
ax.set_yscale("log")
ax.plot(ts,np.maximum(St,4e-4),color=C2,lw=1.15,label=r"portador RVM   $|\sum_k e^{it\tau_k}|/\sqrt{N}$",zorder=3)
ax.plot(ts,np.maximum(Sz,4e-4),color=C1,lw=1.15,label=r"ordenadas zeta   $|\sum_k e^{it\gamma_k}|/\sqrt{N}$",zorder=4)
for x,lab in [(2,"2"),(3,"3"),(4,"4"),(5,"5"),(7,"7"),(9,"9"),(11,"11"),(13,"13"),(17,"17"),(19,"19"),(23,"23"),(29,"29"),(31,"31"),(37,"37"),(41,"41"),(43,"43"),(47,"47")]:
    t=np.log(x); i=np.argmin(abs(ts-t))
    ax.annotate(lab,(t,Sz[i]*1.35),ha="center",fontsize=7.5,color=MUT,zorder=5)
ax.axhline(1.0,color=INK,lw=0.8,ls=(0,(5,3)),zorder=2)
ax.annotate(r"objetivo de Montgomery  $|S|\sim\sqrt{N}$",(3.93,1.15),ha="right",fontsize=8.5,color=INK)
ax.set_xlim(ts[0],ts[-1]); ax.set_ylim(4e-4,40)
ax.set_xlabel(r"frecuencia  $t=\log x$      (Montgomery: $\alpha=t/\log(T/2\pi)$)",fontsize=10)
ax.set_ylabel(r"$|S(t)|\,/\,\sqrt{N}$",fontsize=10)
sec=ax.secondary_xaxis("top",functions=(lambda t:t/L,lambda a:a*L))
sec.set_xlabel(r"$\alpha$",fontsize=10); sec.tick_params(labelsize=8.5)
ax.set_title("Toda la aritmética vive en el residuo. El portador RVM es ciego.",fontsize=12.5,pad=26,loc="left",color=INK)
ax.tick_params(labelsize=8.5); [s.set_color(MUT) for s in ax.spines.values()]
ax.spines["top"].set_visible(False); ax.spines["right"].set_visible(False)
ax.legend(frameon=False,fontsize=9,loc="lower right")
ax.annotate(f"picos de Landau en $x=p^m$, altura $(T/2\\pi)\\Lambda(x)x^{{-1/2}}$\nN={N} ceros,  T={T:.0f}",
            (0.33,12),fontsize=8,color=MUT,va="top")
plt.tight_layout(); plt.savefig("carrier_blind.png",bbox_inches="tight",facecolor="white")
print("ok")
