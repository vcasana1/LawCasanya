# Portador RVM vs. residuo: qué parte de la suma exponencial sobre ordenadas zeta lleva la aritmética

Paquete de reproducción. Todo lo de aquí se genera desde cero con `numpy` + `scipy`
(no se usa ninguna tabla externa de ceros: se calculan).

Contexto: acompaña al trabajo de V. Casaña-Giner sobre el centroide triangular
`C_N` de la caminata exponencial sobre las ordenadas de los ceros no triviales de
zeta y el reloj de Riemann–von Mangoldt (RVM / Lambert).

---

## 0. Convenios

    reloj exacto        H(t) = 1 + theta(t)/pi          (theta = Riemann-Siegel)
    reloj liso RVM      M(t) = (t/2pi) log(t/2pi e) + 7/8
    niveles Lambert     M(tau_k) = k - 1/2   =>   tau_k = 2pi(k-11/8)/W_0((k-11/8)/e)
    argumento medio     S_*(gamma_k) = k - 1/2 - H(gamma_k)
    discrepancia        eps_k = gamma_k - tau_k
    caminata            S_N = sum_{k<=N} e^{i gamma_k}
    centroide           C_N = (1/N) sum_{k<=N} (N-k+1) e^{i gamma_k}
                            = sum_{k<=N} (1 - (k-1)/N) e^{i gamma_k}

    diccionario de frecuencias:   t = log x = alpha * log(T/2pi)
                                  (alpha = variable de Montgomery)

`C_N` se evalúa en `t = 1`, es decir `x = e`, es decir **alpha = 1/log(T/2pi) -> 0**.

---

## 1. Datos calculados

**Ceros.** 22 491 ordenadas en `0 < gamma <= 19999.3`.

- Localización: barrido de la función `Z` de Riemann–Siegel (término principal +
  corrección `C_0`), paso 0.02, detección de cambios de signo, bisección.
- Recuento: 22 491 frente a `N(T) = 22491.4` de Riemann–von Mangoldt (dif. −0.4),
  es decir **no se pierde ningún cero**.
- Refinado: Newton sobre `Z(t) = e^{i theta(t)} zeta(1/2+it)` con `zeta` por
  Euler–Maclaurin (`M = ceil(0.75 t)+3`, 12 términos de Bernoulli).
- Precisión verificada contra los 10 primeros ceros conocidos a alta precisión:
  **max |error| = 8.9e-15** (antes del refinado, Riemann–Siegel solo: 7.5e-3).

Ficheros: `data/gammas.npy` (Riemann–Siegel), `data/g_hp.npy` (refinados).

**Reloj RVM.** `tau_k` por Lambert W + 4 pasos de Newton, con
`max |M(tau_k) - (k-1/2)| = 4.5e-13` en `k <= 2 001 052`.

**Precisión de fase.** Las fases `t*gamma` llegan a ~4e7. Todas las sumas
coherentes se hacen reduciendo `t*x mod 2pi` en `numpy.longdouble` (80 bits)
antes de bajar a `complex128`.

---

## 2. Resultados

### 2.1 El portador RVM es aritméticamente ciego

`output/05_spikes.txt`, `figures/carrier_blind.png`

En `x = p^m` la suma sobre ordenadas reproduce la fórmula de Landau
`(T/2pi) Lambda(x) x^{-1/2}` a 3–4 cifras significativas:

| x  | t=log x | \|S_zeta\|/√N | \|S_tau\|/√N | Landau/√N |
|----|---------|---------------|--------------|-----------|
| 2  | 0.69315 | 10.387        | 0.008        | 10.403    |
| 3  | 1.09861 | 13.458        | 0.020        | 13.462    |
| 5  | 1.60944 | 15.273        | 0.031        | 15.276    |
| 7  | 1.94591 | 15.604        | 0.045        | 15.610    |
| 13 | 2.56495 | 15.079        | 0.061        | 15.099    |
| 6  | 1.79176 | 0.013         | 0.018        | 0 (no p^m)|

El portador `sum e^{i t tau_k}` da 0.008–0.147 **en todo el rango**, sin ninguna
estructura en los puntos aritméticos.

Lectura: en la factorización exacta `e^{i t gamma_k} = e^{i t tau_k} e^{i t eps_k}`
toda la aritmética vive en `eps_k` y nada en `tau_k`.

### 2.2 Ley de sillas del portador (fase estacionaria)

`output/04_saddle.txt`

Empíricamente, con `n = ceil(alpha)`:

    | sum_{k<=N} e^{i t tau_k} |  ~  t * exp(t/(2n)) / n^{3/2}

con puntos de silla en `tau = 2pi e^{t/n}`. Verificado en `N = 2 001 052`,
`alpha` en [0.3, 2.9]: cociente medido/predicho en **[0.83, 1.20]**, casi siempre
dentro del 5 %. La silla `n` sale del rango de sumación cuando `alpha` cruza `n`,
lo que produce el colapso observado en `alpha = 1, 2, 3`.

Consecuencia asintótica:

    |S_tau| / sqrt(N)  ~  alpha * n^{-3/2} * (log T')^{1/2} * (T')^{alpha/(2n) - 1/2},
    T' = T/2pi

El exponente es `<= 0`, con igualdad solo en `alpha` entero. Para `alpha` fijo no
entero el portador es **o(sqrt N)**.

Interpretación: es el análogo arquimediano exacto del teorema de Landau. Landau
tiene resonancias en puntos aritméticos `x = p^m`; el portador RVM las tiene en las
sillas arquimedianas `tau = 2pi e^{t/n}`, para todo `t`, sin condición aritmética.

### 2.3 Umbral de linealización del residuo

`output/06_residual.txt`

Identidad verificada: `eps_k ≈ -2pi S_*(gamma_k)/log(gamma_k/2pi)`.
`rms(eps) = 0.26366`; `rms(-2pi S_*/log)` = 0.26366 (coincide a 5 decimales);
desviación máxima del término de 2.º orden = 0.0041.

| alpha | t | rms(t·eps) rad | \|media e^{i t eps}\| | media\|e^{i t eps}−1\| |
|-------|-------|------|--------|--------|
| 0.124 (x=e) | 1.000 | 0.264 | 0.9658 | 0.2114 |
| 0.500 | 4.033 | 1.063 | 0.5610 | 0.7834 |
| 1.000 | 8.066 | 2.127 | 0.0800 | 1.2051 |
| 1.500 | 12.098| 3.190 | 0.0029 | 1.2739 |
| 2.000 | 16.131| 4.253 | 0.0032 | 1.2745 |

Referencia de fase uniforme: `|media| = 0`, `media|e^{i.}−1| = 4/pi = 1.2732`.

A `t = 1` el residuo es una perturbación coherente del 21 %. A `alpha >= 1` es
indistinguible de fase uniforme: la descomposición pasa de ser una perturbación a
ser un producto de dos secuencias independientes.

### 2.4 Tasa de convergencia del centroide

`output/08_convergence.txt`, `output/09_law.txt`, `figures/rate.png`

Con `L = 0.77689426079325358 + 0.767855668864547 i`
(parte real = forma cerrada `(1/2 sqrt e)(e − 1/(e²−1))`, confirmada a 16 cifras;
parte imaginaria = `B(1).im + P(1).im` del paper):

    |C_N - L| * N/log N  sobre N en [300, 22491]:
        media 1.145,  sd 0.259,  min 0.666,  max 1.764,  sin tendencia
        (1.ª mitad 1.124   2.ª mitad 1.165)

Comparación de ajustes (`sd/media`, menor es mejor):

    |C_N-L| * N/log N   ->  0.23   <-- mejor
    |C_N-L| * N         ->  0.27
    |C_N-L| * N^{1/2}   ->  0.53   (cancelación de raíz, tipo GUE)
    |C_N-L| * 1         ->  1.10

Extrapolación 90× hasta `N = 2 001 052`: la ley predice `8.3e-6`. El paper mide
allí `8.7162e-6` para `|C_N − Q_N^{(H)}|` y `1.29e-5` para la discrepancia de la
coordenada real; ambos caen en la banda `[4.8e-6, 1.3e-5]` que da el coeficiente
observado.

La tasa observada es de orden `log N / N`, no `N^{-1/2}`. Es el mismo orden que el
`O((log N)²/N)` que el Teorema 6.4 del paper demuestra **incondicionalmente** para
el reloj liso.

### 2.5 Divergencia de la serie de primos en sigma = 1/2

`output/09_law.txt`

La serie del transformado unilateral (ec. 8.2 del paper) evaluada en `sigma = 1/2`:

    sum_n Lambda(n) / ( sqrt(n) log n |1 - log n| )

sumas parciales: 11.834 (X=1e2), 15.709 (1e4), 29.040 (1e6), 33.477 (2e6).
Diverge como `2 sqrt(X)/log² X`. `P_{inf,1/2}` existe solo como límite `sigma -> 1/2+`.

---

## 3. Limitaciones (leer antes de usar)

- Las secciones 2.1, 2.3, 2.4 usan `T ≈ 2e4`, o sea `log(T/2pi) = 8.07`. El barrido
  de frecuencias en `figures/carrier_blind.png` llega a `t = 4`, es decir solo
  **alpha = 0.44**. No hay dato directo en el régimen `alpha > 1` de Montgomery.
- La ley `log N/N` de 2.4 es **empírica** en `N <= 22491`, no un teorema. La
  extrapolación al `N` del paper es consistente pero no es demostración.
- `L` es el valor **condicional** del paper (bajo RH + Hipótesis 7.3 para la parte
  real, + Hipótesis 8.2 para la compleja). Que `C_N` converja siquiera es problema
  abierto.
- La ley de sillas de 2.2 es un ajuste de fase estacionaria contrastado
  numéricamente; la derivación rigurosa (Poisson + puntos de silla con control del
  término de error y del borde `k = N`) no está escrita aquí.
- Nada en este paquete demuestra la conjetura de Montgomery ni afecta a su estado.
  2.1 y 2.3 son evidencia de que la descomposición RVM no transporta información
  aritmética a la escala de frecuencia donde vive esa conjetura.

---

## 4. Scripts

Ejecutar en este orden (`bash runall.sh` lo hace):

| script | qué hace | salida |
|--------|----------|--------|
| `zeros.py`    | localiza 22 491 ceros por Riemann–Siegel | `01_zeros.txt`, `gammas.npy` |
| `refine2.py`  | refina a 1e-14 por Euler–Maclaurin + Newton | `02_refine.txt`, `g_hp.npy` |
| `carrier.py`  | portador RVM `N=2 001 052` vs alpha | `03_carrier.txt` |
| `saddle.py`   | contrasta la ley de sillas | `04_saddle.txt` |
| `spikes.py`   | tabla de Landau en `x = p^m` | `05_spikes.txt` |
| `residual.py` | estadística de `eps_k` y decoherencia | `06_residual.txt` |
| `scan.py`     | barrido fino de ambas sumas | `07_scan.txt`, `scan.npz` |
| `conv.py`     | tabla de convergencia de `C_N` | `08_convergence.txt` |
| `law.py`      | ajuste de la ley + serie de primos | `09_law.txt` |
| `fig.py`      | figura 1 | `carrier_blind.png` |
| `fig2.py`     | figura 2 | `rate.png` |

Dependencias: `numpy`, `scipy`, `matplotlib`. Tiempo total ≈ 4 min.
`carrier.py` y `saddle.py` reservan ~500 MB (arrays de 2e6 en `longdouble`).
