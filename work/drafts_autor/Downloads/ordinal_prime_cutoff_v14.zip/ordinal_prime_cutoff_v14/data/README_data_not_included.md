zeross.bin and zLamb.bin are not included (2 x 16 MB).
Regenerate them from Odlyzko's table zeros6 with code/make_inputs_v14.py (see README.md).
SHA-256: zeross.bin fafb9436ce6a506de58c96c9bc9765d3942de3f15c921e99e0015b3e945fe0ac
         zLamb.bin  b4c6758f0aef3724d3345f894ff82d5bbcb0f6139025b8b266091f713faa9504
