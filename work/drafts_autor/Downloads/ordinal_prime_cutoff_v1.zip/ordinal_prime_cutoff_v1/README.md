# ordinal_prime_cutoff_v1

An improvement of the França–LeClair approximation of the Riemann zeros with a variable number of primes (Rotkiv Aynäsac, version 1).

- manuscript/ordinal_prime_cutoff_v1.tex (single self-contained file; .txt is an identical copy) and the compiled PDF.
  Build: cd manuscript && pdflatex ordinal_prime_cutoff_v1.tex (three passes; figures are read from ../figures/).
  Hover tooltips: python3 ../tools/make_tips.py ordinal_prime_cutoff_v1.tex ordinal_prime_cutoff_v1.aux tips.tex && python3 ../tools/replace_tips.py ordinal_prime_cutoff_v1.tex tips.tex, then three more passes.
- code/opc_analysis.py (also as .txt): produces every table (outputs/) and figure (figures/) of the paper. Usage: python3 code/opc_analysis.py [data_dir]
- outputs/: CSV tables A-E, close-pair report and run log.
- data/: NOT INCLUDED. The run needs data/zeross.bin (ordinates gamma_k) and data/zLamb.bin (clock tau_k),
  2,001,052 little-endian float64 values each (16 MB each), excluded from this zip because of their size.
