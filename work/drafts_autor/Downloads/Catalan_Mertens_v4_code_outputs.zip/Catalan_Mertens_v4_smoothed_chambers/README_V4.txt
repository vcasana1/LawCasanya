CATALAN MERTENS V4

Main paper:
  paper/Catalan_Mertens_v4_catalan_selector_audit.tex
  paper/Catalan_Mertens_v4_catalan_selector_audit.pdf

Version 4 preserves the full introduction, Catalan theory, physical routes,
bibliography, numerical outputs, and Python appendices.  It removes the
prime-dilation alignment proposal from the proof route and adds three explicit
no-go results: Catalan universality, redundant prime lifting, and the stability
floor for smoothed chambers.

New finite audit:
  code/catalan_no_go_audit_v4.py
  outputs/catalan_no_go_audit_v4.json

The audit verifies primitive counts C_(n-1) for semilengths 1 through 7 and
the prime-shell identity through 5000.  These finite checks are not asymptotic
evidence for RH.
