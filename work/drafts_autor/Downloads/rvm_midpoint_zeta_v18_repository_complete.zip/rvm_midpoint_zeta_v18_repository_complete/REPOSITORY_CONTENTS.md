# Repository contents

This package is intentionally self-contained for compilation, numerical reproduction, and archival publication.

## Manuscript
- `rvm_zeta_pi_mertens_v18.tex`
- `rvm_zeta_pi_mertens_v18.txt`
- `rvm_zeta_pi_mertens_v18.pdf`
- 
## Figures
All PNG figures referenced by the manuscript are in `figures/`.

## Main reproducibility code
`code/` contains the curated Python reproduction programs `s01` through `s13` and `rvm_common.py`.
The scripts are written in English and use the binary ordinate data in `data/`.

## Raw data
- `data/zeross.bin`: genuine zeta-zero ordinates used only where explicitly documented, including diagnostics.
- `data/zLamb.bin`: midpoint RVM ordinates.

## Main generated outputs
`output/` contains CSV, MAT, binary, and console outputs used by the numerical section.

## Supplementary numerical work
`supplementary/post_v17_numerics/` contains the later bounded-section and nested-metric scripts, CSV files, and figures from the continuation of the numerical investigation.
These are supplementary diagnostics and are not silently promoted to proved statements in the paper.

## Recovered Claude/session files
`recovered_claude/` contains locally recovered scripts and outputs associated with the finite-section experiments, plus a SHA256 recovery manifest.
`supplementary/exploracion_ruta_theta_eps/` contains the uploaded theta/epsilon exploration extracted in full, including its output text files.

## Raw MATLAB material
`supplementary/raw_matlab/` preserves the three raw MATLAB snippets supplied in the conversation. They are archival inputs, not the curated publication scripts.

## Original archives
`archives/` keeps the original uploaded theta/epsilon and theta-half experiment ZIPs and the ordinary v18 release snapshot.

## Previous complete releases
`previous_versions/` contains the complete v15 and v16 ZIP packages.

## Build
Run `./build_pdf.sh` or `make pdf` from the repository root.
Run `./run_all_python.sh` for the curated Python numerical suite.

## Integrity
`MANIFEST_SHA256.txt` gives SHA256 hashes of every file except the manifest itself.
