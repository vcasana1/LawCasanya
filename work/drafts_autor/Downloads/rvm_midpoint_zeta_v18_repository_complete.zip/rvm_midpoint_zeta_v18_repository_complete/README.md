# The midpoint Riemann-von Mangoldt synthetic zeta system

Paper, code, data and results for

> Rotkiv Aynäsac, *The midpoint Riemann-von Mangoldt synthetic zeta system: canonical products,
> exponential sums, prime counts, Mertens transforms, and the transformation to zeta_Z1* (9 October 2026).

## What is constructed

* The **midpoint clock** `N_RVM(T) = T/(2 pi) log(T/(2 pi e)) + 7/8` is the smooth part of the
  Riemann-von Mangoldt formula `N(T) = N_RVM(T) + S(T) + O(1/T)`.  Its **midpoint ordinates**
  `tau_k` solve `N_RVM(tau_k) = k - 1/2`; in closed form
  `tau_k = 2 pi (k - 11/8) / W_0((k - 11/8)/e)` with the principal Lambert branch `W_0`.
* `zeta_RVM(s) = prod_k (1 + s(s-1)/(1/4 + tau_k^2)) / G(s)`, `G(s) = s(s-1) Gamma(s/2) pi^(-s/2)`,
  with zeros exactly at `1/2 +- i tau_k`.
* Prime coordinate: `J_RVM` (explicit formula with the `tau_k`), `pi_RVM` (finite Moebius
  inversion), cell masses `c_n = pi_RVM(n) - pi_RVM(n-1)`, real RVM prime levels `pi_RVM(p_j) = j`.
  Unconditionally `pi_RVM(x) - li(x) = O(sqrt(x) (log log x)^2 / log x)`, so `li/pi_RVM -> 1`; with the
  prime number theorem also `pi/li -> 1` and `pi/pi_RVM -> 1`.
* Mertens coordinate: `M_RVM^crit`, inverse Mellin transform of `1/zeta_RVM`, with
  `M_RVM^crit(x) = L + O(x^(1/2+eps))`, `L = 1/varpi_RVM`, `varpi_RVM = 0.9619415807...`;
  its ternary integer version `M_h` with values of `mu_h` in `{-1, 0, +1}` on the squarefree support.
* The **lambda-family**: ordinates `gamma_k(lambda) = (1 - lambda) gamma_k + lambda tau_k`,
  `zeta_1 = zeta_RVM`, `zeta_0 = zeta_Z1`; all zeros stay on `Re s = 1/2`.  The final step of the
  method is the identity `zeta_Z1 = zeta`, equivalently `prod_k (1/4+gamma_k^2)/(1/4+tau_k^2) = varpi_RVM`; the paper proves that it implies `M(x) = O(x^(1/2+eps))`
  (Step 3) and that it is equivalent to Hamburger's condition (D).  The identity itself is not proved.
* Criteria for the final step (Section 14 of the paper): no `zeta_lambda` with `0 < lambda <= 1` is a
  Dirichlet series; `log zeta_lambda(sigma)` is strictly convex in `lambda` for real `sigma > 1`;
  Hamburger's theorem applies to the pair `(zeta_lambda, atomized zeta_lambda)` when the joining factor is
  symmetric under `s -> 1-s`; (D) holds exactly when `zeta_Z1` is the Mellin-Stieltjes transform of a
  positive measure.  At the clock end the density of `d pi_RVM` is
  `1/log y + 2 cos(2 pi y) - 2^(-1/2) y^(-1/4) cos(4 pi sqrt(y) + pi/4) + O(y^(-1/3))`.
* Existence form of the final step (Section 15): for every list of ordinates within a bounded distance of
  the clock one builds the continuous zeta function and its atomization; at most one list has the two
  coinciding, and such a list exists exactly when `zeta_Z1 = zeta`.  Further proved criteria:
  `zeta_Z1(sigma) >= zeta(sigma)` for real `sigma > 1`; Hamburger's theorem for the pair in theta form and
  in vertical mean-square form; the value at infinity as one number from the summation formula.
* Criteria written where the joining factor is defined (Section 14, Subsections 14.9-14.13):
  (D) holds exactly when every cell mass at `lambda = 0` is the indicator of the primes; the ladder
  (`h_lambda(sigma) = O(sigma N^(-sigma))` exactly when the prime-power count of `zeta_lambda` has no mass
  outside the integers below `N`); the bridge theorem in phase form (if the imaginary part of the joining
  factor vanishes on the critical line and the factor is temperate, then the atomized function is `zeta`;
  the two conditions hold for no `lambda > 0` and are equivalent to (D) at `lambda = 0`); the transport
  from the clock on each cell as an entire function of `lambda`, with its moment series on the clock and
  the exact defect of the clock by Poisson summation.
* Rung system with free masses (Section 15): (D) is equivalent to the solvability of
  `sum_k cos(kappa_k u) + sum_n a_n delta(u - log n) = k(u)` in the space of lists; the solution is then
  unique, its masses are `log p / (2 sqrt n)` at prime powers, and it is nondegenerate.
* Multiscale Jacobian at the clock (new in v16, retained in v18): with `Delta_T` the minimum midpoint-clock gap below height `T`,
  `Delta_T >= 2 pi / log(T/(2 pi))`.  The finite ordinate linearization has a lower Ingham frame bound on
  windows of length `(1+varkappa_win) log(T/(2 pi))`; no height-uniform lower bound can hold on a fixed window; the
  infinite clock linearization has dense range on every finite window; and every smooth bounded-displacement
  transport tail is `O_A(T^(1-A) log T)`.  This uses only the midpoint clock, not the genuine zeta ordinates or
  the individual displacements.  The multiscale bounds are diagnostic stability results only; they do not provide an existence or continuation theorem, and v18 does not present them as a route to (D).
* Models without zeta (Section 16): the acceptance criterion (window and frequencies); a non-periodic
  list accepted through one unitary matrix; the finite Euler products `prod_{p <= X} (1 - p^(-s))`, to
  which the constructions of the paper apply and for which the final step is a theorem; the diagonal
  operator over all primes and its three abscissas.
* Proved / not proved: every statement of the paper is proved except the identity `zeta_Z1 = zeta`
  (equivalently (D) and the criteria listed in Subsection 1.4 of the paper), which is the open step.
  The experiments are computations and are not part of any proof.


## v18 correction release

Version 18 is a systematic correction and consistency release of v17. It applies the full mathematical, convergence, domain, reference, and notation audit supplied after v17 rather than merely appending a status note. In particular it:

* fixes the midpoint-clock branch statement at `k=1`, the atomic jumps of `pi_RVM`, the power-of-two cell terms, the entire extension in `lambda`, the transition constants, and the ordered (not absolutely convergent) endpoint product;
* makes the branch, Mellin/Stieltjes, compactness, limiting, and termwise-differentiation hypotheses explicit where they are used;
* corrects the status of Step 3, the transfer statement, the cell-form hypotheses, and the critical-point language on the product-topology space of lists;
* performs a full notation-collision pass, separating global clock ordinates, Perron heights, local stationary heights, test bumps, displacement symbols, and list variables;
* documents the previously omitted multiscale and bounded-section programs/outputs and corrects the description of the failed linearized clock experiment: the exploding variables there were the ordinate-direction coefficients, not endpoint masses;
* retains the three interpolation diagnostics only as structural information. The exact-atomic interpolation has no established interior path; the additive interpolation is a level-set reformulation through `zeta/zeta_RVM`; neither is presented as a route proving (D);
* adds an a-priori bounded-displacement proposition for any exact rung-system solution satisfying the stated local-density hypothesis. This is an a-priori theorem only; it is not an existence theorem for an intermediate exact-atomic path.

The autonomous clock-injectivity problem remains a legitimate rigidity problem about the midpoint clock. The identity `zeta_Z1 = zeta`, equivalently (D) and RH, remains open. Version 18 does not claim a continuous exact path from the clock to zeta.

The directory `recovered_claude/` contains the locally recovered scripts and CSV files whose filenames, timestamps, and contents match the finite-section calculations attributed to Claude in the conversation. The filesystem contains no model-author provenance tag, so the grouping is evidential rather than cryptographically attributable. A SHA256 manifest is included. The uploaded theta/epsilon exploration is preserved verbatim and extracted under `supplementary/`.

`code/s13_nested_bounded_endpoint.py` is a clean English-only reproduction of the nested bounded endpoint experiment. It uses `zLamb.bin` as the autonomous input and reads `zeross.bin` only after solving, if available, for diagnostics.

## Repository layout

```
rvm_zeta_pi_mertens_v18.tex   the paper (single file); .txt is an identical copy, .pdf the compiled paper
code/      Python programs (s01 ... s13; s11 reproduces the recent MATLAB difference analysis)
data/      zeross.bin and zLamb.bin (included in this complete repository bundle)
output/    stored console output, CSV, MAT and binary results used by the paper; very large derived files such as `s05_walks.csv` are regenerated by the corresponding script rather than stored redundantly
figures/   PNG figures used by the paper
```

## Data format

The two binary files are included in `data/` in this complete repository bundle. Both are raw little-endian IEEE float64 arrays, one ordinate per entry, sorted:

* `zeross.bin`: `gamma_1 = 14.134725142, ..., gamma_2001052 = 1132490.658714`
* `zLamb.bin`: `tau_1 = 14.521346953, ..., tau_2001052 = 1132490.722588`,
  `max |N_RVM(tau_k) - (k - 1/2)| = 7.0e-10`

## Running

```
pip install -r code/requirements.txt
cd code
python3 s01_clock_and_family.py
python3 s02_transition.py
python3 s03_exponential_sums.py
python3 s04_primes.py
python3 s05_mertens.py
python3 s06_prime_ratios.py
python3 s07_product_identity.py
python3 s08_transport_moments.py
python3 s09_clock_defect_split.py
python3 s10_clock_to_zeros.py
python3 s11_rvm_z1_difference_analysis.py
python3 s12_multiscale_jacobian.py
python3 s13_nested_bounded_endpoint.py
```

The original s01--s10 run in a few minutes on two cores.  `s11` is a direct Python reproduction of the
recent MATLAB `RVM_Z1_DIFFERENCE_ANALYSIS` calculation (x <= 100000, K snapshots, shell contributions and
running normalized suprema) and is substantially heavier; it requires the two binary ordinate files.
`s12` is clock-only, requires no external data, and reproduces the new multiscale-gap calculations and
Figures 14--15.  To rebuild the paper, run `pdflatex rvm_zeta_pi_mertens_v18.tex` three times in the
top-level directory; the figures are read from `figures/`.  Required LaTeX packages: amsart, amsmath,
mathrsfs, mathtools, longtable, booktabs, graphicx, listings, xcolor, hyperref, bookmark, pdfcomment.

## Main numerical results (from `output/*_console.txt`)

| quantity | value |
|---|---|
| `max_k |tau_k - gamma_k|` over 2,001,052 zeros | 0.9937 |
| `max |zeta_Z1/zeta - 1|`, `sigma = 2, 1.25, 0.75`, `t <= 2000` | 8.7e-10, 1.1e-9, 2.6e-9 |
| `varpi_RVM` (Richardson) | 0.9619415807 |
| `max_N |sum_{k<=N} 2^(i tau_k)|` | 3.57 |
| `|sum_{k<=N} 2^(i gamma_k)|` at `N = 2,001,052` (Landau: 88,342) | 88,301 |
| `pi_RVM(100)`, `pi(100)`, `li(100)` | 26.08, 25, 30.13 |
| `pi_RVM(1000)`, `pi(1000)`, `li(1000)` | 169.98, 168, 177.61 |
| `li/pi_RVM`, `pi/li`, `pi/pi_RVM` at `x = 1000` | 1.045, 0.946, 0.988 |
| `max |pi_RVM - li| / (sqrt(x)(log log x)^2/log x)` on `[500, 1000]` | 0.72 |
| `prod_{k<=N} (1/4+gamma_k^2)/(1/4+tau_k^2)` (zeta_Z1 = zeta exactly when the limit is `varpi_RVM`) | 0.9619415390 |
| densities of `-1, 0, +1` for `mu_h`, `n <= 10^6` | 0.304003, 0.392074, 0.303923 |
| `max |M_h - M_RVM^crit|`, `10^4 <= n <= 10^6` | 1.65 |
| first rung, test function on `[0.10, 0.62]`: defect of the clock `R_f(1)` | -0.042463282161 |
| first rung: transport `S_f(0)` from the clock to the zeros | -0.042463282147 |
| first rung: share of the first moment, of the first two moments | 95.1 %, 100.8 % |
| rung system solved from the clock: `max |solution - gamma_k|`, `k <= 10` | 4.4e-4 |
| rung system solved from the clock: `max |a_n - log p/(2 sqrt n)|`, `n <= 11` | 7.9e-4 |
| multiscale clock, `K = 2,001,052`: minimum gap / rigorous lower bound | 0.51918344 / 0.51918343 |
| multiscale clock, `K = 2,001,052`: `2 pi / Delta_T` / `log(T/(2 pi))` | 12.102053 / 12.10205288 |

## Complete repository package note

This distribution is the **complete** v18 repository bundle: unlike the smaller archival ZIP,
it includes `zeross.bin` and `zLamb.bin`, all figures needed to compile the paper, the main
Python scripts, stored numerical outputs, the recovered finite-section scripts/results, the
uploaded theta/epsilon exploration, later post-v17 numerical diagnostics incorporated into v18, and build helpers.
No separate data download is required to compile the paper or run the included scripts.
