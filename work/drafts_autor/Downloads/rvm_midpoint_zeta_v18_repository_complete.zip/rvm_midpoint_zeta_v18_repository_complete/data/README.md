# Raw ordinate data

This complete repository package includes both raw arrays required by the numerical programs.
They are little-endian IEEE float64 arrays with 2,001,052 entries each, sorted by ordinate.

- `zeross.bin`: ordinates gamma_k of the nontrivial zeros of the Riemann zeta function.
- `zLamb.bin`: midpoint RVM ordinates tau_k satisfying N_RVM(tau_k) = k - 1/2.

Canonical first values:

- gamma_1 = 14.134725142...
- tau_1 = 14.521346953...

The scripts in `code/` expect these exact filenames in this directory.
