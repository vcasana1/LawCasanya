# Build and reproduction

This is the complete repository package for version 18.

## Paper

The PDF is already included. To rebuild it from source:

```bash
./build_pdf.sh
```

or:

```bash
make pdf
```

The build runs `pdflatex` three times so the table of contents, cross-references,
back-references and hover annotations are resolved. All PNG figures required by
the TeX source are included in `figures/`.

## Numerical programs

Create a Python environment and install:

```bash
python3 -m pip install -r code/requirements.txt
```

The raw ordinate data used by the programs are included in `data/`:

- `data/zeross.bin`
- `data/zLamb.bin`

Then run individual scripts from `code/`, or run all main programs with:

```bash
./run_all_python.sh
```

Generated tables are written to `output/` and figures to `figures/`.

## Supplementary material

- `recovered_claude/`: locally recovered finite-section scripts/results from the conversation session.
- `supplementary/exploracion_ruta_theta_eps/`: the uploaded theta/epsilon exploration, extracted in full.
- `supplementary/post_v17_numerics/`: later bounded/nested numerical diagnostics, scripts, CSV files and figures.
- `supplementary/reference/`: development notes and the original RVM/Z1 difference-analysis text.
- `archives/`: original uploaded supplementary ZIP archives.
- `previous_versions/`: complete v15 and v16 release ZIPs.
- `supplementary/raw_matlab/`: raw MATLAB snippets preserved from the conversation.

## Integrity

`MANIFEST_SHA256.txt` contains SHA256 hashes for every file in this package except the manifest itself.
