#!/usr/bin/env python3
"""Generate the two English-language figures used by the manuscript.

The arithmetic surface is
    F(n,r) = sum_{a|n, a>r} mu(n/a),
for integers n >= 1 and r >= 0.

Outputs in the current directory:
    mobius_heatmap_N80_en.png
    mobius_surface_3d_N200_en.png
"""
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt


def mobius_sieve(N: int) -> np.ndarray:
    """Return mu[0..N]."""
    mu = np.ones(N + 1, dtype=int)
    mu[0] = 0
    is_prime = np.ones(N + 1, dtype=bool)
    is_prime[:2] = False
    for p in range(2, int(N ** 0.5) + 1):
        if is_prime[p]:
            is_prime[p * p : N + 1 : p] = False
    for p in np.where(is_prime)[0]:
        mu[p::p] *= -1
        p2 = p * p
        if p2 <= N:
            mu[p2::p2] = 0
    return mu


def divisors(n: int) -> list[int]:
    ds: list[int] = []
    for a in range(1, int(n ** 0.5) + 1):
        if n % a == 0:
            ds.append(a)
            if a * a != n:
                ds.append(n // a)
    ds.sort()
    return ds


def surface_F(N: int) -> np.ndarray:
    """Return Z[r,n-1] = F(n,r), with 0 <= r <= N and 1 <= n <= N."""
    mu = mobius_sieve(N)
    Z = np.zeros((N + 1, N), dtype=int)
    for n in range(1, N + 1):
        ds = divisors(n)
        for r in range(0, N + 1):
            Z[r, n - 1] = sum(mu[n // a] for a in ds if a > r)
    return Z


def make_heatmap() -> None:
    N = 80
    Z = surface_F(N)[1 : N + 1, :]
    # Z has rows indexed by r and columns indexed by n.  Transpose so that
    # the horizontal coordinate is r and the vertical coordinate is n.
    H = Z.T
    fig, ax = plt.subplots(figsize=(13, 8.5))
    im = ax.imshow(
        H,
        origin="lower",
        aspect="auto",
        interpolation="nearest",
        extent=[1, N, 1, N],
        vmin=-1,
        vmax=1,
        cmap="coolwarm",
    )
    ax.set_xlabel("threshold index r")
    ax.set_ylabel("integer n")
    ax.set_title(
        r"Divisibility surface $F(n,r)=\sum_{a\mid n,\ a>r}\mu(n/a)$, "
        r"$1\leq n,r\leq 80$"
    )
    cbar = fig.colorbar(im, ax=ax)
    cbar.set_label(r"$F(n,r)$, clipped to $[-1,1]$")
    ax.set_xticks([1, 10, 20, 40, 60, 80])
    ax.set_yticks([1, 10, 20, 40, 60, 80])
    ax.grid(linewidth=0.8, alpha=0.6)
    fig.tight_layout()
    fig.savefig(Path("mobius_heatmap_N80_en.png"), dpi=180)
    plt.close(fig)


def make_3d() -> None:
    N = 200
    Z = surface_F(N)
    n_values = np.arange(1, N + 1)
    r_values = np.arange(0, N + 1)
    X, Y = np.meshgrid(n_values, r_values)

    fig = plt.figure(figsize=(14, 10))
    ax = fig.add_subplot(111, projection="3d")
    ax.plot_surface(X, Y, Z, rstride=2, cstride=2, linewidth=0, antialiased=True)
    ax.set_xlabel("column index n")
    ax.set_ylabel("omitted rows / threshold r")
    ax.set_zlabel("F(n,r)")
    ax.set_title("3D divisibility surface of truncated Mobius-column partial sums")
    ax.view_init(elev=28, azim=-135)
    fig.savefig("mobius_surface_3d_N200_en.png", dpi=180, bbox_inches="tight")
    plt.close(fig)


if __name__ == "__main__":
    make_heatmap()
    make_3d()
