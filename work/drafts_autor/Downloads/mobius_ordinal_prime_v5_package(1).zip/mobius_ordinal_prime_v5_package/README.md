# Ordinal-prime transform of the Möbius function — reproduction package (v5)

Version 5 is a mathematical and LaTeX audit of the v4 manuscript built from the
supplied package.  It restores section-based equation numbering and labels, and
corrects several domain, boundary, status, and interpretation issues found in
v4.

## Main files

    mobius_ordinal_prime_transform_S_SS_v5.tex   Version 5 source
    mobius_ordinal_prime_transform_S_SS_v5.pdf   compiled manuscript
    code/       analysis and exact-verification scripts
    outputs/    stdout / supplied follow-up measurements
    figures/    figures used by the manuscript

The large regenerated `.npy` arrays are intentionally not shipped; they are
recreated by `code/build_data.py`.

## V5 audit corrections

1. Restored `\numberwithin{equation}{section}` and gave every displayed formula
   an explicit `\label{...}`; every section/subsection and every figure is also
   labelled.
2. Restored the requested `amsart` preamble, T1/UTF-8/Latin Modern fonts,
   theorem environments, TOC depth, and `hyperref` loaded last.
3. Corrected the prime-scale domain: the multiplicative definition of
   `theta(n)` starts at `n=2`, because the v4 reference scale uses `p_0=0` at
   `n=1`.
4. Corrected Proposition on information content: strict monotonicity is asserted
   for `T` at fixed `Q` on the admissible parity class, not for the residuals.
5. Corrected the centering-offset wording: the offset is exactly half/full a
   prime gap (with the `n=1` convention), but no pointwise `asymp log p` claim is
   made.
6. Added the `|M|<=2` boundary cases to the antisymmetric-gap representation and
   corrected the central-gap wording for odd versus even `|M|`.
7. Made the prime-counting integral valid at `a=0` by stating `p_0=0` and
   `pi(t)=0` on `[0,2)`.  Its derivation is explicitly a finite sum, so no
   interchange of infinite sums is involved.
8. Made the `kappa-rho` identity explicitly finite by introducing the maximal
   lag `D(h)`.  The regenerated direct identity agrees to about `2e-15` in
   double precision; the inverse-recovery error and condition number remain
   reported measurements.
9. Corrected the claim that excess kurtosis decreased monotonically; it decreases
   overall but has a small nonmonotone bin-to-bin rise.
10. Tightened the explicit-formula discussion: for a zero `rho=beta+i gamma`,
    the logarithmic-coordinate mode carries the factor
    `exp((beta-1/2)u) exp(i gamma u)`; pure Fourier modes require RH.  The actual
    sampled signal is `M(floor(exp(u))) exp(-u/2)`.
11. Reclassified the Montgomery-Soundararajan comparison correctly as an
    `H log(X/H)` reference scale motivated by weighted prime counts, not as a
    theorem directly about the unweighted `pi(x+H)-pi(x)` counts used in the
    numerical comparison.
12. Made the shared-counter claim precise as a functional statement on ternary
    histories and supplied an explicit pair with the same endpoint `(M,Q)` but
    different shared-counter sums.  The summation-by-parts identity is finite
    and exact.
13. Fixed the epsilon bookkeeping in the RH-transfer proof.
14. Added a manual bibliography with primary/standard references and DOI/arXiv
    identifiers where available.
15. Removed the overstrong final sentence that endpoint determinism by itself
    rules out every possible analytic leverage inequality.

## Reproduction order

    pip install numpy scipy sympy matplotlib
    cd code
    python3 build_data.py
    python3 weights_identity.py
    python3 gap_covariance.py
    python3 distribution_tests.py
    python3 thinned_ks.py
    python3 ratio_law.py
    python3 figures.py
    python3 envelope_origin.py
    python3 v5_exact_extensions.py

Then run `pdflatex` twice on the v5 TeX file from the package root.

## Output provenance

- `outputs/10_v5_exact_extensions.txt` is regenerated from
  `code/v5_exact_extensions.py` and verifies the prime-counting integral and
  the direct finite `kappa-rho` identity.
- `outputs/09_v5_followup_reported.txt` records the follow-up measurements whose
  originating stage-9 script was not present in the supplied ZIP: inverse
  recovery of `rho` from `kappa`, the short-interval variance ratios, and the
  cross-coupling tests.  They are labelled as reported measurements in the
  manuscript rather than presented as regenerated output.

## Compilation audit

The final v5 source compiles with no LaTeX warnings, no undefined references,
no overfull/underfull boxes, and no duplicate labels.  The PDF was rendered and
visually inspected after compilation.
