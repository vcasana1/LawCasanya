# Part 2 of the rvm_midpoint_zeta version 25 repository: previous versions

- `previous_versions/rvm_midpoint_zeta_v15.zip`, `previous_versions/rvm_midpoint_zeta_v16.zip`: complete earlier release archives.
- `previous_versions/v23_manuscript/`: the v23 manuscript (tex, txt, pdf).

The v24 manuscript is in part 2b (`rvm_midpoint_zeta_v25_repository_part2b_v24_manuscript`), kept separate so that
each archive stays below 30 MB.  The current manuscript, code and outputs are in part 1; the changelogs of all
versions are in part 1, `review/`.
