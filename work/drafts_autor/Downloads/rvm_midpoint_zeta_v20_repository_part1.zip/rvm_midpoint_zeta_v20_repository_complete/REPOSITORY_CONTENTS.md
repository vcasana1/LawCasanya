# Repository contents

This package is intentionally self-contained for compilation, numerical reproduction, and archival publication.

## Manuscript
- `rvm_zeta_pi_mertens_v20.tex`
- `rvm_zeta_pi_mertens_v20.txt` (identical copy of the .tex)
- `rvm_zeta_pi_mertens_v20.pdf`

## Figures
All PNG figures referenced by the manuscript are in `figures/`.

## Main reproducibility code
`code/` contains the curated Python reproduction programs `s01` through `s13` and `rvm_common.py`.
The scripts are written in English and use the binary ordinate data in `data/`.

## Raw data
- `data/zeross.bin` and `data/zLamb.bin` are NOT included in v20 (see `data/README.md`); copy them from the v18 package.

## Main generated outputs
`output/` contains CSV, MAT, binary, and console outputs used by the numerical section.

## Route B numerics (since v19)
`code/routeB/` and `output/routeB/`: the programs of Section 17.7 (floating-point candidate certificates of finite sections, Gonek lists, receding horizon), their logs and figures; `output/routeB/RESULTS.txt` describes each file.

## Companion note lemas_B_v4 (since v19)
`supplementary/lemas_B_v4/`: the standalone note incorporated as Section 17 (tex, txt, pdf, figures, build scripts). The v20 corrections to Section 17 (see `review/V20_CHANGELOG.md`) are made in the paper only; the note is not re-issued, and Section 17 of the paper supersedes it. `supplementary/lemas_B_previous/`: versions 1 and 3.

## Downloads snapshot (since v19)
`supplementary/downloads_2026-10-10/`: RVM-related files from the author's Downloads folder (Bounded_Mrvm, zeta_rvm_camino_ordenadas_completo, handoffs, MATLAB snippets, interactive HTML figures, tooltip scripts).

## Supplementary numerical work
`supplementary/post_v17_numerics/` contains the later bounded-section and nested-metric scripts, CSV files, and figures from the continuation of the numerical investigation.
These are supplementary diagnostics and are not silently promoted to proved statements in the paper.

## Recovered Claude/session files
`recovered_claude/` contains locally recovered scripts and outputs associated with the finite-section experiments, plus a SHA256 recovery manifest.
`supplementary/exploracion_ruta_theta_eps/` contains the uploaded theta/epsilon exploration extracted in full, including its output text files.

## Raw MATLAB material
`supplementary/raw_matlab/` preserves the three raw MATLAB snippets supplied in the conversation. They are archival inputs, not the curated publication scripts.

## Original archives
`archives/` keeps the original uploaded theta/epsilon and theta-half experiment ZIPs and the ordinary v17 release snapshot.

## Previous complete releases
`previous_versions/` contains the complete v15 and v16 ZIP packages.

## Review
`review/` contains the changelogs of versions 18, 19 and 20; `review/V20_CHANGELOG.md` lists the twenty audit points applied in v20 with the places changed.

## Build
Run `./build_pdf.sh` or `make pdf` from the repository root.
Run `./run_all_python.sh` for the curated Python numerical suite.

## Integrity
`MANIFEST_SHA256.txt` gives SHA256 hashes of every file except the manifest itself.
