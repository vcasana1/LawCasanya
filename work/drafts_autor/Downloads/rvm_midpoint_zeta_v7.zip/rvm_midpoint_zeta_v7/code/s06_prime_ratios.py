"""Experiment 6: the three ratios li/pi_RVM, pi/li, pi/pi_RVM and the square-root estimate
pi_RVM(x) - li(x) = O(sqrt(x) (log log x)^2 / log x), from the prime counts written by s04_primes.py.

Input: output/s04_prime_counts_x1000_K17061.csv (columns x, pi_exact, pi_RVM, li, ...).
B(x) = sqrt(x) (log log x)^2 / log x is the scale of the square-root estimate."""
import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from rvm_common import Tee, savefig, write_csv, OUT

say = Tee("s06_prime_ratios")
D = np.genfromtxt(os.path.join(OUT, "s04_prime_counts_x1000_K17061.csv"), delimiter=",", names=True)
x, pe, pr, li = D["x"], D["pi_exact"], D["pi_RVM"], D["li"]
say("grid: %d points on [%.0f, %.0f]; pi_RVM from the first 17061 ordinates tau_k (smooth cut)"
    % (x.size, x[0], x[-1]))

sel = x >= 10
r1, r2, r3 = li[sel] / pr[sel], pe[sel] / li[sel], pe[sel] / pr[sel]
xs = x[sel]
say("")
say("ratios at selected x")
say("%8s %12s %12s %12s %12s %12s %12s" % ("x", "pi", "pi_RVM", "li", "li/pi_RVM", "pi/li", "pi/pi_RVM"))
for X in [10, 20, 50, 100, 200, 500, 1000]:
    i = int(np.argmin(np.abs(x - X)))
    say("%8.1f %12.4f %12.4f %12.4f %12.6f %12.6f %12.6f"
        % (x[i], pe[i], pr[i], li[i], li[i] / pr[i], pe[i] / li[i], pe[i] / pr[i]))

s8 = x >= 8
B = np.sqrt(x[s8]) * np.log(np.log(x[s8])) ** 2 / np.log(x[s8])
e_rvm = (pr[s8] - li[s8]) / B
e_pi = (pe[s8] - li[s8]) / B
say("")
say("square-root scale B(x) = sqrt(x) (log log x)^2 / log x on [8, 1000]")
say("max |pi_RVM - li| / B = %.4f   (at x = %.2f)" % (np.max(np.abs(e_rvm)), x[s8][np.argmax(np.abs(e_rvm))]))
say("max |pi - li| / B     = %.4f   (at x = %.2f)" % (np.max(np.abs(e_pi)), x[s8][np.argmax(np.abs(e_pi))]))
for X in [100, 1000]:
    m = x[s8] >= X / 2
    say("max |pi_RVM - li| / B on [%d, 1000] = %.4f" % (X // 2, np.max(np.abs(e_rvm[m]))))

# CSV files: every 10th grid point
write_csv("s06_prime_ratios.csv", ["x", "li_over_pi_RVM", "pi_over_li", "pi_over_pi_RVM"],
          [xs[::10], r1[::10], r2[::10], r3[::10]])
write_csv("s06_square_root_scale.csv", ["x", "pi_RVM_minus_li_over_B", "pi_minus_li_over_B"],
          [x[s8][::10], e_rvm[::10], e_pi[::10]])

# ---- figure (linear axes)
fig, ax = plt.subplots(1, 2, figsize=(12, 4))
ax[0].plot(xs, r3, "k-", lw=0.8, label=r"$\pi(x)/\pi_{\rm RVM}(x)$")
ax[0].plot(xs, r2, "b-", lw=0.8, label=r"$\pi(x)/\mathrm{li}(x)$")
ax[0].plot(xs, r1, "r-", lw=1.4, label=r"$\mathrm{li}(x)/\pi_{\rm RVM}(x)$")
ax[0].axhline(1.0, color="0.5", lw=0.8, ls="--")
ax[0].set_xlabel("x")
ax[0].set_title(r"The three ratios on $[10,1000]$")
ax[0].legend(fontsize=8)
ax[1].plot(x[s8], e_pi, "b-", lw=0.6, label=r"$(\pi-\mathrm{li})/B$")
ax[1].plot(x[s8], e_rvm, "r-", lw=1.4, label=r"$(\pi_{\rm RVM}-\mathrm{li})/B$")
ax[1].axhline(0.0, color="0.5", lw=0.8, ls="--")
ax[1].set_xlabel("x")
ax[1].set_title(r"Square-root scale $B(x)=\sqrt{x}\,(\log\log x)^2/\log x$")
ax[1].legend(fontsize=8)
fig.tight_layout()
savefig(fig, "fig10_prime_ratios.png")
say.close()
