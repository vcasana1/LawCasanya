Raw little-endian float64 arrays (2,001,052 entries each).
zeross.bin: ordinates gamma_k of the nontrivial zeros of the Riemann zeta function, in increasing order.
zLamb.bin:  midpoint RVM ordinates tau_k, N_RVM(tau_k) = k - 1/2, N_RVM(T) = T/(2 pi) log(T/(2 pi e)) + 7/8.
