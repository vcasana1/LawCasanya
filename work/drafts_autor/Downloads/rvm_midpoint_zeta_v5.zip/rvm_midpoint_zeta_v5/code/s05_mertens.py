"""Experiment 5: the Mertens function M, the synthetic Mertens function M_RVM^crit and the
ternary walk M_h with values in {-1,0,+1} on the squarefree support.

Explicit formulas (simple zeros, residues a = 1/(rho zeta'(rho))):
  M_zeta(x) = -2 + 2 Re sum_k a_k x^(rho_k) + trivial terms        (zeros of zeta)
  M_RVM(x)  = -2 + 2 Re sum_k b_k x^(1/2 + i tau_k) + trivial terms (b_k = 1/(rho_k zeta_RVM'(rho_k)))
Ternary walk: mu_h(n) = mu(n)^2 * sign, sign = +1 if M_h(n-1) < target(n) else -1."""
import os
import math
import numpy as np
import mpmath as mp
import scipy.io as sio
from scipy.interpolate import PchipInterpolator
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from rvm_common import (Tee, load_ordinates, Product, logG, clock_inverse, tail_coefficients,
                        theta_rs, mobius_sieve, write_csv, savefig, OUT)

say = Tee("s05_mertens")
gam, tau = load_ordinates()
Nz = gam.size
XMAX = 10 ** 6
K0 = 1000

# ---------------------------------------------------------------- RVM residues
c1, c2, c3 = tail_coefficients(clock_inverse(float(Nz)))
t2 = tau ** 2
zpR = np.zeros(K0, dtype=complex)
for k in range(K0):
    tk = tau[k]
    fac = (t2 - tk ** 2) / (t2 + 0.25)
    fac[k] = 1.0
    q = -0.25 - tk ** 2
    lmod = np.sum(np.log(np.abs(fac))) + c1 * q - c2 * q ** 2 + c3 * q ** 3
    rho = 0.5 + 1j * tk
    lP = np.log(2j * tk / (0.25 + tk ** 2)) + lmod
    zpR[k] = (-1) ** k * np.exp(lP - logG(rho))
ratio = zpR / np.log(tau[:K0] / (2 * np.pi))
PR = Product(tau)
Ts = 1.0e4 * np.array([0.25, 0.5, 1.0])
from rvm_common import zeta_from_product, w_transition
v = np.array([zeta_from_product(PR, 2 + 1j * T)[0] / (1 + w_transition(2 + 1j * T)) for T in Ts])
varpi = np.linalg.solve(np.column_stack([np.ones(3), 1 / Ts, 1 / Ts ** 2]).astype(complex), v)[0].real
sel = np.arange(K0 // 2, K0)
cfit = np.mean((ratio[sel] / varpi - 1) * tau[sel])
say("zeta_RVM'(rho_k) exact for k <= %d; zeta_RVM'(rho_k)/log(tau_k/2pi) at k = %d: %.10f %+.2e i",
    K0, K0, ratio[-1].real, ratio[-1].imag)
say("varpi_RVM = %.10f; fit zeta_RVM'(rho_k) = varpi log(tau_k/2pi)(1 + c/tau_k), c = %.4f %+.4f i",
    varpi, cfit.real, cfit.imag)
zR = varpi * np.log(tau / (2 * np.pi)) * (1 + cfit / tau)
zR[:K0] = zpR
bR = 1.0 / ((0.5 + 1j * tau) * zR)

# ---------------------------------------------------------------- residues of zeta
def rs_Z(t):
    a = np.sqrt(t / (2 * np.pi))
    Nn = np.floor(a).astype(int)
    p = a - Nn
    nmax = Nn.max()
    n = np.arange(1, nmax + 1)
    ph = theta_rs(t)[:, None] - t[:, None] * np.log(n)[None, :]
    mask = n[None, :] <= Nn[:, None]
    Z = 2 * np.sum(np.cos(ph) * mask / np.sqrt(n)[None, :], axis=1)
    cc = np.cos(2 * np.pi * p)
    C0 = np.cos(2 * np.pi * (p ** 2 - p - 1.0 / 16)) / cc
    return Z + (-1.0) ** (Nn - 1) * (t / (2 * np.pi)) ** (-0.25) * C0


mp.mp.dps = 20
KM = 1000
zG = np.zeros(Nz, dtype=complex)
for k in range(KM + 50):
    zG[k] = complex(mp.zeta(mp.mpc(0.5, gam[k]), 1, 1))
h = 1e-5
for i0 in range(KM, Nz, 4000):
    i1 = min(Nz, i0 + 4000)
    t = gam[i0:i1]
    Zp = (rs_Z(t + h) - rs_Z(t - h)) / (2 * h)
    val = -1j * np.exp(-1j * theta_rs(t)) * Zp
    if i0 == KM:
        chk = np.max(np.abs(val[:50] / zG[KM:KM + 50] - 1))
        say("Riemann-Siegel zeta'(rho) versus mpmath at k = %d..%d: max relative difference %.2e",
            KM + 1, KM + 50, chk)
        zG[KM + 50:i1] = val[50:]
    else:
        zG[i0:i1] = val
aG = 1.0 / ((0.5 + 1j * gam) * zG)
S2G = 2 * np.sum(np.abs(aG) ** 2)
S2R = 2 * np.sum(np.abs(bR) ** 2)
say("median |zeta'(rho)| = %.4f;  spectral sums 2 sum|a|^2: zeta %.6f, RVM %.6f", np.median(np.abs(zG)), S2G, S2R)


def trivial_zeta(x, n=6):
    v = np.zeros_like(x)
    for k in range(1, n + 1):
        v += (-1) ** (k - 1) * (2 * np.pi / x) ** (2 * k) / (math.factorial(2 * k) * k * float(mp.zeta(2 * k + 1)))
    return v


def trivial_rvm(x, n=6):
    v = np.zeros_like(x)
    for k in range(1, n + 1):
        s = -2.0 * k
        lP = np.real(PR.logP(s)[0])
        v -= x ** (-2 * k) * (2 * k + 1) * np.pi ** k * 2 * (-1) ** k / (math.factorial(k) * np.exp(lP))
    return v


def explicit_uniform(ords, wts, u):
    """2 Re sqrt(x) sum_k w_k exp(i o_k u) on a uniform u grid (recurrence)."""
    out = np.zeros(u.size)
    st = np.exp(1j * ords * (u[1] - u[0]))
    for j in range(u.size):
        if j % 200 == 0:
            E = np.exp(1j * ords * u[j])
        out[j] = 2 * np.exp(u[j] / 2) * np.real(E @ wts)
        E = E * st
    return out


# ---------------------------------------------------------------- exact M by sieve
mu = mobius_sieve(XMAX)
M = np.cumsum(mu.astype(np.int64))
sqf = mu != 0
say("M(10^6) = %d;  squarefree density Q(10^6)/10^6 = %.6f (6/pi^2 = %.6f)", M[XMAX], sqf[1:].mean(), 6 / np.pi ** 2)

# ---------------------------------------------------------------- explicit formulas on [2, 2000]
u = np.linspace(np.log(2.0), np.log(2000.0), 2500)
xg = np.exp(u)
Mz = -2 + explicit_uniform(gam, aG, u) + trivial_zeta(xg)
Mc = -2 + explicit_uniform(tau, bR, u) + trivial_rvm(xg)
Mfl = M[np.floor(xg).astype(int)]
off = np.abs(xg - np.round(xg)) > 0.05
say("explicit formula with %d zeros of zeta on [2,2000]: rms(M_zeta - M) = %.4f off integers (|x-n|>0.05)",
    Nz, np.sqrt(np.mean((Mz - Mfl)[off] ** 2)))
write_csv("s05_explicit_formulas.csv", ["x", "M_floor", "M_zeta_explicit", "M_RVM_explicit"], [xg, Mfl, Mz, Mc])

# ---------------------------------------------------------------- integer target for M_RVM^crit
def target_grid(X, div=24):
    x = [1.0]
    while x[-1] < X:
        x.append(min(X, x[-1] + max(1.0, np.floor(np.sqrt(x[-1]) / div))))
    return np.array(x)


def tapered(x, ords, a, C1=2.0, C2=4.0):
    S = np.zeros(x.size, dtype=complex)
    lx = np.log(x)
    i0 = 0
    while i0 < x.size:
        i1 = min(x.size, i0 + 200)
        K = max(1, int(np.searchsorted(ords, C2 * 2 * np.pi * np.sqrt(x[i1 - 1]))))
        uu = ords[None, :K] / (2 * np.pi * np.sqrt(x[i0:i1, None]))
        w = np.where(uu <= C1, 1.0, np.where(uu >= C2, 0.0, np.cos(np.pi / 2 * (uu - C1) / (C2 - C1)) ** 2))
        E = np.exp(1j * lx[i0:i1, None] * ords[None, :K])
        S[i0:i1] = np.sqrt(x[i0:i1]) * np.sum(E * w * a[None, :K], axis=1)
        i0 = i1
    return S


xT = target_grid(float(XMAX))
TT = -2 + 2 * np.real(tapered(xT, tau, bR)) + trivial_rvm(xT)
nn = np.arange(1, XMAX + 1)
T = np.concatenate([[0.0], PchipInterpolator(xT, TT)(nn)])
nchk = np.arange(1000, 100001, 997)
full = -2 + 2 * np.real(np.array([np.sqrt(n) * np.sum(np.exp(1j * np.log(n) * tau) * bR) for n in nchk])) + trivial_rvm(nchk.astype(float))
say("target on %d grid points; at %d integers <= 1e5: max |M_RVM(n) (all zeros) - target(n)| = %.4f",
    xT.size, nchk.size, np.max(np.abs(full - T[nchk])))

# ---------------------------------------------------------------- ternary walk
mu_h = np.zeros(XMAX + 1, dtype=np.int8)
Mh = np.zeros(XMAX + 1)
sgn = np.zeros(XMAX + 1, dtype=np.int8)
cur = 0.0
for n in range(1, XMAX + 1):
    if sqf[n]:
        sgn[n] = 1 if cur < T[n] else -1
        cur += sgn[n]
        mu_h[n] = sgn[n]
    Mh[n] = cur
err = Mh[1:] - T[1:]
say("ternary walk: max |M_h - target| on [1,1e6] = %.4f, on [1e4,1e6] = %.4f", np.max(np.abs(err)), np.max(np.abs(err[9999:])))
dens = lambda a: [np.mean(a[1:] == -1), np.mean(a[1:] == 0), np.mean(a[1:] == 1)]
say("densities of (-1, 0, +1):  mu   %.6f %.6f %.6f", *dens(mu))
say("                           mu_h %.6f %.6f %.6f   (3/pi^2 = %.6f, 1 - 6/pi^2 = %.6f)", *dens(mu_h), 3 / np.pi ** 2, 1 - 6 / np.pi ** 2)
say("sign agreement mu_h = mu on squarefrees: %.6f;  sum mu mu_h / Q = %.6f",
    np.mean(mu_h[sqf] == mu[sqf]), np.sum(mu_h.astype(int) * mu.astype(int)) / sqf[1:].sum())
say("max |M(n)|/sqrt(n) on [10,1e6] = %.4f;  max |M_RVM(n)|/sqrt(n) = %.4f;  max |M_h(n)|/sqrt(n) = %.4f",
    np.max(np.abs(M[10:]) / np.sqrt(nn[9:])), np.max(np.abs(T[10:]) / np.sqrt(nn[9:])), np.max(np.abs(Mh[10:]) / np.sqrt(nn[9:])))
say("\nNUMERICAL EXAMPLE OF THE TERNARY DIVISION (first 40 integers)")
say("%4s %4s %6s %10s %8s %6s %6s %6s %6s" % ("n", "mu", "mu^2", "target", "M_h(n-1)", "sign", "mu_h", "M_h", "M"))
rows = []
for n in range(1, 41):
    say("%4d %4d %6d %10.4f %8d %6s %6d %6d %6d" % (n, mu[n], abs(mu[n]), T[n], Mh[n - 1],
                                                     ("+1" if sgn[n] > 0 else ("-1" if sgn[n] < 0 else "-")),
                                                     mu_h[n], Mh[n], M[n]))
    rows.append([n, mu[n], abs(mu[n]), T[n], Mh[n - 1], sgn[n], mu_h[n], Mh[n], M[n]])
rows = np.array(rows, dtype=float)
write_csv("s05_ternary_example.csv", ["n", "mu", "mu2", "target", "Mh_prev", "sign", "mu_h", "Mh", "M"],
          [rows[:, i] for i in range(rows.shape[1])])

Ns = 10 ** np.arange(3, 7)
say("\nENERGY E_N = (1/N) sum_{n<=N} W(n)^2")
say("%10s %14s %14s %14s" % ("N", "E_N(M)", "E_N(M_RVM)", "E_N(M_h)"))
EN = []
for Nn in Ns:
    EN.append([Nn, np.mean(M[1:Nn + 1].astype(float) ** 2), np.mean(T[1:Nn + 1] ** 2), np.mean(Mh[1:Nn + 1] ** 2)])
    say("%10d %14.4f %14.4f %14.4f" % tuple(EN[-1]))
EN = np.array(EN)
write_csv("s05_energy.csv", ["N", "E_M", "E_MRVM", "E_Mh"], [EN[:, i] for i in range(4)])
dec = np.arange(1, XMAX + 1, 25)
write_csv("s05_walks_decimated.csv", ["n", "M", "M_RVM_target", "M_h"], [dec, M[dec], T[dec], Mh[dec]])
mu_h[1:].astype(np.int8).tofile(os.path.join(OUT, "mu_h_int8_1e6.bin"))

# ---------------------------------------------------------------- figures (linear axes)
fig, ax = plt.subplots(1, 2, figsize=(12, 4))
w = np.arange(1, 2001)
ax[0].step(w, M[w], where="post", color="k", lw=1.0, label=r"$M(n)$")
ax[0].plot(w, T[w], "r-", lw=1.2, label=r"$M_{\rm RVM}^{\rm crit}(n)$")
ax[0].step(w, Mh[w], where="post", color="tab:green", lw=0.8, label=r"$M_h(n)$")
ax[0].set_xlabel("n")
ax[0].set_title(r"Mertens functions on $[1,2000]$, every integer")
ax[0].legend(fontsize=8)
nb = 2000
bw = XMAX // nb
xb = (np.arange(nb) + 0.5) * bw
Mb = M[1:].reshape(nb, bw)
Tb = T[1:].reshape(nb, bw)
ax[1].fill_between(xb, Mb.min(1), Mb.max(1), color="0.6", label=r"$M(n)$ (range per block)")
ax[1].plot(xb, Tb.mean(1), "r-", lw=1.0, label=r"$M_{\rm RVM}^{\rm crit}(n)$")
ax[1].plot(xb, np.sqrt(xb), "k--", lw=0.8, label=r"$\pm\sqrt{n}$")
ax[1].plot(xb, -np.sqrt(xb), "k--", lw=0.8)
ax[1].set_xlabel("n")
ax[1].set_title(r"$[1,10^6]$, blocks of %d integers" % bw)
ax[1].legend(fontsize=8)
fig.tight_layout()
savefig(fig, "fig07_mertens.png")

fig, ax = plt.subplots(1, 2, figsize=(12, 4))
w = np.arange(1, 61)
ax[0].vlines(w - 0.15, 0, mu[w], color="k", lw=2, label=r"$\mu(n)$")
ax[0].vlines(w + 0.15, 0, mu_h[w], color="tab:green", lw=2, label=r"$\mu_h(n)$")
ax[0].axhline(0, color="k", lw=0.5)
ax[0].set_xlabel("n")
ax[0].set_yticks([-1, 0, 1])
ax[0].set_title(r"Ternary values: same zero set $\{\mu(n)=0\}$, signs chosen by tracking")
ax[0].legend(fontsize=8)
w = np.arange(1, 301)
ax[1].step(w, M[w], where="post", color="k", lw=1.0, label=r"$M(n)$")
ax[1].plot(w, T[w], "r.-", lw=0.8, ms=3, label=r"target $M_{\rm RVM}^{\rm crit}(n)$")
ax[1].step(w, Mh[w], where="post", color="tab:green", lw=1.2, label=r"$M_h(n)$")
ax[1].set_xlabel("n")
ax[1].set_title(r"The walk $M_h$ follows $M_{\rm RVM}^{\rm crit}$ within $\pm1$ step")
ax[1].legend(fontsize=8)
fig.tight_layout()
savefig(fig, "fig08_ternary_walk.png")

fig, ax = plt.subplots(1, 2, figsize=(12, 4))
sel = xg <= 300
ax[0].step(np.arange(1, 301), M[1:301], where="post", color="k", lw=1.0, label=r"$M(x)$")
ax[0].plot(xg[sel], Mz[sel], "b-", lw=0.7, label=r"explicit formula, %d zeros of $\zeta$" % Nz)
ax[0].plot(xg[sel], Mc[sel], "r-", lw=1.0, label=r"$M_{\rm RVM}^{\rm crit}(x)$, %d $\tau_k$" % Nz)
ax[0].set_xlabel("x")
ax[0].set_title("Explicit formulas on [2,300]")
ax[0].legend(fontsize=7)
kk = np.arange(5000)
ax[1].plot(gam[kk], np.abs(zG[kk]) / np.log(gam[kk] / (2 * np.pi)), "b.", ms=1.5, label=r"$|\zeta'(\rho_k)|/\log(\gamma_k/2\pi)$")
ax[1].plot(tau[kk], np.abs(zR[kk]) / np.log(tau[kk] / (2 * np.pi)), "r.", ms=1.5, label=r"$|\zeta_{\rm RVM}'(\rho^{\rm RVM}_k)|/\log(\tau_k/2\pi)$")
ax[1].axhline(varpi, color="k", lw=0.8, ls="--", label=r"$\varpi_{\rm RVM}$")
ax[1].set_xlabel("ordinate")
ax[1].set_ylim(0, 4)
ax[1].set_title(r"Derivatives at the zeros, $k\leq5000$")
ax[1].legend(fontsize=7)
fig.tight_layout()
savefig(fig, "fig09_explicit_weights.png")

sio.savemat(os.path.join(OUT, "s05_results.mat"), {"varpi": varpi, "cfit": cfit, "S2G": S2G, "S2R": S2R,
                                                   "energy": EN, "ternary_example": rows,
                                                   "x_explicit": xg, "M_zeta_explicit": Mz, "M_RVM_explicit": Mc})
say.close()
