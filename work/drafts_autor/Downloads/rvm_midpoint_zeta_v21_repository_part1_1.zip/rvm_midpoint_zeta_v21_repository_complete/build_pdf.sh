#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
MAIN="rvm_zeta_pi_mertens_v21.tex"
BASE="${MAIN%.tex}"
# Remove stale cross-reference files so a cloned/unzipped repository always starts cleanly.
rm -f "${BASE}.aux" "${BASE}.toc" "${BASE}.out" "${BASE}.brf" "${BASE}.upa" "${BASE}.upb" "${BASE}.log"
for pass in 1 2 3; do
  echo "pdflatex pass ${pass}/3"
  pdflatex -interaction=nonstopmode -halt-on-error "$MAIN"
done
echo "Built: ${BASE}.pdf"
