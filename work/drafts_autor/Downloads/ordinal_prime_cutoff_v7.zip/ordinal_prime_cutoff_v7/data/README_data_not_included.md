zeross.bin and zLamb.bin are not included (2 x 16 MB).
Regenerate them from Odlyzko's table zeros6 with code/make_inputs_v7.py (see README.md).
