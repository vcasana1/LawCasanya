# Projective Transverse Geometry of the Violet Fibre - Version 2

This archive is a deliberately narrow continuation of the orthogonal-cubic projective line.
It does not carry the older general Violet material unless it is used directly by the present argument.

## Principal manuscript

- `manuscript/VIOLET_PROJECTIVE_TRANSVERSE_GEOMETRY_v2.tex`
- `manuscript/VIOLET_PROJECTIVE_TRANSVERSE_GEOMETRY_v2.pdf`

The manuscript uses `amsart`, contains a table of contents, and places the complete MATLAB sources after the bibliography.
The previous provenance chapter has been removed. The earlier project branding is also removed from the manuscript and retained scripts.

## Numerical material retained

- `scripts/VIOLET_TRANSVERSE_QUOTIENT_RIGIDITY_AUDIT.m`
- `scripts/VIOLET_TRANSVERSE_PROJECTIVE_FLOW_AUDIT.m`
- `scripts/VIOLET_TRANSVERSE_REFLECTION_POLYA_AUDIT.m`
- `data/zeross.bin`
- `outputs/quotient_rigidity_console.txt`
- `outputs/projective_flow_console.txt`
- `outputs/pointwise_curvature_reported.txt`

The first two MATLAB scripts are cleaned/renamed copies of the exact computations underlying the retained quotient and differential results; only labels, variable names, and output names were changed. The third script is new in Version 2 and reconstructs the direct mixed-curvature scan while adding reflection-conjugation, corrected adjacent-Chebyshev, and finite Polya-root diagnostics.

The pointwise-curvature values in `outputs/pointwise_curvature_reported.txt` come from the supplied development log. They are presented in the manuscript as finite reported observations. The new reflection/Polya diagnostics are included as executable tests but no result from an unexecuted diagnostic is asserted in the paper.

## Figures

Only the two PNGs that remain directly relevant to this line are included. Their original top plot titles/application chrome are clipped in LaTeX; the plotted data are not modified.

## Deliberate omissions

No legacy Python is included. `zLamb.bin` is omitted because none of the retained MATLAB scripts reads it. Older Violet figures and scripts that do not advance the orthogonal-cubic positivity direction are omitted.
