RVM SUPPLEMENT FOR excursion_area_section_v49
=============================================

Contents are placed at ZIP root level, as requested.

Included:
- MATLAB sources converted to .txt (no .m copies inside the ZIP).
- All RVM-related PNG files that are physically available in the active runtime.
- RVM_FIGURES_3_PER_PAGE.pdf: contact sheet, maximum 3 PNGs per page.
- RVM_FIGURE_CATALOG.csv: filename/dimensions/size inventory.
- MANIFEST_SHA256.txt.

Important availability note
---------------------------
The Library contains zeross.bin and zLamb.bin and several additional Project PNGs from 2026-09-29/30,
but raw-byte materialization for those Project assets was denied by the file provider in this session.
They are therefore NOT silently replaced or fabricated in this ZIP.
No CSV or MAT numerical output file from the referenced MATLAB runs was physically present in the
active runtime. The scripts name such outputs, but this package does not invent them.

The main manuscript files (TEX/TXT/PDF) are supplied separately and are intentionally not duplicated
inside this supplemental ZIP.
