"""
Twist experiment: G_N(alpha) = L* K* D_alpha K L  with D_alpha = diag(e^{i alpha r}).
Since B_N = K_N L_N, G_N(0) = B_N* B_N = G_N.  For alpha != 0 the operator is
Hermitian (D_alpha unitary diagonal => K* D K is Hermitian? no: (K*DK)* = K* D* K,
so we symmetrize: use G(alpha) = (K L)* D_alpha (K L) is NOT Hermitian unless D real.
Correct twisted form: A(alpha) = B* D_alpha B is Hermitian iff D_alpha Hermitian.
Use instead the standard Thouless twist: replace B by B_alpha where the r-th column
picks up phase e^{i alpha r}, i.e. B_alpha = B @ diag(e^{i alpha r}), and
G(alpha) = B_alpha* B_alpha = diag(e^{-i alpha r}) G diag(e^{i alpha r}).
That is a unitary conjugation -> spectrum unchanged.  So the meaningful twist must
act on the ROW index (the n-variable / boundary), not the column index.
We implement the standard boundary twist: G_alpha = B* D_alpha B with
D_alpha = diag(e^{i alpha n}) acting on the n-index, then Hermitize.
"""
import numpy as np

def mobius_sieve(N):
    lp = np.zeros(N+1, dtype=np.int32); mu = np.zeros(N+1, dtype=np.int8); mu[1]=1
    primes=[]
    for n in range(2,N+1):
        if lp[n]==0: lp[n]=n; primes.append(n); mu[n]=-1
        for p in primes:
            m=p*n
            if p>lp[n] or m>N: break
            lp[m]=p; mu[m]=0 if p==lp[n] else -mu[n]
    return mu

def build_BN_fast(N):
    mu = mobius_sieve(N)
    V = np.zeros((N-1,N-1))
    for r in range(1,N):
        m=np.arange(r,N+1,r); m=m[m>=2]
        V[m-2,r-1]=mu[m//r]
    return -np.cumsum(V,axis=1)

N = 1000
B = build_BN_fast(N)
n_idx = np.arange(2, N+1)          # row variable

print("alpha/pi   lambda_1/N^2   lambda_2/N^2   lambda_3/N^2   Tr/N^2   min_eig")
for frac in [0.0, 0.25, 0.5, 1.0]:
    alpha = frac*np.pi/N
    D = np.exp(1j*alpha*n_idx)
    Ba = B * D[:, None]            # row-phase twist
    Ga = Ba.conj().T @ Ba          # Hermitian by construction
    lam = np.linalg.eigvalsh(Ga)[::-1]
    print(f"{frac:6.2f}   {lam[0]/N**2:.7f}   {lam[1]/N**2:.7f}   {lam[2]/N**2:.7f}   {np.trace(Ga).real/N**2:.7f}   {lam[-1]:.3e}")
