import numpy as np
from math import gcd

def mobius_sieve(N):
    lp = np.zeros(N + 1, dtype=np.int32)
    mu = np.zeros(N + 1, dtype=np.int8); mu[1] = 1
    primes = []
    for n in range(2, N + 1):
        if lp[n] == 0:
            lp[n] = n; primes.append(n); mu[n] = -1
        for p in primes:
            m = p * n
            if p > lp[n] or m > N: break
            lp[m] = p
            mu[m] = 0 if p == lp[n] else -mu[n]
    return mu

def kernel_matrix(M, Dmax):
    mu = mobius_sieve(Dmax)
    y = (np.arange(M) + 0.5) / M
    g = np.zeros((M, M))
    sq = [d for d in range(1, Dmax+1) if mu[d] != 0]
    for d in sq:
        dy = d*y
        # only y with d*y<1 contribute
        if dy[0] >= 1.0: continue
        for e in sq:
            L = d*e // gcd(d, e)
            coef = float(mu[d])*float(mu[e]) / L
            ez = e*y
            if ez[0] >= 1.0: continue
            term = 1.0 - np.maximum.outer(dy, ez)
            np.clip(term, 0.0, None, out=term)
            g += coef * term
    return g, y

M, Dmax = 600, 120
g, y = kernel_matrix(M, Dmax)
K = 0.5*((g/M) + (g/M).T)
ev = np.linalg.eigvalsh(K)[::-1]
print("a_j (M=%d,Dmax=%d):" % (M,Dmax))
for j in range(8): print(f"  a_{j+1} = {ev[j]:.8f}")
print("sum a_j =", ev[ev>1e-12].sum())
np.save('/home/claude/ev_limit.npy', ev)
