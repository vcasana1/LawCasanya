import numpy as np

def mobius_sieve(N):
    lp = np.zeros(N + 1, dtype=np.int32)
    mu = np.zeros(N + 1, dtype=np.int8); mu[1] = 1
    primes = []
    for n in range(2, N + 1):
        if lp[n] == 0:
            lp[n] = n; primes.append(n); mu[n] = -1
        for p in primes:
            m = p * n
            if p > lp[n] or m > N:
                break
            lp[m] = p
            mu[m] = 0 if p == lp[n] else -mu[n]
    return mu

def build_BN_fast(N):
    """F(n,r) = -sum_{d|n, d<=r} mu(n/d), n=2..N, r=1..N-1, via the exact
    vertical-jump identity V(n,r)=1_{r|n} mu(n/r) and a prefix sum over r."""
    mu = mobius_sieve(N)
    V = np.zeros((N - 1, N - 1), dtype=np.float64)
    for r in range(1, N):
        multiples = np.arange(r, N + 1, r)
        multiples = multiples[multiples >= 2]
        rows = multiples - 2
        V[rows, r - 1] = mu[multiples // r]
    return -np.cumsum(V, axis=1)

def oscillator_diagnostics(N):
    B = build_BN_fast(N)
    G = B.T @ B
    vals, vecs = np.linalg.eigh(G)
    omega = np.sqrt(np.clip(vals, 0, None))
    IPR = np.sum(vecs**4, axis=0)

    w = np.sort(omega)
    raw_spacing = np.diff(w)
    window = 41
    mean_local = np.convolve(raw_spacing, np.ones(window) / window,
                              mode="same")
    mask = mean_local > 1e-10
    s = raw_spacing[mask] / mean_local[mask]
    r = np.minimum(s[:-1], s[1:]) / np.maximum(s[:-1], s[1:])
    r = r[np.isfinite(r)]

    print(N, omega.min(), omega.max(), IPR.mean(), IPR.mean() * N,
          r.mean(), np.sum(raw_spacing < 1e-10))
    return omega, IPR, r

if __name__ == "__main__":
    for N in [2000, 4000]:
        oscillator_diagnostics(N)
