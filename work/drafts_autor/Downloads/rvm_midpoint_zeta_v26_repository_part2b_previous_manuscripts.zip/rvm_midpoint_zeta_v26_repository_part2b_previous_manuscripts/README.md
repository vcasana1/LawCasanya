# Part 2b of the rvm_midpoint_zeta version 26 repository: the v24 and v25 manuscripts

- `previous_versions/v24_manuscript/`: the v24 manuscript (tex, txt, pdf), the text reviewed for version 25.
- `previous_versions/v25_manuscript/`: the v25 manuscript (tex, txt, pdf), the base of version 26.

The current manuscript, code and outputs are in part 1; the changelogs of all versions are in part 1, `review/`.
