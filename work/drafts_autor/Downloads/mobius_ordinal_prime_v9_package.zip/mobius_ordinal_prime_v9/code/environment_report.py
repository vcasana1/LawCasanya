"""Record software versions used by the reproducible numerical pipeline."""
import sys
import numpy, scipy, sympy, matplotlib
print('python', sys.version.replace('\n',' '))
print('numpy', numpy.__version__)
print('scipy', scipy.__version__)
print('sympy', sympy.__version__)
print('matplotlib', matplotlib.__version__)
