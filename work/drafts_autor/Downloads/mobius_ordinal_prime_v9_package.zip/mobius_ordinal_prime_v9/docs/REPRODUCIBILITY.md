# Reproducibility status

The Version 9 numerical pipeline was rerun in Python. Earlier follow-up values for which no reproducible source script was available were recomputed, and the manuscript was updated to the regenerated outputs when protocols differed.

The exact checks include the closed form for `SS`, the antisymmetric prime-gap identity, the quadratic parallelogram identity, the level-counting and hyperbolic-sine generating-function identities, the `H_3` increment identity, root-of-unity prefix identities, cut-kernel collapse, first active-lifetime moment, multicut convexity, random-weight active-block identity, character energies modulo 4, 5, and 8, universal ordinal-prime coding, square-root recovery of `Q` and `M`, corrected self-dynamics fibres, the prime-index map, and the length-two collision criterion in the original integer coordinate.

Measured finite-range laws remain labelled as measurements in the manuscript. They are not promoted to asymptotic theorems.
