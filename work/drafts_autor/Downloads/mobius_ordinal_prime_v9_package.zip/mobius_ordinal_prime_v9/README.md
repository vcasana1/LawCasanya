# An Ordinal-Prime Transform of the Mobius Function - Version 9

This package contains the complete Version 9 manuscript, the compiled PDF, all eight figures, all Python source used for the numerical calculations and figure generation, intermediate NumPy arrays, and the corresponding textual outputs.

## Main files

- `mobius_ordinal_prime_transform_S_SS_v9.tex` - canonical LaTeX source.
- `mobius_ordinal_prime_transform_S_SS_v9.pdf` - compiled manuscript.
- `submission/` - submission-ready TeX, PDF, and figure files.
- `code/` - Python source. No MATLAB calculation is used in Version 9.
- `data/` - generated NumPy arrays for the `N=10^6` audit.
- `outputs/` - textual output from every numerical stage and the final LaTeX compilation passes.
- `figures/` - all manuscript PNG figures, regenerated from Python.
- `docs/` - data, reproduction, and audit notes.
- `checksums/` - SHA-256 manifests.

## Reproduction

Create a Python environment with `requirements.txt`, then run the numerical stages in the order documented in `docs/REPRODUCE.md`. Compile the TeX from the package root with two passes of `pdflatex`.

Version 9 corrects the coordinate distinction in the self-iteration section: `alpha_j,beta_j` are squarefree-clock ordinals, while `A_j=s_{alpha_j}` and `B_j=s_{beta_j}` are the original integer occurrence positions. Accordingly, the exact fibre is `phi^{-1}(p_j)={A_j,B_j}`, and a length-two collision of `SS` is equivalent to `|Delta_j|=1`, not `|d_j|=1`.
