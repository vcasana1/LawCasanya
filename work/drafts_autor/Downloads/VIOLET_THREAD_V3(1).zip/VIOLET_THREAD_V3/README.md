# VIOLET_THREAD_V3

Main manuscript:
- manuscript/VIOLET_THREAD_V3.tex
- manuscript/VIOLET_THREAD_V3.pdf

Reproducibility:
- scripts/VIOLET_THREAD_V2_ANALYSIS.py
- scripts/VIOLET_THREAD_V3_ADDITIONAL_GEOMETRY.py

Data:
- data/zeross.bin : 2,001,052 IEEE-754 doubles
- data/zLamb.bin  : 2,001,052 IEEE-754 doubles

Figures:
- 20 PNG figures in figures/

Outputs:
- full-data RVM/phase audit
- recomputed first-49 Euclidean arc metrics
- first-49 eccentric-lobe metrics
- generated TeX tables

All manuscript prose is in English.
