#!/usr/bin/env python3
"""
Additional geometry figures for Version 3 of the Violet Thread manuscript.

Inputs:
  data/zeross.bin
  data/zLamb.bin
  outputs/first_49_eccentric_lobe_metrics.csv
  outputs/first_49_arc_metrics_recomputed.csv

Outputs:
  figures/fig16_zeta_rvm_overlay_3d.png
  figures/fig17_single_lobe_phase_geometry.png
  figures/fig18_quarter_turn_vector_field.png
  figures/fig19_eccentricity_phase_law.png
  figures/fig20_tangent_circle_identity.png
"""
from pathlib import Path
import numpy as np
import pandas as pd
import mpmath as mp
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
gamma = np.fromfile(ROOT/"data"/"zeross.bin", dtype=np.float64)
tau = np.fromfile(ROOT/"data"/"zLamb.bin", dtype=np.float64)
lobes = pd.read_csv(ROOT/"outputs"/"first_49_eccentric_lobe_metrics.csv")
mp.mp.dps = 24

def theta(t):
    return float(mp.siegeltheta(float(t)))

def zeta_line(t):
    return complex(mp.zeta(0.5 + 1j*float(t)))

def theta0(t):
    t = np.asarray(t, dtype=np.complex128)
    return 0.5*t*np.log(t/(2*np.pi*np.e)) - np.pi/8

# Overlay
tz = np.linspace(float(gamma[0]), float(gamma[49]), 2600)
wz = np.array([zeta_line(x) for x in tz])
tr = np.linspace(float(tau[0]), float(tau[49]), 2600)
th0 = theta0(tr).real
wr = np.cos(th0)*np.exp(-1j*th0)
fig = plt.figure(figsize=(12, 7.5))
ax = fig.add_subplot(111, projection="3d")
ax.plot(tz, wz.real, wz.imag, lw=1.05, label="zeta thread")
ax.plot(tr, wr.real, wr.imag, lw=1.15, label="RVM tangent-circle skeleton")
ax.scatter(gamma[:50], np.zeros(50), np.zeros(50), s=12)
ax.scatter(tau[:50], np.zeros(50), np.zeros(50), s=12)
ax.set_xlabel(r"$t$")
ax.set_ylabel("real part")
ax.set_zlabel("imaginary part")
ax.set_title("Actual zeta lobes and the RVM/Lambert tangent-circle skeleton")
ax.view_init(elev=21, azim=-62)
ax.legend(fontsize=8)
fig.tight_layout()
fig.savefig(ROOT/"figures"/"fig16_zeta_rvm_overlay_3d.png", dpi=220, bbox_inches="tight")
plt.close(fig)

# Representative lobe
n = 8
a, b = float(gamma[n-1]), float(gamma[n])
th_a, th_b = theta(a), theta(b)
Omega = th_b-th_a
q = np.linspace(0, 1, 601)
tdense = np.linspace(a, b, 2601)
thdense = np.array([theta(x) for x in tdense])
tq = np.interp(th_a + q*Omega, thdense, tdense)
w = np.array([zeta_line(x) for x in tq])
thq = np.array([theta(x) for x in tq])
Zq = np.real(w*np.exp(1j*thq))
eps = np.sign(Zq[len(Zq)//2]) or 1.0
what = eps*np.exp(1j*th_a)*w
A = np.max(np.abs(what))
model = A*np.sin(np.pi*q)*np.exp(-1j*Omega*q)
C = np.trapezoid(what, q)

fig, ax = plt.subplots(figsize=(8,8))
ax.plot(what.real/A, what.imag/A, lw=1.4, label="actual rotated lobe")
ax.plot(model.real/A, model.imag/A, lw=1.2, ls="--", label="one-arch phase model")
ax.scatter([0],[0],s=34,label="zero-axis contact")
ax.scatter([C.real/A],[C.imag/A],s=34,label="phase centroid")
ax.set_aspect("equal", adjustable="datalim")
ax.set_xlabel("normalized rotated real part")
ax.set_ylabel("normalized rotated imaginary part")
ax.set_title(f"Lobe {n}: eccentric geometry in uniform phase coordinate")
ax.grid(True, alpha=0.2)
ax.legend(fontsize=8)
fig.tight_layout()
fig.savefig(ROOT/"figures"/"fig17_single_lobe_phase_geometry.png", dpi=220, bbox_inches="tight")
plt.close(fig)

# Quarter-turn vectors
dw = np.gradient(what, tq)
sel = np.linspace(25, len(q)-26, 11, dtype=int)
scale = 0.16*A/np.max(np.abs(dw[sel]))
fig, ax = plt.subplots(figsize=(8,8))
ax.plot(what.real/A, what.imag/A, lw=1.2)
for k in sel:
    p = what[k]/A
    tang = dw[k]*scale/A
    norm = -1j*dw[k]*scale/A
    ax.arrow(p.real,p.imag,tang.real,tang.imag,width=0.002,head_width=0.025,length_includes_head=True)
    ax.arrow(p.real,p.imag,norm.real,norm.imag,width=0.002,head_width=0.025,length_includes_head=True)
ax.scatter([0],[0],s=30)
ax.set_aspect("equal", adjustable="datalim")
ax.set_xlabel("normalized rotated real part")
ax.set_ylabel("normalized rotated imaginary part")
ax.set_title("Longitudinal tangent and exact 90-degree transverse direction")
ax.grid(True, alpha=0.2)
fig.tight_layout()
fig.savefig(ROOT/"figures"/"fig18_quarter_turn_vector_field.png", dpi=220, bbox_inches="tight")
plt.close(fig)

# Eccentricity law
s = lobes["s_n"].to_numpy()
Ea = lobes["E_n_2absC_over_A"].to_numpy()
Ep = lobes["E_n_arch_prediction"].to_numpy()
order = np.argsort(s)
fig, ax = plt.subplots(figsize=(8.5,6))
ax.scatter(s,Ea,s=28,label="actual zeta lobes")
ax.plot(s[order],Ep[order],lw=1.25,label="one-arch phase prediction")
ax.set_xlabel(r"$s_n=\Omega_n/\pi$")
ax.set_ylabel(r"$E_n$")
ax.set_title("Lobe eccentricity is controlled by phase sweep")
ax.grid(True, alpha=0.2)
ax.legend()
fig.tight_layout()
fig.savefig(ROOT/"figures"/"fig19_eccentricity_phase_law.png", dpi=220, bbox_inches="tight")
plt.close(fig)

# Exact tangent-circle identity
phi = np.linspace(0,np.pi,600)
fig, ax = plt.subplots(figsize=(8,8))
for shift in [0.0,0.65,1.30]:
    z = np.sin(phi)*np.exp(-1j*(phi+shift))
    ax.plot(z.real,z.imag,lw=1.2)
ax.scatter([0],[0],s=32)
ax.set_aspect("equal", adjustable="box")
ax.set_xlabel("real part")
ax.set_ylabel("imaginary part")
ax.set_title("The unit-sweep arch is an eccentric circle tangent to the origin")
ax.grid(True, alpha=0.2)
fig.tight_layout()
fig.savefig(ROOT/"figures"/"fig20_tangent_circle_identity.png", dpi=220, bbox_inches="tight")
plt.close(fig)
