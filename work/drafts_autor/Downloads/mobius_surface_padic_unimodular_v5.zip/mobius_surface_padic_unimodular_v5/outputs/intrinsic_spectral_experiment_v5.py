# Reproducible spectral experiment for the v5 surface operator.
# Requires numpy, scipy and mpmath.  No zeta-zero data enter the operator.
# mpmath.zetazero is called only after all spectra and branch matches are computed.

import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import eigsh
from scipy.optimize import linear_sum_assignment
from mpmath import zetazero


def mobius_sieve(N):
    lp = np.zeros(N + 1, dtype=np.int32)
    mu = np.zeros(N + 1, dtype=np.int8)
    mu[1] = 1
    primes = []
    for n in range(2, N + 1):
        if lp[n] == 0:
            lp[n] = n
            primes.append(n)
            mu[n] = -1
        for p in primes:
            m = p * n
            if p > lp[n] or m > N:
                break
            lp[m] = p
            mu[m] = 0 if p == lp[n] else -mu[n]
    return mu


def build_surface_dirac(N):
    """Build D_N=(A_N-A_N^*)/(2i), A_N=K_N B_N^{-1}."""
    mu = mobius_sieve(N)

    # K_{n,a}=1_{a|n} mu(n/a), with integers n,a in {2,...,N}.
    kr, kc, kv = [], [], []
    for q in range(1, N + 1):
        mq = int(mu[q])
        amax = N // q
        if mq == 0 or amax < 2:
            continue
        a = np.arange(2, amax + 1, dtype=np.int32)
        n = q * a
        kr.extend((n - 2).tolist())
        kc.extend((a - 2).tolist())
        kv.extend([mq] * len(a))
    K = coo_matrix(
        (np.asarray(kv, dtype=float), (kr, kc)),
        shape=(N - 1, N - 1),
    ).tocsr()

    # (B_N^{-1})_{r,m}=1_{m|r+1}-1_{m|r};
    # matrix row r is stored at index r-1 and integer m at m-2.
    br, bc, bv = [], [], []
    for m in range(2, N + 1):
        v = np.arange(m, N + 1, m, dtype=np.int32)
        br.extend((v - 2).tolist())
        bc.extend([m - 2] * len(v))
        bv.extend([1.0] * len(v))

        v = np.arange(m, N, m, dtype=np.int32)
        br.extend((v - 1).tolist())
        bc.extend([m - 2] * len(v))
        bv.extend([-1.0] * len(v))

    Binv = coo_matrix(
        (np.asarray(bv, dtype=float), (br, bc)),
        shape=(N - 1, N - 1),
    ).tocsr()

    A = K @ Binv
    S = 0.5 * (A - A.T)
    return (-1j) * S.astype(np.complex128)


def edge_spectrum(N, k=25):
    D = build_surface_dirac(N)
    vals, vecs = eigsh(
        D, k=k, which="LA", ncv=max(4 * k + 20, 120),
        tol=1e-10, maxiter=20000,
    )
    order = np.argsort(vals)[::-1]
    vals = vals[order]
    vecs = vecs[:, order]
    residual = np.linalg.norm(D @ vecs - vecs * vals, axis=0)
    if residual.max() > 1e-8:
        raise RuntimeError("ARPACK residual too large")
    return vals, vecs, residual


def match_branches(vecs_N, vecs_2N):
    """Maximum-weight overlap matching under zero-extension N -> 2N."""
    old_block = vecs_2N[:vecs_N.shape[0], :]
    overlap = np.abs(vecs_N.conj().T @ old_block) ** 2
    mass = np.sum(np.abs(old_block) ** 2, axis=0)
    alignment = overlap / mass[None, :]
    rows, cols = linear_sum_assignment(-overlap)
    mapping = np.full(vecs_N.shape[1], -1, dtype=int)
    mapping[rows] = cols
    return mapping, overlap, alignment


def spectral_differences(x):
    d2 = np.full_like(x, np.nan, dtype=float)
    d4 = np.full_like(x, np.nan, dtype=float)
    d2[1:-1] = x[2:] - 2.0 * x[1:-1] + x[:-2]
    d4[2:-2] = (
        x[4:] - 4.0*x[3:-1] + 6.0*x[2:-2]
        - 4.0*x[1:-3] + x[:-4]
    )
    return d2, d4



def branch_difference_matrices(k):
    """
    Finite Dirichlet-boundary representatives of Delta_sp^2 and Delta_sp^4.
    The centered interior stencil is exact; boundary rows are a diagnostic
    choice and are not asserted to be the infinite-operator boundary law.
    """
    L2 = np.zeros((k, k), dtype=float)
    for j in range(k):
        L2[j, j] = -2.0
        if j > 0:
            L2[j, j - 1] = 1.0
        if j + 1 < k:
            L2[j, j + 1] = 1.0
    L4 = L2 @ L2
    return L2, L4


def hp_fourth_order_test_operator(x):
    """
    Finite self-adjoint test operator corresponding to Eq. (HP candidate).
    It is NOT assumed that its eigenvalues equal the componentwise predictor.
    """
    k = len(x)
    L2, L4 = branch_difference_matrices(k)
    X = np.diag(np.asarray(x, dtype=float))
    I = np.eye(k)
    H4 = (
        2.0*np.pi*(X - I)
        + np.pi*(L2 @ X + X @ L2)
        + (2.0/np.pi)*(L4 @ X + X @ L4)
    )
    return H4

def main():
    Ns = [8192, 16384, 32768, 65536, 131072]
    k = 25
    spectra = {}

    # No zeta zeros are used in this loop.
    for N in Ns:
        vals, vecs, residual = edge_spectrum(N, k=k)
        spectra[N] = (vals, vecs)
        print(
            N,
            vals[0],
            vals[0] / np.sqrt(N * np.log(N)),
            residual.max(),
        )

    # Track identities from the N=8192 branches.
    branch_index = {Ns[0]: np.arange(k)}
    for N, M in zip(Ns[:-1], Ns[1:]):
        valsN, vecsN = spectra[N]
        valsM, vecsM = spectra[M]
        mapping, overlap, alignment = match_branches(vecsN, vecsM)
        branch_index[M] = np.array([
            mapping[i] for i in branch_index[N]
        ])
        print("match", N, M)
        for b in range(10):
            i = branch_index[N][b]
            j = mapping[i]
            print(
                b + 1, i + 1, j + 1,
                overlap[i, j], alignment[i, j]
            )

    # Only now are known zeta ordinates loaded as target data.
    gamma = np.array([
        float(zetazero(j).imag) for j in range(1, k + 1)
    ])

    N = Ns[-1]
    vals = spectra[N][0]
    lam = np.array([
        vals[branch_index[N][b]] for b in range(k)
    ])
    x = np.sqrt(N * np.log(N)) / lam
    d2, d4 = spectral_differences(x)

    pred0 = 2.0 * np.pi * (x - 1.0)
    pred = pred0.copy()
    pred[2:-2] = (
        pred0[2:-2]
        + 2.0*np.pi*d2[2:-2]
        + (4.0/np.pi)*d4[2:-2]
    )

    interior = np.arange(2, k - 2)
    rmse0 = np.sqrt(np.mean((pred0[interior] - gamma[interior])**2))
    rmse = np.sqrt(np.mean((pred[interior] - gamma[interior])**2))
    mae = np.mean(np.abs(pred[interior] - gamma[interior]))
    print("base interior RMSE", rmse0)
    print("corrected interior RMSE", rmse)
    print("corrected interior MAE", mae)


    # v5 Hilbert--Polya diagnostic: a self-adjoint operator suggested by
    # the fourth-order branch transform.  This is a falsifiable candidate;
    # the componentwise predictor above is NOT assumed to be its spectrum.
    H4 = hp_fourth_order_test_operator(x)
    hp_eigs = np.linalg.eigvalsh(H4)
    print("H4 Hermitian defect", np.linalg.norm(H4 - H4.T))
    print("H4 eigenvalue range", hp_eigs[0], hp_eigs[-1])

    print("j branch lambda x predicted gamma error")
    for j in range(k):
        print(
            j + 1,
            branch_index[N][j] + 1,
            lam[j], x[j], pred[j], gamma[j], pred[j] - gamma[j]
        )


if __name__ == "__main__":
    main()
