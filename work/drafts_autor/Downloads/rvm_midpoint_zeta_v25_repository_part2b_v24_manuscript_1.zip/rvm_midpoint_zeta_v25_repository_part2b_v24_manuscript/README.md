# Part 2b of the rvm_midpoint_zeta version 25 repository: the v24 manuscript

- `previous_versions/v24_manuscript/`: the v24 manuscript (tex, txt, pdf), the text reviewed for version 25.

The current manuscript, code and outputs are in part 1.
