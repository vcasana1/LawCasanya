# Raw ordinate data

The two raw arrays used by `code/s01`--`s13` are NOT included in the v19 package (they are 16 MB each and unchanged since v18):

- `zeross.bin`: ordinates gamma_k of the nontrivial zeros of the Riemann zeta function.
- `zLamb.bin`: midpoint RVM ordinates tau_k satisfying N_RVM(tau_k) = k - 1/2.

Both are little-endian IEEE float64 arrays with 2,001,052 entries each, sorted by ordinate
(gamma_1 = 14.134725142..., tau_1 = 14.521346953...). Copy them from the v18 complete package
(`rvm_midpoint_zeta_v18_repository_complete.zip`, directory `data/`) into this directory before
rerunning `./run_all_python.sh`. The large output file `output/s05_walks.csv` (29 MB) is likewise
not included. The programs of `code/routeB/` (new in v19) do not need these files: they compute
their own 400 zeta ordinates with mpmath (`zeros.py`) for the diagnostic columns only.
