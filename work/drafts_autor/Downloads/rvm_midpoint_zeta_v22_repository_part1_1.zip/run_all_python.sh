#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/code"
for s in \
  s01_clock_and_family.py \
  s02_transition.py \
  s03_exponential_sums.py \
  s04_primes.py \
  s05_mertens.py \
  s06_prime_ratios.py \
  s07_product_identity.py \
  s08_transport_moments.py \
  s09_clock_defect_split.py \
  s10_clock_to_zeros.py \
  s11_rvm_z1_difference_analysis.py \
  s12_multiscale_jacobian.py \
  s13_nested_bounded_endpoint.py; do
  echo "===== ${s} ====="
  python3 "$s"
done
