# VIOLET_THREAD_V3 - complete project

This archive is self-contained. It is not a patch over V2 and does not require files from any earlier version.

## Main manuscript
- `manuscript/VIOLET_THREAD_V3.tex`
- `manuscript/VIOLET_THREAD_V3.pdf`

## Reproducibility
- `scripts/VIOLET_THREAD_ANALYSIS.py` -- one complete Python program that generates all numerical outputs and all 20 PNG figures.

## Data
- `data/zeross.bin` -- 2,001,052 float64 zeta-zero ordinates
- `data/zLamb.bin` -- 2,001,052 float64 RVM/Lambert ordinates

## Figures
- `figures/fig01_...png` through `figures/fig20_...png`

## Numerical outputs
- `outputs/` contains the CSV summaries and TeX tables used by the manuscript.

Compile the paper from inside `manuscript/` so the relative figure/output paths resolve exactly as written.
