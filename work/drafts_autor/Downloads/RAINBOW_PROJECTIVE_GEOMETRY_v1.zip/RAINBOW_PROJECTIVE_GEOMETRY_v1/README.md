# RAINBOW_PROJECTIVE_GEOMETRY_v1

Focused reproducibility package for the Rainbow/Violet projective-deformation line.

## Principal manuscript

- `manuscript/RAINBOW_PROJECTIVE_GEOMETRY_v1.tex`
- `manuscript/RAINBOW_PROJECTIVE_GEOMETRY_v1.pdf`

## What this paper contains

The manuscript keeps only the Violet material needed to define the fixed lobe coordinate and the exact transverse flow. It then develops:

1. the five-quotient projective rigidity audit;
2. same-lobe Violet identity across Rainbow fibres;
3. exact formulas for the projective defect derivative and intrinsic projective speed;
4. the dense differential audit showing that the sign law is not universal across all quotients;
5. the orthogonal-cubic 240/240 numerical sign result;
6. the exact projected-Gram-kernel reduction;
7. rigorous diagonal/projective-speed positivity and local positivity near Violet;
8. the TP2/log-supermodularity sufficient condition for global positivity;
9. the operator obstruction that prevents orthogonality alone from proving the global sign;
10. the focused total-positivity/reproducing-kernel literature check.

The global statement `M'_n(beta; ORTHOGONAL_CUBIC) >= 0` is stated as a conjecture, not as a proved theorem. The manuscript proves the exact reduction that a complete proof must close.

## Scripts

Current MATLAB:

- `scripts/VIOLET_RAINBOW_QUOTIENT_RIGIDITY_AUDIT.m`
- `scripts/VIOLET_RAINBOW_PROJECTIVE_FLOW_AUDIT.m`

Relevant older Python carried only for the retained baseline figures/coordinate construction:

- `scripts/legacy/VIOLET_THREAD_V2_ANALYSIS.py`
- `scripts/legacy/VIOLET_THREAD_V3_ADDITIONAL_GEOMETRY.py`

The MATLAB scripts resolve `data/zeross.bin` relative to the package root and write generated results into subfolders of `outputs/`.

## Recorded outputs

- `outputs/quotient_rigidity_console.txt`
- `outputs/projective_flow_console.txt`

## Data

- `data/zeross.bin`
- `data/zLamb.bin`

The supplied ordinate files contain the baseline data used by the retained scripts. No zero is searched or transported as beta varies in the Rainbow calculations.

## Build

From `manuscript/`:

```sh
latexmk -pdf RAINBOW_PROJECTIVE_GEOMETRY_v1.tex
```

The TeX source includes the MATLAB and relevant legacy Python scripts as appendices.
