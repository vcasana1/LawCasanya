# The midpoint Riemann-von Mangoldt synthetic zeta system

Paper, code, data and results for

> Rotkin Aynasac, *The midpoint Riemann-von Mangoldt synthetic zeta system: canonical products,
> exponential sums, prime counts, Mertens transforms, and the transformation to zeta_Z1* (4 October 2026).

## What is constructed

* The **midpoint clock** `N_RVM(T) = T/(2 pi) log(T/(2 pi e)) + 7/8` is the smooth part of the
  Riemann-von Mangoldt formula `N(T) = N_RVM(T) + S(T) + O(1/T)`.  Its **midpoint ordinates**
  `tau_k` solve `N_RVM(tau_k) = k - 1/2`; in closed form
  `tau_k = 2 pi (k - 11/8) / W_0((k - 11/8)/e)` with the principal Lambert branch `W_0`.
* `zeta_RVM(s) = prod_k (1 + s(s-1)/(1/4 + tau_k^2)) / G(s)`, `G(s) = s(s-1) Gamma(s/2) pi^(-s/2)`,
  with zeros exactly at `1/2 +- i tau_k`.
* Prime coordinate: `J_RVM` (explicit formula with the `tau_k`), `pi_RVM` (finite Moebius
  inversion), cell masses `c_n = pi_RVM(n) - pi_RVM(n-1)`, real RVM prime levels `pi_RVM(p_j) = j`.
* Mertens coordinate: `M_RVM^crit`, inverse Mellin transform of `1/zeta_RVM`, with
  `M_RVM^crit(x) = L + O(x^(1/2+eps))`, `L = 1/varpi_RVM`, `varpi_RVM = 0.9619415807...`;
  its ternary integer version `M_h` with values of `mu_h` in `{-1, 0, +1}` on the squarefree support.
* The **lambda-family**: ordinates `gamma_k(lambda) = (1 - lambda) gamma_k + lambda tau_k`,
  `zeta_1 = zeta_RVM`, `zeta_0 = zeta_Z1`; all zeros stay on `Re s = 1/2`.  The final step of the
  method is the identity `zeta_Z1 = zeta`; the paper proves that it implies `M(x) = O(x^(1/2+eps))`
  (Step 3) and that it is equivalent to Hamburger's condition (D).  The identity itself is not proved.

## Repository layout

```
rvm_zeta_pi_mertens_v6.tex   the paper (single file); .txt is an identical copy, .pdf the compiled paper
code/      Python programs (run in order s01 ... s05 from this directory)
data/      zeross.bin (2,001,052 ordinates of zeros of zeta), zLamb.bin (2,001,052 midpoint ordinates)
output/    console output (*_console.txt), CSV, MAT and binary results
figures/   PNG figures used by the paper
```

## Data format

Both files in `data/` are raw little-endian IEEE float64 arrays, one ordinate per entry, sorted:

* `zeross.bin`: `gamma_1 = 14.134725142, ..., gamma_2001052 = 1132490.658714`
* `zLamb.bin`: `tau_1 = 14.521346953, ..., tau_2001052 = 1132490.722588`,
  `max |N_RVM(tau_k) - (k - 1/2)| = 7.0e-10`

## Running

```
pip install -r code/requirements.txt
cd code
python3 s01_clock_and_family.py
python3 s02_transition.py
python3 s03_exponential_sums.py
python3 s04_primes.py
python3 s05_mertens.py
```

Total run time is a few minutes on two cores.  To rebuild the paper, run `pdflatex rvm_zeta_pi_mertens_v6.tex` three times in the
top-level directory; the figures are read from `figures/`.  Required LaTeX packages: amsart, amsmath,
mathrsfs, mathtools, longtable, booktabs, graphicx, listings, xcolor, hyperref, bookmark, pdfcomment.

## Main numerical results (from `output/*_console.txt`)

| quantity | value |
|---|---|
| `max_k |tau_k - gamma_k|` over 2,001,052 zeros | 0.9937 |
| `max |zeta_Z1/zeta - 1|`, `sigma = 2, 1.25, 0.75`, `t <= 2000` | 8.7e-10, 1.1e-9, 2.6e-9 |
| `varpi_RVM` (Richardson) | 0.9619415807 |
| `max_N |sum_{k<=N} 2^(i tau_k)|` | 3.57 |
| `|sum_{k<=N} 2^(i gamma_k)|` at `N = 2,001,052` (Landau: 88,342) | 88,301 |
| `pi_RVM(100)`, `pi(100)`, `li(100)` | 26.08, 25, 30.13 |
| `pi_RVM(1000)`, `pi(1000)`, `li(1000)` | 169.98, 168, 177.61 |
| densities of `-1, 0, +1` for `mu_h`, `n <= 10^6` | 0.304003, 0.392074, 0.303923 |
| `max |M_h - M_RVM^crit|`, `10^4 <= n <= 10^6` | 1.65 |
