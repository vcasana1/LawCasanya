# Catalan Mertens v3 reproducibility package

## Contents

- `paper/`: TeX source, Copilot-friendly `.txt` copy, and compiled PDF.
- `code/`: blockwise moment audit, exact selector checks, excursion analysis,
  tau-dephasing illustration, and figure generator.
- `outputs/`: JSON audits, full excursion CSV, and publication PNGs.

The 434 MB `moebius.bin` input is intentionally not redistributed.  Its format
is one signed `int8` value for each `mu(1),...,mu(N)`.

## Reproduction

```bash
python3 code/mertens_moment_audit.py /path/to/moebius.bin \
  --output outputs/moment_audit.json
python3 code/prime_selector_identity_check.py \
  --output outputs/selector_check.json
python3 code/analiza_alturas_excursiones_mertens.py /path/to/moebius.bin \
  --output outputs/mertens_excursiones_alturas.csv
python3 code/tau_dephasing_audit.py \
  --output-png outputs/tau_dephasing.png \
  --output-json outputs/tau_dephasing.json
python3 code/plot_catalan_mertens_outputs.py \
  --moments outputs/moment_audit.json \
  --excursions outputs/mertens_excursiones_alturas.csv \
  --output-dir outputs
```

Python dependencies are listed in `requirements.txt`.  Compile the paper from
the `paper/` directory so its relative `../code` and `../outputs` paths resolve.

The numerical outputs are finite checks and measurements, not asymptotic
evidence or a proof of RH.
