Figures of rvm_zeta_pi_mertens_v25 (PNG, at the root of this archive), with the programs that produce them
and their outputs.

Figure files and programs (run from code/; Route B programs from output/routeB/):
  fig00_clock_zoom.png, fig00b_remainder.png,
  fig01_clock_family.png, fig02_zetaZ1_vs_zeta.png   code/s01_clock_and_family.py
  fig03_transition.png                               code/s02_transition.py
  fig04_exponential_sums.png                         code/s03_exponential_sums.py
  fig05_prime_counts.png, fig06_rvm_primes.png       code/s04_primes.py
  fig07_mertens.png, fig08_ternary_walk.png,
  fig09_explicit_weights.png                         code/s05_mertens.py
  fig10_prime_ratios.png                             code/s06_prime_ratios.py
  fig11_product_identity.png                         code/s07_product_identity.py
  fig14_multiscale_gap.png,
  fig15_fixed_window_degeneracy.png                  code/s12_multiscale_jacobian.py
  fig16_nested_bounded_endpoint.png,
  fig17_bounded_mass_stability.png                   code/s13_nested_bounded_endpoint.py
  fig18_gonek_vs_clock.png, fig19_cert_scaling.png   code/routeB/figs.py (written as output/routeB/fig_gonek_vs_clock.png
                                                     and fig_cert_scaling.png; copied under these names)
  fig20_clock_1000.png ... fig23_mertens_1000.png    code/s15_tables_1000.py and matlab/s15_tables_1000.m
  fig24_walks_3d_1000.png,
  fig25_walks_projection_1000.png                    code/s16_walks_3d_1000.py and matlab/s16_walks_3d_1000.m

code/txt, code/routeB/*_py.txt and matlab/txt hold .txt copies of every program.  code/requirements.txt pins the
software versions (Python 3.13.16, NumPy 2.5.3, SciPy 1.18.1, mpmath 1.4.1, Matplotlib 3.11.2, finufft 2.5.1).

output/: every console output (*_console.txt), CSV, MAT, binary and text result of the programs, and
output/routeB/ for Route B.

Not included: the input data data/zeross.bin and data/zLamb.bin (little-endian float64, 2,001,052 entries each),
and the large output output/s05_walks.csv (29 MB), which code/s05_mertens.py regenerates.
