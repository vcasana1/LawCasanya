# VIOLET_THREAD_V4

Self-contained project.

Principal manuscript:
- manuscript/VIOLET_THREAD_V4.tex
- manuscript/VIOLET_THREAD_V4.pdf

Reproducibility:
- scripts/VIOLET_THREAD_ANALYSIS.py  (single consolidated Python analysis/figure script)

Figures:
- 22 PNG figures in figures/

Data preserved from the prior verified corpus package:
- data/zeross.bin
- data/zLamb.bin

Outputs preserved from the prior verified corpus package:
- outputs/*.csv
- outputs/*.tex

Version 4 adds, analytically and without inspecting the corpus data:
- corrected scattering cocycle sign;
- reciprocal-lobe / scattering normal form;
- integrated reciprocal-curvature identity;
- endpoint-normalized residual J_n;
- rigorous failure of strip analyticity to imply exponential sine coefficients;
- hidden-complex-zero counterexample;
- Chebyshev/Bernstein-ellipse replacement criterion;
- explicit success/failure verdict for the exponential spectral-purity route.
