CATALAN MERTENS V7

Main paper:
  paper/Catalan_Mertens_v7_catalan_energy_hierarchy.tex
  paper/Catalan_Mertens_v7_catalan_energy_hierarchy.pdf

Version 7 preserves the complete introduction, Catalan theory, physical
routes, literature discussion, bibliography, prior figures, numerical
outputs, and Python appendices.

The new central object is the Catalan occupation energy

  E_q(x,H) = sum_{h<=H} |M(x+h)-M(x)|^(2q).

The paper proves the exact dyadic exponent ladder

  E_q(x,x) << x^(q+1+epsilon)
  => M(X) << X^((q+1)/(2q+1)+epsilon).

It also proves the logical equivalence

  [the dyadic bound holds for every fixed q] <=> RH.

This is the precise sense in which non-membership in the exceptional Catalan
class is exactly RH.  A uniform local bound at every shorter H is explicitly
separated: it is stronger than this criterion and is not known to follow
from RH.

Version 7 replaces the absolute sum of all off-diagonal prime-block
correlations by a causal Ramare almost-orthogonal frame inequality together
with diagonal Brownian/Catalan energy.  Higher 2q frame targets are stated as
the open arithmetic selector mechanism.  Their proof is not claimed.

New Version 7 audit:
  code/catalan_energy_ladder_v7.py
  outputs/catalan_energy_ladder_v7.json
  outputs/catalan_energy_ladder_v7.png

The Version 7 plot visualizes exact exponent formulas only; it is not
numerical evidence that the conjectured arithmetic estimates hold.
