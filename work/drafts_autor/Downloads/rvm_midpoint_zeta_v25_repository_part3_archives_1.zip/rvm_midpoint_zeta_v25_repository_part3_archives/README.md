# Part 3 of the rvm_midpoint_zeta version 25 repository: archives

- `archives/exploracion_ruta_theta_eps.zip`, `archives/rvm_theta_half_experiment.zip`: the original uploaded experiment archives.
- `archives/rvm_midpoint_zeta_v17_release_snapshot.zip`: the v17 release snapshot.

The current manuscript, code and outputs are in part 1.
