CATALAN MERTENS V6

Main paper:
  paper/Catalan_Mertens_v6_short_interval_selector.tex
  paper/Catalan_Mertens_v6_short_interval_selector.pdf

Version 6 preserves the full introduction, Catalan theory, physical routes,
bibliography, numerical outputs, and Python appendices.  It adds the exact
characterization

  X not in E_RH  <=>  RH,

where E_RH is the global exceptional Catalan class measured at current
compressed time.  The paper distinguishes this exact criterion from the
strictly stronger local Brownian prefix and moment conditions.  Equivalence
of the criterion to RH is not called circular; the still-open problem is an
independent arithmetic mechanism proving exclusion from E_RH.

Version 6 also adds the Matomaki--Teravainen all-short-interval theorem, its
exact compressed Catalan chord consequence, a rigorous gentle-mountain no-go
construction, the squarefree Ramare prime-colour anti-lift, and causal Ramare
square-function targets.  It distinguishes the critical-scale CRSF
consequence (49/60) from the stronger all-scale consequence (2/3).

New Version 6 audit:
  code/mt_catalan_gentle_mountain_v6.py
  outputs/mt_catalan_gentle_mountain_v6.json
  outputs/mt_catalan_gentle_mountain_v6.png
  code/ramare_prefix_square_function_v6.py
  outputs/ramare_prefix_square_function_v6.json
  outputs/ramare_prefix_square_function_v6.png
