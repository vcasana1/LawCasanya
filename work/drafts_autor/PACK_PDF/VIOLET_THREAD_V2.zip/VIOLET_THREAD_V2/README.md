# VIOLET_THREAD_V2

Reproducible package for the manuscript **Euclidean Lobe Geometry and Transverse Dynamics of the Riemann Zeta Function**.

## Layout

- `manuscript/VIOLET_THREAD_V2.tex` - principal LaTeX manuscript.
- `manuscript/VIOLET_THREAD_V2.pdf` - compiled manuscript.
- `figures/` - all PNG figures used in the manuscript.
- `outputs/` - CSV summaries and appendix tables.
- `scripts/VIOLET_THREAD_V2_ANALYSIS.py` - Python analysis and figure-generation pipeline.
- `data/zeross.bin` - 2,001,052 zeta zero ordinates (`float64`).
- `data/zLamb.bin` - 2,001,052 RVM/Lambert ordinates (`float64`).

## Reproduce

From the project root:

```bash
python scripts/VIOLET_THREAD_V2_ANALYSIS.py
cd manuscript
pdflatex -interaction=nonstopmode VIOLET_THREAD_V2.tex
pdflatex -interaction=nonstopmode VIOLET_THREAD_V2.tex
```

The first 49 Euclidean arc lengths are recomputed directly by quadrature of
`sqrt(1+|zeta'(1/2+it)|^2)`.  The full phase/RVM diagnostics use all 2,001,052 supplied ordinates.
